# V138 — HOÀN THIỆN MODULE KẾ HOẠCH SẢN XUẤT (6 việc còn lại)

Nối tiếp V136 (module) và V136.1 (lệnh cha–con). Bản này làm 6 việc đã liệt kê là "chưa có":

1. **In phiếu lệnh sản xuất A4** + danh sách việc theo ngày dán xưởng
2. **Màn chốt kế hoạch tuần**
3. **Nút "Tạo lệnh sản xuất" ngay trên trang đơn hàng**
4. **Tự dọn lệnh sản xuất khi bộ cửa bị xoá khỏi đơn**
5. **Sửa số lượng lệnh con bằng tay**
6. **Báo cáo OTD / % lỗi / năng suất tổ / lý do trễ**

> ✅ **KHÔNG cần migration mới.** Tất cả bảng cần thiết đã có từ V136/V136.1 (`production_plans`,
> `production_component_orders`, mốc thực tế trong `production_tasks`, `production_logs`).
> **Không sửa bảng đơn hàng** (chỉ THÊM 2 lời gọi dọn dẹp trong route cập nhật/xoá đơn — có bọc try/catch, không làm hỏng việc lưu đơn).

---

## 1. In phiếu lệnh sản xuất A4 + danh sách việc theo ngày

HTML in trực tiếp (không cần Python/ReportLab ⇒ không thêm rủi ro deploy), khổ **A4 dọc**, mỗi bộ/tổ là **một trang**.

| Đường dẫn | Nội dung |
|---|---|
| `/ke-hoach-san-xuat/in` | Màn chọn: ngày + tổ, và nút mở từng mẫu |
| `/ke-hoach-san-xuat/in/phieu-lenh?bo=<id>` | Phiếu lệnh cho **một bộ** (đủ công đoạn) |
| `/ke-hoach-san-xuat/in/phieu-lenh?ngay=YYYY-MM-DD[&to=TO_MAY]` | Phiếu cho mọi bộ có việc trong ngày (lọc theo tổ) |
| `/ke-hoach-san-xuat/in/danh-sach-viec?ngay=YYYY-MM-DD[&to=...]` | Danh sách việc theo ngày — **1 trang/tổ** để dán xưởng |

**Nội dung phiếu lệnh:** công ty + tiêu đề + nhật ký in · Bộ số · mã đơn · khách · sản phẩm · model · hướng mở · màu sơn ·
kích thước · số cánh/bộ · số bộ · hạn giao khách · **ngày xưởng phải xong** · xếp lịch · trạng thái · tiến độ ·
bảng **3 lệnh con** (số lượng + tiến độ + các việc) · bảng **công đoạn** (bước · công đoạn · bộ phận · tổ · SL · ngày KH · ô tích "Xong") ·
ghi chú quy tắc (test cơ khí / vân / màu 11–14) · **3 ô ký** (người lập phiếu · tổ trưởng · quản đốc).

Trong trang in có nút **In / Lưu PDF**; CSS đã đặt `@page A4 portrait`, ẩn thanh công cụ khi in, mỗi phiếu ngắt trang.

## 2. Màn chốt kế hoạch tuần — `/ke-hoach-san-xuat/ke-hoach`

- Chọn **khoảng ngày** (mặc định Thứ 2 → Chủ nhật tuần này) → **Tạo / gom bộ vào kế hoạch**:
  app gom mọi bộ **đã xếp lịch** có ngày bắt đầu trong khoảng → gán vào kế hoạch. **Idempotent** theo mã kế hoạch.
- Mã kế hoạch: `KH-<yyyymmdd>-<yyyymmdd>`. Trạng thái `NHAP` (chưa chốt) / `DA_CHOT` (đã chốt).
- Thẻ kế hoạch hiện: số bộ · tổng cánh · hoàn thành / đang làm / chờ xếp lịch / đã huỷ + **bảng danh sách bộ** trong kế hoạch.
- Nút **Chốt kế hoạch** (ghi tên giám đốc nhà máy) / **Mở lại** / **Xoá**.
- **Mọi thao tác đều ghi `production_logs`** (J1). Chốt **không khoá** việc cập nhật tiến độ (đúng J8: chỉ báo, người xử lý).

## 3. Nút "Tạo lệnh sản xuất" trên trang đơn hàng

Ở trang chi tiết đơn (`/orders/[id]`), cạnh nút *Sửa đơn*:

- Bấm → đưa **mọi bộ cửa của đơn đó** vào kế hoạch (gọi `POST /api/production/sets` với `orderIds`).
- **Chỉ bật khi đơn ĐÃ XÁC NHẬN**; đơn nháp hiện chú thích *"Đơn nháp — chưa có Bộ số"*.
- Báo kết quả ngay trên nút + link **Mở kế hoạch sản xuất**. **Không tạo trùng** khi bấm lại.

## 4. Tự dọn lệnh sản xuất khi bộ cửa bị xoá khỏi đơn

Gọi sau khi **lưu đơn** (`POST/PUT /api/orders/[id]`) và sau khi **xoá đơn** (`DELETE`):

| Tình huống bộ không còn trong đơn | Xử lý |
|---|---|
| **Chưa có tiến độ** (0% và chưa ghi mốc hoàn thành/đã giao) | **XOÁ hẳn** lệnh (kèm công đoạn + lệnh con) |
| **Đã có tiến độ** | **Giữ lại, đánh dấu `HUY`** — không phá công xưởng đã làm |

- Chống nhận nhầm: chỉ xét bộ **có Bộ số**; bộ khớp theo **mã đơn + Bộ số** (nên không bị ảnh hưởng khi sửa đơn làm đổi id dòng hàng).
- Bọc **try/catch**: lỗi ở module sản xuất **không bao giờ** làm hỏng việc lưu đơn.
- Bộ `HUY` **không hiện** trên bảng kế hoạch (đã lọc).
- Ghi log `XOA_VI_BO_KHOI_DON` / `HUY_VI_BO_KHOI_DON`.

## 5. Sửa số lượng lệnh con bằng tay

Ở trang bộ cửa, trên bảng cập nhật tiến độ có khối **"Số lượng lệnh con (sửa tay được)"**:

- 3 ô nhập (Cánh · Khung · Phào) + số **công thức** hiện cạnh để so sánh (đổi khác công thức thì số công thức hiện màu vàng).
- Lưu **chung một nút** với tiến độ → **1 lượt ghi** cho cả lệnh con + công đoạn (bài học V111).
- Ghi log `SUA_SO_LUONG_LENH_CON` (ai sửa, từ giá trị nào sang giá trị nào).

## 6. Báo cáo sản xuất — `/reports/production`

| Khối | Nội dung |
|---|---|
| KPI | **OTD** (%) · bộ giao **trễ** · bộ **quá hạn chưa giao** · **tỷ lệ làm lại** · **thời gian SX trung bình** · thời gian TB/công đoạn · bộ trong kế hoạch + tổng cánh · đang tạm dừng |
| Giao đúng hạn **theo tuần** | mỗi tuần: đã giao · đúng hạn · trễ · tỷ lệ · trễ TB (ngày) |
| Năng suất & tải **theo tổ** | số bộ · số cánh · % tải · công đoạn xong · giờ TB/công đoạn · số lần làm lại |
| **Theo lệnh con** | thanh tiến độ Cánh / Khung / Phào trên toàn bộ bộ trong kế hoạch |
| Thời gian **thực tế vs định mức** từng công đoạn | định mức (danh mục) · thực tế TB · chênh · lượt xong · làm lại |
| **Lý do** trễ / tạm dừng / lỗi | xếp hạng theo số lần, tách "công đoạn" và "bộ" |
| **Tồn thành phẩm > 60 ngày** | bộ đóng gói xong lâu chưa giao (GH9) |
| Danh sách **bộ giao trễ** | bộ số · đơn · khách · hạn giao · hoàn thành SX · đã giao · **số ngày trễ** |

Trang nhắc lại **mốc so sánh gốc** từ khảo sát: trễ ≈ 75% · làm lại ≈ 3% · 1 người ≈ 1,45 m²/ngày · trần ≈ 45–50 cánh/ngày.
Nếu chưa có ai ghi mốc *Bắt đầu/Xong* trên app, trang hiện cảnh báo vàng là **số liệu thời gian chưa có nghĩa** (không hiển thị số 0 giả).

Đã thêm vào **Trung tâm báo cáo** và **menu trái → Báo cáo → Sản xuất (OTD)**.

---

## 7. File thay đổi (V138)

| File | Việc |
|---|---|
| `src/lib/production/service.ts` | + sửa số lượng lệnh con; + `reconcileOrderProductionSets`; + kế hoạch tuần (`createPlan`/`approvePlan`/`reopenPlan`/`deletePlan`/`loadPlans`); + `loadProductionReportData`; lọc bộ `HUY` |
| `src/lib/production/reporting.ts` | **mới** — tính OTD / năng suất / thời gian / lỗi / lý do / tồn |
| `src/lib/production/print.ts` | **mới** — dữ liệu cho mẫu in |
| `src/app/api/production/plans/route.ts` | **mới** — API kế hoạch tuần |
| `src/app/api/production/sets/[id]/route.ts` | nhận `components` (sửa số lượng lệnh con) |
| `src/app/api/orders/[id]/route.ts` | + gọi dọn lệnh sản xuất sau khi lưu / xoá đơn |
| `src/app/ke-hoach-san-xuat/ke-hoach/page.tsx` | **mới** — màn chốt kế hoạch tuần |
| `src/app/ke-hoach-san-xuat/in/{page,phieu-lenh,danh-sach-viec}` | **mới** — 3 trang in |
| `src/app/reports/production/page.tsx` | **mới** — báo cáo sản xuất |
| `src/app/reports/page.tsx`, `src/app/orders/[id]/page.tsx`, `src/app/ke-hoach-san-xuat/page.tsx`, `bo/[id]/page.tsx` | thêm nút/link |
| `src/components/production/{production-plan-board,print-sheets,print-actions,create-production-order-button}.tsx` | **mới** |
| `src/components/production/set-progress-form.tsx` | + khối sửa số lượng lệnh con |
| `src/components/erp-nav.tsx` | + nhóm mục Kế hoạch tuần, Sản xuất (OTD) |
| `src/app/globals.css` | + CSS in A4 dọc `.prod-print-*` |

---

## 8. Kiểm chứng thật (PostgreSQL 14 + app thật + DB test)

| Việc | Kiểm tra | Kết quả |
|---|---|---|
| — | `tsc` 0 lỗi · `eslint` 0 lỗi · `npm run build` 0 lỗi | ✅ |
| 3 | `POST /api/production/sets {orderIds:[1]}` → 2 bộ; gọi tiếp → `skipped: 2` | ✅ đúng đơn, không trùng |
| 5 | Sửa PHAO 4 → **9** → log `SUA_SO_LUONG_LENH_CON PHAO 4→9 bởi Quản đốc`; trả lại 4 | ✅ |
| 2 | Xếp lịch → tạo `KH-20260921-20260927` gán **5 bộ** → **Chốt** (`DA_CHOT`, log `CHOT_KE_HOACH bởi Giám đốc nhà máy`) → **Mở lại** | ✅ |
| 1 | 4 trang in đều HTTP 200; phiếu lệnh bộ 1 có đủ "PHIẾU LỆNH SẢN XUẤT · BỘ SỐ · 3 lệnh con · bước · công đoạn · tổ · ngày KH · ô tích · 3 ô ký" | ✅ |
| 4 | Bỏ bộ **chưa có tiến độ** khỏi đơn → **XOÁ** (`XOA_VI_BO_KHOI_DON`); bỏ bộ **đã có tiến độ** → giữ + **HUY** (`DANG_SX→HUY`) | ✅ cả 2 nhánh |
| 6 | Giao bộ 1 trễ 5 ngày + bộ 3 đúng hạn → **OTD 50% (1/2)** · bộ giao trễ 1 · danh sách trễ ghi **"trễ 5 ngày"** · tỷ lệ làm lại 0,8% (1 công đoạn) | ✅ |
| — | 12 route (kế hoạch, kế hoạch tuần, cấu hình, nhập dở, chi tiết bộ, 3 trang in, báo cáo, trung tâm báo cáo, đơn hàng, tổng quan) | ✅ HTTP 200 |

---

## 9. Còn lại (không chặn dùng)

- **Ép ràng buộc** gom lô sơn ≥ 20 cánh và ≤ 2 lượt đổi khuôn/ngày (hiện là cảnh báo/gợi ý, chưa ép vào thuật toán).
- **Màn nhập chương trình máy cắt từ file** (bảng + tab cấu hình đã có; đang nhập tay).
- **Xuất Excel** cho báo cáo sản xuất (các báo cáo đơn hàng đã có; báo cáo sản xuất mới chỉ xem trên màn).
- **Đăng nhập / phân quyền** (đã biết từ V115: hiện ai có link cũng sửa được; `byName` đang gõ tay).
- **Thông báo** (nhà máy chọn KHÔNG cần — chỉ báo đỏ trong màn).
