# V47 - Thành tiền phụ kiện / chi tiết Bộ cửa

- Thêm cột `Thành tiền` vào dòng Phụ kiện / Chi tiết của Bộ cửa.
- Thành tiền hiển thị theo logic hiện có của hệ thống: ưu tiên `amount` nếu đã có giá trị > 0; nếu không thì tính `KH/Lượng × Đơn giá`.
- Thành tiền tự cập nhật khi KH/Lượng hoặc Đơn giá thay đổi.
- Không thay đổi DB, API, Master Data, cấu hình KH/Lượng hay logic tổng đơn hàng.
