# V133 — Nhiều ảnh cho một bộ cửa

## Yêu cầu

> *"thêm nhiều ảnh"*

Trước V133 mỗi bộ cửa chỉ có **1 ảnh** (`sales_order_items.image_path`).

## Đã làm

### 1. Dữ liệu
- Bảng mới **`sales_order_item_images`**: `order_item_id`, `sort_order`, `image_path`, `image_width`, `image_height` (px, để trống = tự động), `created_at/updated_at`. Khóa ngoại `ON DELETE CASCADE`, unique `(order_item_id, sort_order)`.
- **Backfill**: ảnh đơn cũ tự động thành ảnh số 1 của bộ cửa (chạy 1 lần, không tạo trùng).
- Giới hạn **6 ảnh / bộ cửa** (để file xuất không vỡ bố cục).
- Giữ tương thích: ảnh số 1 luôn được gương vào `sales_order_items.image_path/image_width/image_height` → danh sách đơn, trang chi tiết, bản in, các chỗ dùng ảnh đơn **không phải đổi**.

### 2. Giao diện (thẻ bộ cửa)
- Ô ảnh thành **gallery**: mỗi ảnh một dòng gồm ảnh xem trước, ô `Rộng`/`Cao` (px), nút **Mặc định · Nhỏ · Vừa · Lớn**, nút **Xóa ảnh**, và dòng xác nhận *"Xuất file theo W x H px"* (hoặc cỡ mặc định 56 px).
- Bấm vào ô rồi **Ctrl+V** để dán — dán **nối tiếp** được nhiều ảnh (ô tự giữ focus); hoặc nút **Dán ảnh** (đọc thẳng Clipboard) và **Thêm ảnh / Tải ảnh**.
- Bộ đếm **`3/6 ảnh`**; đủ 6 ảnh thì nút thêm/dán bị khóa kèm nhắc xóa bớt.
- Bảng rút gọn (chế độ xem đầy đủ) hiển thị **ảnh 1 + huy hiệu `+N`** thay vì sửa ảnh — sửa ảnh ở thẻ bộ cửa.

### 3. Xuất file
| Nơi xuất | Kết quả |
|---|---|
| **Excel V2 / V1** | nhúng **tất cả ảnh**, xếp dọc trong ô ẢNH SP (cách nhau 4 px); cột ẢNH SP nới theo ảnh cỡ tay lớn nhất; dòng đầu của bộ nới cao đủ chứa cả cụm |
| **PDF V2** | các ảnh xếp dọc trong ô (bảng con 1 cột), cột ẢNH SP nới theo ảnh cỡ tay lớn nhất (trần 34% bề rộng bảng) |
| **Bản in** | in đủ các ảnh, mỗi ảnh theo cỡ riêng |

- Ảnh **có cỡ tay** giữ đúng cỡ; ảnh **để trống** (tự động) rộng hết bề rộng cột **mặc định** — nhờ vậy cụm ảnh không phình to.
- Trần an toàn: Excel gộp cụm tối đa ~520 px rồi thu nhỏ đều nếu vượt; PDF để ReportLab tự phân trang khi cụm quá cao.

## Kiểm chứng (chạy thật, không đoán)

Đơn test 3 ảnh: `test-a.png` (600×360, đặt 320×192), `test-b.png` (300×400, đặt 120×160), `test-c.png` (480×240, để tự động).

**a) Lưu trữ (DB):** POST đơn → `sales_order_item_images` có **3 dòng** đúng thứ tự 1/2/3 và đúng cỡ (`320×192`, `120×160`, `null`); `sales_order_items.image_path` = ảnh số 1 (gương đúng). Backfill tạo được 2 dòng từ 2 đơn cũ có ảnh đơn.

**b) Excel V2** (soi `xl/drawings/drawing1.xml` + `xl/worksheets/sheet1.xml`):
```
4 ảnh trong file = 1 logo + 3 ảnh sản phẩm
  ảnh 1: 320 x 192 px   (đúng cỡ tay)
  ảnh 2: 120 x 160 px   (đúng cỡ tay)
  ảnh 3:  74 x  37 px   (tự động = bề rộng cột mặc định, không lấy cột đã nới)
cột S (ẢNH SP) = 47 ký tự (~320 px)
dòng 14 cao = 303,75 pt (~405 px) — đủ chứa cả 3 ảnh xếp dọc
neo 3 ảnh trong ô: lệch dọc 4 px, 196 px, 357 px  (không chồng nhau)
```

**c) PDF V2** — dựng PDF thật rồi render 72 dpi và đo từng dải ảnh trong cột ẢNH SP:
```
số ảnh trong cột = 3
  ảnh 1: cao 145 pt = 193 px  (đúng 192 px)
  ảnh 2: cao 121 pt = 161 px  (đúng 160 px)
  ảnh 3: cao  23 pt =  31 px  (tự động, 480x240 → đúng tỉ lệ 2:1)
cột ẢNH SP: 46,4 pt (mặc định) → 246 pt khi có ảnh 320 px
```
→ phát hiện và sửa 1 lỗi khi test: phần **tải trước ảnh** (`_prefetch_product_images`) chưa biết gallery nên PDF không có ảnh; và bề rộng "tự động" từng bị dùng để **kẹp cả ảnh cỡ tay** (làm ảnh 320 px bị co còn 42 pt) — nay tách riêng 2 tham số.

**d) Giao diện** (Chrome thật, trang sửa đơn): gallery hiện **3 ảnh** với 3 nhóm nút riêng, chú thích đúng (`320 x 192`, `120 x 160`, `Cỡ mặc định 56 px…`), bộ đếm `3/6 ảnh`, có nút **Dán ảnh / Thêm ảnh / Xóa ảnh**.

**e) Mã:** `npx tsc --noEmit` → **0 lỗi**; `npx eslint` các file sửa **không phát sinh lỗi mới** (giữ đúng số lỗi cũ); `npx next build` → **PASS**.

## File thay đổi

**Mới:** `prisma/migrations/20260926200000_item_images/migration.sql`

**Sửa:**
- `prisma/schema.prisma` — model `SalesOrderItemImage` + quan hệ `SalesOrderItem.images`.
- `src/lib/order-form.ts` — `OrderImageForm`, `MAX_ORDER_IMAGES = 6`, `OrderItemForm.images`, `OrderItemTextField`.
- `src/lib/order-persistence.ts` — chuẩn hóa danh sách ảnh + gương ảnh số 1.
- `src/app/api/orders/route.ts`, `src/app/api/orders/[id]/route.ts` — ghi bảng ảnh khi tạo/sửa đơn.
- `src/app/orders/[id]/edit/page.tsx` — nạp gallery (đơn cũ tự chuyển thành 1 ảnh).
- `src/components/order-form.tsx` — `ImageGallery` + `ImageGalleryRow` + `ImageGalleryPreview`; `appendItemImage`, `setItemImages`.
- `src/lib/order-output.ts` — `OutputImage`, `group.images`, `groupImages()`, `outputImageManualSize()`.
- `src/lib/excel-image-cell.ts` — `fitProductImageStackInCell()` (xếp dọc nhiều ảnh, trần 520 px, `autoColumnWidth`).
- `src/lib/order-export-v2.ts`, `src/lib/order-export.ts` — nhúng nhiều ảnh; nới cột theo ảnh lớn nhất.
- `src/app/api/orders/[id]/export-v2/route.ts`, `src/app/api/orders/[id]/export/route.ts`, `src/app/orders/[id]/print/page.tsx`, `src/app/orders/[id]/page.tsx` — lấy thêm quan hệ `images`.
- `python/reportlab_order_v2.py` — `_group_image_items`, `_group_image_column_pt`, `_group_image_cell`; prefetch gallery; tách `auto_width_pt`.
- `api/order_pdf_v2.py` — query + gắn `images` vào payload.
- `src/lib/order-input-template.ts` — mẫu Excel: `images: []`.


## V133.1 — sửa lỗi "dán lần đầu bị nhân đôi ảnh"

**Hiện tượng (bạn báo):** dán ảnh lần đầu thì ra **2 ảnh giống nhau**, các lần dán sau bình thường.

**Nguyên nhân (tái hiện được, không phải đoán):** ô ảnh nghe `paste` ở cấp window; khi ảnh trước **còn đang tải lên** (Supabase mất ~1 giây), lần dán thứ hai (giữ Ctrl+V lâu → trình duyệt lặp sự kiện, hoặc dán/bấm nút 2 lần liên tiếp) vẫn được nhận: hàm `handleFile` đọc `images.length`/`canAdd` từ **closure của lần render cũ** (lúc đó còn 0 ảnh) nên vẫn cho thêm → sinh dòng ảnh trùng. Lần dán sau không bị vì lúc đó ảnh đã hiện, người dùng không dán lại nữa.

**Đã sửa** (`src/components/order-form.tsx`):
- Cờ `uploadingRef` bật **đồng bộ** ngay khi bắt đầu tải ảnh → mọi lần dán/bấm nút tiếp theo trong lúc đang tải đều **bị bỏ qua** (không phụ thuộc state `busy` vì state chỉ đổi sau khi re-render).
- Chống trùng theo **nội dung ảnh**: `imageFileKey()` băm nhanh nội dung file (lấy mẫu tối đa ~64KB) + kích thước → cùng một ảnh dán lại trong **1,5 giây** bị bỏ qua. Dùng nội dung vì ảnh từ clipboard luôn tên `clipboard.png` và mỗi lần tạo `File` lại có `lastModified` mới.
- Kiểm tra giới hạn 6 ảnh bằng ref `imagesRef` (bản mới nhất) thay vì closure cũ.
- Áp dụng cho cả gallery (bộ cửa) và ô ảnh đơn.

**Kiểm chứng lại** (Chrome thật + clipboard thật, mạng làm chậm 500ms như Supabase):

| Kịch bản | Trước khi sửa | Sau khi sửa |
|---|---|---|
| Giữ Ctrl+V (6 lần liên tiếp, cùng ảnh) | 2–3 ảnh trùng | **1 ảnh** |
| Dán 2 lần cách 150ms (cùng ảnh) | 3 ảnh (2 ảnh trùng) | **1 ảnh** |
| Bấm nút "Dán ảnh" 2 lần nhanh (cùng ảnh) | 2 ảnh trùng | **1 ảnh** |
| Dán ảnh khác tiếp theo | 1 ảnh | **1 ảnh** (đúng) |
| 4 lần dán ảnh khác nhau | — | **4 ảnh, 0 đường dẫn trùng** |

`npx tsc --noEmit` → 0 lỗi; `eslint` file sửa giữ nguyên số lỗi cũ; `next build` PASS.

> Nếu bạn **cố ý** muốn dán cùng một ảnh 2 lần vào một bộ cửa, chờ ~2 giây rồi dán lại là được.

## Lưu ý

- Tối đa **6 ảnh/bộ cửa**; muốn hơn thì báo mình nâng giới hạn (đổi `MAX_ORDER_IMAGES` + trần cụm ảnh khi xuất).
- Ảnh nhiều + cỡ lớn có thể làm bộ cửa chiếm nhiều dòng trong Excel và có thể đẩy sang trang sau ở PDF — đúng như thiết kế để ảnh không bị bóp méo.
- Đơn cũ (1 ảnh) giữ nguyên hành vi; migration tự chuyển ảnh cũ thành ảnh số 1 nên khi mở lại đơn sẽ thấy ảnh trong gallery.
