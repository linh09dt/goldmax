# V41.32 – Căn chỉnh Thông tin đơn hàng

## Mục tiêu
Sắp xếp lại khối **Thông tin đơn hàng** theo bố cục người dùng gửi, đồng thời căn hàng/cột gọn và đều hơn.

## Bố cục desktop (5 cột)
- Hàng 1: `Thông tin đơn hàng` | `Mã đơn hàng` | `Trạng thái` | `Ngày cập nhật` | ô trống cân layout.
- Hàng 2: `NVKD phụ trách` | `Mã Đại Lý` | `Tên khách hàng` | `Ngày đặt hàng` | `Ngày cần giao hàng`.
- Hàng 3: `Người nhận` | `Số điện thoại` | `Địa chỉ nhận hàng` | `Vùng miền` | `Số Km giao hàng`.
- Hàng 4: `Nhóm` | `Mã biểu mẫu` | `Ngày hiệu lực`.

## Căn chỉnh
- 5 cột đều nhau ở màn hình desktop/laptop từ breakpoint `lg`.
- Khoảng cách ngang 12px, dọc 10px.
- Input/select đồng nhất chiều cao 36px.
- Padding input đồng nhất 10px ngang.
- Label căn đều, cùng line-height và cùng khoảng cách với input.
- Tiêu đề `Thông tin đơn hàng` đặt thành tile cùng chiều cao với một field để thẳng hàng với hàng đầu.
- Responsive: 3 cột tablet, 2 cột màn hình nhỏ, 1 cột mobile.

## Không thay đổi
- Validation bắt buộc V41.24.
- Logic lưu đơn/API/DB.
- Export PDF/Excel.
- Giá, ảnh, phụ kiện và logic bộ cửa.
