# ORDER SET NUMBER AUTO V75

## Yêu cầu

Ở **tab Tạo đơn hàng**, bỏ ô nhập **Bộ số** vì Bộ số sẽ do hệ thống **tính tự động tăng dần**:

- Tình trạng đơn **Nháp** hoặc **Chờ khách hàng xác nhận** → **chưa có Bộ số**.
- Bộ số **chỉ được tạo khi đơn chuyển sang trạng thái Đã xác nhận**.
- Đơn đã xác nhận rồi chuyển tiếp sang **Đã chuyển sản xuất** hoặc **Đã hủy** → **không thay đổi Bộ số**.
- Thêm vào **Cấu hình** một thông số **số bắt đầu áp dụng Bộ số** (vì chưa chốt sẽ bắt đầu từ bộ số mấy).
- Trạng thái Nháp / Chờ khách hàng xác nhận → **không hiện** Bộ số; khi đã sang **Đã xác nhận** / **Đã chuyển sản xuất** thì Bộ số **hiện trên View đơn hàng**, và **View tạo đơn có trường Bộ số với số tạo sẵn**.

## Quy tắc đã chốt

| Trạng thái đơn | Bộ số trong DB | Hiện trên màn Tạo đơn / Chi tiết đơn |
| --- | --- | --- |
| Nháp (NHAP) | Chưa tạo (trống) | Không (ô để trống "—") |
| Chờ khách hàng xác nhận (CHO_XAC_NHAN) | Chưa tạo (trống) | Không (ô để trống "—") |
| **Đã xác nhận (DA_XAC_NHAN)** | **Cấp mới, tăng dần** | **Có** |
| **Đã chuyển sản xuất (CHUYEN_SAN_XUAT)** | Không đổi | **Có** |
| Đã hủy (HUY) | Không đổi (giữ số đã cấp) | Không hiển thị (số vẫn được giữ trong dữ liệu) |

- Số cấp cho một đơn = `max(số lớn nhất đã cấp + 1, số bắt đầu trong cấu hình, số lớn nhất đang có trong dữ liệu + 1, số lớn nhất của chính đơn đó + 1)`.
  Nhờ vậy Bộ số **không bao giờ trùng**, kể cả khi dữ liệu cũ đang có sẵn các bộ số 12xxx nhập từ Excel, và số đã cấp **không bị dùng lại** khi một bộ cửa bị xóa.
- Mỗi bộ cửa của đơn nhận **một bộ số riêng, liên tiếp**. Bộ cửa **Nhân bản** được xóa số để nhận số mới (không dùng lại số của bộ gốc).
- Số đã có sẵn (đơn nhập từ Excel) **được giữ nguyên**, không bị cấp đè.

## Cách làm

### 1. Cấu hình — `Số bắt đầu áp dụng Bộ số`

- `src/lib/calculation-config.ts`: `CalculationConfig` thêm trường `setNumberStart` (mặc định `1`), được chuẩn hóa bằng `positiveInteger` nên luôn ≥ 1. Cấu hình cũ (chưa có trường này) tự nhận giá trị mặc định — không phải migrate dữ liệu.
- `/calculation-config` (Thiết lập chung): thêm ô **Số bắt đầu áp dụng Bộ số** + giải thích cơ chế tự tăng.

### 2. Sinh Bộ số ở server — `src/lib/set-number.ts`

- `SET_NUMBER_STATUSES = [DA_XAC_NHAN, CHUYEN_SAN_XUAT]` (khai báo trong `src/lib/order-form.ts` để dùng chung cho cả server và giao diện).
- `resolveSetNumbers(tx, { status, incoming })`:
  - Trạng thái Nháp / Chờ khách hàng xác nhận / Đã hủy → giữ nguyên số đang có, **không cấp số mới**.
  - Trạng thái Đã xác nhận / Đã chuyển sản xuất → giữ số đã có, cấp số mới cho các bộ cửa chưa có số.
- Bộ đếm `ORDER_SET_NUMBER_COUNTER` lưu trong `system_settings` (bảng đã có sẵn, **không cần migration**).
  - `INSERT ... ON CONFLICT DO NOTHING` + `SELECT ... FOR UPDATE` giữ khóa hàng để hai đơn lưu cùng lúc không nhận cùng một bộ số.
  - Số bắt đầu lấy từ cấu hình tính toán (`ORDER_CALCULATION_CONFIG_V1`).
- Nối vào: `POST /api/orders` (tạo đơn) và `POST/PUT /api/orders/[id]` (cập nhật đơn). Cả hai trả thêm `setNumbers` để giao diện hiện số vừa cấp.

### 3. Giao diện Tạo/Sửa đơn — `src/components/order-form.tsx`

- Ô **Bộ số** không còn nhập tay: thay `CardInput` bằng ô chỉ đọc `CardReadonlyValue`
  (có số → nền xanh nhạt; chưa có số → "—" với chú thích "Bộ số sẽ được tạo tự động khi lưu đơn ở trạng thái Đã xác nhận").
- Chỉ hiện khi đơn ở trạng thái **Đã xác nhận / Đã chuyển sản xuất**; tiêu đề bộ cửa cũng chỉ thêm "· Bộ số …" khi có số.
- Danh sách bộ cửa (legacy grid) đổi ô nhập Bộ số thành ô chỉ đọc.
- Sau khi Lưu, giao diện nạp luôn `setNumbers` trả về nên thấy bộ số ngay, không cần tải lại trang.
- Nhân bản bộ cửa: xóa Bộ số của bản sao để nhận số mới khi lưu.

### 4. View đơn hàng — `src/app/orders/[id]/page.tsx`

- Tiêu đề bộ cửa và cột "BỘ SỐ" của bảng chi tiết chỉ hiện khi đơn ở trạng thái Đã xác nhận / Đã chuyển sản xuất.

## Kiểm chứng

- `npx tsc --noEmit`: 0 lỗi.
- `npx eslint` trên 9 file thay đổi: **8 errors / 13 warnings — đúng bằng bản gốc** (đều là lỗi có sẵn: `no-explicit-any`, `set-state-in-effect`; không phát sinh lỗi mới).
- `npm run build` (Next.js production build): thành công.
- Harness mô phỏng Prisma transaction chạy 18 kịch bản trên `resolveSetNumbers` — **tất cả PASS**:
  - Nháp / Chờ khách hàng xác nhận: chưa cấp số, bộ đếm không đổi.
  - Đã xác nhận: cấp 12000, 12001 → đơn kế tiếp 12002.
  - Giữ số cũ + cấp số mới cho dòng trống.
  - Chuyển sang Đã chuyển sản xuất / Đã hủy: số giữ nguyên, bộ đếm không đổi.
  - Số bắt đầu là sàn; dữ liệu cũ 12500 → cấp 12501.
  - Thêm bộ cửa vào đơn đã có số sẵn (1, 2) → cấp 3, không trùng.
- Không chạy trên database thật (`.env` trỏ Supabase) để tránh ghi dữ liệu ngoài ý muốn — cần kiểm tra lại trên môi trường dev trước khi dùng chính thức.

## File thay đổi

- `src/lib/set-number.ts` (mới)
- `src/lib/calculation-config.ts`
- `src/lib/order-form.ts`
- `src/components/calculation-config.tsx`
- `src/components/order-form.tsx`
- `src/app/api/orders/route.ts`
- `src/app/api/orders/[id]/route.ts`
- `src/app/orders/[id]/page.tsx`

## Không thay đổi

- Không thay đổi schema Prisma, không cần `npm run db:migrate` (dùng lại bảng `system_settings`).
- Không thay đổi `.env`, `DATABASE_URL`, cấu hình Vercel.
- Không thay đổi công thức KH/Lượng, Đơn giá, cước vận chuyển, in PDF/Excel.

## Cách dùng

1. Vào **Cấu hình tính toán** → nhập **Số bắt đầu áp dụng Bộ số** (ví dụ `12000` hoặc `13000`) → **Lưu cấu hình**.
2. Tạo đơn ở trạng thái **Nháp** → ô Bộ số để trống "—".
3. Chuyển trạng thái đơn sang **Đã xác nhận** và Lưu → hệ thống cấp Bộ số ngay và hiện trên View đơn hàng.
4. Chuyển tiếp sang **Đã chuyển sản xuất** hoặc **Đã hủy** → Bộ số không đổi.

> Nếu chưa lưu cấu hình, số bắt đầu mặc định là `1`; hệ thống vẫn tự cấp tiếp trên bộ số lớn nhất đang có trong dữ liệu nên không trùng với các bộ số 12xxx nhập từ Excel.
