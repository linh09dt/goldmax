# V115 — Cần làm gì trước khi mở module Lên kế hoạch sản xuất

Module kế hoạch sản xuất sẽ **đọc trực tiếp** 3 thứ đang có trong dữ liệu: **Bộ số** (`sales_order_items.set_no`),
**KH/Lượng** (`pricing_quantity`) và **hạn giao** (`required_delivery_date`). Nếu 3 thứ đó còn bẩn hoặc nghiệp vụ chưa chốt
thì kế hoạch sẽ sai ngay từ đầu. Vì vậy có **5 việc phải xong trước**.

---

## 1. Năm việc phải xong (theo đúng thứ tự này)

### ☐ 1.1. Đóng nốt các thay đổi đang treo
| Việc | Trạng thái |
|---|---|
| V112 (loại đơn × trạng thái) — code + migration | ✅ đã chạy trên production |
| **V112b/V112c** (hàng thông tin đơn 1 hàng, thu nhỏ SĐT, mở rộng Loại đơn, hết xuống dòng ở chi tiết đơn) | ⏳ **chưa deploy** |
| **V113** (tab Tổng quan dashboard) + **V114** (đặc tả) | ⏳ **chưa deploy** |
| 4 câu hỏi nghiệp vụ còn treo (mục 4 bên dưới) | ⏳ chưa chốt |

→ Nên deploy gộp một lần rồi kiểm tra lại 4 màn: Tạo đơn · Chi tiết đơn · Danh sách đơn · Tổng quan.

### ☐ 1.2. Chốt trạng thái migration (bắt buộc, vì V112 chạy SQL tay)
```bash
npx prisma migrate resolve --applied 20260925120000_order_type_v112
```
Không chạy lệnh này thì lần sau `migrate deploy` / `migrate dev` sẽ thấy **lệch lịch sử (drift)** và có thể đề nghị reset DB — rất nguy hiểm khi đã có dữ liệu thật.
**Nguyên tắc từ nay:** `migrate DB trước → deploy code sau` (bài học V112: code đi trước DB làm 500 toàn app, lỗi Prisma `P2022`).

### ☐ 1.3. Dọn dữ liệu (chạy 10 câu SQL ở mục 3)
Ngưỡng đề xuất: các ô **phải bằng 0** là 1, 2, 6, 10. Ô 3, 4, 5 phải rà rồi sửa/xác nhận.

### ☐ 1.4. Chốt nghiệp vụ sản xuất (10 câu ở mục 4)
Không chốt thì không thiết kế được bảng, mà thiết kế sai thì phải làm lại migration + nhập lại kế hoạch.

### ☐ 1.5. Chốt 3 quyết định kỹ thuật
1. **Đơn vị lên kế hoạch = 1 BỘ CỬA** (không phải cả đơn) — vì Bộ số đã định danh bộ và xưởng làm theo bộ. (Đề xuất, xem mục 5.)
2. **Thêm vòng đời sản xuất cho từng bộ**: Chờ sản xuất → Đang sản xuất → Hoàn thành → Đã giao (+ Tạm dừng). Hiện đơn chỉ có 2 trạng thái (nháp/đã xác nhận) nên **không biết bộ nào đã làm xong**.
3. **Phân quyền**: hiện **chưa có đăng nhập** — ai có link cũng sửa được kế hoạch. Nếu để nhiều người (xưởng, sale, kế toán) cùng dùng thì nên làm **đăng nhập + vai trò** *trước hoặc cùng lúc* với module kế hoạch.

---

## 2. Vì sao 5 việc trên chặn module kế hoạch

| Module kế hoạch cần | Lấy từ đâu | Rủi ro nếu chưa dọn |
|---|---|---|
| Định danh từng bộ để xếp lịch | `set_no` | Bộ số trùng → xếp 1 bộ 2 lần, hoặc bỏ sót |
| Khối lượng/tải | `pricing_quantity` | KH/Lượng = 0 → không tính được tải, kế hoạch thiếu |
| Ngày cần xong | `required_delivery_date` | Thiếu ngày → không xếp được thứ tự ưu tiên |
| Biết bộ nào đã xong | *chưa có* | Kế hoạch tuần sau vẫn ôm việc đã làm xong |
| Biết đơn nào phải xếp lịch | `order_type` + `status` | Đơn nháp/đơn mẫu lọt vào kế hoạch sản xuất |

---

## 3. Bộ SQL kiểm tra dữ liệu (copy chạy được, đã thử trên Postgres 14)

```sql
-- 1) Đơn đã xác nhận nhưng dòng hàng THIẾU Bộ số → PHẢI = 0
select count(*) as so_dong from sales_order_items i join sales_orders o on o.id = i.order_id
where o.status = 'DA_XAC_NHAN' and (i.set_no is null or i.set_no = '');

-- 2) Bộ số TRÙNG (cùng 1 bộ số nằm ở nhiều dòng/đơn) → PHẢI = 0
select set_no, count(*) as so_lan from sales_order_items
where set_no ~ '^[0-9]{1,18}$' group by 1 having count(*) > 1 order by 2 desc limit 20;

-- 3) Dòng hàng THIẾU KH/Lượng → rà & sửa
select count(*) as so_dong from sales_order_items where coalesce(pricing_quantity, 0) = 0;

-- 4) Dòng hàng (cửa) THIẾU kích thước cao/rộng → cắt nhôm/kính cần số này
select count(*) as so_dong from sales_order_items
where coalesce(pricing_quantity, 0) > 0 and (height_mm is null or width_mm is null);

-- 5) Dòng hàng THIẾU cả mã hàng lẫn model → không biết sản xuất cái gì
select count(*) as so_dong from sales_order_items
where coalesce(nullif(product_code, ''), nullif(model, '')) is null;

-- 6) Đơn đã xác nhận THIẾU ngày cần giao → PHẢI = 0
select count(*) as so_don from sales_orders where status = 'DA_XAC_NHAN' and required_delivery_date is null;

-- 7) Đơn đã xác nhận ĐÃ QUÁ HẠN → phải đưa vào kế hoạch gấp
select count(*) as so_don, min(required_delivery_date) as som_nhat from sales_orders
where status = 'DA_XAC_NHAN' and required_delivery_date < current_date;

-- 8) TẢI SẢN XUẤT 8 TUẦN TỚI (chính là đầu vào của kế hoạch)
select to_char(date_trunc('week', o.required_delivery_date), 'IYYY-"W"IW') as tuan,
       count(*) as so_bo, round(sum(coalesce(i.pricing_quantity, 0))::numeric, 1) as kh_luong
from sales_order_items i join sales_orders o on o.id = i.order_id
where o.status = 'DA_XAC_NHAN' and o.required_delivery_date >= current_date
  and o.required_delivery_date < current_date + interval '8 weeks'
group by 1 order by 1;

-- 9) TOP MODEL cần sản xuất (8 tuần tới) — để biết cần gom lô nhôm/sơn gì
select coalesce(nullif(i.product_code, ''), i.model) as ma_hang, count(*) as so_bo
from sales_order_items i join sales_orders o on o.id = i.order_id
where o.status = 'DA_XAC_NHAN' and o.required_delivery_date >= current_date
group by 1 order by 2 desc limit 10;

-- 10) Bất thường: đơn NHÁP mà đã có Bộ số, và đơn HUY còn sót → PHẢI = 0 cột đầu
select
  (select count(*) from sales_order_items i join sales_orders o on o.id = i.order_id
     where o.status = 'NHAP' and i.set_no is not null) as nhap_co_bo_so,
  (select count(*) from sales_orders where status = 'HUY') as don_huy;
```

**Kết quả chạy thử trên DB test của mình:** câu 1 = 0 ✅ · câu 2 phát hiện **5 bộ số bị lặp 3 lần** (do test nhập lại cùng một file 3 lần) · câu 4 = 12 dòng thiếu kích thước · câu 7 = **2 đơn đã quá hạn** · câu 8 = tuần W40: 4 bộ, W41: 152 bộ · câu 9 = GM2-Đ-HPK-VK-2TK: 150 bộ.

---

## 4. Mười câu hỏi nghiệp vụ phải chốt trước khi thiết kế

| # | Câu hỏi | Ảnh hưởng thiết kế | Gợi ý mặc định |
|---|---|---|---|
| 1 | Đơn vị lên kế hoạch là **bộ cửa** hay **cả đơn**? | Quyết định khóa chính của bảng kế hoạch | **Bộ cửa** (theo Bộ số) |
| 2 | Đơn nào được đưa vào kế hoạch: chỉ *Sản xuất + Đã xác nhận*, hay cả *Đơn làm lại* / *Đơn hàng mẫu*? | Bộ lọc đầu vào | *Sản xuất + Đã xác nhận*; *Đơn làm lại* xếp luồng riêng |
| 3 | Xưởng có chia **công đoạn** (cắt nhôm → đột dập → hàn → sơn → lắp kính → đóng gói) không? | Có/không cần bảng nhật ký công đoạn | Nên có, nhưng đợt 1 chỉ cần trạng thái bộ |
| 4 | Kế hoạch theo **ngày** hay theo **tuần**? | Màn hình + độ chi tiết | Theo **tuần**, trong tuần xếp theo ngày |
| 5 | Xưởng có **mấy tổ**, mỗi tổ/tuần làm được **bao nhiêu bộ**? | Cần bảng năng lực (`work_center`) hoặc cấu hình | Cần chốt số thật để so tải |
| 6 | Xếp lịch theo **hạn giao (EDD)** hay **gom lô** theo màu sơn / model nhôm? | Thuật toán xếp lịch — quan trọng nhất | Ưu tiên EDD, nhưng gom lô sơn theo tuần nếu có thể |
| 7 | Ai là người **lên kế hoạch** và ai **cập nhật tiến độ**? | Phân quyền + màn hình | 1 người lên kế hoạch (quản đốc), tổ trưởng cập nhật tiến độ |
| 8 | Có cần theo dõi **% tiến độ** từng bộ hay chỉ cần trạng thái? | Trường dữ liệu | Chỉ **trạng thái** (đơn giản, ít sai) |
| 9 | Có cần **in phiếu lệnh sản xuất** cho xưởng không? | Thêm mẫu in (dùng lại reportlab) | Nên có (in theo tuần/tổ) |
| 10 | Có cần quản lý **tồn vật tư** (nhôm/kính/phụ kiện) không? | Nếu có thì đây là module kho riêng, lớn hơn nhiều | Chưa cần — chỉ cần **định mức ước tính** nếu muốn cảnh báo thiếu vật tư |

---

## 5. Thiết kế kỹ thuật đề xuất (để bạn hình dung trước khi mình làm)

**Nguyên tắc:** module mới **không sửa** bảng đơn hàng hiện tại (tránh ảnh hưởng màn đơn/doanh thu/export đang chạy), chỉ **đọc** đơn và ghi vào bảng riêng.

```
sales_orders ─┐
sales_order_items ──(1 bộ cửa = 1 dòng)──> production_tasks ──> production_plans
                                                │
work_centers (tổ, năng lực bộ/tuần) ────────────┘
                                                └──> production_stage_logs (tuỳ chọn: theo công đoạn)
```

- `production_plans`: mã kế hoạch, từ ngày – đến ngày, trạng thái (Nháp / Đã chốt), ghi chú.
- `production_tasks`: mỗi dòng = **1 bộ cửa** (`order_item_id` duy nhất), có `set_no`, `planned_start/end`, `work_center_id`,
  `priority`, `status` (Chờ sản xuất / Đang sản xuất / Hoàn thành / Đã giao / Tạm dừng), `actual_delivery_date`.
- `work_centers`: mã tổ, tên tổ, năng lực (bộ/tuần), đang hoạt động hay không.
- **Index** cần có: `production_tasks(order_item_id)`, `(plan_id)`, `(status)`, `(planned_start)`.
- Khi lưu kế hoạch: gom **mỗi bảng một lượt ghi** (`createMany` / `createManyAndReturn`) — bài học V111: DB remote ~40–100 ms mỗi lượt, ghi từng dòng sẽ timeout.
- Màn hình gồm: (1) **bảng kế hoạch tuần** (kéo–thả hoặc đổi ngày), (2) **cảnh báo quá tải** (tuần vượt năng lực), (3) **danh sách bộ chưa xếp lịch**, (4) **phiếu lệnh sản xuất in theo tổ**.

---

## 6. Thứ tự đề xuất (khoảng 1–2 tuần)

**Đợt A — dọn nhà (1–2 ngày):** deploy V112b–V114 → `migrate resolve` → chạy 10 câu SQL và sửa dữ liệu bẩn → chốt 10 câu hỏi nghiệp vụ.

**Đợt B — nền dữ liệu sản xuất (2–3 ngày):** thêm `production_tasks` với trạng thái từng bộ + `work_centers`; hiện trạng thái bộ ngay trên trang chi tiết đơn và danh sách đơn (không cần màn kế hoạch trước).

**Đợt C — màn kế hoạch tuần (3–5 ngày):** kéo bộ chưa xếp lịch vào tuần/tổ, cảnh báo quá tải, in phiếu lệnh sản xuất.

**Đợt D — đo lường (1–2 ngày):** thêm *ngày giao thực tế* + mốc *hoàn thành* để có chỉ số **giao đúng hạn (OTD)** — cũng chính là dữ liệu còn thiếu đã nêu ở V114.

---

## 7. Nếu bỏ qua 5 việc trên thì rủi ro gì

- **Bộ số trùng / thiếu** → kế hoạch xếp trùng hoặc sót bộ, xưởng làm sai thứ tự, khách trễ hẹn.
- **Không có trạng thái sản xuất** → mỗi tuần vẫn thấy việc đã làm xong trong danh sách, kế hoạch mất giá trị sau 1 tuần.
- **Migration lệch lịch sử** → lần thêm bảng kế hoạch đầu tiên có thể bị Prisma đề nghị reset DB.
- **Chưa phân quyền** → kế hoạch bị sửa bởi bất kỳ ai có link; khi có tranh cãi không biết ai đổi.
- **Chưa chốt quy tắc xếp lịch (gom lô sơn/nhôm hay theo hạn giao)** → làm xong vẫn phải sửa lại thuật toán và nhập lại kế hoạch.
