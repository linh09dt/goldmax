# V41.5 - PDF V2 logo Vercel fix

- Giữ nguyên logic PDF V2 V41.4.
- Sửa logo GOLDMAX bị mất khi chạy trên Vercel Python Function.
- Local/dev vẫn ưu tiên `public/goldmax-logo.png`.
- Nếu `public/` không có trong bundle Python của Vercel, PDF tự dùng logo PNG đã nhúng trong `reportlab_order_v2.py`.
- Không thay đổi DB/Supabase, Excel V2 hay PDF cũ.
