# V105 — Trang chi tiết đơn hàng: bỏ cột ghi chú, in ghi chú kỹ thuật như bản xuất

## Yêu cầu

> “view chi tiết đơn hàng cũng bỏ sửa ghi chú kỹ thuật” *(trang `/orders/[id]` — nối tiếp V104 đã làm cho cột phải của tab Quản lý đơn hàng)*

## Đã làm

Trang chi tiết đơn hàng (`/orders/[id]`, phần “Chi tiết từng bộ cửa”) nay xếp ghi chú kỹ thuật **giống hệt bản xuất Excel V2 / PDF**:

| | Trước | Nay |
|---|---|---|
| Ghi chú | nằm trong cột **“Ghi chú (18)”** rộng 9,5% | **bỏ hẳn cột**, in thành **hàng riêng trải hết bề ngang bảng** (`colSpan=19`) |
| Số cột | 20 cột | **19 cột**, bề rộng chia lại hết 100% (Tên sản phẩm 11→12%, Model 8→9%, Hình ảnh SP 6,5%) |
| Chữ | chữ thường trong ô | **đỏ, in nghiêng**, nhãn **in đậm** `GHI CHÚ KỸ THUẬT (Bộ số 12062):` |
| Vị trí | trong dòng hàng | **cuối mỗi bộ cửa**, sau dòng phụ kiện cuối cùng |
| Bộ số trong nhãn | — | kèm khi đơn đã vào Sản xuất (đơn hàng mẫu thì nhãn không có bộ số, giống bản xuất) |

- Ghi chú của **cả dòng cửa lẫn từng dòng phụ kiện** đều được in (mỗi ghi chú 1 hàng), đúng thứ tự như bản xuất.
- Ghi chú nhiều dòng giữ nguyên xuống dòng.
- Chỉ in ghi chú của những dòng **đang hiển thị** (đúng như bản xuất: bản xuất cũng chỉ lấy ghi chú của dòng có KH/Lượng).

## Kiểm chứng (chạy thật)

Mình dựng Prisma giả cho **chính trang `/orders/[id]`** (đơn 3 bộ cửa: bộ 1 có 4 dòng phụ kiện + 2 ghi chú, bộ 2 có 1 ghi chú, bộ 3 không có ghi chú) rồi render thật:

```
OK   không còn cột "Ghi chú" ở tiêu đề           OK   chữ đỏ + in nghiêng
OK   bảng còn 19 cột, chia lại vừa 100%          OK   nhãn đậm kèm Bộ số: "GHI CHÚ KỸ THUẬT (Bộ số 12062):"
OK   hàng "Chi tiết / phụ kiện" trải 19 cột      OK   nội dung ghi chú nguyên vẹn (không bị cắt)
OK   không còn ô ghi chú riêng trong dòng hàng   OK   ghi chú của phụ kiện cũng in ra
OK   có 4 hàng ghi chú (2 dòng cửa + 2 phụ kiện) OK   bộ cửa #2 có nhãn bộ số riêng (12063)
OK   hàng ghi chú trải hết bề ngang (colSpan=19) OK   bộ cửa #3 không có ghi chú → không thêm hàng
OK   ghi chú nằm CUỐI bộ cửa: ROW×5 → NOTE×3 → ROW
```

**Đo trong trình duyệt (1280px):** bảng khớp đúng bề rộng vùng chứa (930px = 930px), **không phát sinh cuộn ngang**.

**Ảnh `order-detail-notes-v105.png`** — chụp từ chính trang chi tiết đơn (3 hàng ghi chú đỏ ở cuối bộ cửa #1).

**`npm run build` → PASS**, `npx tsc --noEmit` → 0 lỗi, `npx eslint` → **3 errors / 1 warning — đúng bằng bản gốc** (đều là `no-explicit-any` có từ trước ở `ReadRow` và `buildOutputGroups`, không phát sinh mới).

## Lưu ý

- Không cần migration DB, không đổi dữ liệu.
- Còn **1 chỗ** vẫn để cột ghi chú: **trang in trên web** `/orders/[id]/print` (mở từ nút “In / Lưu PDF”) — *file* PDF/Excel tải về thì đã xếp kiểu hàng riêng từ trước. Muốn làm cho giống nốt thì nói.

## File thay đổi

- `src/app/orders/[id]/page.tsx` — bỏ cột Ghi chú + các ô ghi chú, thêm hàng `GHI CHÚ KỸ THUẬT` ở cuối mỗi bộ cửa, chia lại bề rộng 19 cột.
