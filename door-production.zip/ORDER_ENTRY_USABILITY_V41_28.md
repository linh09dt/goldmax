# V41.28 - Cải thiện nhập liệu bảng Bộ cửa

Phạm vi thay đổi: chỉ giao diện nhập liệu trong `src/components/order-form.tsx`.

## Thay đổi
- Không còn ép toàn bộ 21 cột vào đúng chiều rộng màn hình; bảng dùng chiều rộng tối thiểu và cuộn ngang khi cần.
- Tăng font nội dung ô nhập lên 13px, header 12px.
- Tăng chiều cao input/select lên 40px và tăng padding để dễ đọc, dễ bấm.
- Cân lại độ rộng từng cột: Tên sản phẩm, Model, Đơn giá, Thành tiền, Ghi chú và Hình ảnh rộng hơn.
- Header được gom nhóm rõ: Thông tin sản phẩm / Thông số kỹ thuật / Kích thước cửa / KT thông thủy / Thương mại / Khác.
- Ô ảnh lớn hơn, vẫn giữ Ctrl+V và Tải ảnh như trước.
- Giữ nguyên toàn bộ logic dữ liệu, giá, Master Data, phụ kiện, upload ảnh, validation và API.

## Kiểm tra
- TSX transpile/syntax: OK.
