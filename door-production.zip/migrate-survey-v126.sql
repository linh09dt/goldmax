-- V126: bảng lưu câu trả lời khảo sát nhà máy (module Lên kế hoạch sản xuất)
CREATE TABLE "survey_answers" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(20) NOT NULL,
    "answer" TEXT,
    "choice" VARCHAR(40),
    "updated_by" VARCHAR(120),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "survey_answers_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "survey_answers_code_key" ON "survey_answers"("code");
