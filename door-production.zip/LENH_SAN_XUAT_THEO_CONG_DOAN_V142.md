# V142 — LỆNH SẢN XUẤT CHO TỪNG CÔNG ĐOẠN (mã lệnh lưu trong DB)

Trước đây một bộ cửa chỉ có **lệnh CHA** (bộ) + **3 lệnh CON** (cánh · khung · phào).
Mỗi **công đoạn** chỉ là một dòng tiến độ, **không có lệnh riêng**.

Nay mỗi bộ phát ra **đủ lệnh cho từng công đoạn**, mỗi lệnh có **MÃ LỆNH riêng** lưu trong DB:

```
1 BỘ = 1 lệnh CHA (BO)  +  3 lệnh CON (CANH · KHUNG · PHAO)  +  N lệnh CÔNG ĐOẠN   (= 24 với danh mục V139)
```

---

## 1. Bảng mới `production_work_orders`

| Cột | Ý nghĩa |
|---|---|
| `code` | **Mã lệnh** — duy nhất toàn hệ thống, `VARCHAR(220)`, sinh theo mẫu trong *Cấu hình sản xuất* |
| `set_id` | Bộ cửa (xoá bộ → xoá hết lệnh của bộ) |
| `task_id` | Lệnh **công đoạn** trỏ đúng dòng công đoạn; lệnh cha/con để trống (duy nhất; xoá công đoạn → xoá lệnh) |
| `kind` | `BO` · `CANH` · `KHUNG` · `PHAO` · `CONG_DOAN` |
| `stage_code`, `scope`, `seq` | Chép từ công đoạn để tra cứu khi lệnh được sinh lại |
| `issued_at`, `issued_by` | ⚠️ **Chưa dùng** — chỗ dành sẵn cho bước “phát lệnh cho tổ” sau này (chưa có màn nhập, chưa in ra phiếu) |
| `note` | Ghi chú riêng của lệnh (chưa có màn nhập) |

> **Không lưu trùng số liệu.** Số lượng, trạng thái, % tiến độ, ngày kế hoạch **suy ra** từ
> `production_tasks` (lệnh công đoạn) hoặc từ bộ / lệnh con — đúng quy ước đã dùng cho lệnh con
> (`production_component_orders`). Sửa tiến độ ở màn bộ cửa là mọi thứ khớp ngay, không lo lệch số.

## 2. Mã lệnh

Mẫu mặc định (sửa ở **Cấu hình sản xuất → Mã lệnh sản xuất**):

```
LSX-{orderCode}-{setNo}-{seq:02}{scopeShort}
```

| Loại lệnh | Ví dụ | Bước thật của danh mục V136 |
|---|---|---|
| Lệnh cha (bộ) | `LSX-26082201QN17DH01-1-00B` | — |
| 3 lệnh con | `…-00C` (Cánh) · `…-00K` (Khung) · `…-00P` (Phào) | — |
| Lệnh công đoạn *Chấn cánh* | `LSX-26082201QN17DH01-1-40C` | `CHAN` = bước 40 |
| Lệnh công đoạn *Test cơ khí* | `…-70B` | `TEST_CO_KHI` = bước 70 |

- **Chữ phần:** Cánh **C** · Khung **K** · Phào **P** · cả bộ **B**.
- Token: `{orderCode}` `{setNo}` `{set}` (id bộ) `{seq}` `{seq:02}` (canh 0) `{scope}` `{scopeShort}` `{stage}` `{kind}`.
- **Điều kiện bắt buộc của mẫu:** phải có **`{set}`** — hoặc có **cả `{orderCode}` và `{setNo}`**.
  - `{orderCode}` **một mình là KHÔNG đủ**: mọi bộ trong cùng một đơn sẽ ra cùng bộ mã → app **từ chối khi lưu cấu hình**
    (báo lỗi tiếng Việt). Đây là lỗi đã bị kiểm chứng độc lập phát hiện ở bản đầu và đã sửa.
- Bộ **không có mã đơn** (nhập bộ đang dở) tự dùng mẫu dự phòng `LSX-{set}-{seq:02}{scopeShort}` → vẫn duy nhất.
- Hai công đoạn trùng mã (cùng bước + cùng phần) → tự thêm hậu tố `-2`, `-3`… (app **và** SQL làm giống nhau).
- Mã dài quá **220 ký tự** bị cắt (TS và SQL cắt giống nhau) — với mẫu mặc định, mã đơn 120 ký tự + bộ số 80 ký tự
  vẫn chỉ ~209 ký tự nên thực tế không tới ngưỡng này.
- **Bước công đoạn phải ≥ 1** (API danh mục đã chặn `seq = 0`): bước `00` được dành cho lệnh cha/lệnh con.
  Nếu dữ liệu cũ có công đoạn bước 0, mã lệnh công đoạn đó tự thành `…-00B-2` (không đè lên lệnh cha).

## 3. Hiện ở đâu

| Màn | Nội dung thêm |
|---|---|
| **Bộ cửa** (`/ke-hoach-san-xuat/bo/<id>`) | Cột **Mã lệnh** ở bảng *Lệnh sản xuất cha – con* và bảng *Cập nhật tiến độ theo công đoạn*; ô *Thông tin bộ cửa* có “Mã lệnh (bộ)” |
| **In phiếu lệnh SX** (`?bo=<id>` hoặc `?ngay=…`) | Dòng “Mã lệnh (bộ)” + cột **Mã lệnh** trong bảng lệnh con và bảng công đoạn |
| **In danh sách việc theo ngày** | Cột **Mã lệnh** để tổ tích xong theo đúng lệnh |
| **Cấu hình sản xuất** | Ô “Mẫu mã lệnh” + danh sách token, sửa được không cần deploy |

**Chưa có:** màn tra cứu theo mã lệnh, và mã lệnh **chưa hiện** trên bảng kế hoạch / báo cáo.
Muốn tra cứu hiện phải vào đúng bộ cửa. (Ghi rõ để không hiểu nhầm là đã có.)

## 4. Áp dụng (thứ tự)

```bash
# 1) Chạy SQL (idempotent) TRƯỚC khi deploy code — bài học V112
psql "<CHUỖI KẾT NỐI>" -f migrate-production-v142-lenh-cong-doan.sql
#    hoặc dán cả file vào SQL Editor. File tự tạo bảng + sinh lệnh cho MỌI bộ đang có.
#    Nếu đang dùng dữ liệu mô phỏng (sim-500/sim-1000): nạp sim TRƯỚC, rồi chạy file này.

# 2) Nếu pipeline có chạy `prisma migrate deploy` → đánh dấu migration đã áp dụng, tránh lỗi
#    "relation already exists":
npx prisma migrate resolve --applied 20260927000000_production_work_orders

# 3) Deploy code (zip này), rồi kiểm tra
npx tsc --noEmit && npm run build
```

Cuối file SQL có **câu kiểm tra báo lỗi to**: nếu có bộ nào thiếu lệnh (thường do 2 bộ **cùng mã đơn + cùng Bộ số**
— dữ liệu lỗi), script **dừng và báo rõ số bộ**, KHÔNG bỏ qua im lặng. Sửa dữ liệu rồi chạy lại.

Kiểm tra tay:

```sql
SELECT "kind", count(*) FROM production_work_orders GROUP BY "kind";
SELECT (SELECT count(*) FROM production_sets) * 4
     + (SELECT count(*) FROM production_tasks) AS ky_vong,
       (SELECT count(*) FROM production_work_orders) AS thuc_te;   -- 2 số phải bằng nhau
```

## 5. Bộ mới và sinh lại

- **Bộ mới** (`POST /api/production/sets`): lệnh sinh ngay trong **cùng một transaction** với bộ + công đoạn
  (mỗi bảng 1 câu `createMany`) — vẫn “ghi gộp 1 lượt”. Lệnh cha + 3 lệnh con **luôn có**, kể cả khi
  danh mục công đoạn đang trống (bộ chưa có công đoạn nào).
- Hai dòng hàng **cùng đơn + cùng Bộ số** trong một lượt đưa vào kế hoạch: app **chỉ lấy dòng đầu**
  (trước V142 cả hai đều được tạo → nay sẽ trùng mã lệnh, nên đã chặn từ đầu vào).
- **Sinh lại lệnh**: hiện chỉ có **API** `POST /api/production/sets/<id>` với `{"action":"rebuild"}` —
  **chưa có nút trên giao diện**.
  ⚠️ `rebuild` **XOÁ và SINH LẠI công đoạn** (mất trạng thái, người làm, ghi chú, ngày thực tế đã ghi) ⇒ **không dùng
  để đổi mã lệnh cho bộ đang sản xuất**.
- **Đổi mẫu mã lệnh hàng loạt**: file SQL luôn sinh theo **mẫu mặc định** (SQL không đọc được mẫu token trong
  `system_settings`). Muốn mã cũ đổi theo mẫu mới phải làm bằng app — hiện chưa có chức năng sinh lại mã hàng loạt.
  ⇒ **Kết luận thực tế: chọn kỹ mẫu mã lệnh NGAY TỪ ĐẦU**; đổi mẫu chỉ áp dụng cho bộ tạo mới sau đó.

## 6. Kiểm chứng

Test tự động: `tmp-verify-v142.mjs` (chạy `node --import /tmp/register.mjs tmp-verify-v142.mjs`) — **đạt hết**,
gồm cả các ca mà bản đầu bỏ sót:

- **19/19 migration** chạy sạch trên DB trắng (PGlite); cột `code` đúng `VARCHAR(220)`.
- **SQL ↔ TS giống nhau** cho: bộ có mã đơn, bộ không có mã đơn, **công đoạn bước 0**, mã đơn/bộ số dài hết cỡ.
- Mẫu **chỉ có `{orderCode}` bị từ chối**; mẫu thiếu token duy nhất tự quay về mẫu theo mã bộ.
- Chạy lại SQL lần 2 → **không nhân đôi**; chèn **đúng như app** (Prisma `createMany`) → đủ lệnh, không lỗi ràng buộc.
- **2 bộ cùng mã đơn + cùng bộ số** → bộ thứ hai không sinh được lệnh và câu kiểm tra **BÁO LỖI** (đúng thiết kế).
- Ràng buộc: chặn 2 lệnh CHA cùng bộ, chặn mã lệnh trùng; xoá bộ → xoá lệnh; xoá công đoạn → xoá lệnh công đoạn.
- `tsc --noEmit` 0 lỗi · `eslint` vùng sản xuất 0 lỗi · `npm run build` OK.

**Kiểm chứng độc lập** (agent khác, đọc mã nguồn thật, tự viết test) đã tìm ra **6 lỗi thật** ở bản đầu và **đã sửa hết**:

| Lỗi | Đã sửa bằng |
|---|---|
| Mẫu chỉ có `{orderCode}` → mã trùng giữa các bộ cùng đơn, cả transaction bị huỷ | Bắt buộc `{set}` hoặc (`{orderCode}` + `{setNo}`) |
| 2 dòng hàng cùng đơn + cùng Bộ số → trùng mã, huỷ cả lượt nhập | Chỉ lấy dòng đầu khi đưa vào kế hoạch |
| SQL backfill bỏ im lặng khi mã trùng (bộ thiếu lệnh cha/con) | Xếp hạng theo TỪNG BỘ + câu kiểm tra báo lỗi to |
| Công đoạn bước 0 trùng mã với lệnh cha/con; SQL ≠ TS | Xếp hạng tính cả mã đã có của bộ; API chặn bước 0 |
| `VARCHAR(160)` cắt ở TS nhưng SQL báo lỗi | Nâng lên 220 và cắt `left(...,220)` ở cả hai |
| Tài liệu hướng dẫn thiếu bước `prisma migrate resolve` | Đã thêm vào mục 4 |

**Chưa kiểm chứng được trong sandbox:** đường ghi thật qua Prisma (`createManyAndReturn`) — sandbox không có
PostgreSQL. Đã kiểm bằng `tsc`, đối chiếu mã lệnh, và mô phỏng đúng câu ghi trên PGlite.
Cách dùng Prisma này giống hệt chỗ đang chạy sẵn (`productionSet.createManyAndReturn`).

## 7. File thay đổi

| File | Việc |
|---|---|
| `prisma/migrations/20260927000000_production_work_orders/migration.sql` | **MỚI** — DDL + backfill + kiểm tra |
| `migrate-production-v142-lenh-cong-doan.sql` | **MỚI** — bản chạy tay, idempotent, không bảng tạm |
| `src/lib/production/work-order.ts` | **MỚI** — mẫu mã lệnh + sinh mã + kiểm tra mẫu (thuần, có test) |
| `prisma/schema.prisma` | model `ProductionWorkOrder` + ghi chú chỉ số riêng phần |
| `src/lib/production/service.ts` | sinh lệnh khi tạo bộ + khi sinh lại; nạp lệnh ở chi tiết bộ |
| `src/lib/production/config.ts` | `workOrderCodeTemplate` + kiểm tra hợp lệ |
| `src/app/api/production/catalog/route.ts` | chặn `seq = 0` (dành bước 00 cho lệnh cha/con) |
| `src/lib/production/print.ts` · `src/components/production/print-sheets.tsx` | mã lệnh trên phiếu lệnh + danh sách việc |
| `src/components/production/set-progress-form.tsx` | cột **Mã lệnh** (chỉ xem) |
| `src/app/ke-hoach-san-xuat/bo/[id]/page.tsx` | mã lệnh ở bảng cha–con, bảng công đoạn, thông tin bộ |
| `src/app/ke-hoach-san-xuat/in/danh-sach-viec/page.tsx` | truyền mã lệnh xuống mẫu in |
| `src/components/production/production-config.tsx` | ô sửa mẫu mã lệnh |
