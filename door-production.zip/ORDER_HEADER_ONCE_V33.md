# ERP V33 - Chỉ hiển thị thông tin đầu đơn một lần

Trong bảng **Danh sách đơn hàng**, các thông tin thuộc cấp đơn hàng chỉ hiển thị ở dòng đầu tiên của từng đơn:

- Ngày đơn hàng
- Số đơn hàng
- Hạn giao hàng
- Người nhận và địa chỉ nhận
- Số Km từ nhà máy đến nơi giao
- Mã khách hàng
- Tên khách hàng

Các dòng sản phẩm/phụ kiện phía dưới cùng đơn để trống 7 cột trên. Các cột sản phẩm vẫn hiển thị bình thường.

Giữ nguyên:
- Phân nhóm màu/viền giữa các đơn (V32)
- Full view
- Sticky header
- Bộ lọc
- Sửa/Xóa đơn
- Không đổi database

Cài đặt:
```cmd
Ctrl + C
rmdir /s /q .next
npm run dev -- --webpack
```
