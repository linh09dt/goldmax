# V41.31 - Hiện lại Excel V2

- Hiện lại nút **Excel V2** trên từng đơn nhưng đổi nhãn người dùng thành **Xuất Excel**.
- Nút này vẫn gọi đúng route Excel V2 hiện tại: `/api/orders/{orderId}/export-v2`.
- Giữ nút **Xuất PDF** là PDF V2 như hiện tại.
- Hai chức năng legacy **Excel cũ** và **PDF cũ** vẫn tạm ẩn, không xóa code/API.
- Cập nhật Hướng dẫn sử dụng tương ứng.
- Không thay đổi logic export, dữ liệu, DB, PDF, giá hoặc ảnh.
