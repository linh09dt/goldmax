# ERP V14.1 - Fix tạo lại Danh mục hàng hóa

Lỗi V14 phát sinh do API `createMany()` ghi thêm các field mở rộng của V13 (`salesName`, `salesModel`, `source`, `lastSourceFile`, `priceSourceFile`...), trong khi Prisma Client/database hiện tại của máy chưa đồng bộ đủ các field đó.

V14.1 thu gọn thao tác reset Master Data về đúng yêu cầu hiện tại:

- chỉ lấy `TENHANG` + `MODEL` từ file `danh muc hang hoa.xlsx`;
- ghi vào `name` + `code`;
- trạng thái mặc định `active = true`;
- chưa ghi ĐVT;
- chưa ghi Giá đại lý;
- chưa ghi các field nguồn/giá mở rộng;
- không thay đổi đơn hàng hiện có.

## Cài đặt

Chép patch chồng lên V14, sau đó chạy:

```cmd
rmdir /s /q .next
npm run dev
```

Không cần migrate database cho patch này.
