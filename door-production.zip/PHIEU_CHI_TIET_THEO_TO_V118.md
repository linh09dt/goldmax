# V118 — Phiếu câu hỏi CHI TIẾT theo tổ & công đoạn (thiết kế module Lên kế hoạch sản xuất)

Bản mở rộng của V117: V117 là **bản ngắn 12 câu chặn** (dùng khi trao đổi nhanh với quản đốc),
V118 là **bản đầy đủ 152 câu hỏi** chia theo **từng tổ → từng công đoạn**, mỗi câu gắn với dữ liệu app đang có.

**File giao:** `artifacts/phieu-cau-hoi-chi-tiet-theo-to-v118.docx` (điền được trong Word) ·
`artifacts/phieu-cau-hoi-chi-tiet-theo-to-v118.pdf` (in A4, 15 trang) · script sinh: `dp/scripts/phieu-v118/mk_v118.py`.

---

## Cấu trúc phiếu (11 mục)

| Mục | Nội dung | Số câu | Mã câu |
|---|---|---|---|
| 0 | **Dữ liệu app đang có** cho 1 bộ cửa (đọc trước) | 12 dòng | — |
| 1 | **TỔ MÁY**: Thiết kế · **Bồi Lares (nạp chương trình máy cắt — hậu thiết kế)** · Cắt · Chấn + câu hỏi chung | 39 | TK1–7, BL1–8, C1–10, CH1–8, TM1–6 |
| 2 | **TỔ HÀN**: Hàn · Ép cánh · Test cơ khí + chung | 25 | HAN1–7, EP1–7, TC1–6, TH1–5 |
| 3 | **TỔ SƠN** (nút thắt theo bảng công đoạn) | 16 | SON1–16 |
| 4 | **TỔ VÂN** | 12 | VAN1–12 |
| 5 | **LẮP KÍNH + PHỤ KIỆN** (công đoạn chưa có trong bảng) | 12 | LK1–12 |
| 6 | **TỔ KHO**: Vệ sinh + Đóng gói · Kho & Giao hàng & lắp đặt | 20 | KHO1–8, GH1–12 |
| 7 | **Các vấn đề xuyên suốt khi LÊN KẾ HOẠCH** | 28 | KH1–28 |
| 8 | **Dữ liệu app sẽ thêm** (chốt theo câu trả lời) | 15 dòng | — |
| 9 | **Kiểm tra chéo**: app có X — xưởng có dùng không? | 20 dòng | — |
| 10 | **Mặc định** nếu chưa trả lời được | 20 hạng mục | — |
| 11 | Xin kèm theo (mẫu kế hoạch, bản vẽ, số liệu…) | 10 gạch | — |

**Tổng: 152 câu hỏi** (mỗi câu ghi rõ **P1** = bắt buộc để lập trình, **P2** = cho đợt sau, và một dòng *“vì sao cần hỏi”*).

---

## Câu hỏi ↔ ảnh hưởng thiết kế app

| Nhóm câu | Chốt được gì cho app |
|---|---|
| TK (thiết kế) | Thiết kế có chiếm tải tuần không; app cần đủ trường gì để vẽ (cao/rộng/thông thủy/số cánh/ô thoáng) |
| BL (Bồi Lares) | Đã xác nhận là **công đoạn chuẩn bị (CAM)**, không phải gia công: theo model hay theo bộ · thời gian chương trình mới/cũ · có chặn Cắt không · nguồn lực kỹ thuật riêng |
| C (cắt) | Gom lô theo model nhôm, thời gian setup đổi model, lead time đặt nhôm |
| CH (chấn) | Nút thắt theo **khuôn**; quy tắc “đủ đơn mới đẩy” đang gây chờ |
| HAN/EP/TC (hàn/ép cánh/test) | Thứ tự công đoạn thật; thời gian Ép cánh; luồng quay lại khi lỗi (làm lại) |
| SON | Năng lực **mẻ lò**, số màu, thời gian đổi màu, quy tắc gom lô màu, thời gian chờ khô |
| VAN | Danh mục **mã vân**, gom lô vân, vị trí vân so với lắp kính |
| LK (lắp kính + phụ kiện) | Bổ sung **công đoạn còn thiếu**; lead time kính; trường dữ liệu phụ kiện còn thiếu |
| KHO/GH (kho & giao) | Mốc **Hoàn thành sản xuất** vs **Đã giao**; ngày giao thực tế; năng lực giao hàng; có lắp đặt tại công trình |
| KH (kế hoạch) | Cách lên kế hoạch hiện nay, màn hình chính, quy tắc xếp lịch, ai cập nhật, báo cáo cần xem |
| Mục 8–9 | Danh sách **trường dữ liệu** phải thêm / đang thừa |

---

## Cách sinh lại tài liệu

```bash
pip install python-docx                     # 1 lần
python3 dp/scripts/phieu-v118/mk_v118.py    # -> artifacts/phieu-cau-hoi-chi-tiet-theo-to-v118.docx
libreoffice --headless --convert-to pdf --outdir artifacts artifacts/phieu-cau-hoi-chi-tiet-theo-to-v118.docx
```

> Ghi chú kỹ thuật: `libreoffice --convert-to pdf` từ **.docx** chạy tốt (15 trang A4);
> nhưng convert từ **HTML** thì LibreOffice luôn chèn 1 trang trắng đầu — xem [[error-libreoffice-pdf-trang-trang]].
