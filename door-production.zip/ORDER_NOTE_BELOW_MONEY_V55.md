# ORDER NOTE BELOW MONEY BOX V55

## Mục tiêu
Chuyển **hộp ghi chú** từ chỗ nằm **bên trái box tiền** xuống **dưới box tiền**, cách **1 dòng**. Giữ nguyên kiểu hộp (nền nhạt `#F8FAFC`, viền `#C9D5E3`, chữ nhỏ màu xám, 2 dòng đầu in đậm).

## Cách làm
- `_bottom_section` dựng bảng ngoài **2 cột** `[CONTENT_W*0.66 | CONTENT_W*0.34]`:
  - Hàng 1: ô trái để trống, ô phải = **box tiền** (giữ đúng vị trí bên phải như cũ).
  - Hàng 2: `SPAN (0,1)-(1,1)` = **hộp ghi chú** (rộng 60% CONTENT_W, căn trái).
  - `BOTTOMPADDING` hàng 1 = 4pt → đúng “1 dòng” giữa box tiền và hộp ghi chú.
- Vì sao dùng `SPAN` thay vì bảng 1 cột: khi để 1 cột full-width, ReportLab **không tôn trọng `hAlign="RIGHT"` của bảng con** nên box tiền bị dạt sang trái (đã kiểm chứng bằng đo pixel trên bản render).
- Hàm `_footnote_block()` được ghim `hAlign="LEFT"`.

## File sửa
1. `python/reportlab_order_v2.py` — `_bottom_section`, `_footnote_block`.
2. `python/reportlab_order_preview.py` — bố cục tương tự (import hằng số từ module V2).

## Không thay đổi
- **Excel V2**: hộp ghi chú vốn đã nằm dưới box tiền (cách 1 dòng trống) từ V53/V54 → không cần sửa. Box tiền vẫn ở cột L→S, ghi chú ở cột A→K phía dưới.
- Nội dung ghi chú, style chữ, màu nền/viền, toàn bộ công thức tiền và bảng hàng hóa.

## Kiểm chứng thực tế (đo trực tiếp trên bản render)
- **PDF V2** (trang rộng 2189px @2.6x): box tiền (nền navy) ở `x 1450–2165`, hàng “CÒN LẠI…” ở `y 185–229`; hộp ghi chú (nền `#F8FAFC`) ở `x 54–1319`, `y 310–532` → **nằm dưới box tiền**, lệch trái, cách khoảng 1 dòng.
- **PDF preview**: box tiền `x 1450–2165`, `y 333–414`; hộp ghi chú `x 54–1319`, `y 505–785` → cùng bố cục.
- Chạy thật `python3 python/reportlab_order_v2.py --input … --output …`: dựng PDF không lỗi, đủ ghi chú + tổng kết, không còn checklist.
- `python -m py_compile`: OK.
