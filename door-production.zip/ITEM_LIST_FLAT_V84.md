# V84 — Danh mục hàng hóa A1: bỏ nhóm TENHANG, chia 2 khối CỬA / PHỤ KIỆN

## Yêu cầu

> “hiện tại đang hiển thị nhóm, mình muốn liệt kê chi tiết từng dòng hàng khóa, không nhóm chung nữa.
> chia ra nhóm cửa và nhóm phụ kiện”

Hiện trạng trước V84: khối **A1 — Danh mục hàng hóa** gom các MODEL theo **TENHANG**, mỗi TENHANG là một dòng
nhóm thu gọn được; muốn xem từng MODEL phải bấm “+”. Ví dụ nhóm **Khóa** hiển thị là `Khóa — 18 MODEL`
(vì “Khóa” và “KHÓA” bị gộp làm một), không thấy ngay từng ổ khóa.

Yêu cầu mới:

1. **Không gom theo TENHANG nữa** — liệt kê chi tiết từng MODEL thành một dòng riêng (kể cả từng dòng khóa).
2. Chỉ chia **2 khối lớn: CỬA và PHỤ KIỆN**.

## Cách làm

File sửa duy nhất: `src/components/item-master.tsx`.

### 1. Bỏ hoàn toàn kiểu nhóm theo TENHANG

- Xoá state `groupedView`, `expandedGroups`, type `ItemGroup`, memo `itemGroups`, các hàm `isGroupExpanded`,
  `toggleGroup`, `expandAllGroups`, `collapseAllGroups`.
- Xoá nút bật/tắt **“Đang nhóm theo TENHANG / Nhóm theo TENHANG”**.
- Xoá dòng nhóm `NHÓM TENHANG` và tiền tố `↳` ở cột TENHANG của dòng chi tiết (giờ hiện nguyên tên TENHANG).
- Cột **TENHANG** trở lại là dữ liệu thật của từng dòng, không còn bị thay bằng “↳ …”.

### 2. Chia 2 khối CỬA / PHỤ KIỆN

Phân loại dùng **đúng quy ước đang có ở view Tạo đơn hàng** (`isDoorCatalogItem` trong `order-form.tsx`):
TENHANG (bỏ dấu, hạ chữ thường) bắt đầu bằng `cua ` hoặc bằng `cua` → **Cửa**; mọi TENHANG còn lại → **Phụ kiện**.

Thêm 2 helper cục bộ ở cuối file: `normalizeText()` (giống view Tạo đơn hàng) và `isDoorTenhang()`.

Dữ liệu thật trong Master Data (92 MODEL, 15 cách ghi TENHANG):

| Khối | TENHANG | Số MODEL |
|---|---|---|
| **CỬA** (52 MODEL · 7 TENHANG) | Cửa Đi 1 Cánh 11 · Cửa Đi 2 Cánh 13 · Cửa Đi 4 Cánh 16 · Cửa Đi Cánh Kính 3 · Cửa Đi Vách Kính 1 · Cửa Sổ 7 · Cửa Vòm 1 | 52 |
| **PHỤ KIỆN** (40 MODEL · 7 TENHANG) | Khóa + KHÓA 18 · Phào Biệt Thự 8 · Ô Thoáng 6 · Gia Công Ô Kính 5 · Khuôn Kép 1 · Phao Rời 1 · Song Tròn 1 | 40 |

Trong mỗi khối, dòng được sắp **theo TENHANG rồi theo MODEL** để các MODEL cùng loại nằm liền nhau.

### 3. Giao diện

- Mỗi khối có **1 dòng tiêu đề**: nút thu gọn `−/+`, tên khối **CỬA** / **PHỤ KIỆN**, badge số MODEL,
  badge số TENHANG, và ghi chú bên phải (“Dùng làm bộ cửa trong đơn” / “Dùng làm dòng phụ kiện / chi tiết trong đơn”).
- **Mặc định mở cả 2 khối** → thấy ngay toàn bộ 92 dòng.
- Nút **Mở tất cả / Thu gọn** ở thanh công cụ giờ thu gọn/mở 2 khối này.
- Khi **tìm kiếm**, 2 khối tự mở; khối không có kết quả sẽ tự ẩn.
- Badge tổng ở đầu bảng: `92 MODEL` · `92 đang sử dụng` · `Cửa 52` · `Phụ kiện 40`.
- Thêm 1 dòng ghi chú dưới thanh công cụ nói rõ quy tắc chia khối.
- Cột **STT** đánh số liên tục 1 → 92 theo thứ tự đang hiển thị.

## Kiểm chứng

- `npx tsc --noEmit` → 0 lỗi. `npm run build` → OK.
- `npx eslint src/components/item-master.tsx` → đúng bằng bản gốc (1 lỗi có sẵn ở dòng `<a href="/api/items/export">`,
  V84 không thêm lỗi nào).
- Đo thật trong trình duyệt ở **1280×720** (trang `/settings?tab=items`, chỉ đọc Supabase production):

| Nội dung kiểm tra | Kết quả |
|---|---|
| Số dòng tiêu đề khối | 2 — `CỬA 52 MODEL 7 TENHANG` và `PHỤ KIỆN 40 MODEL 7 TENHANG` |
| Số dòng chi tiết | **92** (khớp 92 MODEL), STT 1 → 92 |
| Dòng cuối khối CỬA / dòng đầu khối PHỤ KIỆN | `52 · Cửa Vòm` → `53 · Gia Công Ô Kính` |
| Dòng khóa | **18 dòng riêng biệt** (trước đây gộp thành 1 nhóm) |
| Còn tiền tố `↳` | Không |
| Còn nút “Nhóm theo TENHANG” | Không |
| Ô bị cắt chữ | 0 (đo `scrollWidth` vs `clientWidth` của dòng tiêu đề) |
| Trang bị cuộn ngang | Không (`scrollWidth 1280 = clientWidth 1280`) |
| Thu gọn khối CỬA | còn 42 dòng (1 tiêu đề PHỤ KIỆN + 40 chi tiết + 1 dòng lịch sử) |
| Thu gọn tất cả / Mở tất cả | hoạt động đúng |
| Tìm “khóa” khi đang thu gọn hết | tự mở khối PHỤ KIỆN, ra 18 dòng, khối CỬA tự ẩn |

## Lưu ý về dữ liệu (cần bạn quyết)

Trong Master Data đang có **2 cách ghi cho cùng một nhóm khóa**: `Khóa` (8 MODEL) và `KHÓA` (10 MODEL)
— 18 MODEL nhưng 2 chuỗi TENHANG khác nhau. V84 **hiển thị đúng như dữ liệu đang lưu** (không tự sửa dữ liệu),
nên trong danh sách bạn sẽ thấy 18 dòng khóa với TENHANG lúc là `Khóa`, lúc là `KHÓA`.

Muốn cho đẹp thì có 2 cách, nói mình biết chọn cách nào:

- **Chỉ thống nhất khi hiển thị** — không đụng database, sửa 1 chỗ trong `item-master.tsx`.
- **Sửa thẳng Master Data** — cập nhật 10 MODEL từ `KHÓA` về `Khóa` (đổi dữ liệu thật trên Supabase, cần bạn duyệt trước).

## File thay đổi

- `src/components/item-master.tsx` — bỏ kiểu nhóm theo TENHANG, chia 2 khối CỬA / PHỤ KIỆN, liệt kê từng dòng chi tiết.
