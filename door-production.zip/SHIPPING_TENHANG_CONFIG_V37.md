# ERP V37 – Cấu hình vận chuyển

V37 thay logic nhận diện nguồn tính cước từ **Model đơn hàng** sang **TENHANG trong Danh mục hàng hóa**.

## Logic chính thức

1. Dòng bộ cửa trong đơn có `MODEL` / mã hàng.
2. Hệ thống tra `item_masters` (Danh mục hàng hóa) theo MODEL để lấy `TENHANG` chuẩn.
3. `TENHANG` được ánh xạ trong tab **Cấu hình vận chuyển** sang `Model tính cước` (`SV1`, `SV2`, `SV4`, `SVCS1`...).
4. Model tính cước dùng để lấy giá trong `shipping_rates`.
5. Nếu không tìm được TENHANG trong Danh mục hàng hóa hoặc TENHANG chưa được cấu hình thì hiển thị **Chưa cấu hình TENHANG** và không cho áp dụng cước.

Không còn dùng logic Model đơn hàng trùng trực tiếp Model cước hoặc nhận diện tiền tố mã hàng để quyết định Model tính cước.

## Giao diện

Tab cấu hình lấy danh sách TENHANG trực tiếp từ `item_masters` đang active, tránh nhập sai tên.

Bảng chi tiết tính cước hiển thị:

- TENHANG.
- Model tính cước.
- Mô tả Model tính cước.
- Số bộ và mức đối chiếu.
- Khung giá, cước toàn tuyến, nhà máy hỗ trợ, phần thu khách.
- Dòng đơn hàng và trạng thái kiểm tra.

## Database / Supabase

Giữ nguyên bảng `shipping_model_mappings` và cột `source_model` để không tạo migration DB không cần thiết. Từ V37, giá trị trong `source_model` được dùng để lưu **TENHANG**.

Do không thay đổi cấu trúc bảng Supabase, bản V37 không cần migration mới. Sau khi cập nhật source chỉ cần generate Prisma/build theo quy trình hiện tại.
