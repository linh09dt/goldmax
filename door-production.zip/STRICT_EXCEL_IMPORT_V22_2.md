# ERP V22.2 — Import Excel giữ nguyên ô trống

## Logic đã sửa

- Import `.xlsb/.xlsx` theo đúng giá trị có trong file.
- Ô nào trong Excel trống thì trên form sau import cũng để trống.
- Không tự bù dữ liệu từ Danh mục hàng hóa sau import.
- Không tự bù `TENHANG`, `MODEL`, `ĐVT`, `Đơn giá`, `Model khóa` hay các trường khác.
- Không tự gán `QP-01`, ngày hiệu lực, cước vận chuyển, đặt cọc, trừ tiền tại kho hoặc chiết khấu nếu file không có giá trị.
- Nếu file không có `% chiết khấu`, ô Chiết khấu (%) để trống.
- Mã đơn SX nếu file trống cũng được để trống để người dùng nhập tay.
- Cột ảnh vẫn giữ cơ chế tải ảnh riêng trên Web App. Khi chỉnh sửa đơn đã có ảnh, import vẫn cố giữ ảnh hiện có theo dòng tương ứng.
- Logic dòng hàng kèm `KH/Lượng > 0` vẫn giữ nguyên theo phiên bản trước.

## Liên kết Master Data

Sau import, hệ thống không tự liên kết/bù dữ liệu. Khi người dùng chủ động chọn hàng hóa/Model từ Danh mục hàng hóa trên form thì logic liên kết Master Data hoạt động như bình thường.

## Cài đặt

Chép patch chồng lên V22.1 hiện tại rồi chạy:

```cmd
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần migrate database.
