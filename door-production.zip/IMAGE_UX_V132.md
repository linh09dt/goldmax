# V132 — Bỏ tab "Chuẩn hóa ảnh SP" + làm lại ô ảnh sản phẩm cho dễ dán/xóa

## Yêu cầu

1. *"xóa tab Chuẩn hóa ảnh SP giúp mình, mình không cần dùng nó nữa, có thể xóa trên code liên quan đến tab Chuẩn hóa SP"*
2. *"chỗ cột hình ảnh SP không có chế độ xóa hình, nút đổi và tải ảnh có thể nằm ngoài ô hình ảnh, vì mỗi lần dán vào phải click vào ô, hiện ra bảng nhập link hình ảnh, nhấn thoát mới dán ảnh vào được, rất khó khăn… kích cỡ mặc định bằng chiều rộng cột trên hình ảnh SP trên xuất pdf"*

---

## 1. Đã xóa tab "Chuẩn hóa ảnh SP"

| Hạng mục | Xử lý |
|---|---|
| `src/app/cong-cu-anh/page.tsx` | **xóa** |
| `src/components/product-image-tool.tsx` | **xóa** |
| Mục menu "Chuẩn hóa ảnh SP" (`src/components/erp-nav.tsx`) + icon `IconImage` | **xóa** |
| `IMAGE_TOOL_V110.md` (tài liệu của công cụ đã bỏ) | **xóa** |
| Đường dẫn `/cong-cu-anh` | nay trả **404** |

**Giữ lại** `src/lib/png-size.ts` (`readImageSize`, `readPngSize`, `logoBox`) vì **Excel/PDF vẫn dùng** để đọc kích thước thật của ảnh/logo — không liên quan tới tab đã xóa.

Kết quả build: danh sách route **không còn `/cong-cu-anh`**, menu Công cụ chỉ còn *Khảo sát nhà máy · Tính cước vận chuyển · Hướng dẫn sử dụng*.

---

## 2. Làm lại ô "Hình ảnh SP"

### Nguyên nhân khó dán trước đây
Ảnh được bọc trong thẻ `<a href="…">` (để bấm mở ảnh gốc). Vì vậy **bấm vào ô ảnh là mở ảnh/link ảnh** → phải đóng tab/bảng đó rồi mới quay lại dán được.

### Đã sửa
| Vấn đề | Cách sửa |
|---|---|
| Bấm vào ô ảnh mở bảng/link ảnh | **Bỏ thẻ `<a>`** quanh ảnh. Bấm vào ô chỉ **focus ô ảnh** để Ctrl+V dán ngay (không mở gì, không đổi trang). |
| Khó dán | Thêm nút **Dán ảnh** ở ngoài ô → đọc thẳng ảnh từ Clipboard (một cú bấm). Vẫn dán được bằng Ctrl+V như cũ. |
| Không xóa được ảnh | Thêm nút **Xóa ảnh** (đỏ) — xóa ảnh + kích thước của dòng đó. |
| Nút Đổi/Tải ảnh nằm trong ô | Đưa **ra ngoài ô ảnh**: hàng nút riêng `Dán ảnh · Đổi ảnh (Tải ảnh) · Xóa ảnh` nằm dưới khung ảnh. |
| Muốn dán tiếp ảnh khác | Sau khi tải xong, ô ảnh **tự giữ focus** → dán tiếp ảnh khác ngay, không phải click lại. |
| Cỡ ảnh mặc định không khớp file xuất | **Cỡ mặc định = bề rộng cột "HÌNH ẢNH SP" khi xuất PDF = 56 px** (xem công thức bên dưới). |

### Cỡ mặc định 56 px — cách tính
PDF: cột ảnh = `15,5/273` bề rộng nội dung A4 ngang (`CONTENT_W ≈ 813,5 pt`) ≈ **46,2 pt**; trừ padding 4 pt còn ≈ 42,2 pt = **56 px** (96 dpi). Vì vậy ảnh trong form hiện **đúng bằng cỡ ảnh khi xuất PDF**.

Nút chỉnh cỡ: **Nhỏ (120) · Vừa (200) · Lớn (320)** và **Mặc định** (nút sáng xanh khi đang ở cỡ mặc định). Vẫn kéo được tay nắm ở góc dưới-phải, hoặc gõ số px vào ô Rộng / Cao (giữ đúng tỉ lệ ảnh).

---

## Kiểm chứng (chạy thật, không đoán)

Dựng PostgreSQL 18 cục bộ + app Next.js, đo bằng trình duyệt thật (Chrome headless):

```
/cong-cu-anh                          → HTTP 404
menu "Chuẩn hóa ảnh SP"               → không còn (0 kết quả)
thẻ <a> trong ô ảnh                    → 0 (trước đây có 1 → gây mở link)
bấm vào ảnh                            → URL KHÔNG đổi (không mở bảng/link)
nút hiện có                            → Dán ảnh · Đổi ảnh · Xóa ảnh
đơn chưa đặt cỡ: khung ảnh = 56 px     → chú thích "Cỡ mặc định 56 px (bề rộng cột ảnh khi xuất PDF)"
đơn đặt 200×120: chú thích             → "Xuất file theo 200 x 120 px"
bấm Xóa ảnh                            → ảnh mất, nút Xóa ẩn đi
```

`npx tsc --noEmit` → **0 lỗi** · `npx eslint` không phát sinh lỗi mới · `npx next build` → **PASS**.

---

## File thay đổi

**Xóa:**
- `src/app/cong-cu-anh/page.tsx`
- `src/components/product-image-tool.tsx`
- `IMAGE_TOOL_V110.md`

**Sửa:**
- `src/components/erp-nav.tsx` — bỏ mục menu + icon của tab đã xóa.
- `src/components/order-form.tsx` — thay `ImageCell`: bỏ thẻ `<a>`; nút Dán ảnh / Đổi ảnh / Xóa ảnh **ngoài** ô ảnh; tự focus sau khi dán; cỡ mặc định 56 px + nút "Mặc định"; prop `onClear`.
- `src/app/guide/page.tsx` — cập nhật hướng dẫn sử dụng ảnh cho khớp giao diện mới.

---

## Lưu ý

- Kích thước ảnh vẫn lưu theo từng dòng (V131) và giới hạn 24–800 px; bấm **Mặc định** để trả về cỡ 56 px (bằng cột ảnh PDF).
- Vẫn **1 ảnh cho cả bộ cửa** (dòng cửa + phụ kiện) như V109 — mỗi dòng/bộ cửa dán một ảnh khác nhau được, nhưng một bộ chỉ có một ảnh đại diện.
- Nút **Dán ảnh** cần trình duyệt cho đọc Clipboard; nếu bị chặn, hệ thống nhắc *"hãy bấm vào ô ảnh rồi nhấn Ctrl+V"* (vẫn dán được bằng Ctrl+V như trước).
- Ảnh không có trường kích thước (đơn cũ) vẫn xuất file như trước.

---

## 3. V132.1 — bấm vào ô Ảnh để dán cho dễ

**Yêu cầu:** *"sửa lại như hình, click vào ô Ảnh để dán cho dễ"*.

**Đã sửa:**
- Ô ảnh **trống** nay là khung nét đứt **lớn** (cao 78 px, trải hết bề rộng cột) ghi rõ **"Bấm vào đây để dán ảnh"**; khi ô đang được chọn thì đổi thành **"Nhấn Ctrl+V để dán ảnh"** (viền + nền xanh) để biết đã sẵn sàng dán.
- **Bắt sự kiện dán ở cấp `window` khi ô ảnh đang được chọn** — `Ctrl+V` **luôn ăn**, kể cả khi trình duyệt không phát sự kiện `paste` cho thẻ `div` (không editable) như trước.
- Nút **Dán ảnh** hiện **cả khi chưa có ảnh** (trước đây chỉ hiện khi đã có ảnh).
- Bỏ dòng chữ *"Ctrl+V để dán"* bị trùng trong trạng thái trống.
- Sửa 2 lỗi lint phát sinh: không ghi ref khi render (đồng bộ qua `useEffect`), bỏ `role="slider"` thừa trên tay nắm kéo.

**Kiểm chứng (Chrome headless, thao tác thật):**
```
trạng thái trống            → khung cao 78 px, chữ "Bấm vào đây để dán ảnh" + nút "Dán ảnh" / "Tải ảnh"
bấm vào ô ảnh              → ô được FOCUS, chữ đổi thành "Nhấn Ctrl+V để dán ảnh"
dán ảnh (sự kiện paste)     → ảnh vào đúng ô, lưu /uploads/orders/…png, hiện 56×34 px (cỡ mặc định)
                           → chú thích "Cỡ mặc định 56 px (bề rộng cột ảnh khi xuất PDF)", đủ nút Nhỏ/Vừa/Lớn/Mặc định/Dán ảnh/Đổi ảnh/Xóa ảnh
```
`npx tsc --noEmit` → **0 lỗi** · `npx eslint` → **4 lỗi cũ** (react-hooks trong các component catalog, có từ trước) — **không phát sinh lỗi mới** · `npx next build` → **PASS**.
