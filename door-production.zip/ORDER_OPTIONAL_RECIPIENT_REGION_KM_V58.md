# ORDER OPTIONAL RECIPIENT REGION KM V58

## Mục tiêu
Bỏ chế độ **bắt buộc** cho 3 trường ở tab tạo đơn hàng: **Người nhận**, **Vùng miền**, **Số Km giao hàng**.

## Điểm quan trọng: có 2 lớp kiểm tra, phải sửa cả hai
1. **Client** — `src/components/order-form.tsx`
   - Xóa 3 mục khỏi `REQUIRED_ORDER_INFO_FIELDS` (`receiverName`, `region`, `deliveryKm`).
   - Bỏ prop `required` + `invalid` ở 3 `<Field>` tương ứng → không còn dấu `*` và không còn viền đỏ “Bắt buộc nhập”.
2. **Server** — `src/lib/order-persistence.ts` (nếu chỉ sửa client thì lưu vẫn lỗi 400)
   - Bỏ 3 trường khỏi danh sách `missing` (xóa `receiverName`/`region` khỏi `textFields`, bỏ hẳn `numberFields`).
   - `receiverName`, `region` đổi từ `requiredText(...)` → `optionalText(...)`.
   - `deliveryKm` đổi từ `requiredNonNegativeNumber(...)` → helper mới `optionalNonNegativeNumber(...)`: **bỏ trống được**, nhưng nếu có nhập thì vẫn chặn số âm. Xóa helper `requiredNonNegativeNumber` nay không còn dùng.
3. **Màn xem đơn** — `src/app/orders/[id]/page.tsx`: bỏ dấu `*` (prop `required`) ở 3 ô “Người nhận”, “Vùng miền”, “Số Km giao hàng” cho khớp trạng thái mới.

## Không thay đổi
- 10 trường bắt buộc còn lại (Mã đơn hàng, Trạng thái, Ngày cập nhật, NVKD phụ trách, Mã Đại Lý, Tên khách hàng, Ngày đặt hàng, Ngày cần giao hàng, Số điện thoại, Địa chỉ nhận hàng).
- DB/Prisma: 3 cột vốn đã nullable (`receiver_name`, `region`, `delivery_km`) → **không cần migration**.
- Công thức tiền, KH/Lượng, cước vận chuyển, file xuất Excel/PDF.

## Kiểm chứng thực tế (Postgres thật + dev server)
- **API**: `POST /api/orders` với payload **thiếu cả 3 trường** → `{"ok":true,"id":3}`; DB lưu `receiver_name = NULL`, `region = NULL`, `delivery_km = NULL`.
- **Vẫn chặn dữ liệu sai**: `deliveryKm = "-5"` → `{"ok":false,"error":"Số Km giao hàng không hợp lệ."}`.
- **Có nhập đủ** → lưu đúng (`Anh B` / `Miền Bắc` / `25`).
- **UI**: form chỉ còn **10 nhãn có dấu `*`** (trước là 13); bấm “Lưu đơn hàng” khi form trống → thông báo chỉ đòi `Mã Đại Lý, Tên khách hàng, NVKD phụ trách, Ngày cần giao hàng, Ngày cập nhật, Số điện thoại, Địa chỉ nhận hàng` (không còn 3 trường đã bỏ).
- **Lưu thật từ UI**: điền các trường bắt buộc, **để trống 3 trường này** rồi bấm Lưu → chuyển sang `/orders/5`, DB ghi `receiver_name = NULL`, `region = NULL`, `delivery_km = NULL`.
- **Màn xem đơn**: 14 nhãn, 10 có dấu `*`; “NGƯỜI NHẬN”, “VÙNG MIỀN”, “SỐ KM GIAO HÀNG” không còn dấu `*`.
- `npx tsc --noEmit`: pass. `npx eslint` 3 file: đúng bằng mức nền cũ (3 error + 3 warning), không phát sinh mới.
