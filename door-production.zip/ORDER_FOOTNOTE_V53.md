# ORDER FOOTNOTE V53

## Mục tiêu
Thêm **“Bảng ghi chú”** vào file xuất: đặt ở **trang cuối cùng, góc dưới cùng bên trái**, **chữ nhỏ chú thích, không làm nổi bật** (không viền, không nền, không màu nhấn).

## Nội dung in nguyên văn
```
Ghi chú:
Khách hàng xác nhận các thông tin sau:
- Kích thước đã trừ khe hở chưa?
- Nền có giật cấp hay không?
- Mép tường có đắp phào xi măng hay không?
- Khách hàng lên đơn lưu ý kiểm tra lại thông tin đơn hàng chăm sóc đã lên trước khi chốt cọc sx, mọi sai xót bên phía nhà máy không chịu trách nhiệm khi đã chốt cọc sx.
```

## File sửa
1. `python/reportlab_order_v2.py` — thêm hằng `FOOTNOTE_TITLE` / `FOOTNOTE_LINES` và hàm `_footnote_block()`; `_bottom_section` bọc lại thành 2 cột: **ghi chú (trái, `VALIGN BOTTOM` để dồn xuống đáy)** + **tổng hợp thanh toán (phải, giữ nguyên)**. Style mới `footnote` / `footnote_title`: 7.2pt, màu xám `MUTED`, không viền/nền; “Ghi chú:” đậm cùng cỡ.
2. `python/reportlab_order_preview.py` — import `FOOTNOTE_LINES` / `FOOTNOTE_TITLE` từ module V2 (một nguồn dữ liệu), thêm style và bố cục tương tự.
3. `src/lib/order-export-v2.ts` — thêm `FOOTNOTE_TITLE` / `FOOTNOTE_LINES`; sau khối tổng kết, ghi các dòng ghi chú vào cột **A→K**, chữ **8pt màu xám**, left, **không viền/nền**; chiều cao dòng ước lượng theo độ dài (`13 × ceil(len/140)`) để câu dài không bị Excel cắt chữ.

## Vị trí thực tế
- **PDF**: ghi chú nằm ngay dưới khối tổng kết, sát đáy trang cuối, bên trái → đúng “góc dưới cùng bên trái”.
- **Excel**: ghi chú là nội dung cuối cùng của sheet (dưới khối tổng kết), nằm ở góc dưới bên trái vùng in `A1:S…`.

## Không thay đổi
- Công thức tiền, KH/Lượng, cước vận chuyển, chiết khấu (quy tắc V51), đặt cọc, trừ kho.
- DB/Prisma, API, dữ liệu đơn hàng; bảng checklist vẫn không xuất (V52).
- Excel cũ `src/lib/order-export.ts` (nút đang ẩn) không thêm ghi chú.

## Kiểm chứng thực tế
- **Excel V2**: dựng file rồi đọc lại toàn bộ ô → có `Ghi chú:` và đủ 4 dòng, **không còn** `BẢNG CHECKLIST`, `printArea = A1:S28`; convert sang PDF bằng LibreOffice ở chế độ headless rồi trích text → đủ nguyên câu (kể cả đoạn dài kết thúc “…khi đã chốt cọc sx.”), không bị cắt.
- **PDF V2**: render `_bottom_section` + chạy thật `python3 python/reportlab_order_v2.py --input … --output …`, trích text → có `Ghi chú:` và toàn bộ nội dung, không còn `CHECKLIST`.
- **PDF preview**: kết quả tương tự.
- `npx tsc --noEmit`: pass. `npx eslint src/lib/order-export-v2.ts`: đúng 7 lỗi `no-explicit-any` có sẵn từ bản gốc. `python -m py_compile`: OK.
