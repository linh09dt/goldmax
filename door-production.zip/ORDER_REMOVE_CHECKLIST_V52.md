# ORDER REMOVE CHECKLIST V52

## Mục tiêu
1. Tab **Tạo đơn hàng / Sửa đơn hàng**: bỏ box **“Câu hỏi thêm / Xác nhận”** (6 câu hỏi kỹ thuật + dropdown xác nhận + ghi chú).
2. **Xuất Excel / PDF**: bỏ bảng **“BẢNG CHECKLIST XÁC NHẬN KỸ THUẬT VỚI ĐẠI LÝ”**. Khối **Tổng hợp giá trị đơn hàng** giữ nguyên, vẫn nằm bên phải như trước.

## File sửa
1. `src/components/order-form.tsx` — xóa card “Câu hỏi thêm / Xác nhận”; card “Tổng hợp giá trị đơn hàng” giữ nguyên vị trí (cột phải, `xl:col-start-2`).
2. `src/lib/order-export-v2.ts` — hàm `writeChecklistAndSummary` → `writeSummary`: bỏ toàn bộ phần ghi checklist (vùng `A:K`), chỉ còn khối tổng kết ở `L:S`; dòng “(Bằng chữ: …)” chiếm 2 hàng để câu tiếng Việt dài xuống dòng gọn.
3. `python/reportlab_order_v2.py` — `_bottom_section(calc)`: bỏ bảng checklist và bảng bọc `outer`; khối tổng kết đặt `hAlign="RIGHT"` để giữ đúng vị trí bên phải.
4. `python/reportlab_order_preview.py` — `_bottom_section`: bỏ bảng checklist (kể cả 6 câu hỏi mẫu khi đơn chưa có câu trả lời), giữ khối tổng kết.

## Không thay đổi
- Công thức tiền, KH/Lượng, cước vận chuyển, chiết khấu (kể cả quy tắc V51 ẩn “Tổng tiền sau chiết khấu” khi 0%), đặt cọc, trừ kho.
- DB/Prisma, API, dữ liệu `requirements` cũ vẫn nằm trong bảng `sales_order_requirements` và **vẫn được lưu khi lưu đơn** (form không còn ô nhập nên các câu trả lời để trống).
- Màn hình **xem đơn** `/orders/[id]` vẫn có mục “Câu hỏi thêm / Xác nhận” cho các đơn cũ (không thuộc phạm vi yêu cầu lần này).
- Excel cũ `src/lib/order-export.ts` (nút đang ẩn) không có bảng checklist.

## Kiểm chứng thực tế
- **Excel V2**: dựng workbook bằng `buildOrderExcelV2` rồi đọc lại toàn bộ ô:
  - không còn chuỗi `BẢNG CHECKLIST` (0 lần), không còn nội dung câu hỏi (“Nền có giật cấp…”), vùng cột A trống;
  - khối tổng kết còn nguyên: `Tổng giá trị đơn hàng` · `Đã đặt cọc` · `CÒN LẠI CẦN THANH TOÁN` và dòng `(Bằng chữ: …)`.
- **PDF V2 + PDF preview**: render và trích text → không còn chữ `CHECKLIST` ở cả 2 mẫu; khối tổng kết đúng như cũ (0% và 12%).
- **Giao diện**: chạy `next dev`, mở `/orders/new` → không còn “Câu hỏi thêm”, không còn “Chưa xác nhận”, card “Tổng hợp giá trị đơn hàng” vẫn hiển thị đủ 8 dòng và nút Lưu đơn hàng.
- `npx tsc --noEmit`: pass. `npx eslint`: đúng bằng mức nền cũ (`order-form.tsx` 4 error/11 warning, `order-export-v2.ts` 7 error — đều có sẵn từ bản gốc). `python -m py_compile`: OK.
