# V141 — BỎ XẾP LỊCH TỰ ĐỘNG, CHUYỂN SANG XẾP LỊCH BẰNG TAY

Theo yêu cầu: **gỡ chế độ sắp xếp tự động**, làm **xếp tay trước**.

---

## 1. Đã bỏ những gì

| Bỏ | Chi tiết |
|---|---|
| Nút **“Xếp lịch tự động”** | Xoá `src/components/production/schedule-button.tsx` + lời gọi trong màn *Kế hoạch sản xuất* |
| API **`POST /api/production/schedule`** | Xoá `src/app/api/production/schedule/route.ts` |
| Hàm xếp lịch | Xoá `src/lib/production/auto-schedule.ts` và `applyAutoSchedule()` + kiểu `AutoScheduleSummary` trong `service.ts` |
| Câu chữ hướng dẫn | Sửa ở *Kế hoạch tuần*, *Kế hoạch sản xuất*, và các tài liệu V137 / V139.1 |

*(Bản thiết kế cũ ở `KE_HOACH_SAN_XUAT_V136.md` mục xếp lịch tự động nay **không còn áp dụng** — giữ lại chỉ để tra cứu lịch sử.)*

## 2. Xếp lịch bằng tay — làm thế nào

Vào **Chi tiết bộ cửa** (*Kế hoạch sản xuất* → bấm **Bộ số**), bảng **“Cập nhật tiến độ theo công đoạn”** giờ có thêm cột **“Ngày KH”**:

1. Điền **Ngày KH** cho từng công đoạn (ô ngày, cạnh cột SL).
2. Bấm **Lưu tiến độ** — ghi gộp 1 lượt cho cả bộ (bài học V111).
3. **Ngày của BỘ tự suy** = ngày sớm nhất → muộn nhất của các công đoạn, nên:
   - cột **“Xếp lịch”** trên bảng kế hoạch,
   - bảng **“Tải theo tổ và ngày”**,
   - **phiếu lệnh / danh sách việc theo ngày** khi in,
   đều khớp ngay với ngày bạn gán.
4. Muốn **ghi đè ngày cấp bộ** thì nhập 2 ô **“Xếp lịch từ / đến”** ở khung trên (khi đó ngày cấp bộ lấy theo 2 ô này, không suy từ công đoạn).

**Mẹo:** các công đoạn **cùng một bước** (`seq`) — Cắt cánh / Cắt khung / Cắt phào — nên gán **cùng ngày** để phản ánh đúng việc các phần chạy song song.

**Trạng thái bộ:** chưa gán ngày và chưa làm gì ⇒ vẫn là **CHỜ XẾP LỊCH (BACKLOG)**; gán ngày rồi ⇒ **ĐÃ XẾP LỊCH**; có công đoạn bắt đầu ⇒ **ĐANG SẢN XUẤT**.

## 3. Sửa kèm: lỗi BACKLOG bị “tan” (đã biết từ SIM-1000)

`deriveSetStatus()` trước đây **luôn** biến bộ *Chờ xếp lịch* thành *Đã xếp lịch* ngay khi bấm Lưu,
dù chưa gán ngày nào ⇒ cột BACKLOG mất dần.

Nay hàm nhận thêm `hasPlan` (bộ **đã có ngày kế hoạch chưa**): **chưa có ngày thì giữ nguyên `CHO_XEP_LICH`**.
Nhờ vậy BACKLOG phản ánh đúng số bộ chưa xếp lịch.

## 4. API để gán ngày hàng loạt (khi cần)

```bash
curl -X POST "$APP_URL/api/production/sets/<setId>" -H 'Content-Type: application/json' \
  -d '{"action":"update","byName":"VP xưởng",
       "tasks":[{"id":123,"plannedStart":"2026-09-28"},
                {"id":124,"plannedStart":"2026-09-28"},
                {"id":125,"plannedStart":null}]}'
```
- `plannedStart: "YYYY-MM-DD"` = gán ngày · `null` = xoá ngày · không truyền = không đổi.
- Ngày công đoạn và **actual** (Bắt đầu/Xong thực tế) gửi chung **một lượt** như trước.

## 5. File thay đổi

| File | Việc |
|---|---|
| `src/lib/production/auto-schedule.ts` | **XOÁ** |
| `src/app/api/production/schedule/route.ts` | **XOÁ** |
| `src/components/production/schedule-button.tsx` | **XOÁ** |
| `src/lib/production/service.ts` | bỏ `applyAutoSchedule`; `TaskPatch` thêm `plannedStart`; gán ngày công đoạn + suy ngày bộ |
| `src/app/api/production/sets/[id]/route.ts` | nhận `plannedStart` của từng công đoạn |
| `src/components/production/set-progress-form.tsx` | thêm cột **Ngày KH**; chỉ gửi ngày cấp bộ khi tự sửa |
| `src/app/ke-hoach-san-xuat/bo/[id]/page.tsx` | truyền ngày KH xuống form |
| `src/lib/production/catalog.ts` | `deriveSetStatus(..., hasPlan)` giữ BACKLOG đúng |
| `src/app/ke-hoach-san-xuat/page.tsx`, `ke-hoach/page.tsx`, `production-plan-board.tsx` | bỏ nút + sửa câu chữ |
| `HUONG_DAN_TAO_LENH_SAN_XUAT_V137.md`, `NANG_LUC_THEO_CONG_DOAN_V139_1.md`, `HUONG_DAN_AP_DUNG_V139.txt`, `CHAY_THU_KE_HOACH_SAN_XUAT.md` | cập nhật hướng dẫn sang xếp tay |

## 6. Kiểm chứng

- `tsc` 0 lỗi · `eslint` (các thư mục sản xuất) 0 lỗi · `npm run build` OK.
- Unit test `deriveSetStatus`: giữ BACKLOG khi chưa có ngày; ĐÃ XẾP LỊCH khi có ngày; DANG_SX / TAM_DUNG / HOAN_THANH / DA_GIAO đúng.
- Chạy thật câu SQL gán ngày trên PostgreSQL (PGlite): gán ngày → `planned_start = planned_end`; `has_plan=false` → **giữ nguyên** ngày cũ; gửi `null` → **xoá** ngày; ngày BỘ suy đúng min/max.

## 7. Nếu sau này muốn xếp tự động trở lại

Logic cũ vẫn nằm trong lịch sử git/zip các bản trước (`auto-schedule.ts`). Khi cần, có thể làm lại bản tốt hơn
với 2 sửa đổi đã ghi nhận: **seed tải đã xếp từ các bộ có lịch** và **`planned_start` = ngày bước đầu tiên thực tế**.
