> ⚠️ **V146 (26/09/2026):** bảng **Tải theo tổ và ngày** (gồm các dòng ↳ công đoạn) đã BỎ khỏi màn Kế hoạch sản xuất.
> Năng lực theo công đoạn nay chỉ dùng cho **cảnh báo quá tải** (`QUA_TAI_CONG_DOAN`) + khai ở Cấu hình. Xem `BO_KE_HOACH_TUAN_VA_BANG_TAI_V146.md`.

# V139.1 — NĂNG LỰC CHIA THEO CÔNG ĐOẠN

Tiếp nối **V139** (tách công đoạn Cắt/Chấn/Hàn/Vân theo cánh·khung·phào). Nhà máy yêu cầu:
**năng lực (capacity) cũng phải khai theo từng công đoạn**, không chỉ theo tổ.

> ✅ **KHÔNG cần migration schema.** Cột `production_stages.capacity_per_day` / `capacity_unit`
> đã có từ V136 — nay mới được **sửa được trên UI** và **dùng thật** trong xếp lịch + bảng tải.
> Chỉ thêm 1 file SQL: `migrate-production-v139-1-nang-luc-cong-doan.sql`.

---

## 1. Trước và sau

| | Trước | Sau (V139.1) |
|---|---|---|
| Khai năng lực | Chỉ ở Tổ (`production_work_centers`) | Thêm **Năng lực/ngày** cho **từng công đoạn** ở tab Công đoạn |
| Bảng tải | 1 dòng/tổ | Mỗi tổ có **dòng con `↳` theo công đoạn**, năng lực riêng từng dòng |
| Xếp lịch | Chỉ chặn theo năng lực tổ | Chặn theo **cả** năng lực tổ **và** năng lực công đoạn |
| Cảnh báo | Quá tải tổ | Thêm cảnh báo **Quá tải công đoạn** |

## 2. Cách hiểu con số (quan trọng)

Thứ tự lấy năng lực của một công đoạn:

1. `production_stages.capacity_per_day` — nếu công đoạn **có khai** ⇒ dùng số này.
2. `production_work_centers.capacity_per_day` — nếu công đoạn **để trống** ⇒ **kế thừa năng lực tổ**.
3. Cả hai đều trống ⇒ chỉ so với ngưỡng toàn xưởng (`dailyWarnCanh` / `dailyMaxCanh`).

⇒ **Để trống = giữ nguyên hành vi cũ.** Muốn tách riêng công đoạn nào thì nhập số cho công đoạn đó.

Đơn vị tính tải là **CÁNH** (quy đổi từ số cánh × số bộ), nên năng lực công đoạn cũng khai theo cánh/ngày.

## 3. Migration `migrate-production-v139-1-nang-luc-cong-doan.sql`

- Đặt năng lực cho **Chấn cánh / Chấn khung / Chấn phào = 60 cánh/ngày**
  (khảo sát: 30 cánh/ca × 2 ca — CH7/TM3). Bằng đúng năng lực tổ máy nên **không làm hụt năng lực**;
  xưởng chạy 1 ca thì sửa lại thành `30` trong Cấu hình.
- Các công đoạn Cắt / Hàn / Vân **để trống** (kế thừa tổ), kèm ghi chú hướng dẫn.
- Idempotent — chạy lại vô hại.

## 4. File thay đổi (V139.1)

| File | Việc |
|---|---|
| `src/components/production/production-config.tsx` | tab Công đoạn: thêm ô **Năng lực/ngày** + **ĐV** |
| `src/lib/production/scheduling.ts` | **mới** `buildStageLoad()` + kiểu `StageLoadCell`; `buildWarnings()` thêm cảnh báo `QUA_TAI_CONG_DOAN` |
| `src/lib/production/auto-schedule.ts` | nhận `stages`; thêm ràng buộc năng lực theo công đoạn khi chọn ngày |
| `src/lib/production/service.ts` | `applyAutoSchedule()` nạp danh mục công đoạn và truyền vào xếp lịch |
| `src/app/ke-hoach-san-xuat/page.tsx` | bảng "Tải theo tổ và ngày": thêm dòng con theo công đoạn, hiện năng lực từng công đoạn |
| `src/components/production/production-warnings.tsx` | nhãn "Quá tải công đoạn" |
| `migrate-production-v139-1-nang-luc-cong-doan.sql` | **mới** — đặt năng lực Chấn = 60/ngày |

## 5. Cách dùng

1. **Cấu hình sản xuất → tab Công đoạn**: nhập cột *Năng lực/ngày* cho công đoạn muốn tách
   (vd `CHAN_KHUNG` = 30 nếu chỉ 1 ca). Để trống cho công đoạn nào thì công đoạn đó theo tổ.
2. **Kế hoạch sản xuất**: bảng *Tải theo tổ và ngày* hiện thêm dòng `↳ <công đoạn>` với năng lực riêng;
   ô đỏ = vượt năng lực, vàng = trên 85%.
3. **Xếp lịch bằng tay** (V141 đã BỎ xếp lịch tự động): mở một bộ → gán **Ngày KH** cho từng công đoạn → **Lưu tiến độ**.
   Năng lực công đoạn dùng để **cảnh báo quá tải trên bảng tải** và các cảnh báo đỏ/vàng, không còn tự xếp lịch.
