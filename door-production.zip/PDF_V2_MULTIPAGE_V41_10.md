# PDF V2 V41.10 - Multi-page server fix

- Prefetch ảnh sản phẩm song song trước khi ReportLab layout.
- Timeout ảnh ngắn; ảnh chậm/lỗi không làm hỏng PDF.
- Cache chỉ giữ thumbnail JPEG đã nén.
- Bỏ NumberedCanvas giữ toàn bộ page state; footer vẽ trực tiếp theo từng trang để giảm peak RAM.
- PDF V2 trên web dùng fetch để nhận lỗi rõ hơn.
- Nếu bản đầy đủ vẫn lỗi do ảnh ngoài hệ thống, tự retry `noImages=1` để người dùng vẫn lấy được PDF.
- Không đổi dữ liệu đơn hàng, Excel V2, Supabase hay schema DB.
