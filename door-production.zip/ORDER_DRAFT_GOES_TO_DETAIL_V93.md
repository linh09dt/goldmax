# V93 — Bấm “Lưu nháp” thì mở luôn trang chi tiết đơn

## Yêu cầu

> “khi nhấn nút lưu nháp thì sẽ tiếp tục đến view chi tiết đơn”

## Cách làm

Sửa hành vi sau khi lưu trong `src/components/order-form.tsx`:

- **Trước (V91):** Lưu nháp lưu xong thì **ở lại trang** (tạo mới → chuyển sang `/orders/{id}/edit` để nhập tiếp; sửa đơn → `router.refresh()`), chỉ nút Lưu đơn hàng mới mở trang chi tiết.
- **Sau (V93):** **cả hai** hành động lưu đều `router.push('/orders/{id}')` + `router.refresh()` → mở **trang chi tiết đơn**. Khác biệt duy nhất còn lại giữa 2 nút là trạng thái của đơn:
  - **Lưu nháp** → đơn ở trạng thái **Đơn hàng mẫu** (không hạ cấp đơn đã ở Sản xuất).
  - **Lưu đơn hàng** → đơn chuyển sang **Sản xuất** (cấp Bộ số).

Nhánh điều hướng `stayOnPage` đã được bỏ hẳn khỏi `save()` (không còn code chết), tooltip nút Lưu nháp và Hướng dẫn sử dụng (bước 6 + bảng thao tác) đã cập nhật theo.

## Kiểm chứng

Lần này mình chạy **test có DOM thật** (jsdom + React `createRoot`, giả lập API server) — bấm đúng nút trên form rồi kiểm tra payload gửi lên và điều hướng thực tế, không chỉ đọc code:

| Kịch bản | Payload gửi lên | Điều hướng |
|---|---|---|
| Tạo đơn mới → bấm **Lưu nháp** | `status: "NHAP"` (Đơn hàng mẫu) | `push /orders/99` (chi tiết đơn) ✓ |
| Tạo đơn mới → bấm **Lưu đơn hàng** | `status: "CHUYEN_SAN_XUAT"` (Sản xuất) | `push /orders/99` ✓ |
| Sửa đơn đang Sản xuất → bấm **Lưu nháp** | `status: "CHUYEN_SAN_XUAT"` (giữ nguyên, không hạ cấp) | `push /orders/99` ✓ |

Thêm 2 kiểm tra chống hồi quy: **không** còn điều hướng nào tới `/orders/{id}/edit`, và khi thiếu thông tin bắt buộc thì hệ thống báo lỗi và **không** gọi API lưu.

- `npx tsc --noEmit` → 0 lỗi.
- `npx eslint` 2 file sửa → 4 errors / 11 warnings, **đúng bằng bản gốc** (lỗi `react-hooks/set-state-in-effect` đã có từ trước), không phát sinh lỗi mới.

## Lưu ý

- Sau khi bấm **Lưu nháp**, bạn được đưa sang trang chi tiết đơn; muốn nhập tiếp thì bấm **Sửa** ở trang đó (trước đây V91 giữ nguyên trang nhập để nhập tiếp liền).
- Không đổi gì về trạng thái/Bộ số/DB so với V91 — chỉ đổi điểm đến sau khi lưu.

## File thay đổi

- `src/components/order-form.tsx` — bỏ nhánh `stayOnPage`, cả 2 hành động lưu đều mở trang chi tiết đơn.
- `src/app/guide/page.tsx` — cập nhật bước 6 và bảng thao tác theo hành vi mới.
