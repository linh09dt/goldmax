# ERP V5 — ĐVT, đơn giá và danh mục cấu hình

## Phạm vi
Bản V5 chỉ mở rộng Master Data và màn hình đơn hàng hiện tại, không thay đổi logic bộ cửa, import đơn hàng, câu hỏi xác nhận hoặc tính tổng đã chốt.

## Danh mục hàng hóa
Bổ sung cho `item_masters`:
- `unit`: Đơn vị tính.
- `dealer_price`: Giá đại lý.
- `price_source_file`: File nguồn giá gần nhất.
- `price_imported_at`: Thời điểm cập nhật giá.

File `đơn giá , đơn vị tính, màu.xlsx` được đối chiếu bằng Mã hàng hóa. Mã chưa có trong Item Master chỉ báo cảnh báo, không tự tạo mới.

## Danh mục cấu hình
Tạo `master_options` với 4 nhóm:
- `PAINT_COLOR`: Màu sơn.
- `OPENING_DIRECTION`: Hướng mở.
- `TRIM_DIRECTION`: Hướng phào.
- `PANEL_OPTION`: Ô thoáng / Pano / Nan chớp.

Có trang `/master-options` để thêm, sửa, ngưng sử dụng/kích hoạt lại.

## Đơn hàng
Khi chọn Mã/Tên hàng hóa:
- tự điền Mã + Tên;
- tự đề xuất ĐVT;
- tự đề xuất Giá đại lý vào Đơn giá;
- người dùng vẫn được phép sửa ĐVT/Đơn giá tại đơn hàng;
- Màu sơn, Hướng mở, Hướng phào, Ô thoáng dùng danh sách gợi ý từ Master Data và vẫn cho phép nhập tay khi cần.

Áp dụng cho cả dòng sản phẩm chính và các dòng phụ kiện/phụ phí.

## Chạy sau khi chép patch
```cmd
npm run db:generate
npm run db:migrate -- --name price_config_v5
npm run dev
```

Sau đó:
1. Mở `/items`.
2. Nếu chưa có Item Master, import `Danh mục hàng hóa.xlsx` trước.
3. Import `đơn giá , đơn vị tính, màu.xlsx` tại khối **Nhập ĐVT, đơn giá và danh mục cấu hình**.
4. Kiểm tra `/master-options`.
5. Tạo/chỉnh đơn hàng để kiểm tra tự điền ĐVT và đơn giá.
