# ORDER HEADER TUNING V70

## Yêu cầu
1. Cột **HÌNH ẢNH SP** nhỏ lại một chút để tiêu đề bảng cân đối hơn.
2. **STT** đang bị xuống dòng → cho nằm 1 dòng.
3. **TÊN SẢN PHẨM / QUY CÁCH** → đổi thành **TÊN SẢN PHẨM**.
4. **Ô TH.** → đổi thành **Ô THOÁNG**.
5. **PHÀO** bị xuống dòng → 1 dòng; **KHUÔN** cũng vậy.
6. **KT THÔNG THỦY** có 1 ô trống → điền **RỘNG**.
7. **ĐƠN GIÁ** và **THÀNH TIỀN** hẹp lại một chút (cho phép chữ "GIÁ"/"TIỀN" xuống dòng).

## Lỗi thật đứng sau yêu cầu số 6 (đã tìm ra và sửa)
Trong PDF, `header_sub` bị **lệch 1 ô kể từ V63** (khi tách "KT CỬA (MM)" thành 2 cột nhưng chỉ cập nhật nửa đầu mảng):
mảng cũ `[…, "CAO", "RỘNG", "", "", "CAO", "RỘNG", …]` → "CAO/RỘNG" của **KT THÔNG THỦY** nằm ở cột **12/13**
thay vì **11/12**, nên:
- cột 11 (sub trái của KT THÔNG THỦY) **trống**;
- chữ "RỘNG" rơi vào cột 13 = **SL** — mà SL đã được SPAN dọc (merge 2 dòng) nên **bị che mất hoàn toàn**.

Đã sửa thành `[…, "CAO", "RỘNG", "", "CAO", "RỘNG", …]` → đo lại: "CAO" ở `x=526.8–543.9` (cột 11) và "RỘNG" ở
`x=562.7–585.8` (cột 12), đều nằm dưới "KT THÔNG THỦY" ✓.

## Bề rộng cột
### PDF (`base_widths_mm`)
Trước: `[5.5, 11, 31, 23, 9, 9, 9, 10, 10.5, 10.5, 10, 10, 10, 7, 8, 14, 21, 24, 40.5]`
Sau:  `[7.5, 11, 34, 23.5, 17.5, 13, 10.5, 15.5, 10.5, 10.5, 12.5, 12.5, 13.5, 6, 8, 15, 17, 18.5, 15.5]`
Cách chọn: đo bề rộng chữ tiêu đề bằng `pdfmetrics.stringWidth(..., Roboto-Bold, 8.5)` + padding 4pt + biên 0.8pt
(script đo: STT 7.26mm, BỘ SỐ 10.33, Ô THOÁNG 16.72, HƯỚNG 12.21, PHÀO 9.83, MÀU SƠN 15.13, KHUÔN 11.88,
KT CỬA (MM) 20.41, KT THÔNG THỦY 24.96, CAO 7.74, RỘNG 9.84) rồi đặt bề rộng cột ≥ ngưỡng đó.
Các tiêu đề chấp nhận xuống dòng (KHỐI LƯỢNG, ĐƠN GIÁ (Đ), THÀNH TIỀN (Đ), HÌNH ẢNH SP) bị thu hẹp để lấy chỗ.

### Excel (`setupColumns`)
Trước: `[4.5, 9, 27, 19, 7.5, 7.5, 7.5, 8.5, 8, 8, 8, 8, 8, 5.5, 6.5, 10.5, 12.5, 14, 14.5]`
Sau:  `[5, 9, 29, 19, 10, 7.5, 7.5, 9.5, 8, 8, 8, 8, 8, 5.5, 6.5, 10.5, 11.5, 12.5, 11]`
(Tổng vẫn 194 → cỡ chữ khi fit 1 trang không đổi.)

Đổi tiêu đề: `C12:C13` → "TÊN SẢN PHẨM", `E12:E13` → "Ô THOÁNG".

## Kiểm chứng
- **PDF**: trích text dải header — `STT`, `BỘ SỐ`, `TÊN SẢN PHẨM`, `MODEL`, `Ô THOÁNG`, `HƯỚNG`, `PHÀO`, `MÀU SƠN`,
  `KHUÔN`, `SL`, `ĐVT` đều **cùng một dòng**; `CAO/RỘNG` xuất hiện **2 lần** (dưới KT CỬA và KT THÔNG THỦY);
  `KHỐI/LƯỢNG`, `ĐƠN GIÁ/(Đ)`, `THÀNH TIỀN/(Đ)`, `HÌNH ẢNH/SP` xuống 2 dòng như mong muốn.
- **Excel** (render qua LibreOffice): `STT`, `BỘ SỐ`, `TÊN SẢN PHẨM`, `MODEL`, `Ô THOÁNG`, `HƯỚNG`, `PHÀO`, `MÀU SƠN`,
  `KHUÔN`, `SL`, `ĐVT` cùng 1 dòng (y=394.2); `CAO/RỘNG` ×2 ở y=384.8; ĐƠN GIÁ (Đ) 1 dòng, THÀNH TIỀN/HÌNH ẢNH xuống dòng.
- Ảnh cột HÌNH ẢNH SP: PDF vẫn vẽ ảnh 11×11mm nên cột 15.5mm vẫn đủ chỗ (11mm + 2×3pt padding);
  Excel cột 11 ≈ 82px vẫn chứa ảnh 58px.
- `npx tsc --noEmit`: 0 lỗi. `npx eslint src/lib/order-export-v2.ts`: 7 lỗi `no-explicit-any` có sẵn từ bản gốc.
  `python -m py_compile`: OK.

## File thay đổi
- `python/reportlab_order_v2.py`
- `src/lib/order-export-v2.ts`
