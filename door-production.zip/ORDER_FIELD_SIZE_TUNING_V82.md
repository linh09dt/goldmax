# CHỈNH KÍCH THƯỚC Ô NHẬP THEO % NGƯỜI DÙNG — V82

## Việc đã làm

Áp **đúng bảng % người dùng gửi** vào 3 hàng ô nhập. Quy ước: **mốc chuẩn 1920px**, số `fr` trong code = số % người dùng ghi.

### A. Thông tin đơn hàng (13 ô)

| Ô | % | px @1920 | (thay đổi) |
| --- | --- | --- | --- |
| Mã đơn hàng | 8.0 | 127 | |
| **Trạng thái** | **13.4** | **212** | ↑ rộng gấp đôi (đủ chỗ “Chờ khách hàng xác nhận”) |
| Ngày cập nhật | 6.8 | 108 | |
| NVKD phụ trách | 7.2 | 114 | |
| **Mã Đại Lý** | **4.6** | **73** | ↓ |
| Tên khách hàng | 9.1 | 144 | |
| Ngày đặt hàng | 6.8 | 108 | |
| Ngày cần giao | 7.2 | 114 | |
| Người nhận | 6.8 | 108 | |
| Số điện thoại | 6.4 | 101 | |
| Địa chỉ nhận hàng | 11.4 | 180 | |
| **Vùng miền** | **4.7** | **74** | ↓ |
| **Số Km** | **3.1** | **49** | ↓ |

### B. Bộ cửa (17 ô)

| Ô | % | px @1920 | (thay đổi) |
| --- | --- | --- | --- |
| **Bộ số** | **7.4** | **116** | ↑ |
| **Nhóm cửa** | **9.2** | **142** | ↑ |
| **Model** | **15.2** | **236** | ↓ (trước 21.2% = 330) |
| **Ô thoáng** | **3.9** | **61** | ↑ |
| **Hướng mở** | **3.9** | **61** | ↑ |
| Phào | 4.9 | 77 | |
| Màu sơn | 4.9 | 77 | |
| Cao / Rộng / Khuôn | 4.3 | 68 | |
| TT Cao / TT Rộng | 4.9 | 77 | |
| SL bộ | 2.1 | 33 | |
| ĐVT | 3.6 | 57 | |
| KH/L | 4.9 | 77 | |
| Đơn giá | 4.9 | 74 | |
| Thành tiền | 5.6 | 88 | |

### C. Phụ kiện / chi tiết (10 ô)

| Ô | % | px @1920 | (thay đổi) |
| --- | --- | --- | --- |
| **Nhóm hàng** | **8.6** | **129** | ↓ |
| **Model** | **35.3** | **541** | ↑↑ rất rộng (trước 14.3% = 220) |
| **Cao / Rộng / Khuôn** | **4.2** | **65** | ↓ |
| **ĐVT** | **3.6** | **55** | ↓ |
| KH/Lượng | 7.9 | 122 | |
| **Đơn giá** | **7.2** | **108** | ↓ |
| **Thành tiền** | **8.2** | **126** | ↓ |
| Ghi chú | 12.9 | 156 | |

## Mức sàn (chỉ hoạt động ở màn hẹp, KHÔNG ảnh hưởng màn 1920)

`Model ≥168px · Mã Đại Lý ≥52px · Ô thoáng ≥56px · Hướng mở ≥46px · SL bộ ≥30px`
— thêm sàn cho Mã Đại Lý và Ô thoáng vì ở màn 1366–1600 nhãn của 2 ô này bị “…” khi chỉ dùng %.

## Kiểm chứng

| Khổ màn | Nhãn bị “…” | Ghi chú |
| --- | --- | --- |
| **1920 (mốc)** | **0** | đúng 100% bảng % người dùng gửi |
| 1600 | 0 | |
| 1536 | 0 | |
| 1366 | 0 | |
| 1280 | 5 nhãn (Số Km, Ô thoáng, Khuôn, TT Rộng, Thành tiền) | màn rất hẹp, có sàn nên không bị bóp thêm |

- `npx tsc --noEmit`: 0 lỗi · `next build`: **Compiled successfully** · 13 ô + 17 ô vẫn 1 hàng, không tràn ngang.

## File thay đổi

- `src/components/order-form.tsx` (3 dòng `xl:grid-cols-[...]`)
