# V122 — Bộ câu hỏi CHUẨN cho module Lên kế hoạch sản xuất

Làm lại từ đầu, **thay thế V117 + V118** khi làm module này (V118 vẫn giữ để tra cứu chi tiết theo từng tổ).
Đã gộp mọi thứ đã chốt trước đó: bảng công đoạn 5 tổ (V116) · **Bồi Lares = bước nạp chương trình cho máy cắt chuyên dụng** (V121) ·
quy tắc **“cần đầy đủ đơn”** (V120) · bài học từ quy trình cửa thép Alux (V119) · dữ liệu app đang có.

**File giao:** `artifacts/bo-cau-hoi-ke-hoach-san-xuat-v122.docx` (điền trong Word) ·
`artifacts/bo-cau-hoi-ke-hoach-san-xuat-v122.pdf` (in A4, 7 trang) · script sinh: `scripts/v122/mk_v122.py`.

---

## Cấu trúc (62 câu hỏi + 4 bảng điền)

| Phần | Nội dung | Câu |
|---|---|---|
| **A** | **6 câu chặn** — trả lời được là bắt đầu lập trình được | 6 |
| **B** | Phạm vi & điều kiện vào kế hoạch (đơn nào, bộ nào, điều kiện đủ, lệnh sản xuất) | 8 |
| **C** | Quy trình & công đoạn (thiếu công đoạn nào, song song/ghép bộ, Bồi Lares chặn Cắt, QC, thuê ngoài, đơn làm lại) | 10 |
| **D** | Thời lượng & định mức + **bảng điền thời lượng 14 dòng** (ô trống: ép cánh, lắp kính+PK, chờ khô) | 9 |
| **E** | Năng lực & nguồn lực (người/tổ, bộ/tuần, máy & khuôn, khâu kỹ thuật–CAM, chỗ để hàng chờ, giao hàng) | 7 |
| **F** | Xếp lịch, gom lô & ngoại lệ (ưu tiên, chen gấp, gom lô sơn/vân/chấn, thiếu 1–2 bộ, trễ hạn) | 12 |
| **G** | Cập nhật tiến độ & đầu ra (ai nhập ở đâu, mức nào, phiếu lệnh SX, màn hình ngày, cảnh báo, báo cáo) | 10 |
| **H** | **Bảng 17 trường dữ liệu** app cần thêm (tick Cần/Không) | — |
| **I** | **Bảng kiểm tra chéo 12 trường** app đang có — xưởng có dùng không | — |
| **J** | **Bảng 21 mặc định** nếu nhà máy chưa trả lời | — |

## 6 câu chặn (Phần A)

1. **A1** “Đầy đủ đơn” = đủ 3 phần của 1 bộ, hay đủ tất cả các bộ trong đơn? → quyết định app cho đẩy từng bộ hay bắt buộc theo đơn.
2. **A2** Đơn vị thời gian là giờ hay ngày làm việc? Có làm T7/CN?
3. **A3** Ép cánh bao lâu? Lắp kính + phụ kiện có phải công đoạn không, ai làm, bao lâu?
4. **A4** Mỗi tổ bao nhiêu người, một tuần được bao nhiêu bộ (số thực tế)?
5. **A5** Chương trình Bồi Lares theo model hay theo từng bộ? Chương trình đã có thì nạp lại mất bao lâu?
6. **A6** Ai lên kế hoạch, bao lâu một lần, bằng gì? **Xin 1 bản mẫu.**

## Cách dùng

- **Trang 1–2 (A, B, C)** → trao đổi với **quản đốc**.
- **Phần D** → đưa cho **tổ trưởng từng tổ** tự điền thời lượng; đây là phần quyết định độ chính xác của kế hoạch.
- **Phần E** → hỏi **quản đốc + kỹ thuật** (năng lực tổ, máy, khâu kỹ thuật/CAM).
- **Phần F, G** → hỏi **người đang lên kế hoạch** (thường 1 người).
- **Phần H, I** → chỉ cần tick; dùng để chốt danh sách trường dữ liệu trước khi viết migration.
- **Phần J** → để đối chiếu: nhà máy không trả lời được thì app vẫn chạy theo mặc định này.

## Sinh lại tài liệu

```bash
python3 dp/scripts/v122/mk_v122.py     # -> artifacts/bo-cau-hoi-ke-hoach-san-xuat-v122.docx
libreoffice --headless --convert-to pdf --outdir artifacts artifacts/bo-cau-hoi-ke-hoach-san-xuat-v122.docx
```
