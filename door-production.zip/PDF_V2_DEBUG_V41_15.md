# PDF V2 Debug V41.15

Endpoint: `/api/order_pdf_v2_debug`

Không thay đổi logic xuất PDF V2 hiện tại. Endpoint chỉ chẩn đoán và luôn cố gắng trả JSON.

Test theo thứ tự:

- `?test=runtime`
- `?test=imports`
- `?test=font`
- `?orderId=14&test=db`
- `?orderId=14&test=data`
- `?orderId=14&test=build&noImages=1&limit=1`
- tăng `limit=2`, `4`, `6`, `8`, ... cho tới khi lỗi
- `?orderId=14&test=build&noImages=1` để build toàn bộ đơn không ảnh
- `?orderId=14&test=all&noImages=1`

Nếu nhận JSON `ok:false`, gửi toàn bộ JSON để thấy `failedStage` và traceback.
Nếu nhận trang HTML 500 của Vercel, function bị kill ngoài Python; limit cuối cùng chạy được sẽ chỉ ra ngưỡng dữ liệu/phân trang.
