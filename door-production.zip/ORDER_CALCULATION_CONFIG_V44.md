# ORDER CALCULATION CONFIG V44

## Mục tiêu

Đưa logic KH/Lượng và đề xuất kích thước phụ kiện ra khỏi hard-code để người dùng tự gán đúng cho Nhóm hàng hoặc Model/Hàng hóa.

## Nơi cấu hình

Menu **Cấu hình tính toán** (`/calculation-config`).

Cấu hình được lưu trong bảng `system_settings`, key `ORDER_CALCULATION_CONFIG_V1`; không cần thay đổi Prisma schema/migration.

## Thứ tự áp dụng

1. Bộ cửa chính dùng rule `MAIN`.
2. Dòng phụ kiện: rule `ITEM` (Model/Hàng hóa) ưu tiên hơn rule `GROUP`.
3. Trường để `Kế thừa` sẽ lấy từ rule Nhóm hàng.
4. Không có rule phù hợp => KH/Lượng nhập tay; Cao/Rộng giữ nguyên.

## Rule KH/Lượng

- `MANUAL`: nhập tay.
- `DOOR_AREA`: `(Cao × Rộng) / 1.000.000`.
- `TRIM_LINEAR`: `(Cao × 2 + Rộng) / 1.000`; Cao/Rộng trống được tính là 0 nếu còn một kích thước hợp lệ.
- `PANEL_COUNT`: lấy số từ Ô thoáng của Bộ cửa cha (`3TK -> 3`, `2TK -> 2`, `1TK -> 1`).
- `PARENT_QUANTITY`: lấy SL bộ của Bộ cửa cha.
- `INHERIT`: kế thừa rule từ Nhóm hàng (dùng cho cấu hình Model).

## Đề xuất input Cao/Rộng

Mỗi Model có thể cấu hình riêng:

- `KEEP`: nhập tay / giữ giá trị hiện tại.
- `PARENT_HEIGHT`: lấy Cao của Bộ cửa cha.
- `PARENT_WIDTH`: lấy Rộng của Bộ cửa cha.
- `CLEAR`: để trống.
- `INHERIT`: kế thừa Nhóm hàng.

Mẫu gợi ý tạo tự động từ Danh mục hàng hóa:

- Phào rời: Cao = Cao cửa, Rộng = Rộng cửa.
- Phào biệt thự đứng: Cao = Cao cửa, Rộng = trống.
- Phào biệt thự ngang: Cao = trống, Rộng = Rộng cửa.
- Phào biệt thự đỉnh: Cao = trống, Rộng = Rộng cửa.

## Làm tròn

Số chữ số thập phân của KH/Lượng cấu hình từ 0 đến 4; mặc định 2.

## Lưu ý

Đề xuất Cao/Rộng chỉ được áp dụng khi chọn Model/Hàng hóa. Sau khi hệ thống điền, người dùng vẫn sửa tay được. Không thay đổi DB đơn hàng, API đơn hàng, giá, PDF hay Excel.
