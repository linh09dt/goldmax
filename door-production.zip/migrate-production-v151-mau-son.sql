-- ============================================================================
-- V151 — DANH MỤC MÀU SƠN + NHÓM MÀU CHÍNH (để GOM LÔ SƠN)
--
-- Vì sao: nhiều mã màu khác nhau nhưng cùng một NHÓM CHÍNH (Đỏ / Vàng / Cát chay)
-- thì sơn CHUNG MỘT LÔ được. Trước đây engine chỉ gom theo MÀU CHÍNH XÁC nên
-- mỗi ngày Sơn vẫn ~6 màu. Có nhóm chính rồi thì gom lô theo nhóm (3 nhóm).
--
-- Lưu ý kỹ thuật: hai màu KHÁC CHẾ ĐỘ NUNG (nhiệt độ/thời gian) KHÔNG gom chung lô.
--   GM01…GM12 = 176°C / 20 phút  |  GM11, GM14 = 200°C / 10 phút
--
-- Chạy trên Supabase → SQL Editor → dán cả file → Run.
-- Idempotent: chạy lại nhiều lần vô hại. ON CONFLICT DO NOTHING ⇒ KHÔNG ghi đè
-- những gì bạn đã sửa trên màn Cấu hình sản xuất → Màu sơn.
-- ============================================================================

CREATE TABLE IF NOT EXISTS "production_paint_colors" (
  "id"            serial PRIMARY KEY,
  "code"          varchar(40)  NOT NULL,           -- mã ĐÃ CHUẨN HOÁ: "GM-01" → "GM01"
  "label"         varchar(80)  NOT NULL,           -- mã như xưởng gọi
  "color_name"    varchar(80),                     -- Đỏ / Vàng / Cát chay …
  "family"        varchar(40),                     -- DO | VANG | CAT_CHAY | KHAC (rỗng = chưa rõ)
  "spec_code"     varchar(60),                     -- mã màu / ký hiệu NCC
  "temp_c"        integer,                         -- nhiệt độ nung (°C)
  "minutes"       integer,                         -- thời gian nung (phút)
  "needs_veneer"  boolean      NOT NULL DEFAULT true,
  "sort_order"    integer      NOT NULL DEFAULT 0,
  "active"        boolean      NOT NULL DEFAULT true,
  "note"          text,
  "created_at"    timestamp    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at"    timestamp    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS "production_paint_colors_code_key"
  ON "production_paint_colors" ("code");

-- ----------------------------------------------------------------------------
-- SEED — bảng màu xưởng cung cấp (26/09/2026)
-- ----------------------------------------------------------------------------
INSERT INTO "production_paint_colors"
  ("code", "label", "color_name", "family", "spec_code", "temp_c", "minutes", "needs_veneer", "sort_order", "note")
VALUES
  ('GM01', 'GM-01', 'Đỏ',       'DO',       '8011',       176, 20, true,  10, NULL),
  ('GM03', 'GM-03', 'Đỏ',       'DO',       '8033',       176, 20, true,  30, NULL),
  ('GM04', 'GM-04', 'Đỏ',       'DO',       '806-13',     176, 20, true,  40, NULL),
  ('GM05', 'GM-05', 'Đỏ',       'DO',       '80413',      176, 20, true,  50, NULL),
  ('GM06', 'GM-06', 'Vàng',     'VANG',     '8011',       176, 20, true,  60, NULL),
  ('GM08', 'GM-08', 'Đỏ',       'DO',       '810-2',      176, 20, true,  80, NULL),
  ('GM09', 'GM-09', 'Vàng',     'VANG',     '806-13',     176, 20, true,  90, NULL),
  ('GM10', 'GM-10', 'Vàng',     'VANG',     '8028',       176, 20, true, 100, NULL),
  ('GM11', 'GM-11', NULL,        NULL,      NULL,         200, 10, false, 110,
   'Chưa rõ nhóm màu chính — 200°C/10'' nên KHÔNG gom chung với nhóm 176°C/20''. Xác nhận nhóm rồi điền.'),
  ('GM12', 'GM-12', 'Đỏ',       'DO',       '8017',       176, 20, true, 120, NULL),
  ('GM14', 'GM-14', 'Cát chay', 'CAT_CHAY', 'MF04-125/P', 200, 10, false, 130,
   'Cát chay: 200°C/10'' — chế độ nung khác nhóm Đỏ/Vàng nên gom lô riêng.')
ON CONFLICT ("code") DO NOTHING;

-- 3 mã màu ĐANG CÓ TRONG ĐƠN nhưng CHƯA có trong bảng xưởng gửi → tạo sẵn để bạn điền.
INSERT INTO "production_paint_colors"
  ("code", "label", "color_name", "family", "spec_code", "temp_c", "minutes", "needs_veneer", "sort_order", "note")
VALUES
  ('GM02', 'GM-02', NULL, NULL, NULL, NULL, NULL, true, 20, 'Có trong đơn nhưng chưa có trong bảng màu xưởng gửi — xác nhận màu + nhóm chính.'),
  ('GM07', 'GM-07', NULL, NULL, NULL, NULL, NULL, true, 70, 'Có trong đơn nhưng chưa có trong bảng màu xưởng gửi — xác nhận màu + nhóm chính.'),
  ('GM13', 'GM-13', NULL, NULL, NULL, NULL, NULL, true, 125, 'Có trong đơn nhưng chưa có trong bảng màu xưởng gửi — xác nhận màu + nhóm chính.')
ON CONFLICT ("code") DO NOTHING;

-- ============================================================================
-- KIỂM TRA SAU KHI CHẠY
-- ============================================================================

-- 1) Danh mục màu sơn (kỳ vọng 14 dòng)
SELECT code, label, color_name, family, spec_code, temp_c, minutes, needs_veneer, active
  FROM "production_paint_colors" ORDER BY sort_order, code;

-- 2) Màu trong ĐƠN chưa khớp được danh mục (kỳ vọng: rỗng)
SELECT s.paint_color, count(*) AS so_bo
  FROM "production_sets" s
 WHERE s.paint_color IS NOT NULL
   AND upper(regexp_replace(s.paint_color, '[^A-Za-z0-9]', '', 'g'))
       NOT IN (SELECT code FROM "production_paint_colors")
 GROUP BY 1 ORDER BY 2 DESC;

-- 3) Số bộ theo NHÓM MÀU CHÍNH (cơ sở để gom lô)
SELECT coalesce(p.family, '(chưa rõ nhóm)') AS nhom_chinh,
       count(*) AS so_bo,
       count(DISTINCT coalesce(s.paint_color, '')) AS so_ma_mau
  FROM "production_sets" s
  LEFT JOIN "production_paint_colors" p
         ON p.code = upper(regexp_replace(s.paint_color, '[^A-Za-z0-9]', '', 'g'))
 GROUP BY 1 ORDER BY 2 DESC;
