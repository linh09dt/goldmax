# ERP V12 - Danh sách đơn hàng theo cấu trúc MISA

## Thay đổi

- Tab **Quản lý đơn hàng** hiển thị dạng bảng chi tiết theo file `Danh sách đơn hàng.xlsx`.
- Mỗi dòng là một dòng hàng hóa của đơn, gồm cả dòng sản phẩm chính và dòng phụ kiện/chi tiết.
- Chỉ hiển thị dòng có `KH/Lượng > 0`, thống nhất với trang chi tiết và xuất Excel/PDF.
- Lặp lại thông tin đầu đơn trên từng dòng để dễ lọc/đối chiếu theo kiểu ERP/MISA.
- Giữ `Trạng thái`, `Sửa`, `Xóa` ở tab quản lý.
- Dòng sản phẩm chính được tô nền nhẹ để phân biệt với phụ kiện.
- Không thay đổi database schema.

## Cài đặt

Giải nén chồng lên bản V11 hiện tại rồi chạy:

```cmd
rmdir /s /q .next
npm run dev
```

Không cần chạy migrate.
