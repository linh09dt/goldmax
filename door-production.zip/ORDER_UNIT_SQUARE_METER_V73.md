# ORDER UNIT SQUARE METER V73

## Yêu cầu
Ô đơn vị **m2** trong file xuất phải hiển thị thành **m²** (số 2 nhỏ nằm phía trên, ký hiệu mét vuông).

## Cách làm
Thêm hàm chuẩn hoá đơn vị hiển thị (giữ nguyên dữ liệu gốc trong DB, chỉ đổi lúc in):

- **PDF V2** (`python/reportlab_order_v2.py`):
  ```python
  UNIT_LABELS = {"m2": "m²"}   # ký tự ² thật (U+00B2)

  def format_unit(value):
      text = clean(value)
      return UNIT_LABELS.get(text.strip().lower(), text)
  ```
  Dùng cho ô ĐVT trong bảng dữ liệu: `para(format_unit(row.get("unit")), ...)`.
- **Excel V2** (`src/lib/order-export-v2.ts`): thêm `formatUnit()` — `/^m2$/i` → `"m\u00B2"`, dùng cho ô ĐVT.
- **Preview PDF** (`python/reportlab_order_preview.py`): import `format_unit` từ module V2 và dùng cho ô ĐVT
  (để bản preview không lệch với bản xuất chính).

Không phân biệt hoa/thường: `m2`, `M2` đều ra `m²`. Các đơn vị khác (`md`, `bộ`, `ô`, `m3`…) giữ nguyên.

## Kiểm chứng
- **Font**: kiểm tra trực tiếp 4 file font tĩnh (`python/fonts/Roboto-*.ttf`) đều có glyph `U+00B2` (`²`) → không bị ô vuông/mất chữ.
- **PDF V2**: trích text toạ độ → ô ĐVT trả về `'m²'` với codepoint `['0x6d', '0xb2']` (= m + ²); các ô `md`, `Ô` giữ nguyên.
- **Excel V2**: đọc lại workbook → `O14 = "m²"` với input `m2`, `O16 = "m²"` với input `M2`, `md` giữ nguyên.
  Render qua LibreOffice cũng ra `'m²'` (codepoint `0xb2`) — hết ô vuông.
- **Preview PDF**: trích text chỉ gặp `'m²'`, không còn `'m2'`.
- Ảnh `unit_m2_v73.png`: cột ĐVT của PDF V2 (nhìn rõ số 2 nhỏ phía trên).
- `npx tsc --noEmit`: 0 lỗi. `npx eslint src/lib/order-export-v2.ts`: 7 lỗi `no-explicit-any` có sẵn từ bản gốc.
  `python -m py_compile` cả 2 module: OK.

## File thay đổi
- `python/reportlab_order_v2.py`
- `python/reportlab_order_preview.py`
- `src/lib/order-export-v2.ts`

## Ghi chú
- Chỉ đổi ở **khâu in file**. Giao diện trong app (màn xem đơn, form tạo đơn) vẫn hiển thị `m2` như dữ liệu gốc.
  Nếu muốn đổi cả giao diện thì nói, mình thêm hàm format dùng chung.
- Muốn thêm `m3 → m³` thì chỉ cần thêm 1 dòng vào `UNIT_LABELS` (PDF) và `formatUnit` (Excel).
