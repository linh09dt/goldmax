# V106 — Đồng bộ UI trang Theo dõi doanh thu với các tab khác

## Yêu cầu

> “theo dõi doanh thu, bảng nhìn hơi thô, không đồng bộ UI với các tab khác”

## Cái gì đang “thô” / lệch

| Chỗ | Trước | Vấn đề |
|---|---|---|
| Header bảng | `bg-[#a9bee1]` — **màu tự chế, không dùng ở đâu khác** | lệch hẳn hệ bảng của app |
| Đường kẻ ô | `border-slate-300/500` **kẻ cả dọc lẫn ngang** | kiểu bảng tính, nặng mặt |
| Số tiền | không `tabular-nums`, canh lẫn lộn | **cột số không thẳng**, đọc mỏi |
| Chân bảng | **không có dòng tổng** | bảng “cụt”, thiếu kết luận |
| Cỡ chữ | 10px, padding `py-2` mỗi ô | dày, khó đọc |
| Thanh lọc | nhãn chữ thường 12px, ô cao `h-10`, nút Lọc/Xóa lọc | khác kiểu thanh lọc mới của tab Quản lý đơn hàng |
| Ô tổng | thẻ `rounded-xl p-4 shadow-sm`, nhãn 12px, số 20px | khác kiểu ô tổng hợp ở tab Quản lý đơn hàng |

## Đã đồng bộ theo đúng hệ UI của app

**1. Hai bảng dùng luôn hệ bảng chuẩn `erp-table` + `erp-table-full`** (chính là hệ bảng tab **Cấu hình** đang dùng, khai báo trong `globals.css`):

- header **nền đậm, chữ IN HOA** nhỏ (10,5px) — thay màu `#a9bee1` tự chế;
- dòng chỉ còn **kẻ ngang mảnh** (`border-b border-slate-100`), hover xanh nhạt;
- ô số dùng `erp-td-num` → **canh phải + `tabular-nums`**, các cột tiền thẳng cột với nhau;
- ô chữ đậm dùng `erp-td-strong`; chữ dài tự xuống dòng (`overflow-wrap: anywhere`), **không kéo bảng rộng ra**.

**2. Thêm dòng “TỔNG CỘNG” cuối mỗi bảng** (nền xám nhạt, đậm):

- Bảng theo đơn: tổng tiền · **% chiết khấu bình quân** + tiền chiết khấu · tổng sau CK · đặt cọc · còn lại.
- Bảng sản phẩm: tổng doanh thu.

**3. Thanh lọc xếp lại đúng kiểu tab Quản lý đơn hàng:** lưới 12 cột, nhãn **IN HOA 10px**, ô cao đều `h-9`, nút `Lọc / Xoá lọc` cùng cỡ, ô chọn ghi rõ **“Tất cả đại lý” / “Tất cả khách hàng”**, và nút **“⤓ Xuất Excel doanh thu”** chuyển vào thanh lọc (giống tab đơn).

**4. 5 ô tổng dùng đúng kiểu ô tổng hợp của tab Quản lý đơn hàng:** nhãn IN HOA 9,5px + số 15px đậm `tabular-nums`; ô **“Còn lại”** được làm nổi (viền + nền xanh nhạt) đúng như ô “Còn phải thu”.

**5. Tiêu đề mỗi bảng** gọn lại (`px-4 py-3`, tiêu đề 13px đậm + dòng ghi chú 11px) và thêm **số lượng ở góc phải** (`2 đơn`, `3 sản phẩm`).

## Kiểm chứng (chạy thật)

Dựng Prisma giả rồi **chạy chính trang doanh thu** (2 đơn sản xuất + 1 đơn hàng mẫu để chắc vẫn lọc đúng):

```
OK   2 bảng dùng hệ bảng chuẩn của app (erp-table)     OK   nút xuất Excel nằm trong thanh lọc
OK   đã bỏ màu header tự chế #a9bee1                   OK   5 ô tổng dùng nhãn IN HOA nhỏ
OK   ô số dùng erp-td-num (thẳng cột số) — 28 ô        OK   ô "Còn lại" được làm nổi
OK   bảng đơn có dòng TỔNG CỘNG (2 đơn)                OK   tiêu đề bảng có số đơn / số sản phẩm
OK   bảng sản phẩm có dòng TỔNG CỘNG (3 sản phẩm)      OK   vẫn đủ 11 + 9 cột
OK   tổng tiền 104.792.815 đ · % CK tổng 10,32%        OK   khi rỗng: không hiện dòng tổng
OK   thanh lọc ghi rõ "Tất cả đại lý/khách hàng"       OK   khi rỗng: vẫn đủ câu báo rỗng + 2 bảng
```

**Đo trong trình duyệt:** cả 2 bảng khớp bề rộng vùng chứa (944px), **không phát sinh cuộn ngang**, header/nút/cột số canh đúng.

**Ảnh `revenue-ui-v106.png`** — TRƯỚC/SAU (bản TRƯỚC copy nguyên văn từ gói V103 để so cho công bằng).

**`npm run build` → PASS**, `npx tsc --noEmit` → 0 lỗi, `npx eslint` → 0 errors / 0 warnings.

## Lưu ý

- **Không đổi nghiệp vụ, không đổi dữ liệu**: vẫn đúng các tham số lọc (ngày/tháng/năm/từ/đến/đại lý/khách hàng), vẫn chỉ tính đơn đã vào sản xuất (V103), cột “Loại ĐH” vẫn theo trạng thái thật (V102). File Excel xuất ra không đổi.
- Chỉ đổi **giao diện** và **vị trí nút “Xuất Excel doanh thu”** (từ góc phải tiêu đề bảng → trong thanh lọc, giống tab Quản lý đơn hàng). Nếu bạn thích nút nằm ở tiêu đề bảng như cũ thì nói, mình đưa về.

## File thay đổi

- `src/app/revenue/page.tsx` — thanh lọc kiểu lưới 12 cột, 2 bảng dùng `erp-table`, ô tổng + tiêu đề đồng bộ, thêm dòng “TỔNG CỘNG”.
