# V41.36 – Fix build cho card chi tiết/phụ kiện

## Lỗi
Next.js/TypeScript báo lỗi tại `<details>` vì HTML details không có prop `defaultOpen`.

## Sửa
- File: `src/components/order-form.tsx`
- Thay `defaultOpen={...}` bằng state React `isOpen`.
- `<details>` dùng `open={isOpen}` + `onToggle`.
- Giữ nguyên UX đã chốt:
  - 3 dòng chi tiết đầu mở sẵn.
  - Dòng mới mở sẵn.
  - Người dùng vẫn đóng/mở accordion bình thường.

Không thay đổi logic giá, dữ liệu, API, DB, export hay layout khác.
