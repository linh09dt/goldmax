# ORDER_EXPORT_V2_REPORTLAB_V41_2

- Sửa font tiếng Việt PDF V2 trên Vercel: thêm dependency `fontpkg-roboto` và không fallback sang Helvetica thiếu glyph.
- Đổi tiêu đề PDF V2 thành `THÔNG TIN ĐƠN HÀNG`.
- Xóa toàn bộ khu vực ký xác nhận 3 bên ở cuối PDF V2.
- Phóng lớn logo GOLDMAX; crop vùng trong suốt trước khi render.
- Mở rộng cột `GHI CHÚ KỸ THUẬT`, cho phép row tự tăng chiều cao và căn top để không mất nội dung.
- Giữ nguyên Excel/PDF cũ, Excel V2 và logic dữ liệu/Supabase.
- PDF V2 vẫn tự chia 1-2+ trang A4 ngang, lặp header bảng.
