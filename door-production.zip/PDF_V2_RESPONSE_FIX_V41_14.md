# PDF V2 V41.14

- Bỏ header `Connection: close` khỏi Python Function.
- Bỏ `Content-Length` thủ công cho binary PDF; để Vercel runtime đóng gói response.
- Giữ một lần `wfile.write()` cho PDF.
- Thêm `?diag=smoke` để test riêng Python runtime + binary PDF response, không chạm DB.
- Giữ `?diag=build` để test DB + ReportLab nhưng chỉ trả JSON nhỏ.
- Không thay layout PDF V2 / Excel V2 / Supabase schema.
