-- ============================================================================
-- V143 — KHÔI PHỤC NGOẠI LỆ "MÀU SƠN 11 VÀ 14 KHÔNG CẦN VÂN" (LK5)
--
-- LỖI ĐÃ XẢY RA (do V139 — tách công đoạn theo phần):
--   • Công đoạn cũ `VAN` có `skip_condition = 'PAINT_COLOR:11,14'` (V136, mục LK5).
--   • V139 tạo `VAN_CANH` / `VAN_KHUNG` / `VAN_PHAO` với `skip_condition = NULL` rồi XOÁ `VAN`
--     ⇒ NGOẠI LỆ BỊ MẤT: mọi bộ đều phải làm vân, kể cả màu 11 và 14.
--   • Ngoài ra đơn hàng ghi màu kèm tiền tố (`GM-11`, `GM-14`) còn điều kiện ghi theo số (`11`, `14`)
--     nên phép so cũ (so chuỗi tuyệt đối) cũng KHÔNG BAO GIỜ khớp ⇒ phải so thêm PHẦN SỐ.
--     (Phần này đã sửa trong code: `paintColorMatches()` ở `src/lib/production/catalog.ts`.)
--
-- File này: IDEMPOTENT, KHÔNG bảng tạm, mỗi câu tự chứa — dán cả file vào SQL Editor được,
--   chạy từng câu một (autocommit / pooler) cũng được.
--
-- ⚠️ Chạy SAU khi deploy code mới (code cũ hiểu `skip_condition` như cũ — không sao, chỉ là
--    code cũ vẫn so chuỗi tuyệt đối nên chỉ đúng khi màu sơn ghi đúng '11'/'14').
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) Khôi phục điều kiện bỏ qua cho 3 công đoạn VÂN
--    (chỉ đắp khi đang NULL — không ghi đè nếu xưởng đã tự sửa ở Cấu hình sản xuất)
-- ----------------------------------------------------------------------------
UPDATE "production_stages"
SET "skip_condition" = 'PAINT_COLOR:11,14',
    "updated_at"     = now()
WHERE "code" IN ('VAN_CANH', 'VAN_KHUNG', 'VAN_PHAO')
  AND "skip_condition" IS NULL;

-- ----------------------------------------------------------------------------
-- 2) Sửa câu ghi chú nói SAI ở V139 ("Tất cả các cửa đều đi qua công đoạn này.")
-- ----------------------------------------------------------------------------
UPDATE "production_stages"
SET "note"       = replace("note",
                           'Tất cả các cửa đều đi qua công đoạn này.',
                           'Màu sơn 11 và 14 KHÔNG cần vân (tự bỏ qua).'),
    "updated_at" = now()
WHERE "code" IN ('VAN_CANH', 'VAN_KHUNG', 'VAN_PHAO')
  AND "note" LIKE '%Tất cả các cửa đều đi qua công đoạn này.%';

-- ----------------------------------------------------------------------------
-- 3) SỬA DỮ LIỆU ĐANG SAI: công đoạn vân của bộ thuộc màu 11 / 14 mà còn "Chưa làm"
--    → "Bỏ qua" (chỉ đổi dòng CHƯA_LÀM; dòng đã XONG thì GIỮ NGUYÊN, không xoá lịch sử).
-- ----------------------------------------------------------------------------
UPDATE "production_tasks" t
SET "status"     = 'BO_QUA',
    "updated_at" = now()
FROM "production_sets" s
WHERE t."set_id" = s."id"
  AND t."stage_code" IN ('VAN_CANH', 'VAN_KHUNG', 'VAN_PHAO')
  AND t."status" = 'CHUA_LAM'
  AND s."paint_color" IS NOT NULL
  AND regexp_replace(upper(btrim(s."paint_color")), '[^0-9]', '', 'g') IN ('11', '14');

-- ----------------------------------------------------------------------------
-- 4) TÍNH LẠI % và TRẠNG THÁI cho các bộ màu 11/14 — đúng công thức của app
--    (`percentDoneOf` + `deriveSetStatus` trong `src/lib/production/catalog.ts`):
--      • chỉ tính công đoạn KHÔNG phải BO_QUA và KHÔNG phải khoảng CHỜ
--      • % = làm tròn(XONG / tổng phải làm × 100)
--      • TAM_DUNG > HOAN_THANH (đủ) > DANG_SX (có dòng đã bắt đầu) > theo ngày kế hoạch
--    Chỉ chạy cho bộ màu 11/14 — đúng nhóm bị ảnh hưởng.
--    (Ngày "hoàn thành SX" sẽ được đóng dấu lần sau khi mở bộ và bấm Lưu — SQL không tự đóng.)
-- ----------------------------------------------------------------------------
UPDATE "production_sets" s
SET "percent_done" = sub."percent",
    "status"       = CASE
        WHEN s."status" IN ('HUY', 'DA_GIAO') THEN s."status"
        WHEN sub."total" = 0 THEN 'CHO_XEP_LICH'
        WHEN sub."tam_dung" > 0 THEN 'TAM_DUNG'
        WHEN sub."xong" = sub."total" THEN 'HOAN_THANH'
        WHEN sub."started" > 0 THEN 'DANG_SX'
        WHEN s."status" IN ('CHO_XEP_LICH', 'DA_XEP_LICH')
             THEN CASE WHEN s."planned_start" IS NULL THEN 'CHO_XEP_LICH' ELSE 'DA_XEP_LICH' END
        ELSE s."status"
    END,
    "updated_at"   = now()
FROM (
    SELECT t."set_id",
           count(*)                                                   AS "total",
           count(*) FILTER (WHERE t."status" = 'XONG')                AS "xong",
           count(*) FILTER (WHERE t."status" = 'TAM_DUNG')            AS "tam_dung",
           count(*) FILTER (WHERE t."status" IN ('XONG', 'DANG_LAM')) AS "started",
           CASE WHEN count(*) = 0 THEN 0
                ELSE round(100.0 * count(*) FILTER (WHERE t."status" = 'XONG') / count(*))::int
           END                                                        AS "percent"
    FROM "production_tasks" t
    WHERE t."status" <> 'BO_QUA' AND t."stage_kind" <> 'CHO'
    GROUP BY t."set_id"
) sub
WHERE s."id" = sub."set_id"
  AND s."paint_color" IS NOT NULL
  AND regexp_replace(upper(btrim(s."paint_color")), '[^0-9]', '', 'g') IN ('11', '14');

-- ----------------------------------------------------------------------------
-- 5) KIỂM TRA SAU KHI CHẠY
--    a) 3 công đoạn vân đã có điều kiện bỏ qua:
--       SELECT "code", "skip_condition" FROM production_stages
--        WHERE "code" IN ('VAN_CANH','VAN_KHUNG','VAN_PHAO');
--       --  kỳ vọng: PAINT_COLOR:11,14 cả 3 dòng
--    b) Không còn công đoạn vân "Chưa làm" ở bộ màu 11/14:
--       SELECT count(*) FROM production_tasks t JOIN production_sets s ON s.id = t.set_id
--        WHERE t.stage_code IN ('VAN_CANH','VAN_KHUNG','VAN_PHAO') AND t.status = 'CHUA_LAM'
--          AND regexp_replace(upper(btrim(s.paint_color)), '[^0-9]', '', 'g') IN ('11','14');
--       --  kỳ vọng: 0
-- ----------------------------------------------------------------------------
