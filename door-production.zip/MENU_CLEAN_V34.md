# ERP V34 - Xóa menu Tạo đơn hàng mẫu

- Xóa mục `Tạo đơn hàng mẫu` khỏi sidebar.
- Giữ nguyên route `/orders/new` vì chức năng tạo đơn vẫn được gọi từ tab `Quản lý đơn hàng`.
- Không thay đổi logic tạo đơn, import Excel, database hay quyền truy cập.
- Không cần migrate database.
