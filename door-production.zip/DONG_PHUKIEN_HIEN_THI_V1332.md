# V133.2 — Dòng phụ kiện/chi tiết bị ẩn khi không điền "Số KH/Lượng"

## Hiện tượng (bạn báo)

- Tạo đơn **chỉ nhập phụ kiện/chi tiết**, không nhập dòng bộ cửa → trang chi tiết đơn hiện **"Chi tiết từng bộ cửa (0)"**, không thấy dòng nào; **xuất Excel/PDF cũng mất dòng đó**.
- Bạn đã kiểm tra lại: **do không nhập "Số KH/Lượng" nên không hiện**; nhập vào thì hiện.

## Nguyên nhân

Cả 3 nơi đều lọc dòng bằng `hasPricingQuantity()` — tức **chỉ nhận dòng có "Số KH/Lượng" > 0**:

| Nơi | Hàm |
|---|---|
| Trang chi tiết đơn | `src/app/orders/[id]/page.tsx` |
| Mọi file xuất Excel V1/V2, trang in | `buildOutputGroups()` trong `src/lib/order-output.ts` |
| File PDF V2 | `build_groups()` trong `python/reportlab_order_v2.py` (`has_pricing`) |

Quy tắc này trái với thiết kế gốc **ORDER_DETAIL_V4**: *"chỉ hiện các dòng thực sự có dữ liệu"* — dòng mẫu rỗng (`0`, `-`, `—`, `#N/A`) mới bị ẩn. Vì đòi "Số KH/Lượng", dòng phụ kiện nhập tay mà bỏ trống ô đó bị coi như rỗng ⇒ biến mất; và nếu **không có dòng bộ cửa nào** có KH/Lượng thì cả đơn ra **(0)**.

## Đã sửa

Thay điều kiện "có Số KH/Lượng" bằng **"có dữ liệu thật"**, dùng chung một quy tắc cho cả TS và Python:

- Thêm `hasRowContent(row)` (`src/lib/order-output.ts`) = `isMeaningfulOrderDetail(row, { ignoreSetNo: true })`.
- `isMeaningfulOrderDetail` (`src/lib/order-detail.ts`) nay nhận tùy chọn `ignoreSetNo`: **Bộ số do hệ thống tự sinh nên không tính là "có dữ liệu"** — nếu tính, mọi thẻ bộ cửa trống đều lọt vào chi tiết/xuất file.
- Dòng được coi là có dữ liệu khi có một trong: mã hàng, model, hướng mở/thanh nẹp/màu sơn, các kích thước, thông tin pano, nẹp, khóa, song cửa, số cánh, số lượng, đơn vị, **KH/Lượng**, đơn giá, thành tiền, ghi chú, ảnh… hoặc có tên hàng không nằm trong danh sách nhãn mẫu.
- Python: thêm `has_row_content()` + `ROW_CONTENT_FIELDS` (không có `setNo`), dùng trong `build_groups()` thay `has_pricing()`.
- Sửa nhãn trên thẻ bộ cửa: *"N dòng chi tiết có KH/Lượng"* → **"N dòng chi tiết"** (vì nay có thể có dòng chưa điền KH/Lượng).
- **Không đổi**: tiền vẫn tính theo KH/Lượng × đơn giá; báo cáo sản lượng / số bộ vẫn theo KH/Lượng (`src/lib/reporting.ts`) — đó là định nghĩa chỉ số, không phải hiển thị dòng.

## Kiểm chứng (chạy thật trên Postgres cục bộ)

Tạo đơn test bằng API đúng như bạn làm: **1 thẻ bộ cửa trống (không nhập gì) + 1 dòng phụ kiện "Khóa Việt Tiệp / PK01", số lượng 2, đơn giá 150.000, để trống KH/Lượng.**

| Kiểm tra | Kết quả |
|---|---|
| Trang chi tiết đơn | **"Chi tiết từng bộ cửa (1)"** + hiện dòng `PK01 · Khóa Việt Tiệp` |
| Excel V1 | có `PK01`, `Khóa Việt Tiệp` |
| Excel V2 | có `PK01`, `Khóa Việt Tiệp` |
| PDF V2 (dựng bằng đúng code `api/order_pdf_v2.py`) | dòng: `12123  Khóa Việt Tiệp  PK01  …  2  Cái  150.000` |
| Trang in | có `PK01`, `Khóa Việt Tiệp` |
| Đơn có thẻ bộ cửa **hoàn toàn trống** | vẫn **"(0)"** — không lọt dòng rỗng |
| Đơn có bộ cửa bình thường (id 100, 6 đơn thật trong backup) | **không đổi** số dòng |

Kiểm tra "bán kính ảnh hưởng" trên **12 đơn** trong DB test: chỉ **2 đơn đổi** số dòng hiển thị (đều là đơn test tạo bằng API, trước đây hiện 0 dòng — nay hiện đúng dòng có dữ liệu); 6 đơn thật giữ nguyên.

`npx tsc --noEmit` → 0 lỗi · `eslint` các file sửa không phát sinh lỗi mới (chỉ còn các lỗi `no-explicit-any` có sẵn) · `npx next build` → PASS.

## File thay đổi

- `src/lib/order-output.ts` — thêm `hasRowContent()`, dùng trong `buildOutputGroups()`.
- `src/lib/order-detail.ts` — `isMeaningfulOrderDetail(row, { ignoreSetNo })` + `PAYLOAD_FIELDS` tách ra ngoài hàm.
- `src/app/orders/[id]/page.tsx` — dùng `hasRowContent`, sửa nhãn đếm dòng.
- `python/reportlab_order_v2.py` — `has_row_content()`, `ROW_CONTENT_FIELDS`, `TEMPLATE_DETAIL_NAMES`, `PLACEHOLDER_VALUES`; `build_groups()` dùng quy tắc mới.

**Không cần migration** (chỉ đổi logic hiển thị/xuất file). Deploy code là đủ.
