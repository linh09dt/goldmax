# V91 — Đơn hàng chỉ còn 2 trạng thái + 2 hành động lưu (Lưu nháp / Lưu đơn hàng)

## Yêu cầu

> “tab tạo đơn hàng, ở trạng thái chỉ cần 2 trạng thái đơn hàng mẫu và sản xuất, khi lưu đơn hàng sẽ có 2 hành động là lưu nháp và lưu đơn hàng, khi lưu đơn hàng thì trạng thái chuyển sang trạng thái sản xuất, lưu nháp thì trạng thái vẫn là đơn hàng mẫu”

## Cách làm

### 1. Chỉ còn 2 trạng thái

| Trạng thái | Mã lưu trong DB | Ghi chú |
|---|---|---|
| Đơn hàng mẫu | `NHAP` | giữ nguyên mã cũ để **không phải migrate dữ liệu** |
| Sản xuất | `CHUYEN_SAN_XUAT` | đơn đã vào sản xuất |

Đơn đã lưu trước đây còn mã cũ được **quy về 2 trạng thái này khi hiển thị** (`CHO_XAC_NHAN` → Đơn hàng mẫu, `DA_XAC_NHAN` → Sản xuất); riêng `HUY` giữ nhãn “Đã hủy” để đơn đã hủy không bị hiển thị nhầm thành đang sản xuất.

Nhãn trạng thái giờ dùng **một hàm chung** `orderStatusLabel()` trong `src/lib/order-form.ts` cho mọi màn: danh sách đơn, chi tiết đơn, Thông tin khách hàng, Excel danh sách đơn.

### 2. Ô “Trạng thái” trên form không còn chọn tay

Trạng thái do **hành động khi lưu** quyết định, nên ô Trạng thái trong Thông tin đơn hàng chuyển thành **ô hiển thị** (có chấm màu: xám = Đơn hàng mẫu, xanh = Sản xuất) kèm tooltip giải thích. Trường “Trạng thái” cũng được bỏ khỏi danh sách trường bắt buộc.

### 3. Hai hành động lưu

| Nút | Trạng thái sau khi lưu | Sau khi lưu xong |
|---|---|---|
| **Lưu nháp** (nút viền) | giữ **Đơn hàng mẫu**; đơn đã ở **Sản xuất** thì **không bị hạ cấp** | ở lại trang (chuyển sang `/orders/{id}/edit`) để nhập tiếp |
| **Lưu đơn hàng** (nút xanh) | chuyển sang **Sản xuất** | mở trang chi tiết đơn |

Quy tắc trạng thái nằm ở hàm thuần `statusAfterSave(currentStatus, action)` trong lib → test được, không phụ thuộc giao diện.

### 4. Bộ số vẫn theo quy tắc V75

Bộ số chỉ được cấp khi đơn ở trạng thái **Sản xuất** — tức khi bấm **Lưu đơn hàng** (giữ nguyên mã cũ `DA_XAC_NHAN` trong danh sách cho phép để đơn cũ không mất số). Đơn ở **Đơn hàng mẫu** chưa có Bộ số; câu chữ gợi ý trên form/trang cấu hình/Hướng dẫn đã cập nhật theo.

### 5. Server chuẩn hoá trạng thái

Thêm `normalizeOrderStatus()` trong `src/lib/order-persistence.ts`: khi ghi DB, mã cũ được quy về 2 mã chuẩn (`CHO_XAC_NHAN` → `NHAP`, `DA_XAC_NHAN` → `CHUYEN_SAN_XUAT`), `HUY` giữ nguyên. Nhờ vậy dữ liệu không bị lẫn thêm mã cũ về sau.

## Kiểm chứng

Chạy trực tiếp các hàm thật của app (bundle bằng esbuild) — **27/27 case đúng**:

| Nhóm | Case | Kết quả |
|---|---|---|
| 2 trạng thái | số lựa chọn / nhãn / mã | 2 · “Đơn hàng mẫu”, “Sản xuất” · `NHAP`, `CHUYEN_SAN_XUAT` |
| Lưu nháp | tạo mới + Lưu nháp | `NHAP` |
| Lưu đơn hàng | tạo mới + Lưu đơn hàng | `CHUYEN_SAN_XUAT` |
| Không hạ cấp | đang Sản xuất + Lưu nháp | giữ `CHUYEN_SAN_XUAT` |
| Đơn cũ | `DA_XAC_NHAN` + Lưu nháp | giữ `CHUYEN_SAN_XUAT` |
| Đơn cũ | `CHO_XAC_NHAN` + Lưu nháp | `NHAP` |
| Nhãn | `NHAP` / `CHUYEN_SAN_XUAT` / `CHO_XAC_NHAN` / `DA_XAC_NHAN` / `HUY` / rỗng | Đơn hàng mẫu · Sản xuất · Đơn hàng mẫu · Sản xuất · Đã hủy · “—” |
| Bộ số | mẫu / Sản xuất / đơn cũ `DA_XAC_NHAN` | ẩn · hiện · hiện |
| Ghi DB | lưu `CHO_XAC_NHAN` / `DA_XAC_NHAN` | thành `NHAP` / `CHUYEN_SAN_XUAT` |

- `npx tsc --noEmit` → 0 lỗi.
- `npx eslint` 12 file sửa → **8 errors / 15 warnings, đúng bằng bản gốc** (đã đối chiếu lại bản trước khi sửa: y hệt, chỉ lệch số dòng), không phát sinh lỗi mới.

## Lưu ý

- **Không cần migration DB.** Đơn cũ giữ nguyên dữ liệu trong bảng; chỉ khác là khi mở lên sửa và lưu, trạng thái sẽ được quy về mã chuẩn.
- Đơn cũ đang ở “Đã hủy” vẫn hiển thị “Đã hủy” (không có nút hủy trong giao diện). Nếu muốn dẹp luôn nhãn này thì phải chạy 1 câu SQL cập nhật dữ liệu cũ — mình chưa làm, nói nếu bạn cần.
- Vì ô Trạng thái không chọn tay được nữa, muốn đưa một đơn đã lưu ở trạng thái mẫu sang Sản xuất thì mở đơn rồi bấm **Lưu đơn hàng**.
- “Lưu nháp” trên đơn đã ở Sản xuất = lưu thay đổi, giữ nguyên trạng thái (không hạ cấp). Nếu muốn nút này đổi nhãn thành “Lưu thay đổi” khi đơn đã vào sản xuất thì nói mình chỉnh.

## File thay đổi

- `src/lib/order-form.ts` — 2 trạng thái + `orderStatusLabel()`, `isProductionStatus()`, `statusAfterSave()`.
- `src/lib/order-persistence.ts` — chuẩn hoá trạng thái khi ghi DB.
- `src/components/order-form.tsx` — ô Trạng thái chỉ hiển thị, 2 nút Lưu nháp / Lưu đơn hàng, gửi trạng thái theo hành động.
- `src/app/orders/page.tsx`, `src/app/orders/[id]/page.tsx`, `src/components/customer-directory.tsx`, `src/app/api/orders/export-list/route.ts` — dùng chung nhãn trạng thái, badge còn 2 màu.
- `src/components/calculation-config.tsx`, `src/lib/set-number.ts`, `src/app/api/orders/route.ts`, `src/app/api/orders/[id]/route.ts`, `src/app/orders/[id]/page.tsx` — cập nhật câu chữ/ghi chú Bộ số theo luồng lưu mới.
- `src/app/guide/page.tsx` — cập nhật Hướng dẫn: 2 trạng thái, 2 nút lưu, quy tắc Bộ số.
