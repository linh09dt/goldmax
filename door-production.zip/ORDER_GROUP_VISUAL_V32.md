# ERP V32 - Phân biệt từng đơn hàng trong Danh sách đơn hàng

- Mỗi đơn hàng được xem là một nhóm dòng.
- Hai nhóm đơn kế tiếp dùng nền rất nhẹ khác nhau để dễ theo dõi: xanh cyan / xanh indigo.
- Dòng sản phẩm chính của mỗi bộ được tô đậm hơn so với dòng hàng hóa kèm theo.
- Dòng đầu của mỗi đơn có viền trên 4px cùng màu nhóm để phân cách rõ ràng.
- Giữ nguyên full view, bộ lọc, sticky header, Sửa/Xóa và toàn bộ logic dữ liệu.
- Không thay đổi database.
