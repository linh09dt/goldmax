# ERP V36 – Cấu hình Model vận chuyển (đã thay thế)

Logic V36 đã được thay thế bởi **V37 – Cấu hình vận chuyển**.

Không còn dùng Model đơn hàng hoặc tiền tố mã hàng để quyết định Model tính cước.

Logic hiện hành:

`MODEL trên đơn hàng → Danh mục hàng hóa → TENHANG → Cấu hình vận chuyển → Model tính cước → shipping_rates`

Xem `SHIPPING_TENHANG_CONFIG_V37.md`.
