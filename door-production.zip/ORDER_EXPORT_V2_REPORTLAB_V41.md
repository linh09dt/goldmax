# V41 - Excel V2 + PDF V2 ReportLab

- Giữ nguyên hai nút xuất cũ.
- Thêm `Excel V2` dùng `src/lib/order-export-v2.ts` và route `/api/orders/[id]/export-v2`.
- Thêm `PDF V2` dùng Python ReportLab qua Vercel Python Function `/api/order_pdf_v2.py`.
- Core PDF ReportLab nằm tại `python/reportlab_order_v2.py` và có thể chạy độc lập với payload JSON.
- PDF V2: A4 ngang, lề 12/12/10/10 mm, Navy #1E3A8A, Amber #D97706, bảng 17 cột tổng 273 mm, dòng cha/con, checklist, summary, số tiền bằng chữ, chữ ký và footer.
- Python Function đọc dữ liệu hiện có từ Supabase PostgreSQL bằng `DIRECT_URL` (ưu tiên) hoặc `DATABASE_URL`.
- Thêm `requirements.txt`: ReportLab + psycopg.
- Không đổi schema DB, không migration.
