# ORDER EXPORT V2 V41.6

- PDF V2 + Excel V2 bổ sung KT Thông thủy: Cao, Rộng.
- Header KT Thông thủy dùng 2 tầng Cao/Rộng.
- Các cột từ ĐVT đến Thành tiền căn phải.
- Excel V2 dùng logo crop vùng trong suốt và tăng kích thước để gần PDF V2.
- Giữ nguyên PDF/Excel cũ và không thay đổi database.
