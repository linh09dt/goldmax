# V136 — THIẾT KẾ MODULE LÊN KẾ HOẠCH SẢN XUẤT (bản thiết kế từ kết quả khảo sát nhà máy)

**Nguồn dữ liệu:** `khao-sat-ke-hoach-san-xuat-20260926-0549.md` (222/230 câu trả lời, 4 câu P1 còn thiếu)
+ ảnh *"QUY TRÌNH TIẾN ĐỘ SẢN XUẤT, CÔNG ĐOẠN ĐƠN HÀNG"* (5 tổ, tổng 12, ghi chú "cần đầy đủ đơn để đẩy công đoạn kế tiếp").

**Trạng thái:** thiết kế xong, **chưa viết code**. Mục 2 là các điểm **phải chốt** trước khi migration.
**Nguyên tắc:** module **chỉ ĐỌC** bảng đơn hàng hiện có, ghi vào bảng riêng — không sửa `sales_orders` / `sales_order_items`.

---

## 1. NGHIỆP VỤ THẬT ĐÃ CHỐT ĐƯỢC TỪ KHẢO SÁT

### 1.1. Routing đầy đủ (13 bước + 5 chờ) — khác bảng giấy ở 6 điểm

Bảng giấy có 11 dòng; khảo sát cho thêm **Mài ba via**, **Ép cánh**, **Lắp kính + phụ kiện**, **Kho/giao** và **các khoảng chờ**.

| # | Công đoạn | Loại | Phạm vi | Tổ | Thời lượng (K) | Năng lực thật | Nguồn |
|---|---|---|---|---|---|---|---|
| 1 | **Thiết kế** | CHUAN_BI | theo **model** | Kỹ thuật (CAD, tại nhà máy) | 1 ngày | tùy model, nhiều phi tiêu chuẩn | K1 · TK1–TK6 |
| 2 | **Bồi Lares (CAM)** | CHUAN_BI | theo **model** | Nhà máy | 1 ngày | **60 cánh/ca/người** | K2 · BL2–BL4 |
| 3 | **Cắt** | GIA_CONG | KHUNG / CÁNH / PHAO | TỔ MÁY | 1 ngày | 2 máy CNC Lares Fiber × 2 người | K3 · C1–C2 · C8 |
| 4 | **Chấn** | GIA_CONG | KHUNG / CÁNH / PHAO | TỔ MÁY | 1 ngày | **30 cánh/ca → 60 cánh/2 ca** | K4 · CH2 · CH7 |
| 5 | **Hàn** | GIA_CONG | KHUNG / CÁNH / PHAO | TỔ HÀN | 1 ngày | 8 máy MIG, **10 phút/cánh** | K5 · HAN1–HAN3 |
| 5b | *Mài ba via* | *(gộp vào Hàn)* | phần | TỔ HÀN | — | thợ hàn mài luôn | HAN6 |
| 6 | **Ép cánh** | GIA_CONG | CÁNH | TỔ HÀN | 1 ngày | 1 máy, 45'/lượt, 9–12 cánh/lượt → **90–100 cánh/8h** | K6 · EP2 · EP7 |
| 7 | **Test cơ khí** | GIA_CONG **+ QC** | cả BỘ | TỔ HÀN | 2 ngày | **20 phút/bộ**, 1 người = 10 bộ/ngày | K8 · TC1–TC6 |
| 8 | **Sơn** | GIA_CONG | cả BỘ (1 lượt) | TỔ SƠN | 2 ngày | 1 lò, **20–25 cánh/mẻ × 2 mẻ = 40–50 cánh/ngày** | K9 · SON1–SON4 |
| 9 | **Vân** | GIA_CONG | cả BỘ | TỔ VÂN | 2 ngày | dán tay, **13 người** | K10 · VAN1 · VAN5 |
| 10 | **Lắp kính + phụ kiện** | GIA_CONG | cả BỘ | **TỔ ĐÓNG GÓI** | 1 ngày | 20 phút/bộ | K11 · LK1 · LK4 |
| 11 | **Vệ sinh + Đóng gói** | GIA_CONG | BỘ → **KIỆN** | TỔ ĐÓNG GÓI | 1 ngày | 4'/kiện, **~5 kiện/bộ**; 50 cánh/ngày | K12 · KHO2–KHO3 |
| 12 | **Kho / Giao hàng** | GIA_CONG | ĐƠN | KHO | 1 ngày | xe ghép (thuê ngoài) | K13 · GH3 |
| W1 | Chờ sau Bồi Lares → Cắt | CHO | BỘ | — | 1 ngày | gối công đoạn | K16 · C6 |
| W2 | Chờ keo khô (ép cánh) | CHO | CÁNH | — | 45 phút | | EP3 |
| W3 | **Chờ khô/nguội sau Sơn** | CHO | BỘ | — | **chưa trả lời (K14)** | sấy rồi nguội mới dán vân | SON11 |
| W4 | Chờ sau Vân (sấy in chuyển nhiệt) | CHO | BỘ | — | 1 ngày | | K15 · VAN8 |
| W5 | Chờ sơn (sau test) | CHO | BỘ | — | ≤ 24 giờ | | TH2 |

**Sáu điểm khác bảng giấy (đã xác nhận bằng lời):**
1. **Mài ba via** là việc thật (thợ hàn làm luôn) — bảng giấy không có.
2. **Ép cánh nằm SAU khi hàn cánh** (EP4), không phải trước.
3. **Lắp kính + phụ kiện do TỔ ĐÓNG GÓI làm** (LK1), **sau Vân**, trước Vệ sinh+Đóng gói.
4. **Màu sơn 11 và 14 KHÔNG cần vân** (LK5) → công đoạn Vân phải **bỏ qua được theo màu**.
5. **Hàn không cần đủ 3 phần** — "làm độc lập" (HAN5). Ba phần khung/cánh/phào chạy **song song** đến khi **hội tụ ở Test cơ khí**.
6. **Đóng gói theo KIỆN, không theo bộ** (KHO3: 1 bộ ≈ 5 kiện) nhưng **mốc "hoàn thành sản xuất" là khi đóng gói xong** (KHO5).

### 1.2. Luồng song song 3 phần + điểm hội tụ (điểm khó nhất)

```
                    ┌── KHUNG ── Cắt ─ Chấn ─ Hàn ─────────┐
Thiết kế → Bồi Lares ├── CÁNH ── Cắt ─ Chấn ─ Hàn ─ Ép cánh ┤→ Test cơ khí → Sơn → Vân* → Lắp kính+PK → Vệ sinh+ĐG → Kho
                    └── PHAO ── Cắt ─ Chấn ─ Hàn ─────────┘      (QC, 20'/bộ)   ↑ GATE          (*màu 11/14 bỏ qua)
                                                                          「bộ phải đủ 3 phần」
```

- **Chấn**: 2 máy — *máy 1: khung + phào*, *máy 2: cánh + phào* (phào chấn được cả 2 máy) → tranh máy giữa 3 luồng.
- **Gate trước Sơn**: Sơn làm **cả bộ 1 lượt** (SON4) ⇒ bộ phải **đủ khung + cánh + phào đã test** mới sơn được. Đây chính là chỗ câu A1/CH5 nói tới.
- **Chấn** đổi khuôn **5 phút, nhưng ngày chỉ đổi 2 lần** (CH4) → đây là lý do phải **gom lô theo model nhôm**, không phải "làm độc lập".
- **Sơn** đổi màu **2 giờ** (SON6) → gom lô màu **tối thiểu 20 cánh** (SON7); khách ít/chờ ghép lô (SON8); sơn **hằng ngày** (SON9), không gom cả tuần.

### 1.3. Nguồn lực & năng lực (số thật)

| Tổ | Người | Máy | Năng lực thật | Ghi chú |
|---|---|---|---|---|
| TỔ MÁY | 8 người/ca · **2 ca** (TM1–TM2) | 2 máy CNC cắt + 2 máy chấn | **60 cánh/2 ca** "sạch" (TM3) | chấn 30 cánh/ca (CH7) |
| TỔ HÀN | **12 người** (TH1) | 8 máy MIG + 1 máy ép | **45 cánh/ngày** đã test đạt (TH3) | test 10 bộ/người/ngày (TC6) |
| TỔ SƠN | — | 1 lò tĩnh điện | **40–50 cánh/ngày** (2 mẻ × 20–25) | nút thắt |
| TỔ VÂN | **13 người** (VAN5) | buồng sấy riêng | chưa có số (VAN12) | dán tay |
| TỔ ĐÓNG GÓI | **8 người** (KHO6, LK10) | — | **50 cánh/ngày** | gồm cả lắp kính+PK |
| KỸ THUẬT | kỹ sư CAD (TK3) | — | 1 người 1 ca bồi 60 cánh (BL3) | nguồn lực riêng |
| Toàn xưởng | — | — | **tối đa 80 cánh/ngày**, quá 70 là quá nhiều (KH6–KH7) | ⚠️ xem mục 2.4 |

**Quy đổi đơn vị — vấn đề gốc:** xưởng nói bằng **cánh**, đơn hàng ghi bằng **bộ**. Một bộ có `leaves_per_set` cánh (1–4+). Nếu bình quân **2 cánh/bộ** thì 45 cánh/ngày ≈ **22 bộ/ngày**. Toàn bộ tính tải **phải quy về cánh** (hoặc m²) rồi mới hiển thị lại theo bộ — nếu tính thẳng theo bộ sẽ sai 2–4 lần.

### 1.4. Quy tắc nghiệp vụ đã chốt

| Quy tắc | Chốt từ | Thiết kế |
|---|---|---|
| **Đơn vị lên kế hoạch = 1 BỘ CỬA** | B1 | `production_sets` 1 dòng / bộ |
| **Đơn vào kế hoạch: "tất cả"** | B2 | config `entryOrderTypes` (mặc định cả 3 loại) — nhưng xem mâu thuẫn 2.3 |
| **Điều kiện đủ vào SX**: khách đã xác nhận + đủ kích thước/hướng mở/màu | B3 · KH5 | gate `requireInfoBeforePlan` |
| **Hạn giao = ngày giao TỚI KHÁCH** (không phải ngày xưởng xong) | B6 · GH2 | phải trừ **đệm vận chuyển** trước khi tính ngày xưởng phải xong |
| **Không giao từng phần** — giao đủ cả bộ | B7 · GH5 | không có nhánh partial |
| **Bộ số do kinh doanh đánh khi chốt đơn** | B5 | `set_no` đã có sẵn từ module đơn hàng ✅ |
| **Ưu tiên xếp lịch = hạn giao gần nhất trước (EDD)** | A7 · KH4 | sort theo `required_delivery_date` |
| **Chen đơn gấp**: chỉ quản lý/kế hoạch được chen | KH14 | quyền + log |
| **Đơn làm lại (LAM_LAI) chen trước đơn thường** | KH17 | `priority` cao nhất |
| **Đơn hàng mẫu KHÔNG chiếm chỗ sản xuất** | KH18 | ⚠️ mâu thuẫn với B2 — xem 2.3 |
| **Không sản xuất trước / không làm tồn** | KH19 | kế hoạch chỉ theo đơn |
| **Sau 3 ngày không được đổi kích thước** | KH15 | cảnh báo cứng trên bộ đã vào SX |
| **Đơn hủy giữa chừng → hoàn thiện và lưu kho** | KH16 | trạng thái riêng, không xóa |
| **Sơn: gom lô màu ≥ 20 cánh** | SON7 | `batchMinQty = 20`, `batchKey = MAU_SON` |
| **Vân: không cần gom lô** | VAN6 | `batchKey = null` |
| **Chấn: ngày chỉ đổi khuôn 2 lần** | CH4 | ràng buộc `changeoverMaxPerDay = 2` |
| **Thiếu kính/phụ kiện thì bộ KHÁC vẫn đẩy trước được** | LK7 | chặn mềm theo từng bộ, không chặn cả đơn |
| **Thuê ngoài**: cắt kính (đặt ngay sau thiết kế) · đôi khi hàn khung ≤ 3 ngày | LK6 · J12 · KH30 | trường `outsourced` + lead time |
| **Cập nhật tiến độ ở mức CÔNG ĐOẠN của từng bộ** | KH22 · L2 | `production_tasks` = bộ × công đoạn |
| **Theo dõi % tiến độ từng bộ** | J5 | `percent_done` = công đoạn xong / tổng |
| **Ai cập nhật: văn phòng, tại máy tính ở xưởng** | KH21 · KH23 · TM6 | một màn nhập nhanh, không cần mobile |
| **Không cần gắn tên thợ** (tổ trưởng phân việc) | KH27 | `assignee` để trống được |
| **Cảnh báo mong muốn: quá tải tổ + bộ sắp chậm tiến độ** | KH29 | đúng 2 loại cảnh báo, không thêm |
| **Trễ hạn: chỉ báo đỏ, KHÔNG tự đề xuất lại lịch** | J8 | không auto-reschedule |
| **Không cần thông báo/chuông/Zalo** | J9 | không làm notification |
| **In**: phiếu lệnh SX **A4** + danh sách việc theo ngày dán xưởng | KH25 · KH26 · J11 | 2 mẫu in |
| **Lưu lịch sử sửa kế hoạch** | J1 | `production_logs` |
| **Kế hoạch tuần do KD + SX thống nhất, giám đốc nhà máy chốt** | J3 | plan có `status` + `approved_by` |
| **Báo cáo theo cả bộ và m²** | J10 | 2 cột |
| **Theo dõi máy dừng + lý do** | KH28 | `production_downtime` |
| **Mỗi tổ KHÔNG cần xem kế hoạch tổ khác** | J6 | màn tổ chỉ hiện việc của tổ |
| **Cập nhật thời gian thực từng công đoạn** | L11 "Cần — quan trọng" | `actual_start` / `actual_end` mọi công đoạn |
| **Lỗi & làm lại theo công đoạn** | L15 · TC5 · VAN10 · SON19 | `is_rework` + `rework_from_stage` |

### 1.5. Chất lượng & thực trạng (để đo sau này)

- **Tỷ lệ trễ hạn hiện nay ≈ 75%** (KH10); nguyên nhân trễ: **do sản xuất chưa xong** (GH12). Đây là chỉ số gốc để chứng minh module có ích.
- Tỷ lệ phải làm lại ≈ **3%** (KH12); lỗi test thường là **móp méo / hàn sai vị trí** (TC4); lỗi sơn **< 1%** (SON13).
- **Chờ vật tư 5–7 ngày** khi nhân viên mua quên phôi (KH13) → cần cảnh báo thiếu nguyên liệu (C5).
- Năng suất: **1 người ≈ 1,45 m²/ngày** (KH11).
- Mùa vụ chênh tới **100%** giữa thấp điểm và cao điểm (KH8).
- Hàng để kho **quá 2 tháng** thì tính tồn kho (GH9).
- O1: cản trở nhất = **lượng hàng chưa đủ + thiếu người**. O2: cần **lên kế hoạch công đoạn, đo lường, cảnh báo, % lỗi, nguy cơ trễ**.
- **Không** lắp đặt tại công trình (GH6); giao bằng **xe ghép thuê ngoài** (GH3); **thu tiền khi giao** (GH10).

---

## 2. MƯỜI HAI ĐIỂM PHẢI CHỐT TRƯỚC KHI LẬP TRÌNH

| # | Mâu thuẫn / lỗ hổng | Ảnh hưởng | Đề xuất mặc định (chờ bạn xác nhận) |
|---|---|---|---|
| **2.1** | **Đơn vị thời gian**: bảng giấy tổng = **12** (1,1,1,1,2,1,2,2,1,0) nhưng bảng K trả lời **mỗi công đoạn 24h, test/sơn/vân 48h** → cộng ra ~15–18 ngày | Sai toàn bộ ngày xong dự kiến | Coi **24h = 1 ngày làm việc** (T2–T7, **nghỉ Chủ nhật + lễ** — A2). Lưu theo **giờ**, quy đổi ngày làm việc. Tổng đường găng ≈ **15 ngày làm việc** |
| **2.2** | **"Đầy đủ đơn"**: A1 nói *"áp dụng sau khi test cơ khí"*, CH5 trả lời gượng "đúng rồi" cho câu hoặc–hoặc, HAN5 nói hàn *"làm độc lập"*, SON4 nói sơn *"cả bộ 1 lượt"* | Quyết định xếp lịch có bị chặn theo lô đơn hay không | Hiểu là **đủ 3 PHẦN của 1 bộ, đã test cơ khí xong** mới sang **Sơn**. Hàn/cắt/chấn vẫn chạy **song song theo từng phần**. Làm **dữ liệu cấu hình** (`stage_transition_rule`) để đổi được |
| **2.3** | **Đơn hàng mẫu**: B2 nói *"tất cả"* đơn vào kế hoạch, KH18 nói đơn mẫu *"không"* chiếm chỗ | Xếp lịch sai nếu đưa đơn mẫu vào | Mặc định: kế hoạch chính gồm **SAN_XUAT + LAM_LAI**; **MAU** để **bật/tắt bằng cấu hình** (mặc định tắt). Cần bạn chốt |
| **2.4** | **Năng lực không khớp**: KH7 nói tối đa 80 cánh/ngày, nhưng Hàn 45 · Sơn 40–50 · Chấn 60 · Test (10 bộ/người) → trần thật ~**45–50 cánh/ngày** | Cảnh báo quá tải sẽ sai nếu lấy 80 | Lấy **trần theo công đoạn** để cảnh báo quá tải; **80 cánh/ngày** coi là mục tiêu toàn xưởng, chỉ báo đỏ khi vượt **từng tổ**. Ngưỡng cảnh báo: > 70 cánh/ngày (KH6) |
| **2.5** | **Thời gian chờ**: L9 chọn "**Không cần**" nhưng K15/K16 điền 24h, SON11 + TH2 nói có chờ | Không xếp sát khi chưa khô → trượt kế hoạch | Vẫn mô hình hoá chờ thành công đoạn `CHO` mặc định **1 ngày**, **bật/tắt được**; K14 (chờ khô sau sơn) mặc định **24h** |
| **2.6** | **Vân**: VAN12 để trống ("chưa trả lời") — không biết tổ vân làm tối đa bao nhiêu | Không tính được tải tổ vân | Tạm để **trống năng lực tổ vân** → app vẫn xếp lịch, **không cảnh báo quá tải** tổ vân cho tới khi có số |
| **2.7** | **Bồi Lares**: BL1 (theo model hay theo bộ?) và BL9 (sửa chương trình mất bao lâu?) **chưa trả lời** | Không biết chương trình tái dùng được không | Theo **V121**: chương trình **theo model**, **tái dùng được** (đã có ⇒ ~0). Sửa chương trình mặc định **1 ngày**. Chặn Cắt nếu chưa có chương trình |
| **2.8** | **M10**: nhà máy đánh dấu *"Hạn giao · Ngày đặt hàng"* là **"Thiếu thông tin"** | Có thể xưởng không nhìn thấy/không dùng 2 trường này | App **đang có** 2 trường đó (`required_delivery_date`, `order_date`). Cần hỏi lại: thiếu ở đâu — trên app, trên phiếu in, hay trên đơn sale gửi? |
| **2.9** | **Thời gian Cắt**: C3 "căn cứ tính theo doanh thu", C8 "một ngày" — không dùng được | Không tính được tải tổ máy theo cắt | Dùng **Chấn** (30 cánh/ca, số cụ thể) làm nút chặn của tổ máy; Cắt coi là **không chặn** (cùng người/máy) |
| **2.10** | **Một kiện ≈ 1 bộ nhưng 1 bộ ≈ 5 kiện** (KHO3); đóng gói theo kiện, hoàn thành theo bộ | Lệch giữa đóng gói và mốc hoàn thành | `production_sets` hoàn thành khi **đóng gói xong cả bộ**; số kiện lưu ở bộ để in phiếu giao |
| **2.11** | **Nút thắt thật = SƠN** (SON 2 mẻ/ngày, đổi màu 2h, lô tối thiểu 20 cánh, chỉ để được ≤ 2 ngày) + **CHẤN** (đổi khuôn tối đa 2 lần/ngày) | Đây là nguyên nhân gốc của 75% trễ | Cảnh báo quá tải **ưu tiên 2 tổ này**; gợi ý gom lô màu trước khi xếp; không xếp 2 lượt đổi khuôn/ngày |
| **2.12** | **Thuê ngoài**: cắt kính (sau thiết kế) + đôi khi hàn khung (≤ 3 ngày) — chưa có chỗ lưu | Trễ vì chờ kính/hàn ngoài không ai thấy | Thêm `outsourced` + `outsource_lead_days` trên công đoạn; hiện như một chờ có tên |
| **2.13** | **Chữ "cánh" được dùng KHÔNG nhất quán**: SON2 nói *"mỗi mẻ 20–25 cánh (bao gồm kèm cả khung)"* — tức "cánh" ở đây đã bao hàm cả khung đi kèm; còn CH7/HAN3/EP7 nói "cánh" thuần (1 cánh = 1 lá cửa). Nếu hiểu sai, tải sơn bị lệch 2 lần | Sơn bị tính sai gấp đôi → cảnh báo quá tải sai | Định nghĩa rõ trong app: **1 cánh = 1 lá cửa**; khung/phào là **bộ phận riêng**. Khi báo năng lực SƠN quy đổi: "1 mẻ 20–25 cánh + khung tương ứng". Cần hỏi lại 1 câu để chốt |

**4 câu P1 chưa trả lời:** BL1 · BL9 · VAN12 · K14 → đề xuất mặc định ở 2.6, 2.7, 2.5.

---

## 3. THIẾT KẾ DỮ LIỆU

### 3.1. Bảng mới (10 bảng, chia 2 đợt)

```
sales_orders ─┐
sales_order_items ──(1 bộ = 1 dòng)──► production_sets ──1─n──► production_tasks   (bộ × công đoạn)
                                            │                         ▲
production_plans ───────────────────────────┘                         │
production_stages (danh mục công đoạn) ────────────────────────────────┘
production_work_centers (tổ + năng lực) ───────────────────────────────┘
production_reasons (lý do tạm dừng / trễ / máy dừng) ◄── production_logs (lịch sử sửa)
production_programs (thư viện chương trình máy cắt theo model)   [đợt B]
production_downtime (máy dừng + lý do)                          [đợt B]
production_calendar (ngày nghỉ / lễ)                            [đợt B]
```

**Đợt A (bắt buộc để chạy được):**

| Bảng | Vai trò | Cột chính |
|---|---|---|
| `production_work_centers` | Tổ / nguồn lực | `code` (TO_MAY, TO_HAN, TO_SON, TO_VAN, TO_DONG_GOI, KHO, KY_THUAT, NGOAI), `name`, `kind` (TO \| NGUON_LUC_NGOAI \| VAN_PHONG), `people_count`, `shifts_per_day`, `hours_per_shift`, `capacity_per_day`, `capacity_unit` (CANH \| BO \| M2), `active`, `sort_order` |
| `production_stages` | **Danh mục công đoạn (routing)** | `code`, `name`, `kind` (CHUAN_BI \| GIA_CONG \| CHO \| QC), `scope_mode` (BO \| PARTS \| MODEL), `work_center_code`, `seq`, `lead_time_hours`, `setup_minutes`, `capacity_per_day`, `capacity_unit`, `batch_key` (MAU_SON \| MODEL \| null), `batch_min_qty`, `is_qc_point`, `rework_to_stage`, `run_condition`, `requires_stage`, `active` |
| `production_sets` | **1 dòng = 1 bộ cửa** | `order_id`, `order_item_id` (unique), `set_no`, `order_code`, `order_type`, `model`, `paint_color`, `veneer_code`, `height_mm`, `width_mm`, `leaves_per_set`, `trim_bars_per_set`, `pricing_quantity`, `plan_id`, `priority`, `status`, `percent_done`, `planned_start`, `planned_end`, `actual_completed_at`, `actual_delivered_at`, `ready_for_production`, `program_ready`, `material_ready`, `note` |
| `production_tasks` | **1 dòng = 1 bộ × 1 công đoạn** | `set_id`, `order_item_id`, `stage_code`, `stage_kind`, `scope` (KHUNG \| CANH \| PHAO \| BO), `seq`, `work_center_code`, `status` (CHUA_LAM \| DANG_LAM \| XONG \| BO_QUA \| TAM_DUNG), `qty_expected`, `qty_done`, `planned_start`, `planned_end`, `actual_start`, `actual_end`, `assignee`, `is_rework`, `rework_from_stage`, `reason_code`, `note`, `updated_by` |
| `production_plans` | Kế hoạch tuần/ngày, có chốt | `code`, `from_date`, `to_date`, `status` (NHAP \| DA_CHOT), `created_by`, `approved_by`, `approved_at`, `note` |
| `production_reasons` | Danh mục lý do | `code`, `name`, `group` (TAM_DUNG \| TRE_HAN \| MAY_DUNG \| LOI), `sort_order`, `active` |
| `production_logs` | Lịch sử sửa kế hoạch (J1) | `entity` (PLAN \| SET \| TASK), `entity_id`, `action`, `field`, `old_value`, `new_value`, `by_name`, `created_at` |

**Đợt B:**
`production_programs` (model, file_name, version, machine, made_by, made_at, duration_minutes, reusable),
`production_downtime` (work_center_code, machine, from_at, to_at, reason_code, note),
`production_calendar` (date unique, is_working_day, note).

**Ràng buộc & index quan trọng**
- `production_sets.order_item_id` **unique** → 1 bộ không bị đưa vào kế hoạch 2 lần.
- `production_tasks @@unique([set_id, stage_code, scope])` → không nhân bản công đoạn.
- Index: `production_tasks(work_center_code, planned_start)`, `(status)`, `(planned_start)`, `production_sets(status, planned_start)`, `production_sets(set_no)`.
- **Không** đụng `sales_orders` / `sales_order_items`. Khi xóa bộ ở đơn thì `production_sets.order_item_id` set null hoặc xóa cascade — **thảo luận** (đề xuất: chặn xóa bộ đã vào kế hoạch).

### 3.2. Cấu hình trong `system_settings` (không cần bảng mới)

Key `PRODUCTION_CONFIG_V1` (theo đúng cách `ORDER_CALCULATION_CONFIG_V1` đang làm):

```jsonc
{
  "version": 1,
  "workingDays": [1,2,3,4,5,6],          // T2–T7, nghỉ Chủ nhật (A2); lễ ở production_calendar
  "shiftsPerDay": 2,
  "hoursPerShift": 8,
  "planUnit": "BO",                       // lên kế hoạch theo bộ (B1)
  "capacityUnit": "CANH",                 // tính tải theo cánh (xưởng nói bằng cánh)
  "defaultLeadTimeDays": 15,              // đường găng (chờ chốt 2.1)
  "deliveryBufferDays": 3,                // trừ trước hạn giao vì hạn giao = ngày tới khách (B6)
  "dailyWarnCanh": 70,
  "dailyMaxCanh": 80,
  "entryOrderTypes": ["SAN_XUAT","LAM_LAI"],   // ⚠️ chờ chốt 2.3 (B2 nói "tất cả")
  "requireInfoBeforePlan": ["heightMm","widthMm","openingDirection","paintColor"],
  "paintBatchMinCanh": 20,                // SON7
  "paintColorChangeMinutes": 120,         // SON6
  "bendChangeoverMaxPerDay": 2,           // CH4
  "skipStageByColor": { "VAN": ["11","14"] },  // LK5
  "waitsEnabled": true,                   // ⚠️ chờ chốt 2.5
  "autoReschedule": false                 // J8
}
```

### 3.3. Dữ liệu khởi tạo (seed) — 8 tổ + 16 công đoạn

Sinh sẵn từ chính khảo sát để mở app là dùng được, không phải nhập tay:

- **Work centers**: TO_MAY (8 người, 2 ca, 60 cánh/ngày) · TO_HAN (12 người, 45 cánh/ngày) · TO_SON (2 mẻ × 22 cánh = 44 cánh/ngày) · TO_VAN (13 người, để trống năng lực) · TO_DONG_GOI (8 người, 50 cánh/ngày) · KHO · KY_THUAT (60 cánh/ca) · NGOAI (thuê ngoài).
- **Stages**: THIET_KE · BOI_LARES · CAT · CHAN · HAN · EP_CANH · TEST_CO_KHI · SON · VAN · LAP_KINH · DONG_GOI · KHO + 5 chờ (CHO_BOI_LARES, CHO_KEO_KHO, CHO_KHO_SON, CHO_SAU_VAN, CHO_SON).
- **Reasons**: chờ phôi/nhôm · chờ chương trình · chờ lô sơn · khách đổi · thiếu người · máy hỏng · chờ kính ngoài · lỗi móp méo · hàn sai vị trí · sơn lại · vân lại.

---

## 4. THUẬT TOÁN XẾP LỊCH & TÍNH TẢI

### 4.1. Xếp lịch (7 bước, chạy khi mở màn kế hoạch, không tự động ghi DB)

1. **Lọc bộ vào kế hoạch**: `status = DA_XAC_NHAN`, `orderType ∈ entryOrderTypes`, chưa có `production_set` hoặc đang ở `CHO_XEP_LICH`.
2. **Kiểm điều kiện đủ** (B3/KH5): đủ `heightMm, widthMm, openingDirection, paintColor` → thiếu thì đưa vào **danh sách "chờ bổ sung thông tin"**, không xếp lịch.
3. **Xếp thứ tự**: EDD (`required_delivery_date` tăng dần) → LAM_LAI ưu tiên trước (KH17) → ngày đặt hàng cũ trước.
4. **Tính ngày phải xong của xưởng** = `hạn giao − deliveryBufferDays` (vì hạn giao là ngày tới khách — B6/GH2).
5. **Lùi theo đường găng** (đơn vị **ngày làm việc**, bỏ Chủ nhật + lễ): cộng `lead_time_hours` của các công đoạn trên đường găng → ra **ngày bắt đầu muộn nhất**. So với hôm nay: nếu đã trễ → đánh dấu **đỏ "nguy cơ trễ"** (chỉ báo, không tự sửa — J8).
6. **Gán tải theo từng tổ, theo ngày**: cộng **số cánh** vào `work_center × ngày`; kiểm trần từng tổ (mục 2.4). Vượt trần → **cảnh báo quá tải** (KH29).
7. **Gợi ý gom lô** (không bắt buộc):
   - **Sơn**: gom bộ cùng `paint_color` đủ **≥ 20 cánh** thành 1 mẻ; nếu chưa đủ → gợi ý dồn sang mẻ sau hoặc ghép; tối đa **2 lượt đổi màu/ngày** (mỗi lượt 2h).
   - **Chấn**: gom cùng `model` nhôm, tối đa **2 lượt đổi khuôn/ngày**.
   - **Vân**: không gom.

### 4.2. Công thức tải (quy về cánh)

```
cánh(bộ)          = leaves_per_set ?? 1                  // số cánh của bộ
tải_thô(bộ)       = cánh(bộ) × quantity                  // quantity = số bộ ở dòng hàng
tải_tổ(ngày)      = Σ tải_thô của các bộ được xếp vào tổ trong ngày
quá_tải(tổ, ngày) = tải_tổ(ngày) > work_center.capacity_per_day
cảnh_báo_nguy_cơ_trễ(bộ) = ngày_xong_dự_kiến > (hạn_giao − deliveryBufferDays)
%tiến_độ(bộ)      = số công đoạn (không tính CHO/BO_QUA) đã XONG / tổng số công đoạn phải làm
```

### 4.3. Cảnh báo (đúng 2 loại nhà máy muốn — KH29)

| Cảnh báo | Điều kiện | Màu |
|---|---|---|
| **Quá tải tổ** | `tải_tổ(ngày) > capacity_per_day` | đỏ; vàng khi > 85% |
| **Bộ sắp chậm tiến độ** | `ngày_xong_dự_kiến > hạn giao − đệm` hoặc đã qua `planned_end` mà chưa xong | đỏ |
| *phụ, vì hữu ích và dữ liệu đã có:* chờ chương trình Bồi Lares | model chưa có trong `production_programs` | vàng |
| *phụ:* máy đang dừng | có `production_downtime` đang mở | xám |

---

## 5. MÀN HÌNH & LUỒNG SỬ DỤNG

Thêm nhóm menu **"Sản xuất"** vào `erp-nav.tsx`.

| # | Đường dẫn | Nội dung | Dùng cho |
|---|---|---|---|
| 1 | `/ke-hoach-san-xuat` | **Màn chính — "Việc hôm nay của tổ"** (KH24): chọn tổ + ngày, bảng công đoạn phải làm; kèm dải **cảnh báo** (quá tải / sắp trễ) | Quản đốc, tổ trưởng |
| 2 | `/ke-hoach-san-xuat/ke-hoach` | **Kế hoạch tuần**: xếp bộ vào ngày/tổ, gom lô sơn/chấn, chốt kế hoạch (J3), lịch sử sửa | Quản đốc + kế hoạch |
| 3 | `/ke-hoach-san-xuat/cho-xep-lich` | **Bộ chưa xếp lịch** + bộ chờ bổ sung thông tin + bộ chờ vật tư | Người lên kế hoạch |
| 4 | `/ke-hoach-san-xuat/bo/[id]` | **Chi tiết 1 bộ**: timeline 16 công đoạn, cập nhật trạng thái/ngày thực tế (KH22), % tiến độ, ảnh QC, làm lại | Văn phòng xưởng |
| 5 | `/ke-hoach-san-xuat/nhap-do-dang` | **Nhập bộ đang sản xuất dở** (B8) — chọn đơn có sẵn, đánh dấu công đoạn đã xong | Ngày đầu triển khai |
| 6 | `/ke-hoach-san-xuat/in/...` | **In**: phiếu lệnh SX (A4) + danh sách việc theo ngày dán xưởng (KH25–26, J11) | Quản đốc |
| 7 | `/settings?tab=production` | **Cấu hình sản xuất**: tổ & năng lực · công đoạn & thời lượng · lý do · màu/vân · ngày nghỉ | Chủ/quản đốc |

**Cập nhật tiến độ**: màn #4 là điểm nhập chính (văn phòng, tại máy tính xưởng — KH21/23). Mỗi lần đổi **1 lượt ghi** (bài học V111 — DB remote 40–100 ms/lượt), có ghi `production_logs`.

**Quyền**: chưa có đăng nhập (đã biết từ V115). Đợt A dùng chung 1 vai trò + ghi `updated_by` dạng tên tự do; **đăng nhập/vai trò làm ngay sau** (J1 cần "ai đổi gì" — nếu không có đăng nhập thì chỉ ghi được tên gõ tay).

---

## 6. IN ẤN

Tái dùng hạ tầng ReportLab đã có (2 mẫu in song song đang chạy là tiền lệ: `reportlab_order_v2.py`, `reportlab_order_preview.py`).

1. **Phiếu lệnh sản xuất (A4)** — mỗi bộ 1 phiếu (hoặc gộp theo tổ/ngày): Bộ số · mã đơn · khách · model · màu sơn · mã vân · kích thước · hướng mở · số cánh · danh sách công đoạn + ô tích tiến độ · ghi chú · **ô trống cho tổ trưởng ký**.
2. **Danh sách việc theo ngày (A4)** — dán ở xưởng: theo tổ, liệt kê bộ + công đoạn + số cánh.
3. *Sau này*: mã bộ cỡ lớn để đối chiếu; **chưa cần QR** (KH25 chỉ nói A4).

Cần sửa `api/*.py` + `vercel.json` (`includeFiles: "python/fonts/**"`) khi thêm template mới — **bắt buộc**, quên là mất font.

---

## 7. BÁO CÁO (đợt C/D)

| Báo cáo | Chỉ số | Nguồn |
|---|---|---|
| **Giao đúng hạn (OTD)** | % bộ/đơn giao đúng hạn — **so với mốc gốc 75% trễ** | `production_sets.actual_delivered_at` vs `required_delivery_date` |
| **Tải & năng suất theo tổ** | cánh/ngày, m²/ngày, % dùng năng lực | `production_tasks` + work centers |
| **Thời gian thực từng công đoạn** | TB thực tế vs định mức — chỗ nào trễ | `actual_start/end` (L11) |
| **Lỗi & làm lại** | % theo tổ, theo công đoạn, thời gian làm lại | `is_rework` (L15) |
| **Lý do trễ** | xếp hạng: chờ phôi / chờ chương trình / chờ lô sơn / khách đổi / thiếu người / máy hỏng | `production_reasons` (L14) |
| **Chờ đủ bộ** | thời gian bộ nằm chờ trước Sơn | gate 2.2 |
| **Máy dừng** | số giờ dừng + lý do | `production_downtime` (KH28) |
| **Tồn kho thành phẩm** | bộ đóng gói xong quá **2 tháng** chưa giao (GH9) | `actual_completed_at` |

Mở rộng trang `/reports/production-load` đang có (hiện chỉ đếm theo tuần từ hạn giao).

---

## 8. LỘ TRÌNH TRIỂN KHAI (4 đợt)

| Đợt | Nội dung | Kết quả nhìn thấy được |
|---|---|---|
| **A** | Migration 7 bảng + seed 8 tổ/16 công đoạn + **nhập bộ đang dở** + màn chi tiết bộ cập nhật tiến độ theo công đoạn + % tiến độ | Tuần đầu đã biết **bộ nào đang ở công đoạn nào**, bộ nào xong |
| **B** | Màn kế hoạch ngày/tuần + xếp lịch EDD + tính tải theo cánh + **2 cảnh báo** (quá tải, sắp trễ) + chốt kế hoạch + lịch sử | Lập được kế hoạch ngày thay cho giấy/Excel |
| **C** | In phiếu lệnh SX A4 + danh sách việc dán xưởng | Xưởng có giấy chạy theo |
| **D** | Báo cáo OTD / % lỗi / năng suất / lý do trễ + thư viện chương trình máy + máy dừng | Đo được cải thiện (75% trễ → mục tiêu) |

Thứ tự bắt buộc: **A trước** (không có trạng thái bộ thì kế hoạch vô nghĩa — đúng như V115 đã cảnh báo).

---

## 9. FILE DỰ KIẾN THÊM / SỬA (đợt A)

| File | Việc |
|---|---|
| `prisma/schema.prisma` | thêm 7 model (đợt A) |
| `prisma/migrations/<ts>_production_planning/migration.sql` | tạo bảng + index (**mới**) |
| `src/lib/production/stages.ts` | danh mục công đoạn + seed |
| `src/lib/production/work-centers.ts` | tổ + năng lực |
| `src/lib/production/config.ts` | `PRODUCTION_CONFIG_V1` (đọc/ghi `system_settings`) |
| `src/lib/production/routing.ts` | sinh `production_tasks` từ routing + bỏ qua theo màu |
| `src/lib/production/scheduling.ts` | thuật toán mục 4 (hàm thuần, dễ kiểm thử) |
| `src/lib/production/calendar.ts` | ngày làm việc (bỏ CN + lễ) |
| `src/app/api/production/sets/route.ts` | list/create |
| `src/app/api/production/sets/[id]/route.ts` | cập nhật tiến độ 1 bộ (**1 lượt ghi/bảng**, bài học V111) |
| `src/app/api/production/plans/route.ts` | kế hoạch + chốt |
| `src/app/api/production/catalog/route.ts` | tổ/công đoạn/lý do |
| `src/app/ke-hoach-san-xuat/page.tsx` + `src/components/production/*` | 7 màn ở mục 5 |
| `src/components/erp-nav.tsx` | thêm nhóm **Sản xuất** |
| `src/components/settings/settings-tabs.ts` | thêm tab **Sản xuất** |
| `src/lib/guide-steps.ts` | thêm bước hướng dẫn |
| `python/reportlab_production_order.py` + `api/production_order_pdf.py` + `vercel.json` | phiếu lệnh SX (đợt C) |

---

## 10. CÁCH KIỂM CHỨNG (sau khi lập trình)

1. **Migration**: `npx prisma migrate deploy` **TRƯỚC** khi deploy code (bài học V112 — code trước DB là 500 toàn app, lỗi `P2022`).
2. **Seed**: kiểm 8 tổ + 16 công đoạn + 19 lý do có đủ trong DB.
3. **Nhập bộ dở**: lấy 1 đơn thật đã xác nhận, nhập bộ dở, xem % tiến độ + timeline đúng.
4. **Thuật toán**: tạo 1 tuần giả với ≥ 70 cánh/ngày → phải **báo đỏ quá tải** đúng tổ; bộ có hạn giao gần phải xếp trước.
5. **Gate sơn**: bộ thiếu 1 phần chưa test → **không** được xếp vào lượt sơn.
6. **Bỏ Vân theo màu**: đặt 1 bộ màu 11 hoặc 14 → công đoạn Vân tự `BO_QUA`, % tiến độ vẫn tính đúng.
7. **Đếm lượt ghi**: cập nhật 1 bộ phải ≤ 2–3 lượt round trip (không ghi từng công đoạn một).
8. **In phiếu lệnh**: tải PDF, kiểm font tiếng Việt + không tràn trang.

---

## 11. TÓM TẮT 4 PHÁT HIỆN QUAN TRỌNG NHẤT

1. **Nút thắt thật là SƠN (và CHẤN)** — 40–50 cánh/ngày và tối đa 2 lượt đổi màu/ngày. Con số "80 cánh/ngày" không khớp với năng lực từng tổ (Hàn 45, Sơn 40–50) → **đây là gốc của 75% trễ hạn**.
2. **Đơn vị lẫn lộn bộ ↔ cánh** — xưởng nói bằng **cánh**, đơn ghi bằng **bộ**. Tính tải phải quy về cánh (hoặc m²), nếu không sẽ sai 2–4 lần.
3. **Bảng giấy thiếu 3 công đoạn thật** (Mài ba via, Lắp kính + phụ kiện, và Kho/giao có thời gian) và **Ép cánh nằm sau Hàn cánh**; tổng thời gian 12 trên giấy không khớp bảng K (≈ 15 ngày làm việc).
4. **Nhà máy muốn theo dõi TỚI MỨC CÔNG ĐOẠN của từng bộ + % tiến độ** (L2, KH22, J5) — nên thiết kế bảng `production_tasks = bộ × công đoạn`, chứ không chỉ trạng thái bộ như đề xuất ban đầu ở V115.

---

*Hết V136. Bước tiếp theo: chốt 12 điểm ở mục 2 → viết migration + đợt A.*

---

## 12. ĐÃ TRIỂN KHAI (2026-09-26) — đợt A + xếp lịch tự động

Hai điểm chốt của bạn đã đưa vào code: **2.2 = đủ 3 phần test xong mới sơn**, **2.3 = tất cả loại đơn vào kế hoạch**.
Hai điểm chưa trả lời (2.1 đơn vị thời gian, 2.4 ngưỡng quá tải) đang dùng mặc định đã đề xuất, **sửa được ở Cấu hình sản xuất**.

### 12.1. File đã thêm

| File | Việc |
|---|---|
| `prisma/schema.prisma` | 10 model sản xuất (bảng mới hoàn toàn, không sửa bảng đơn hàng) |
| `prisma/migrations/20260926233000_production_planning/migration.sql` | DDL + seed 8 tổ · 16 công đoạn · 19 lý do |
| `migrate-production-v136.sql` | Bản SQL dán tay cho Supabase SQL Editor (đi kèm `migrate resolve`) |
| `src/lib/production/config.ts` | `PRODUCTION_CONFIG_V1` — mọi con số điều khiển thuật toán |
| `src/lib/production/catalog.ts` | Nhãn, mã công đoạn, hàm thuần (% tiến độ, suy trạng thái, quy đổi cánh) |
| `src/lib/production/calendar.ts` | Ngày làm việc (bỏ Chủ nhật + lễ), `todayInVietnam()` |
| `src/lib/production/routing.ts` | Sinh công đoạn cho 1 bộ (song song 3 phần, bỏ Vân theo màu, tái dùng chương trình) |
| `src/lib/production/scheduling.ts` | Tải theo tổ/ngày, tính đường găng, 2 cảnh báo chính |
| `src/lib/production/auto-schedule.ts` | Xếp lịch tiến theo EDD + ưu tiên đơn làm lại + năng lực từng tổ |
| `src/lib/production/service.ts` | Truy cập DB — ghi gộp 1–2 lượt cho cả bộ (bài học V111) |
| `src/app/api/production/sets/route.ts` | Đưa bộ cửa từ đơn vào kế hoạch (idempotent) |
| `src/app/api/production/sets/[id]/route.ts` | Cập nhật tiến độ / đánh dấu đã giao / sinh lại công đoạn |
| `src/app/api/production/schedule/route.ts` | Chạy xếp lịch tự động |
| `src/app/api/production/catalog/route.ts` | Đọc/ghi danh mục + cấu hình |
| `src/app/ke-hoach-san-xuat/page.tsx` | Màn chính: KPI, cảnh báo, bảng tải theo tổ, 3 danh sách bộ |
| `src/app/ke-hoach-san-xuat/bo/[id]/page.tsx` | Chi tiết bộ + form cập nhật tiến độ từng công đoạn |
| `src/app/ke-hoach-san-xuat/nhap-do-dang/page.tsx` | Nhập bộ đang sản xuất dở (B8) |
| `src/app/ke-hoach-san-xuat/cau-hinh/page.tsx` | Cấu hình sản xuất (6 tab) |
| `src/components/production/*` | Cảnh báo, form tiến độ, nút xếp lịch, nhập dở, màn cấu hình |
| `src/components/erp-nav.tsx` | Thêm nhóm menu **Sản xuất** |

### 12.2. Kết quả kiểm chứng thật (PostgreSQL 14 + chạy app thật)

| Kiểm tra | Kết quả |
|---|---|
| `prisma migrate deploy` toàn bộ 15 migration | ✅ chạy sạch trên DB trống |
| Migration khớp Prisma `migrate diff` | ✅ 35/35 câu lệnh, 0 thiếu / 0 thừa, 100% cột |
| Seed | ✅ 8 tổ · 16 công đoạn · 19 lý do |
| `npx tsc --noEmit` · `eslint` · `npm run build` | ✅ 0 lỗi; 4 trang + 4 API route build được |
| Tạo 4 đơn thật qua API đơn hàng | ✅ bộ số 1–5; đơn NHÁP **không** được cấp bộ số |
| Đồng bộ bộ cửa → kế hoạch | ✅ 5 bộ (đơn nháp bị loại), 110 công đoạn = 5 × 22 |
| Gọi đồng bộ lần 2 | ✅ `createdSets: 0, skipped: 5` (idempotent) |
| Sửa đơn (route xoá–tạo lại dòng hàng, id đổi 1,2,3 → 7,8,9) rồi đồng bộ lại | ✅ 0 bộ trùng (nhờ chống trùng theo **mã đơn + Bộ số**) |
| Bỏ Vân theo màu | ✅ màu 11 & 14 → `VAN = BO_QUA`; màu 01 → `CHUA_LAM` |
| Xếp lịch tự động | ✅ 107 công đoạn; 1 công đoạn/ngày; khung/cánh/phào **cùng ngày**; bỏ Chủ nhật (27/9, 4/10, 11/10) |
| Cập nhật tiến độ 8/17 công đoạn | ✅ `percentDone = 47%`, trạng thái → `DANG_SX`, tự ghi mốc thực tế |
| Hoàn thành hết công đoạn | ✅ 100% → `HOAN_THANH` + `actual_completed_at` |
| Đánh dấu đã giao | ✅ `DA_GIAO` + `actual_delivered_at` |
| Cảnh báo | ✅ 5 "Sắp trễ" + "Chờ chương trình máy cắt"; bộ 3 hạn 10/10 cần xong 09/10 (hạn − 1 đệm) |
| Tải theo tổ | ✅ Tổ máy 16 cánh/ngày (không đếm trùng 3 phần); Tổ vân chỉ nhận 2 bộ màu 01 |
| Render 7 trang | ✅ tất cả HTTP 200 (kể cả `/`, `/orders`, `/reports/production-load`) |

**Ghi chú về con số 75% trễ:** với dữ liệu test, app báo **5/5 bộ không kịp hạn** — vì một bộ cần ~15–16 ngày làm việc
mà hạn giao chỉ cách 2–3 tuần. Đây chính là điều app sẽ chỉ ra cho sale/điều hành: **hạn giao phải cách ngày xác nhận đơn
ít nhất ~3 tuần** (đường găng + đệm giao hàng), nếu không thì trễ là tất yếu.

### 12.3. Hai điểm cần bạn chốt lại (đang dùng mặc định, sửa ở Cấu hình sản xuất)

1. **2.1 — đơn vị thời gian**: đang coi **24 giờ = 1 ngày làm việc**, nghỉ Chủ nhật + lễ. Tổng đường găng 1 bộ = **16 công đoạn ≈ 15–16 ngày làm việc**. Nếu thực tế xưởng gối công đoạn nhiều hơn, đặt `Gối công đoạn = 24` để rút ngắn.
2. **2.4 — ngưỡng quá tải**: cảnh báo theo **năng lực TỪNG TỔ** (Tổ máy 60 · Tổ hàn 45 · Tổ sơn 44 · Tổ đóng gói 50 cánh/ngày), **không** dùng mốc 80 cánh/ngày. Tổ vân để trống năng lực (VAN12 chưa trả lời) nên không bị cảnh báo.

### 12.4. Chưa làm (đợt C/D)

- In **phiếu lệnh sản xuất A4** + danh sách việc dán xưởng (KH25/KH26) — cần thêm `api/*.py` + `vercel.json`.
- **Thư viện chương trình máy cắt**: bảng + màn cấu hình đã có, seed trống; chưa có màn import file.
- Ràng buộc **gom lô màu sơn ≥ 20 cánh** và **tối đa 2 lượt đổi khuôn/ngày**: hiện là *gợi ý/cảnh báo*, chưa ép trong thuật toán.
- Báo cáo **OTD / % lỗi / năng suất tổ / lý do trễ** (đợt D).
- Màn hình **chặn xoá bộ đã vào kế hoạch** — hiện route xoá đơn vẫn xoá được; production_sets sẽ mồ côi liên kết `order_item_id` (đã chống trùng bằng Bộ số nên không sinh trùng).

---

## 13. V136.1 — LỆNH SẢN XUẤT CHA – CON (nhà máy chốt 26/09/2026)

### 13.1. Nhà máy xác nhận gì (nguyên văn ý)

- **Tất cả các cửa đều đi qua tất cả các công đoạn.** *(Riêng Vân: nhà máy xác nhận lại **màu sơn 11 và 14 KHÔNG cần vân** → đã GIỮ điều kiện bỏ qua `PAINT_COLOR:11,14` ở công đoạn Vân.)*
- **1 bộ cửa gồm: cánh · khung · phào** (phào rời + phào biệt thự).
  - Số lượng **cánh** = số cánh × số bộ (số cánh đọc từ tên sản phẩm diễn giải: "cửa đi 1 cánh" = 1, "2 cánh" = 2, "4 cánh" = 4).
  - Số lượng **khung** = số bộ.
  - Số lượng **phào** = (**số cánh + số phào rời mặc định** theo loại cửa) × số bộ,
    với mặc định **cửa đi = 3 · cửa sổ = 4** (nhà máy chốt 26/09/2026; ví dụ cửa đi 1 cánh → 1 + 3 = **4**, cửa sổ 1 cánh → 1 + 4 = **5**).
- **Quy trình**: Thiết kế (theo bộ) → Bồi Lares (theo bộ) → **tách 3 phần**:
  - CÁNH: cắt cánh → chấn cánh → hàn cánh → **ép cánh**
  - KHUNG: cắt khung → chấn khung → hàn khung
  - PHÀO: cắt phào → chấn phào → hàn phào
- Khi **cả 3 phần báo hoàn thành hàn** → kiểm tra **đủ bộ** → **Test cơ khí** (ghép cánh + khung + phào, đủ bộ mới test được).
- Test xong → **Sơn cả bộ** 1 lượt → **tách lại**: **Vân riêng cho cánh / khung / phào**.
- Khi **cả 3 phần báo hoàn thành vân trên cùng bộ** → **Vệ sinh + Đóng gói** → **Kho**.
- Mô hình theo dõi: **lệnh sản xuất CHA – CON** (cha = bộ cửa; con = cánh, khung, phào).

### 13.2. Đã triển khai

| Việc | Chi tiết |
|---|---|
| Bảng mới | `production_component_orders` (lệnh con) — `kind` = CANH/KHUNG/PHAO, `qty_expected`, unique `(set_id, kind)` |
| Lệnh con của 1 bộ | Đúng **3 dòng**, số lượng theo 13.1 |
| Công đoạn của lệnh con | Các `production_tasks` có `scope` = kind → **KHÔNG cần đổi bảng tasks**, tận dụng `scope` sẵn có |
| Trạng thái / % / ngày lệnh con | **Suy ra** từ công đoạn (một nguồn sự thật, không lưu trùng) |
| Vân | `scope_mode` = PARTS, `scope_parts` = KHUNG,CANH,PHAO; bỏ `skip_condition` |
| Ép cánh | PARTS/CANH — **chỉ chờ Hàn của CÁNH** |
| Gate "đủ bộ" | Thực thi trong `updateSetProgress`: chặn (trả lỗi) khi báo Đang làm/Xong mà công đoạn bắt buộc chưa xong |
| Migration | **`20260926234500_production_component_orders`** (migration RIÊNG, chạy sau `20260926233000_production_planning`) |
| Bản SQL dán tay | `migrate-production-v136-1.sql` |

**Cơ chế gate** dùng đúng trường `requires_stage` sẵn có, với luật **cùng phạm vi trước, toàn bộ sau**:
- Nếu công đoạn bắt buộc **có trong cùng lệnh con** → chỉ cần phần đó xong (Ép cánh ← Hàn của CÁNH).
- Nếu không → cần **tất cả** (Test cơ khí ← Hàn của cả 3 phần; Lắp kính/Đóng gói ← Vân của cả 3 phần).

### 13.3. Kiểm chứng thật (PostgreSQL 14 + app thật + DB test)

| Kiểm tra | Kết quả |
|---|---|
| Chuỗi **16 migration** trên DB trống | ✅ chạy sạch, gồm cả migration V136.1 |
| DDL khớp Prisma | ✅ 39/39 câu lệnh, 11/11 bảng khớp cột |
| `tsc` · `eslint` · `npm run build` | ✅ 0 lỗi |
| 5 bộ vào kế hoạch | ✅ 120 công đoạn = 5 × 24; **không công đoạn nào BO_QUA** |
| Vân tách 3 phần | ✅ `VAN` có 3 dòng CANH/KHUNG/PHAO |
| Cắt / Chấn / Hàn | ✅ mỗi công đoạn 3 dòng theo phần, **cùng ngày** khi xếp lịch |
| Ép cánh | ✅ chỉ 1 dòng scope CANH |
| Test cơ khí · Sơn | ✅ 1 dòng scope BO (cả bộ) |
| Số lượng lệnh con | ✅ "Cửa đi 4 cánh" × 2 bộ → Cánh 8 · Khung 2 · Phào 6 |
| **Gate sai thứ tự** | ✅ CHẶN: Test cơ khí khi chưa hàn · Lắp kính khi chưa vân · Cắt khi chưa Bồi Lares |
| **Gate same-scope** | ✅ Ép cánh cho qua khi **chỉ** Hàn CÁNH xong, nhưng Test cơ khí vẫn bị chặn |
| **Gate đủ bộ** | ✅ sau khi cả 3 phần hàn xong → Test cơ khí mở; sau khi cả 3 phần vân xong → Lắp kính mở |
| Tiến độ lệnh con | ✅ cả 3 con 100% khi cha 90% (cha còn chờ/đóng gói/kho) |
| Render 7 trang | ✅ HTTP 200; trang chi tiết hiện bảng CHA–CON + dấu 🔒 ở công đoạn bị khoá |

### 13.4. ⚠️ SỰ CỐ ĐÃ XẢY RA & ĐÃ XỬ LÝ — đọc kỹ

Trong lúc kiểm chứng, tôi đã **chạy app khi chưa có `.env.local`** → app nối vào **DB production Supabase** (không phải DB test) và **tạo 5 đơn test** (`TEST-A`…`TEST-E`, id 33–37, bộ số 12127–12131).

**Đã xử lý:**
1. Dừng app ngay.
2. Đối chiếu từng id ↔ mã đơn (33=TEST-A … 37=TEST-E) rồi **xoá đúng 5 đơn đó** bằng API `DELETE /api/orders/:id`.
3. Kiểm tra lại: **không còn đơn `TEST-%`** nào trong production.
4. Xác nhận **không** có dữ liệu sản xuất nào được tạo (`production_sets = 0`, `production_tasks = 0` — vì lúc đó bảng `production_component_orders` chưa có nên giao dịch đồng bộ đã rollback).

**Còn một dấu vết cần bạn quyết:** bộ đếm **Bộ số** trong `system_settings` (key `ORDER_SET_NUMBER_COUNTER`) đã nhảy lên ~**12131**, nên đơn thật tiếp theo sẽ bắt đầu từ **12132** (5 số 12127–12131 bị bỏ trống). Không gây trùng số, chỉ là mất 5 số. Muốn đưa về đúng như trước thì chạy **1 câu SQL** sau (an toàn, không tái sử dụng số đã cấp):

```sql
UPDATE system_settings
SET value = (SELECT COALESCE(MAX(set_no::bigint), 0)::text FROM sales_order_items WHERE set_no ~ '^[0-9]{1,18}$')
WHERE key = 'ORDER_SET_NUMBER_COUNTER';
```

Từ giờ, quy tắc bắt buộc khi thử trên máy: **luôn có `.env.local` trỏ DB test và luôn kiểm `/api/health/db` trước khi ghi.**

### 13.5. Ba điểm ĐÃ ĐƯỢC NHÀ MÁY CHỐT (26/09/2026)

**① Công thức SỐ PHÀO — đã chốt và đã sửa code.**

    số phào của MỘT bộ = số cánh + số phào rời MẶC ĐỊNH theo loại cửa (cửa đi = 3 · cửa sổ = 4)
    tổng số phào      = số phào của một bộ × số bộ

| Trường hợp | Kết quả app | Ví dụ nhà máy |
|---|---|---|
| Cửa đi 1 cánh, 1 bộ | 1 + 3 = **4** | **4** ✅ |
| Cửa sổ 1 cánh, 1 bộ | 1 + 4 = **5** | **5** ✅ |
| Cửa đi 4 cánh, 2 bộ | (4 + 3) × 2 = **14** | — |
| Cửa đi 2 cánh, 1 bộ | (2 + 3) × 1 = **5** | — |

Công thức này **không** dùng số lượng phào nhập ở dòng chi tiết của đơn (đúng như nhà máy xác nhận).
Số mặc định 3 và 4 sửa được ở **Cấu hình sản xuất → Số phào rời mặc định — cửa ĐI / cửa SỔ**.

**② Thứ tự công đoạn KHUNG** — đã xác nhận: **cắt khung → chấn khung → hàn khung** (đúng như đang chạy).

**③ Màu sơn 11 và 14 KHÔNG cần vân** — đã xác nhận. Điều kiện `PAINT_COLOR:11,14` được **giữ** ở công đoạn Vân;
3 công đoạn Vân của bộ màu 11/14 ở trạng thái **BỎ QUA**, và điều kiện "đủ 3 phần vân" coi BỎ QUA là đã xong.

**Kiểm chứng lại sau khi chốt:**

| Kiểm tra | Kết quả |
|---|---|
| Số phào theo công thức mới | ✅ 4 · 5 · 14 · 5 đúng cả 4 trường hợp |
| Bộ màu **14**: sau sơn, Lắp kính **mở ngay** (không cần vân) | ✅ |
| Bộ màu **01**: sau sơn, Lắp kính **bị chặn** chờ vân; đủ 3 phần vân → mở | ✅ |
| Chuỗi 16 migration · `tsc` · `eslint` · `build` · render 5 trang | ✅ 0 lỗi, HTTP 200 |

### 13.6. Còn lại (đợt C/D)

Không đổi so với mục 12.4: in phiếu lệnh SX A4 · ép ràng buộc gom lô sơn ≥ 20 cánh & ≤ 2 lượt đổi khuôn/ngày · báo cáo OTD / % lỗi / năng suất tổ / lý do trễ · màn import chương trình máy cắt.
