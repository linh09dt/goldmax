-- ============================================================================
-- V140 — THÊM "TỔ THIẾT KẾ" CHO CÔNG ĐOẠN THIẾT KẾ
--
-- Hiện tại `THIET_KE` nằm chung tổ `KY_THUAT` ("Kỹ thuật (Thiết kế + Bồi Lares/CAM)").
-- Bản này tách riêng:
--   • Thêm tổ  TO_THIET_KE  ("Tổ thiết kế", kind = 'TO') → hiện được trên bảng tải.
--   • Công đoạn THIET_KE  →  trỏ sang TO_THIET_KE.
--   • Công đoạn BOI_LARES (CAM)  →  vẫn ở KY_THUAT (đổi tên tổ cho đúng: "Kỹ thuật (Bồi Lares / CAM)").
--
-- ⚠️ KHÔNG có thay đổi cột/bảng ⇒ KHÔNG cần `prisma migrate`.
--    Idempotent — chạy lại vô hại. Chạy trước hay sau khi deploy code đều được.
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- 1) Thêm tổ thiết kế
--    Năng lực/ngày để TRỐNG: thiết kế tuỳ model, nhiều phi tiêu chuẩn (TK2) nên
--    chưa có con số chuẩn — nhập ở Cấu hình sản xuất khi xưởng có số.
--    sort_order = 5 để đứng trước Tổ máy (10) theo đúng thứ tự công đoạn.
-- ----------------------------------------------------------------------------
INSERT INTO "production_work_centers"
  ("code", "name", "kind", "people_count", "shifts_per_day", "hours_per_shift",
   "capacity_per_day", "capacity_unit", "active", "sort_order", "note", "created_at", "updated_at")
VALUES
  ('TO_THIET_KE', 'Tổ thiết kế', 'TO', NULL, NULL, 8,
   NULL, 'CANH', true, 5,
   'Thiết kế bản vẽ CAD (TK1–TK6). Leader thiết kế duyệt trước khi chuyển Bồi Lares (TK6). Tùy model, nhiều phi tiêu chuẩn (TK2) ⇒ CHƯA khai năng lực/ngày; nhập ở Cấu hình sản xuất khi có số thì bảng tải mới cảnh báo quá tải.',
   now(), now())
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 2) Công đoạn Thiết kế → tổ thiết kế
-- ----------------------------------------------------------------------------
UPDATE "production_stages"
SET "work_center_code" = 'TO_THIET_KE',
    "updated_at"       = now()
WHERE "code" = 'THIET_KE'
  AND "work_center_code" IS DISTINCT FROM 'TO_THIET_KE';

-- ----------------------------------------------------------------------------
-- 3) Việc Thiết kế ĐÃ SINH cho các bộ cũ → chuyển sang tổ mới
--    (nếu không, bộ cũ vẫn hiện tổ Kỹ thuật; muốn giữ nguyên lịch sử thì bỏ câu này)
-- ----------------------------------------------------------------------------
UPDATE "production_tasks"
SET "work_center_code" = 'TO_THIET_KE',
    "updated_at"       = now()
WHERE "stage_code" = 'THIET_KE'
  AND "work_center_code" IS DISTINCT FROM 'TO_THIET_KE';

-- ----------------------------------------------------------------------------
-- 4) Tổ KY_THUAT nay chỉ còn Bồi Lares / CAM → sửa tên cho khỏi sai
--    (chỉ đổi nếu tên còn nguyên bản gốc, không đè tên bạn đã tự sửa)
-- ----------------------------------------------------------------------------
UPDATE "production_work_centers"
SET "name"       = 'Kỹ thuật (Bồi Lares / CAM)',
    "note"       = COALESCE("note", '') || ' [V140] Đã TÁCH Thiết kế sang tổ riêng TO_THIET_KE; tổ này còn Bồi Lares/CAM.',
    "updated_at" = now()
WHERE "code" = 'KY_THUAT'
  AND "name" = 'Kỹ thuật (Thiết kế + Bồi Lares/CAM)';

COMMIT;

-- ----------------------------------------------------------------------------
-- Kiểm tra sau khi chạy (không bắt buộc):
--   SELECT code, name, kind, sort_order, capacity_per_day
--     FROM production_work_centers WHERE code IN ('TO_THIET_KE','KY_THUAT') ORDER BY sort_order;
--   SELECT code, name, work_center_code FROM production_stages
--    WHERE code IN ('THIET_KE','BOI_LARES') ORDER BY seq;
--     -- THIET_KE → TO_THIET_KE · BOI_LARES → KY_THUAT
--   SELECT work_center_code, count(*) FROM production_tasks WHERE stage_code='THIET_KE' GROUP BY 1;
-- ----------------------------------------------------------------------------
