# V40 - Chuẩn hóa mẫu Xuất Excel / PDF đơn hàng

- Chỉ thay đổi bố cục file xuất Excel và trang in/PDF của từng đơn hàng.
- Bám mẫu GOLDMAX: header xanh nhạt, logo thật, tiêu đề giữa, badge `MẪU CỬA`, thông tin đơn hàng 4 cụm.
- Bảng xuất dùng 19 cột, kết thúc tại `Ghi chú (18)` như mẫu; không đưa cột ảnh sản phẩm vào bản xuất.
- `Màu sơn (5)` dùng nền vàng như mẫu.
- Dòng hàng chính xanh nhạt, dòng chi tiết nền trắng, ghi chú chữ đỏ.
- Giữ nguyên toàn bộ logic dữ liệu, tính tiền, chiết khấu, cọc, cước vận chuyển và câu hỏi xác nhận.
- Không thay đổi schema / Supabase.
