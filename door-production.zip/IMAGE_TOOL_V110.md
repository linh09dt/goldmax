# V110 — Công cụ "Chuẩn hóa ảnh SP" (dán ảnh → nhận ảnh chuẩn để xuất file)

## Vấn đề

Cột **Hình ảnh SP** khi xuất file bị **ép vào khung cố định**, không dùng kích thước gốc của ảnh:

| Nơi xuất | Khung ảnh | Tỉ lệ khung |
|---|---|---|
| Excel V1 — `src/lib/order-export.ts:378` | 82 × 48 px | 1,708 |
| Excel V2 — `src/lib/order-export-v2.ts:386` | 58 × 36 px | 1,611 |
| PDF — `python/reportlab_order_v2.py:492,567` | thumbnail tối đa 240 px, in trong khung 11 mm | (giữ tỉ lệ) |
| Bản in web — `src/app/globals.css:298` | tối đa 86 × 58 px | 1,483 |

Hai khung Excel là quyết định, trung bình **≈ 1,66 → chọn tỉ lệ vàng 5:3**. Ảnh chụp điện thoại (dọc/vuông) bị Excel **bóp méo** thành 82 × 48 px, còn trong PDF thì hiện rất bé. Ngoài ra ảnh gốc vài MB làm file Excel/PDF phình to.

## Giải pháp: trang `/cong-cu-anh`

- Dán ảnh bằng **Ctrl + V** ở bất kỳ đâu trong trang (giống thao tác dán vào ô Hình ảnh SP), hoặc kéo-thả / chọn file (JPG, PNG, WEBP).
- Trả về ảnh **5:3, nền trắng, JPEG**, mặc định **400 × 240 px**, tự hạ chất lượng JPEG để không vượt mức KB đặt trước (mặc định 300 KB).
- Hai kiểu đưa ảnh vào khung: **Vừa khung** (giữ trọn ảnh, đệm nền trắng — an toàn) và **Tràn khung** (lấp đầy ô, cắt cạnh thừa).
- Cảnh báo khi ảnh gốc lệch tỉ lệ > 15% hoặc nhỏ hơn 240 px (ngưỡng nét của PDF).
- **Xem thử trong đúng khung** 82×48 / 58×36 / 86×58 / 240 px trước khi dùng.
- **Copy để dán vào ô ảnh**: copy ảnh chuẩn vào clipboard (dạng PNG) → sang form đơn hàng, bấm ô *Hình ảnh SP* rồi Ctrl + V. Hoặc **Tải ảnh chuẩn (.jpg)** để upload như bình thường.
- Xử lý **hoàn toàn phía trình duyệt (canvas)** — ảnh không rời khỏi máy người dùng, không cần server, không cần đăng nhập, không đụng database.
- Ảnh chụp điện thoại được **xoay theo EXIF** trước khi cắt (`imageOrientation: "from-image"`), ảnh lớn được **hạ mẫu từng bước** nên không bị răng cưa.

## Kiểm chứng (chạy thật trên `next build` + trình duyệt)

**a) Đúng khung, không méo — đo trực tiếp pixel của ảnh ra:**

| Ảnh vào | Chế độ | Ra | Khối màu đo được | Tỉ lệ khối | Viền |
|---|---|---|---|---|---|
| 1600 × 1000 (1,6:1) | Vừa khung | 400 × 240 | — | — | — |
| **600 × 900 (dọc)** | Vừa khung | 400 × 240 | 64 × 96 px | **0,667** = đúng tỉ lệ gốc (240/360) | 4 góc trắng `255,255,255` |
| **600 × 900 (dọc)** | Tràn khung | 400 × 240 | 160 × 120 px | cắt cạnh, không bóp | 4 góc kín ảnh `29,78,215` |
| 600 × 900 → preset 240 × 144 | Tràn khung | 240 × 144 | 96 × 72 px | 1,333 = cắt cạnh | kín ảnh |

→ Ảnh dọc vào vẫn **giữ đúng hình dáng** (0,667 không đổi), chỉ đệm nền trắng — đây chính là thứ mà Excel trước đây làm hỏng.

**b) Cảnh báo lệch tỉ lệ:** ảnh 600 × 900 hiện đúng thông báo “lệch **60%** so với tỉ lệ 5:3”.

**c) Tự hạ chất lượng theo mức KB:** ảnh nhiễu 1600 × 1000 (PNG 2,2 MB) → 400 × 240 = **73 KB @ JPEG 88%**; đặt mức tối đa 60 KB → **58 KB @ JPEG 80%**.

**d) Copy clipboard:** bấm *Copy để dán vào ô ảnh* → `navigator.clipboard.write` thành công, hiện badge “✓ Đã copy — sang form đơn hàng, bấm vào ô Hình ảnh SP rồi Ctrl + V”.

**e) Chất lượng mã:** `npx tsc --noEmit` → 0 lỗi · `npx eslint` 3 file → **0 lỗi 0 cảnh báo** · `npm run build` → **Compiled successfully**, route `/cong-cu-anh` được prerender tĩnh (không cần database).

**Ảnh chụp:** `cong-cu-anh-1.png`.

## File thay đổi

- `src/components/product-image-tool.tsx` — **mới**: toàn bộ công cụ (dán/kéo-thả, canvas 5:3, nén theo KB, copy clipboard, xem thử theo khung).
- `src/app/cong-cu-anh/page.tsx` — **mới**: trang bọc `ErpShell`, không truy vấn DB.
- `src/components/erp-nav.tsx` — thêm mục **Chuẩn hóa ảnh SP** vào nhóm menu “Công cụ”.

## Lưu ý

- **Không cần migration DB**, không đổi schema, không đổi API upload (`/api/orders/images` vẫn giới hạn JPG/PNG/WEBP ≤ 8 MB).
- Không đụng vào logic giá, KH/Lượng, xuất Excel/PDF hiện có.
- **Còn tồn (chưa sửa, cần bạn quyết):** trong `order-export.ts:380` và `order-export-v2.ts:388`, sau khi nhúng ảnh code **ép dòng đầu của mỗi bộ cửa cao tối thiểu 43pt (V1) / 34pt (V2)** trong khi các dòng khác chỉ 28pt / 29pt → dòng đầu mỗi bộ cao vống lên, đây mới là nguyên nhân “vỡ form” khi xuất Excel. Ảnh chuẩn hóa **không sửa được** lỗi này vì nó do chiều cao dòng, không do ảnh. Cách sửa: tính chiều cao cả khối bộ cửa rồi scale ảnh vừa khít (giữ tỉ lệ, canh giữa) và bỏ dòng ép 43pt.
