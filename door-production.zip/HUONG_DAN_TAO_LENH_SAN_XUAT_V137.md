# V137 — HƯỚNG DẪN TẠO LỆNH SẢN XUẤT
*(cập nhật theo V138: đã có in phiếu lệnh A4 · kế hoạch tuần · nút tạo lệnh từ trang đơn · xoá lệnh khi bộ bị xoá khỏi đơn · sửa số lượng lệnh con · báo cáo OTD)*

**Dành cho:** người lên kế hoạch · văn phòng xưởng · quản đốc.
**Liên quan:** `KE_HOACH_SAN_XUAT_V136.md` (thiết kế) · `AP_DUNG_V136.md` (cài đặt).

> **Một câu tóm tắt:** tạo lệnh sản xuất = **đưa bộ cửa của đơn ĐÃ XÁC NHẬN vào kế hoạch**.
> App tự sinh **1 lệnh CHA (bộ cửa) + 3 lệnh CON (cánh · khung · phào) + 24 công đoạn**. Không nhập tay công đoạn nào.

---

## 1. Điều kiện để một bộ cửa vào được kế hoạch

| # | Điều kiện | Không đạt thì |
|---|---|---|
| 1 | Đơn ở trạng thái **ĐÃ XÁC NHẬN** (đã bấm **Lưu đơn hàng** ở màn tạo/sửa đơn) | Bộ **không hiện** trong danh sách. Đơn **Nháp** (bấm *Lưu nháp*) không vào kế hoạch |
| 2 | **Loại đơn** nằm trong danh sách cho phép. Hiện cài đặt: **cả 3 loại** (Đơn hàng mẫu · Sản xuất · Đơn làm lại) | Bộ không hiện. Sửa ở **Cấu hình sản xuất → Cấu hình chung → Loại đơn đưa vào kế hoạch** |
| 3 | Đơn đã có **Bộ số** (hệ thống tự cấp lúc bấm *Lưu đơn hàng*) | Không có Bộ số thì không định danh được → không vào kế hoạch |
| 4 | Bộ cửa **chưa có lệnh** trong kế hoạch | App **bỏ qua**, không tạo trùng (xem mục 5) |
| 5 | Trong DB đã có các bảng sản xuất (đã chạy migration V136 + V136.1) | Bấm tạo lệnh sẽ báo lỗi *"table … does not exist"* → chạy migration trước |

**Lưu ý về thông tin thiếu:** nếu bộ cửa thiếu **Cao / Rộng / Hướng mở / Màu sơn**, app **vẫn tạo lệnh được** nhưng sẽ hiện
cảnh báo vàng *"bộ chưa đủ thông tin để xếp lịch"* và không xếp lịch cho bộ đó. Cần sale bổ sung rồi nhập lại.
(Nhà máy chốt: đủ điều kiện vào sản xuất = khách đã xác nhận + đủ kích thước, hướng mở, màu sắc.)

**Đơn vị tạo lệnh:** **mỗi dòng bộ cửa (mỗi Bộ số) = 1 lệnh cha.**
Các dòng **phụ kiện/chi tiết** (khoá, phào, kính, ô thoáng…) **KHÔNG** tạo lệnh riêng — chúng đi kèm bộ cửa.
Một đơn có 5 bộ cửa → 5 lệnh cha → 15 lệnh con.

---

## 2. Ba cách tạo lệnh

### Cách 1 — Tạo cho MỘT VÀI bộ cụ thể *(dùng hằng ngày)*

```
Menu trái:  Sản xuất  →  Kế hoạch sản xuất
        ↓
Nút (góc phải):  “Nhập bộ đang sản xuất dở (N)”
        ↓
Danh sách hiện các bộ CHƯA có lệnh  →  tick chọn từng bộ
        ↓
Nút:  “Đưa N bộ đã chọn vào kế hoạch”
        ↓
Báo: “Đã đưa N bộ vào kế hoạch (… công đoạn). Bỏ qua 0 bộ đã có.”
```

### Cách 2 — Tạo cho TẤT CẢ bộ còn lại *(dùng lần đầu, hoặc sau khi nhập nhiều đơn)*

Cùng màn hình trên → bấm **“Đưa TẤT CẢ vào kế hoạch”**.
Nút này đưa **toàn bộ** bộ cửa của mọi đơn đã xác nhận mà chưa có lệnh (không giới hạn).
Màn hình chỉ **hiện** 300 bộ đầu (xếp theo hạn giao gần nhất) nhưng nút "TẤT CẢ" làm hết.

### Cách 3 — Tạo cho một ĐƠN cụ thể *(từ trang đơn hàng)*

```
Quản lý đơn hàng  →  mở một đơn đã xác nhận
        ↓
Nút  “Tạo lệnh sản xuất”  (cạnh nút Sửa đơn)
        ↓
Báo: “Đã tạo N lệnh sản xuất (… công đoạn) cho đơn …”  +  link “Mở kế hoạch sản xuất”
```

Nút này **chỉ bật khi đơn ĐÃ XÁC NHẬN**; đơn nháp hiện chú thích *“Đơn nháp — chưa có Bộ số”*.
Bấm lại **không tạo trùng**.

---

## 3. App tự sinh ra những gì

Khi tạo lệnh cho **1 bộ cửa**, app tạo **1 + 3 + 24**:

### 3.1. Một LỆNH CHA = bộ cửa

Sao chép từ đơn: Bộ số · mã đơn · loại đơn · khách hàng · tên sản phẩm · model · **hướng mở** · **màu sơn** ·
Cao × Rộng · số cánh · số bộ · KH/Lượng · **hạn giao**.

| Trường | Giá trị tự điền |
|---|---|
| Trạng thái | **Chờ xếp lịch** |
| Ưu tiên | **Đơn làm lại = 0** (chen trước) · **Sản xuất = 5** · **Đơn hàng mẫu = 8** |
| Số cánh quy đổi (để tính tải) | số cánh × số bộ |

### 3.2. Ba LỆNH CON (Cánh · Khung · Phào)

| Lệnh con | Số lượng |
|---|---|
| **CÁNH** | số cánh × số bộ *(số cánh đọc từ tên sản phẩm: "cửa đi 4 cánh" = 4)* |
| **KHUNG** | số bộ |
| **PHÀO** | (**số cánh + phào rời mặc định**) × số bộ — mặc định **cửa đi = 3 · cửa sổ = 4** |

*Ví dụ:* cửa đi 1 cánh, 1 bộ → Cánh 1 · Khung 1 · **Phào 4**. Cửa sổ 1 cánh → Phào **5**.

### 3.3. 24 CÔNG ĐOẠN (16 công đoạn; Cắt/Chấn/Hàn/Vân tách theo phần)

| # | Công đoạn | Phạm vi | Tổ |
|---|---|---|---|
| 1 | Thiết kế (bản vẽ CAD) | cả bộ | Kỹ thuật |
| 2 | Bồi Lares (nạp chương trình máy cắt) | cả bộ | Kỹ thuật |
| 3 | *Chờ sau Bồi Lares* | cả bộ | — |
| 4 | **Cắt** | khung · cánh · phào | Tổ máy |
| 5 | **Chấn** | khung · cánh · phào | Tổ máy |
| 6 | **Hàn + mài ba via** | khung · cánh · phào | Tổ hàn |
| 7 | **Ép cánh** | **chỉ cánh** | Tổ hàn |
| 8 | **Test cơ khí** (QC) | cả bộ | Tổ hàn |
| 9 | *Chờ trước sơn* | cả bộ | — |
| 10 | **Sơn** | cả bộ (1 lượt) | Tổ sơn |
| 11 | *Chờ khô / nguội sau sơn* | cả bộ | — |
| 12 | **Vân** | khung · cánh · phào | Tổ vân |
| 13 | *Chờ sau vân* | cả bộ | — |
| 14 | **Lắp kính + phụ kiện** | cả bộ | Tổ đóng gói |
| 15 | **Vệ sinh + Đóng gói** | cả bộ | Tổ đóng gói |
| 16 | **Kho / giao hàng** | cả bộ | Kho |

**App tự bỏ qua 2 trường hợp** (không phải sửa tay):

- **Bồi Lares**: nếu **model đã có chương trình** trong *Cấu hình sản xuất → Chương trình máy cắt* → công đoạn này thành **Bỏ qua**.
- **Vân**: nếu **màu sơn là 11 hoặc 14** → cả 3 công đoạn Vân (cánh/khung/phào) thành **Bỏ qua** (đã chốt: 2 màu này không cần vân).

### 3.4. Điều kiện chuyển bước (app CHẶN, không chỉ cảnh báo)

| Công đoạn | Chỉ mở khi |
|---|---|
| Cắt | Bồi Lares xong |
| Chấn | Cắt xong (cùng phần) |
| Hàn | Chấn xong (cùng phần) |
| Ép cánh | Hàn xong **của CÁNH** (không cần chờ khung/phào) |
| **Test cơ khí** | **CẢ 3 phần** (cánh + khung + phào) **đã hàn xong** ← "đủ bộ mới test được" |
| Sơn | Test cơ khí xong |
| Vân | Sơn xong |
| **Lắp kính + Đóng gói** | **CẢ 3 phần đã vân xong** ← "đủ bộ mới chuyển vệ sinh, đóng gói" |
| Kho / giao hàng | Đóng gói xong |

Báo sai thứ tự sẽ bị **từ chối** kèm lý do, ví dụ:
> *"Chưa đủ điều kiện: Test cơ khí (đang chờ Hàn + mài ba via). Phải báo hoàn thành công đoạn trước rồi mới báo bước sau."*

---

## 4. Làm gì tiếp sau khi tạo lệnh

1. **Xếp lịch** — ở màn *Kế hoạch sản xuất*, bấm **“Xếp lịch tự động”**.
   - Mặc định chỉ xếp các bộ đang **Chờ xếp lịch**.
   - Tick **“Xếp lại cả bộ đã có lịch”** nếu muốn xếp lại từ đầu (ô này hỏi xác nhận).
   - Cách xếp: **hạn giao gần nhất trước**, đơn làm lại chen trước; tôn trọng **năng lực từng tổ** và **nghỉ Chủ nhật + ngày lễ**.
   - Kết quả: mỗi công đoạn có **ngày kế hoạch**; các phần khung/cánh/phào của cùng công đoạn **cùng ngày**.
2. **Xem tải** — bảng **Tải theo tổ và ngày** trên màn kế hoạch: xanh = trong năng lực, vàng > 85%, đỏ = vượt năng lực.
3. **Cập nhật tiến độ** — mở một bộ cửa → bảng **Cập nhật tiến độ theo công đoạn**:
   chọn Trạng thái (Chưa làm / Đang làm / Xong / Tạm dừng / Bỏ qua) → ghi Lý do nếu tạm dừng hoặc làm lại → bấm **Lưu tiến độ**.
   - Đổi nhiều dòng rồi lưu **một lần** (app ghi gộp, nhanh).
   - Dòng bị khoá hiện dấu **🔒 chờ …** và không chọn được *Đang làm / Xong*.
   - Khi tất cả công đoạn **Xong** → bộ tự chuyển **Hoàn thành** và ghi mốc hoàn thành sản xuất.
4. **Đánh dấu đã giao** — nút **“Đánh dấu đã giao”** ở trang bộ cửa (ghi ngày giao thực tế, dùng tính tỷ lệ giao đúng hạn).
5. **Kế hoạch tuần + chốt kế hoạch** — menu *Sản xuất → Kế hoạch tuần*:
   chọn khoảng ngày (mặc định Thứ 2 → Chủ nhật) → **“Tạo / gom bộ vào kế hoạch”** → nhập tên người chốt → **“Chốt kế hoạch”**.
   Chốt xong vẫn sửa được (không khoá) nhưng mọi thay đổi đều ghi lịch sử. Có nút **Mở lại** và **Xoá**.
6. **In cho xưởng** — menu *Sản xuất → Kế hoạch sản xuất → nút “In phiếu lệnh SX”*, hoặc trang **In phiếu lệnh sản xuất**:
   - **Phiếu lệnh A4** cho một bộ (từ trang bộ cửa) hoặc cho mọi bộ có việc trong ngày (lọc theo tổ);
   - **Danh sách việc theo ngày** — mỗi tổ một trang để dán ở xưởng.
   Trong trang in bấm **In / Lưu PDF** (khổ A4 dọc).
7. **Xem kết quả** — *Báo cáo → Sản xuất (OTD)*: giao đúng hạn, bộ giao trễ, tỷ lệ làm lại, thời gian thực tế từng
   công đoạn so với định mức, năng suất tổ, lý do trễ, tồn thành phẩm.

---

## 5. Câu hỏi thường gặp

**Bấm tạo lệnh 2 lần có bị trùng không?**
Không. App chống trùng theo **id dòng hàng** *và* theo **(mã đơn + Bộ số)** → bấm lại báo `skipped`. Nhờ vậy **sửa đơn
rồi tạo lại cũng không sinh lệnh trùng** (dù sửa đơn làm id dòng hàng đổi).

**Sửa đơn sau khi đã tạo lệnh thì tiến độ có mất không?**
Không mất. Lệnh sản xuất là bản ghi riêng; liên kết giữ theo **mã đơn + Bộ số**. Thông tin cũ (kích thước, màu…)
trong lệnh **không tự cập nhật** — nếu đơn đổi kích thước/màu thì phải sửa/xử lý riêng (xem mục 6).

**Vì sao không thấy bộ nào trong danh sách?**
Kiểm 3 việc: (1) đơn đã bấm **Lưu đơn hàng** chưa; (2) **loại đơn** có bị tắt trong Cấu hình sản xuất không;
(3) bộ đó **đã có lệnh** rồi (thì nó nằm ở danh sách chính, không nằm ở màn nhập).

**Một bộ cửa tạo ra mấy lệnh?**
**1 lệnh cha + 3 lệnh con** (cánh/khung/phào), tổng **24 công đoạn**. Một đơn 5 bộ → 5 lệnh cha.

**Đơn hàng mẫu có vào kế hoạch không?**
Có — hiện đặt cả 3 loại đơn đều vào (nhà máy chốt 26/09/2026). Ưu tiên thấp hơn đơn sản xuất và đơn làm lại.

**Bộ không nằm trong đơn nào (làm bù, hàng tồn) thì tạo lệnh thế nào?**
Hiện **chưa hỗ trợ tạo lệnh tay** ngoài đơn hàng — cần tạo một đơn cho bộ đó trước.

**In phiếu lệnh sản xuất cho tổ?**
**Đã có.** Vào *Sản xuất → Kế hoạch sản xuất → “In phiếu lệnh SX”*, chọn tổ + ngày.
Phiếu khổ **A4 dọc** gồm thông tin bộ, 3 lệnh con và bảng công đoạn có ô tích để tổ ghi.
Có thêm **Danh sách việc theo ngày** (mỗi tổ 1 trang) để dán ở xưởng.

**Chốt kế hoạch tuần (giám đốc nhà máy duyệt)?**
**Đã có.** *Sản xuất → Kế hoạch tuần*: tạo kế hoạch cho khoảng ngày, gom các bộ đã xếp lịch, rồi bấm **Chốt kế hoạch**
(ghi tên giám đốc nhà máy). Chốt không khoá việc cập nhật tiến độ nhưng có lưu lịch sử ai chốt/mở lại.

**Bộ cửa bị xoá khỏi đơn thì lệnh sản xuất ra sao?**
Tự xử lý khi lưu đơn: bộ **chưa có tiến độ** → **xoá hẳn lệnh**; bộ **đã có tiến độ** → **giữ lại và đánh dấu ĐÃ HUỶ**
(không phá công xưởng đã làm). Bộ đã huỷ không hiện trên bảng kế hoạch.

**Cần đổi số lượng cánh/khung/phào của một bộ thì làm sao?**
Mở bộ cửa → khối **“Số lượng lệnh con (sửa tay được)”** → sửa 3 ô → bấm **Lưu tiến độ**.
Số hiện cạnh là số theo **công thức** để bạn đối chiếu; sửa khác thì số công thức hiện màu vàng.

---

## 6. Những việc CHƯA làm (để không hiểu nhầm là đã có)

| Việc | Trạng thái |
|---|---|
| In **phiếu lệnh sản xuất A4** + danh sách việc dán xưởng | ✅ **đã có** |
| Màn **kế hoạch tuần** + nút **chốt kế hoạch** (giám đốc duyệt) | ✅ **đã có** |
| Nút **“Tạo lệnh sản xuất”** ngay trên trang đơn hàng | ✅ **đã có** |
| **Xoá lệnh sản xuất** khi bộ cửa bị xoá khỏi đơn | ✅ **đã có** (chưa tiến độ → xoá; có tiến độ → đánh dấu HUỶ) |
| Sửa **số lượng lệnh con** bằng tay | ✅ **đã có** |
| Báo cáo **OTD · % lỗi · năng suất tổ · lý do trễ** | ✅ **đã có** (xem trên màn, chưa xuất Excel) |
| Ép ràng buộc **gom lô sơn ≥ 20 cánh** / **≤ 2 lượt đổi khuôn/ngày** | mới chỉ cảnh báo |
| Màn **nhập chương trình máy cắt** từ file | chưa có (đang nhập tay ở Cấu hình sản xuất) |
| **Đăng nhập / phân quyền** | chưa có (ai có link cũng sửa được) |

---

## 7. Ai làm gì

| Bước | Ai làm | Ở đâu |
|---|---|---|
| Chốt đơn với khách | Kinh doanh | Quản lý đơn hàng → Lưu đơn hàng (cấp Bộ số) |
| Đưa bộ cửa vào kế hoạch | Người lên kế hoạch | Sản xuất → Kế hoạch sản xuất → Nhập bộ đang sản xuất dở (hoặc nút “Tạo lệnh sản xuất” ở trang đơn) |
| Xếp lịch, xem tải, xử lý quá tải | Người lên kế hoạch / quản đốc | Sản xuất → Kế hoạch sản xuất |
| Cập nhật tiến độ từng công đoạn | Văn phòng xưởng | Sản xuất → Kế hoạch sản xuất → mở bộ cửa |
| Sửa năng lực tổ, thời lượng công đoạn, lý do | Quản đốc | Sản xuất → Cấu hình sản xuất |
| Chốt kế hoạch tuần | Giám đốc nhà máy | Sản xuất → Kế hoạch tuần |
| In phiếu lệnh SX / danh sách việc | Văn phòng xưởng | Sản xuất → Kế hoạch sản xuất → In phiếu lệnh SX |
| Xem OTD, % lỗi, năng suất | Chủ / quản đốc | Báo cáo → Sản xuất (OTD) |
