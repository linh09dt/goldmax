-- ============================================================================
-- V144 — MỐC SẢN XUẤT (ngày bắt đầu) + TARGET TỪNG CÔNG ĐOẠN — BẢN CHẠY TAY (idempotent)
--
-- Giống hệt `prisma/migrations/20260927010000_production_targets/migration.sql`.
-- Chỉ nhập MỘT mốc "Ngày bắt đầu sản xuất" ở bộ cửa → bấm "Đưa vào sản xuất" → bộ thành WIP ở
-- công đoạn đầu, hệ thống tự suy target của mọi công đoạn sau theo thứ tự bước + số giờ của bước
-- (1 ngày = 2 ca × 8h = 16 giờ; bỏ Chủ nhật + ngày lễ) → cảnh báo CHẬM / KHÔNG KỊP.
-- `planned_start/planned_end` giữ nguyên, sau này là "ngày kế hoạch sản xuất" theo điều độ.
--
-- MỖI CÂU TỰ CHỨA: không bảng tạm, không session state.
-- ============================================================================

ALTER TABLE "production_tasks" ADD COLUMN IF NOT EXISTS "target_start" DATE;
ALTER TABLE "production_tasks" ADD COLUMN IF NOT EXISTS "target_end"   DATE;
CREATE INDEX IF NOT EXISTS "production_tasks_target_end_idx" ON "production_tasks"("target_end");

ALTER TABLE "production_sets" ADD COLUMN IF NOT EXISTS "started_at" DATE;
ALTER TABLE "production_sets" ADD COLUMN IF NOT EXISTS "target_end" DATE;
CREATE INDEX IF NOT EXISTS "production_sets_target_end_idx" ON "production_sets"("target_end");

-- ----------------------------------------------------------------------------
-- KIỂM TRA SAU KHI CHẠY
--   SELECT column_name FROM information_schema.columns
--    WHERE table_name IN ('production_tasks','production_sets')
--      AND column_name IN ('target_start','target_end','started_at');
--   -- kỳ vọng: target_start, target_end (tasks) + started_at, target_end (sets)
-- ----------------------------------------------------------------------------
