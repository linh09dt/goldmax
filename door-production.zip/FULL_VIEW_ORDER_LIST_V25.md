# ERP V25 - Full View Danh sách đơn hàng

- Áp dụng cho tab **Quản lý đơn hàng** `/orders`.
- Bỏ `min-width: 3600px` và bỏ cuộn ngang.
- Bảng dùng `table-layout: fixed` + `width: 100%` để toàn bộ cột nằm trong chiều rộng màn hình.
- Giảm font/padding của riêng bảng danh sách, cho phép tiêu đề và dữ liệu xuống dòng trong ô.
- Phân bổ độ rộng theo mức quan trọng: địa chỉ, ghi chú, mã hàng, đơn giá/thành tiền rộng hơn; các cột số/ngắn hẹp hơn.
- Nút thao tác được xếp dọc để không làm tràn cột.
- Không đổi dữ liệu, logic KH/Lượng, sửa/xóa, giá, import, xuất Excel/PDF hay database.

## Cập nhật

Chép patch chồng lên bản hiện tại, sau đó chạy:

```cmd
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần migrate database.
