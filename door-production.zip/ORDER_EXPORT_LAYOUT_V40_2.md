# V40.2 - Điều chỉnh Excel/PDF đơn hàng

- Ẩn dòng Chiết khấu khi chiết khấu bằng 0% hoặc số tiền chiết khấu bằng 0.
- Thông tin đầu đơn hàng hiển thị trên một dòng, không tự xuống dòng trong Excel/PDF.
- Dòng chi tiết/phụ kiện: các ô kích thước cửa Cao/Rộng/Khuôn có dữ liệu được tô xanh nhạt theo mẫu.
- Giữ nguyên cột Hình ảnh SP và logic nhiều trang A4 ngang từ V40.1.
- Không thay đổi DB/Supabase hoặc logic nghiệp vụ khác.
