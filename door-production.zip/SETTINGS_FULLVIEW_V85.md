# V85 — Tab CẤU HÌNH: full view, hết cuộn ngang

## Yêu cầu

> “review tất cả các bản trong tab cấu hình, mình muốn fullview, không bị kéo ngang qua lại”

## Hiện trạng trước V85 (đo thật trong trình duyệt ở 1280×720)

Mỗi bảng trong tab CẤU HÌNH có `min-width` cứng lớn hơn khung chứa → xuất hiện thanh cuộn ngang **bên trong khung**, phải kéo qua kéo lại mới xem được các cột bên phải.

| Khu vực | Bảng | Bề rộng bảng | Khung chứa | Tràn ngang |
|---|---|---|---|---|
| **A1** Danh mục hàng hóa | Danh sách hàng hóa (10 cột) | 1344px | 696px | **648px** |
| **A1** | Lịch sử tạo lại Master Data (4 cột) | 720px | 696px | **24px** |
| **A2** Danh mục cấu hình | Dải 5 nút chọn nhóm | 988px | 696px | **292px** |
| **A2** | Bảng giá trị (6 cột) | 1000px | 696px | **304px** |
| **B1** Cấu hình tính toán | Bảng rule (9 cột) | 1560px | 696px | **864px** |

Lưu ý: bảng rule B1 dài **1560px** nên **kể cả trên màn 1920 vẫn tràn ngang** (vùng nội dung tối đa của tab CẤU HÌNH là ~1530px) — đây là lỗi thật, không chỉ do màn hẹp.

## Cách làm

Đổi toàn bộ bảng của tab CẤU HÌNH sang chế độ **full view**: bảng luôn bằng đúng bề rộng khung, các cột chia theo %, không còn cuộn ngang.

### 1. `src/app/globals.css` — thêm 2 class dùng chung

- `.erp-table-full` — `table-layout: fixed` + (đã có `width: 100%` từ `.erp-table`) → bề rộng cột lấy theo % khai báo ở hàng `<th>` đầu tiên. Kèm giảm padding ô (6px), cỡ chữ (ô 12px, tiêu đề 10.5px) và `overflow-wrap: anywhere` để nội dung dài tự xuống dòng thay vì đẩy bảng rộng ra.
- `.erp-cell-input` — ô nhập/select dùng bên trong bảng: luôn `width: 100%; min-width: 0; max-width: 100%`, padding nhỏ, chữ 11.5px. Nhờ vậy input/select **co theo ô** chứ không kéo bảng rộng ra.

### 2. `src/components/settings/settings-ui.tsx` — `SettingsTable`

Bỏ prop `minWidthClass`; mọi bảng dùng chung dùng `erp-table erp-table-full`. Bề rộng cột khai báo bằng % ngay tại `<th>` của từng bảng.

### 3. Chia lại % cột cho từng bảng (tổng luôn = 100%)

| Bảng | Phân bổ cột |
|---|---|
| **A1** (10 cột) | STT 4 · TENHANG 12 · Diễn giải 22 · MODEL 12 · ĐVT 5 · Giá đại lý 10 · Giá bán lẻ 10 · Trạng thái 9 · Nguồn 9 · Thao tác 7 |
| **A1** lịch sử (4 cột) | Thời gian 22 · File 48 · Số hàng 15 · Bỏ qua 15 |
| **A2** (6 cột) | Mã 16 · Tên hiển thị 34 · Thứ tự 9 · Nguồn 17 · Trạng thái 11 · Thao tác 13 |
| **B1** (9 cột) | Áp dụng cho 13 · Nhóm hàng 10 · Model 11 · Cách tính KH/Lượng 16 · Đề xuất Cao 15 · Đề xuất Rộng 15 · Ghi chú 12 · Dùng 3 · Xóa 5 |

Bỏ toàn bộ `min-w-*`, `w-*` cứng trong các ô (ví dụ `min-w-80`, `min-w-52`, `min-w-64`, `w-64`, `min-w-256`) — chính chúng là nguyên nhân ép bảng rộng ra.

### 4. Sửa các chi tiết gây tràn

- **Dải 5 nút chọn nhóm ở A2**: từ “dải cuộn ngang” (`flex` + `min-w-[188px] shrink-0`) → **lưới tự xuống dòng** (`grid sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5`). Hết cuộn ngang.
- **Thanh chọn A1/A2/B1 (chỉ hiện dưới 1280)**: cũng đổi từ dải cuộn ngang → lưới 2–3 cột.
- **A1**: đơn vị **“đ” chuyển lên tiêu đề cột** (`GIÁ ĐẠI LÝ (Đ)`, `GIÁ BÁN LẺ (Đ)`) để cột giá đủ chỗ hiện số trên 1 dòng. Nút Sửa/Xóa cho phép xuống dòng.
- **B1**: ô **Ghi chú đổi từ input 1 dòng → textarea 2 dòng** nên ghi chú dài hiện đủ nội dung trong cột hẹp; thêm `title` cho tất cả select để rê chuột xem nhãn đầy đủ khi cột hẹp; rút gọn nhãn `Theo Ô thoáng 1TK/2TK/3TK/4TK` → **`Theo số TK ô thoáng`** (nội dung 1TK/2TK/3TK/4TK vẫn còn ở khối ví dụ bên dưới bảng).

## Kiểm chứng

- `npx tsc --noEmit` → 0 lỗi. `npm run build` → OK.
- `npx eslint` 5 file đã sửa → **4 lỗi, đúng bằng bản V83** (lỗi cũ `react-hooks/set-state-in-effect` trong `master-options.tsx`), không thêm lỗi mới.
- Đo thật trong trình duyệt (chỉ đọc Supabase production), cả **1280×720** và **mô phỏng 1920×1080**:

| Tab | Khổ màn | Số khung còn cuộn ngang | Bề rộng bảng vs khung | Nhãn bị cắt |
|---|---|---|---|---|
| A1 Danh mục hàng hóa | 1280 | **0** | 696 / 696 · 696 / 696 | 0 |
| A2 Danh mục cấu hình | 1280 | **0** | 696 / 696 | 0 |
| B1 Cấu hình tính toán | 1280 | **0** | 696 / 696 | 49 nhãn (màn hẹp, có tooltip) |
| A1 | ~1920 | **0** | 1335 / 1335 · 1335 / 1335 | 0 |
| A2 | ~1920 | **0** | 1335 / 1335 | 0 |
| B1 | ~1920 | **0** | 1335 / 1335 | 0 (chỉ lệch 3px do làm tròn) |

- Trang không bị cuộn ngang ở mọi trường hợp (`document.scrollWidth == clientWidth`).
- Chiều cao dòng A1 tại 1280: 52–55px (chữ tự xuống 2 dòng), B1 tại 1920: ~59px.

## Lưu ý

- Bảng rule **B1 có 9 cột toàn select nhãn dài** (“Cao × Rộng / 1.000.000”, “Nhập tay / giữ nguyên”…). Từ khoảng **1600px trở lên** thì hiện đủ; ở màn **1280–1440** một số nhãn trong B1 sẽ bị cắt bớt — **rê chuột vào select để xem đầy đủ** (đã gắn tooltip). Đây là giới hạn vật lý: muốn hiện đủ mọi nhãn thì bảng cần ~1800px, mà vùng nội dung tối đa chỉ ~1530px.
- Nếu muốn B1 dễ đọc hơn ở màn ≤1440, có 3 hướng (nói mình biết chọn hướng nào): (1) rút gọn thêm nhãn select, (2) tách mỗi rule thành thẻ 2 hàng có nhãn phía trên, (3) cho thanh chọn A1/A2/B1 chỉ hiện từ 1600px để vùng nội dung rộng thêm ~250px.
- Không đổi logic nghiệp vụ, không đổi dữ liệu, không đổi Prisma schema → **không cần `npm run db:migrate`**.

## File thay đổi

- `src/app/globals.css` — thêm `.erp-table-full`, `.erp-cell-input`.
- `src/components/settings/settings-ui.tsx` — `SettingsTable` chuyển sang full view.
- `src/components/settings/settings-workspace.tsx` — thanh chọn A1/A2/B1 hết cuộn ngang.
- `src/components/item-master.tsx` — A1: chia % cột, bỏ min-width, đơn vị “đ” lên tiêu đề.
- `src/components/master-options.tsx` — A2: dải nhóm thành lưới, chia % cột.
- `src/components/calculation-config.tsx` — B1: chia % cột, select/input co theo ô, ghi chú thành textarea, tooltip.
