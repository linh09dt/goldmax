# HƯỚNG DẪN SỬ DỤNG & BÀN GIAO
## ERP SẢN XUẤT CỬA — GOLDMAX

*Cập nhật: 26/09/2026 — bản V135*

> Toàn bộ ảnh trong tài liệu là **ảnh chụp thật** từ hệ thống đang chạy với dữ liệu thật.
> Số tròn màu cam (①②③…) trên ảnh được giải thích ngay bên dưới mỗi ảnh.

---

# PHẦN A — HƯỚNG DẪN SỬ DỤNG

## A0. Luồng công việc tổng thể

```
CẤU HÌNH (A1/A2/A3/B1)  →  LẬP ĐƠN (thông tin → bộ cửa → phụ kiện → ảnh)  →  LƯU / XÁC NHẬN
        ↑                                                                          ↓
   Báo cáo · Doanh thu · Cước vận chuyển  ←──────  XUẤT EXCEL / PDF / IN  ←──  SỬA ĐƠN
```

Nguyên tắc cần nhớ:

1. **Chỉ đơn SẢN XUẤT ở trạng thái ĐÃ XÁC NHẬN mới được tính vào doanh thu.** Đơn Mẫu / Làm lại và đơn Nháp không vào doanh thu.
2. **Tiền = Số KH/Lượng × Đơn giá.** Dòng không có KH/Lượng vẫn hiện đầy đủ trong đơn và file xuất, nhưng thành tiền = 0.
3. **Bộ số** chỉ hiện khi đơn đã xác nhận (số bắt đầu cấu hình ở B1).
4. **Hàng hóa lấy giá & ĐVT từ Danh mục hàng hóa (A1)** — không nhập giá tay ở danh mục thì đơn sẽ lấy 0.

---

## A1. Tổng quan (dashboard)

![Bước 1 — Tổng quan](anh/01-tong-quan.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Menu trái | Vào **Tổng quan, Quản lý đơn hàng, Thông tin khách hàng, Báo cáo, Doanh thu, Tính cước vận chuyển, Cấu hình**. Bấm logo/thu gọn được menu. |
| ② | Nút “+ Tạo đơn hàng” | Lập đơn mới. Nút này có ở mọi trang danh sách. |
| ③ | Thẻ KPI | Số liệu theo **kỳ đang lọc**: doanh thu (chỉ đơn Sản xuất đã xác nhận), số đơn đã xác nhận, đơn nháp, sản lượng… Mỗi thẻ có so sánh kỳ trước và **cùng kỳ năm trước**. |
| ④ | Bộ lọc nhanh | Đại lý · Loại đơn · Trạng thái · Khoảng ngày → bấm **Lọc**; **Xoá lọc** để về mặc định. |
| ⑤ | “Đơn cần chú ý” | Đơn sắp tới hạn giao / chưa xác nhận. Bấm mã đơn để mở. |
| ⑥ | “Mở trong Quản lý đơn hàng” | Nhảy sang danh sách đơn **giữ nguyên điều kiện lọc** (drill-down). |

*Mẹo:* biểu đồ bên dưới (doanh thu theo tháng, cơ cấu loại đơn, top đại lý/NVKD/sản phẩm) đều bấm được để nhảy sang danh sách tương ứng.

---

## A2. Quản lý đơn hàng — lọc, xem nhanh, xuất file

![Bước 2 — Quản lý đơn hàng](anh/02-quan-ly-don-hang.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Tiêu đề | Đang ở khu vực Quản lý đơn hàng. |
| ② | Nút **Lọc** | Bộ lọc nằm gọn trên **một dòng** (mã đơn, khách hàng, NVKD, loại đơn, trạng thái, ngày…). Trường dài thì cuộn ngang, nhưng nút **Lọc / Xoá lọc / Xuất Excel** luôn hiển thị. |
| ③ | **Xuất Excel** | Xuất danh sách **đúng theo điều kiện đang lọc** (kèm dòng hàng, ảnh SP). |
| ④ | **Xuất PDF** | Xuất PDF danh sách/đơn để gửi khách hoặc lưu hồ sơ. |
| ⑤ | Bảng chi tiết | Bấm một đơn → bảng chi tiết bên phải hiện ra; **“Xem đầy đủ 23 cột”** để xem toàn bộ cột dòng hàng (gồm Ảnh SP). |

*Lỗi thường gặp:* xuất Excel ra thiếu điều kiện lọc → kiểm tra bạn đã bấm **Lọc** trước khi xuất.

---

## A3. Tạo đơn — thông tin đơn hàng

![Bước 3 — Thông tin đơn hàng](anh/03-tao-don-thong-tin.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Khối **Thông tin đơn hàng** | Khai: mã đơn, loại đơn, trạng thái, ngày cập nhật, NVKD, mã/tên đại lý, ngày đặt, ngày cần giao, người nhận, SĐT, địa chỉ, vùng miền, số km. Các ô có dấu **\*** là bắt buộc. |
| ② | Loại đơn | **Đơn hàng mẫu / Sản xuất / Đơn làm lại** — chọn đúng vì chỉ **Sản xuất** mới vào doanh thu. |
| ③ | Khối nhập từ Excel | Nếu đã có mẫu đơn hàng (.xlsb/.xlsx), mở khối này để nhập — dòng hàng hiện có sẽ được thay bằng dữ liệu trong file. |
| ④ | **Lưu nháp / Lưu đơn hàng** | *Lưu nháp* = giữ ở trạng thái Nháp (chưa sinh Bộ số, chưa vào doanh thu). *Lưu đơn hàng* = xác nhận đơn. |

---

## A4. Tạo đơn — nhập bộ cửa

![Bước 4 — Nhập bộ cửa](anh/04-tao-don-bo-cua.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Thẻ **Bộ cửa #1** | Mỗi thẻ = **một bộ cửa**. Bấm tiêu đề để thu gọn/mở rộng; nút **Nhân bản bộ** để tạo bộ giống hệt (đơn nhiều bộ giống nhau nhập rất nhanh). |
| ② | Ô **Nhóm cửa** | Chỉ liệt kê hàng hóa thuộc phân loại **DÒNG CHÍNH** (mặc định là “Cấp cửa”). Danh sách này do bạn cấu hình ở **Cấu hình → A3**. |
| ③ | **+ Thêm phụ kiện** | Thêm dòng phụ kiện/chi tiết cho bộ cửa này (xem bước 5). |
| ④ | **+ Thêm bộ cửa** | Thêm bộ cửa khác trong cùng đơn. |

**Cách nhập nhanh một bộ cửa:**

1. Chọn **Nhóm cửa** → chọn **Model** → hệ thống tự điền tên diễn giải, ĐVT, **đơn giá đại lý** (lấy từ A1).
2. Nhập **Cao / Rộng / Khuôn**, hướng mở, màu sơn, ô thoáng… theo bản vẽ.
3. Nhập **Số lượng bộ** — **Số KH/Lượng** có thể tự tính theo rule ở **B1**, nếu không có rule thì nhập tay.
4. Kiểm tra **Thành tiền** ở cuối dòng.

---

## A5. Tạo đơn — phụ kiện / chi tiết của bộ cửa

![Bước 5 — Phụ kiện / chi tiết](anh/05-phu-kien-chi-tiet.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Khối **PHỤ KIỆN / CHI TIẾT CỦA BỘ CỬA (n)** | Nằm ngay dưới bộ cửa: khóa, phào, ô thoáng, kính, **chi phí gia công**, phụ phí… |
| ② | Ô **Nhóm hàng** | Liệt kê hàng hóa thuộc phân loại **DÒNG PHỤ KIỆN / CHI TIẾT**. Nhóm hàng của phân loại có bật **“Nhóm riêng”** (ví dụ **CHI PHÍ GIA CÔNG**) nằm trong một nhóm riêng trong danh sách — chọn nhanh hơn. |
| ③ | **+ Thêm phụ kiện** | Thêm dòng chi tiết mới. Mỗi dòng có Model, số lượng, KH/Lượng, đơn giá, ghi chú. |

> **Lưu ý quan trọng:** dòng phụ kiện **không bắt buộc** điền KH/Lượng để hiện trong đơn và file xuất (chỉ cần có dữ liệu: mã hàng, kích thước, số lượng, giá…). Nhưng **tiền chỉ được tính khi có KH/Lượng × Đơn giá**, nên nếu muốn dòng đó ra tiền thì phải điền KH/Lượng.

---

## A6. Tạo đơn — ảnh sản phẩm (nhiều ảnh)

![Bước 6 — Ảnh sản phẩm](anh/06-anh-san-pham.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Ô **Hình ảnh SP (cả bộ cửa)** | Mỗi bộ cửa dán được **nhiều ảnh (tối đa 6)**. Bấm vào ô rồi **Ctrl+V** để dán; dán liên tiếp nhiều ảnh được, ô tự giữ chọn. |
| ② | Nút **Dán ảnh** | Dán ảnh trực tiếp từ clipboard (không cần Ctrl+V). Cạnh đó là **Thêm ảnh** (chọn file) và bộ đếm **n/6 ảnh**. |
| — | Ô **Rộng / Cao (px)** | Mỗi ảnh đặt cỡ riêng: gõ số hoặc bấm **Mặc định / Nhỏ / Vừa / Lớn**. Để trống = **cỡ mặc định 56 px** (đúng bằng bề rộng cột ảnh khi xuất PDF). |
| — | Nút **Xóa ảnh** | Xoá từng ảnh khỏi bộ cửa. |

**Ảnh xuất ra file thế nào?**
- Excel V1/V2, PDF V2 và bản in đều xuất **đủ các ảnh, xếp theo thứ tự, đúng cỡ đã đặt**; cột Ảnh SP tự nới rộng theo ảnh lớn nhất.
- Dán trùng trong 1,5 giây sẽ **tự bỏ qua** (không bị nhân đôi ảnh).

---

## A7. Xem lại đơn sau khi lưu

![Bước 7 — Chi tiết đơn](anh/07-chi-tiet-don.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | **Chi tiết từng bộ cửa (n)** | Mỗi bộ cửa một khối: dòng chính + các dòng phụ kiện/chi tiết bên dưới + ảnh SP. Cột **BỘ SỐ** chỉ hiện khi đơn đã xác nhận. |
| ② | **Tổng hợp giá trị** | Cước vận chuyển, tổng tiền, chiết khấu (%), số tiền chiết khấu, tổng sau chiết khấu, đặt cọc, trừ tiền nhận hàng tại kho, **thanh toán khi giao hàng**. |
| ③ | **Xuất Excel / Xuất PDF** | Tải file gửi khách hoặc lưu hồ sơ. |
| ④ | **Sửa đơn** | Mở lại form nhập (ảnh, phụ kiện, giá… giữ nguyên). |

---

## A8. Bản in / PDF của đơn

![Bước 8 — Bản in / PDF](anh/08-ban-in-pdf.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Cột **Hình ảnh SP** | Chứa **đủ các ảnh** của bộ cửa, đúng cỡ đã đặt ở bước 6. |

Trang này dùng để **in trực tiếp (Ctrl+P)** hoặc **lưu PDF**; bố cục giống file PDF xuất từ đơn. Nếu cần bản không ảnh, dùng nút xuất PDF và chọn “không kèm ảnh”.

---

## A9. Cấu hình A1 — Danh mục hàng hóa

![Bước 9 — Danh mục hàng hóa](anh/09-cau-hinh-a1.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | **A1 Danh mục hàng hóa** | Toàn bộ TENHANG/MODEL dùng khi lập đơn, kèm tên diễn giải, ĐVT, giá đại lý, giá bán lẻ. |
| ② | Khối **CẤP CỬA** | Hàng hóa dùng làm **dòng chính / bộ cửa** trong đơn. |
| ③ | Khối **PHỤ KIỆN** | Hàng hóa dùng làm **dòng phụ kiện / chi tiết**. |
| ④ | Khối **CHI PHÍ GIA CÔNG** | Nhóm chi phí gia công / khoét / phụ phí — nhập ở dòng chi tiết. |
| ⑤ | Cột **Phân loại** | Đổi phân loại của từng dòng ngay tại đây — **lưu liền**, dòng tự nhảy sang khối mới. |

**Lưu ý:** tên các khối (CẤP CỬA / PHỤ KIỆN / CHI PHÍ GIA CÔNG) **không cố định trong code** — bạn tự thêm/đổi tên/xoá ở **A3**.

**Các nút khác:** *Tạo lại Master Data từ Excel* (nạp lại danh mục; phân loại đã đặt giữ theo MODEL) · *Xuất Master Data* · *+ Thêm hàng hóa* · *Sửa / Xoá* từng dòng.

---

## A10. Cấu hình A3 — Phân loại hàng hóa

![Bước 10 — Phân loại hàng hóa](anh/10-cau-hinh-a3.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | **A3 Phân loại hàng hóa** | Nơi quản lý danh sách phân loại dùng cho A1 và form tạo đơn. |
| ② | **+ Thêm phân loại** | Nhập **Tên**, chọn **Dùng cho** (*Dòng chính (bộ cửa)* hoặc *Dòng phụ kiện / chi tiết*), bật **Nhóm riêng** nếu muốn tách nhóm khi chọn hàng. Mã sinh tự động từ tên. |
| ③ | Bảng phân loại | Sửa **Tên**, **Dùng cho**, **Nhóm riêng**, **Thứ tự**; cột **Hàng hóa** cho biết đang có bao nhiêu mã thuộc phân loại đó. |
| ④ | **Lưu** | Ghi thay đổi. **Đổi tên không làm thay đổi hàng hóa đã gán** vì hệ thống lưu theo mã phân loại. |
| ⑤ | **Xoá** | Nếu còn hàng hóa đang dùng, hệ thống **chặn** và yêu cầu chọn phân loại thay thế để chuyển hàng trước khi xoá. Nút **Ngưng dùng** chỉ ẩn khỏi danh sách chọn, vẫn giữ phân loại cũ. |

**Ví dụ thực tế:** muốn tách riêng “Kính” — bấm **+ Thêm phân loại**, đặt tên *Kính*, chọn *Dòng phụ kiện / chi tiết*, bật *Nhóm riêng* → vào **A1** đổi cột Phân loại của các mã kính sang *Kính* → khi lập đơn, ô “Nhóm hàng” có thêm nhóm riêng **KÍNH**.

---

## A11. Cấu hình B1 — Quy tắc tính toán

![Bước 11 — Cấu hình tính toán](anh/11-cau-hinh-b1.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | **B1 Cấu hình tính toán** | Các quy tắc tự động khi lập đơn. |
| ② | **Làm tròn KH/Lượng** | Số chữ số thập phân của KH/Lượng. |
| ③ | **Rule tính KH/Lượng & đề xuất nhập liệu** | Rule áp theo **Nhóm hàng / Model / Bộ cửa chính**: cách tính KH/Lượng + gợi ý Cao/Rộng. Rule Model ưu tiên hơn rule Nhóm hàng. |
| ④ | **Lưu cấu hình** | Áp cho các đơn tạo/sửa **sau đó**. |

**Khối khác trong B1:** *Bộ số* (số bắt đầu + cơ chế cấp số) và *Tự động tính Đơn giá cửa theo Khuôn*.

---

## A12. Báo cáo Đơn hàng

![Bước 12 — Báo cáo Đơn hàng](anh/12-bao-cao-don-hang.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | **Báo cáo Đơn hàng** | Một trong các báo cáo: Đơn hàng, Sản phẩm, Hiệu quả bán hàng, Công nợ (theo dõi), Tải sản xuất. |
| ② | Bộ lọc | Giống bộ lọc danh sách đơn (một dòng) — áp cho cả biểu đồ và bảng. Nút **Xuất Excel** nằm cùng thanh này. |
| ③ | Biểu đồ | Đơn theo tháng, cơ cấu loại đơn, theo trạng thái, doanh thu/giá trị theo vùng miền, tỉ trọng đơn. |
| ④ | **Mở Quản lý đơn hàng** | Nhảy sang danh sách đơn với đúng điều kiện lọc. |

---

## A13. Theo dõi doanh thu

![Bước 13 — Doanh thu](anh/13-doanh-thu.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | **Theo dõi doanh thu** | Chỉ tính **đơn loại SẢN XUẤT ở trạng thái ĐÃ XÁC NHẬN** (đơn Mẫu / Làm lại / Nháp không vào doanh thu). |
| ② | Bảng theo đơn | Số đơn, tổng tiền, chiết khấu, tổng sau chiết khấu, đặt cọc, còn lại. |
| ③ | Bảng theo sản phẩm | Sản phẩm phát sinh doanh thu — dùng đối chiếu sản lượng. |

**Bộ lọc:** khoảng ngày, khách hàng, NVKD, sản phẩm… **Xuất Excel** để lấy số liệu.

---

## A14. Tính cước vận chuyển

![Bước 14 — Tính cước vận chuyển](anh/14-van-chuyen.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | **Tính cước vận chuyển** | Khu vực tính cước theo bảng giá chuẩn. |
| ② | **Tính cước theo đơn hàng** | Chọn đơn → hệ thống tra bảng cước theo **TENHANG/Model, số bộ, vùng miền, số km**. |
| ③ | **Bảng tiêu chuẩn cước** | Bảng giá cước theo nhóm cửa/kích thước và mức **nhà máy hỗ trợ**. |
| — | **Áp dụng cước vào đơn hàng** | Ghi số cước đã tính vào đơn (nếu bạn dùng cước tự động). |

---

## A15. Tìm kiếm nhanh (Ctrl+K)

![Bước 15 — Tìm kiếm nhanh](anh/15-tim-kiem.png)

| # | Trên ảnh | Giải thích |
|---|---|---|
| ① | Ô tìm kiếm | Bấm **Ctrl+K** ở **bất kỳ trang nào** để mở. Gõ **mã đơn, tên khách hàng** hoặc **mã/tên hàng hóa**; kết quả gồm Đơn hàng và Hàng hóa — bấm để mở thẳng. |

---

# PHẦN B — QUY TẮC NGHIỆP VỤ CẦN NHỚ

| Quy tắc | Nội dung |
|---|---|
| **Doanh thu** | Chỉ đơn `Loại = Sản xuất` **và** `Trạng thái = Đã xác nhận`. |
| **Loại đơn** | Đơn hàng mẫu · Sản xuất · Đơn làm lại. |
| **Trạng thái** | Đơn nháp → Đã xác nhận. |
| **Bộ số** | Chỉ hiện/hiển thị khi đơn **đã xác nhận**; số bắt đầu cấu hình ở **B1**. |
| **Tiền** | `Số KH/Lượng × Đơn giá`. Dòng không có KH/Lượng vẫn hiện nhưng thành tiền 0. |
| **Dòng hiện trong đơn & file xuất** | Dòng **có dữ liệu thật** (mã hàng, kích thước, số lượng, giá, ghi chú, ảnh…). Dòng mẫu rỗng (`0`, `-`, `—`) tự ẩn. **Bộ số tự sinh không tính là dữ liệu.** |
| **Giá & ĐVT** | Lấy từ **Danh mục hàng hóa (A1)** khi chọn Model; nhập tay được nhưng nên khai giá trong danh mục. |
| **Phân loại hàng hóa** | Là **dữ liệu** (bảng `item_categories`), quản lý ở **A3**. Quyết định hàng nào vào ô *Nhóm cửa* / *Nhóm hàng* / nhóm riêng. |
| **Ảnh SP** | Nhiều ảnh/bộ cửa, tối đa **6**; cỡ ảnh theo px (24–800), để trống = mặc định 56 px; ảnh xuất theo đúng cỡ trong Excel/PDF/in. |
| **Đơn vị tiền** | VNĐ, hiển thị có phân cách nghìn. |

---

# PHẦN C — NHỮNG GÌ CHƯA CÓ (giới hạn hiện tại)

Để bạn chủ động khi vận hành, đây là các phần **chưa** được xây (chưa có dữ liệu nền nên không làm):

1. **Giá vốn & lợi nhuận** — chưa có cột giá vốn nên chưa có báo cáo lãi gộp.
2. **Công nợ / phiếu thu** — đã có “còn phải thu” theo đơn (từ tổng tiền − cọc − trừ kho), nhưng **chưa có phiếu thu/đối chiếu công nợ**.
3. **Phân quyền người dùng & nhật ký thao tác** — hiện chưa có đăng nhập/phân quyền trong app; nên đặt sau proxy xác thực nếu cần.
4. **Theo dõi giao hàng / vận đơn**, **thông báo realtime**, **Báo giá – Thanh toán** (đã thống nhất không làm).
5. **Tải sản xuất** chỉ ở mức báo cáo theo KH/Lượng, chưa có lệnh sản xuất/tiến độ công đoạn.

---

# PHẦN D — BÀN GIAO KỸ THUẬT

## D1. Kiến trúc & công nghệ

| Thành phần | Chi tiết |
|---|---|
| Giao diện + API | **Next.js 16** (App Router) + **React 19**, TypeScript |
| Dữ liệu | **PostgreSQL** (Supabase) qua **Prisma 7** (`@prisma/adapter-pg`) |
| Excel | `exceljs` (xuất/nhập), `xlsx` (đọc file nguồn) |
| PDF V2 | Hàm Python `api/order_pdf_v2.py` + `python/reportlab_order_v2.py` (ReportLab) — chạy trên Vercel Python runtime |
| Ảnh | Lưu ở **Supabase Storage** (bucket cấu hình qua `SUPABASE_ORDER_IMAGE_BUCKET`), fallback thư mục `uploads/orders` khi chạy nội bộ |

## D2. Bảng dữ liệu (16 bảng)

| Nhóm | Bảng |
|---|---|
| Đơn hàng | `sales_orders`, `sales_order_items`, `sales_order_item_details`, `sales_order_item_images` (ảnh — mới), `sales_order_requirements`, `order_imports` |
| Danh mục | `item_masters`, `item_categories` (phân loại — mới), `item_master_imports`, `item_attribute_imports`, `master_options` |
| Vận chuyển | `shipping_rates`, `shipping_model_mappings`, `shipping_calculations` |
| Khác | `system_settings` (cấu hình tính toán + bộ đếm Bộ số), `survey_answers` |

## D3. Biến môi trường

| Biến | Dùng cho |
|---|---|
| `DATABASE_URL` | Prisma kết nối Postgres (qua pooler) |
| `DIRECT_URL` | Kết nối trực tiếp (migration; hàm Python đọc đơn) |
| `SUPABASE_URL`, `SUPABASE_SECRET_KEY` / `SUPABASE_SERVICE_ROLE_KEY` | Lưu/đọc ảnh trên Supabase Storage |
| `SUPABASE_ORDER_IMAGE_BUCKET` | Tên bucket chứa ảnh đơn |
| `NEXT_PUBLIC_SUPABASE_URL` | URL công khai để hiển thị ảnh |

## D4. Quy trình deploy (quan trọng)

> **Luôn chạy migration TRƯỚC, rồi mới deploy code.** Ngược lại app sẽ lỗi vì thiếu cột/bảng.

1. **Migration:** `npx prisma migrate deploy` — hoặc mở Supabase → SQL Editor → dán nội dung file trong `prisma/migrations/<tên>/migration.sql`.
2. **Code:** deploy bản mới (Vercel).
3. **Kiểm tra sau deploy** theo checklist D7.

## D5. Migration mới nhất (chạy theo thứ tự)

| Migration | Nội dung |
|---|---|
| `20260926120000_report_indexes` | Index phục vụ báo cáo/dashboard |
| `20260926180000_image_size` | Cột `image_width`, `image_height` (cỡ ảnh chỉnh tay) |
| `20260926200000_item_images` | Bảng `sales_order_item_images` (nhiều ảnh/bộ cửa) + chuyển ảnh cũ thành ảnh số 1 |
| `20260926210000_item_category` | Cột `item_masters.category` + tự phân loại dữ liệu cũ |
| `20260926220000_item_categories` | Bảng `item_categories` (phân loại tự cấu hình) + nạp 3 phân loại đang dùng |

## D6. Lịch sử phiên bản gần đây

| Bản | Nội dung chính |
|---|---|
| **V130** | Thêm 6 trang báo cáo + xuất Excel chung, drill-down từ dashboard, so sánh cùng kỳ năm trước, tìm kiếm Ctrl+K, thêm bộ lọc cho danh sách đơn |
| **V130.1** | Thanh lọc của mọi trang báo cáo gọn **1 dòng** (nút Lọc / Xoá lọc / Xuất Excel luôn hiện) |
| **V131** | Kích thước ảnh SP chỉnh tay (px, giữ tỉ lệ), Excel/PDF/in xuất đúng cỡ, cột ảnh tự nới |
| **V132 / V132.1** | Bỏ tab “Chuẩn hóa ảnh SP”; ô ảnh dễ dán (Ctrl+V), nút Dán/Đổi/Xoá nằm **ngoài** ô ảnh |
| **V133** | **Nhiều ảnh cho một bộ cửa** (tối đa 6) + xuất Excel/PDF/in đủ ảnh |
| **V133.1** | Sửa lỗi **dán ảnh bị nhân đôi** (cờ chặn đồng bộ + chống trùng theo nội dung ảnh) |
| **V133.2** | Dòng phụ kiện/chi tiết hiện & xuất file khi **có dữ liệu thật** (không bắt buộc KH/Lượng) |
| **V134** | Danh mục hàng hóa có **cột phân loại** (Cấp cửa / Phụ kiện / Chi phí gia công) |
| **V134.1** | “Tạo lại Master Data” **giữ phân loại** đã đặt theo MODEL |
| **V135** | Bỏ hard-code: phân loại hàng hóa thành **bảng dữ liệu**, tự thêm/đổi tên/xoá ở **Cấu hình → A3** |

Tài liệu chi tiết từng bản nằm trong repo: `BAO_CAO_MOI_V130.md`, `IMAGE_SIZE_V131.md`, `IMAGE_UX_V132.md`,
`ITEM_IMAGES_V133.md`, `DONG_PHUKIEN_HIEN_THI_V1332.md`, `PHAN_LOAI_HANG_HOA_V134.md`, `ANH_HUONG_PHAN_LOAI_V134.md`,
`PHAN_LOAI_TU_CAU_HINH_V135.md`.

## D7. Checklist sau khi deploy

1. Mở `/` → dashboard hiện số liệu, không lỗi.
2. Mở `/orders` → lọc + **Xuất Excel** ra file có dữ liệu.
3. Mở `/settings?tab=items` → danh mục hiện **đủ khối phân loại**, ô *Phân loại* đổi được.
4. Mở `/settings?tab=categories` → thấy danh sách phân loại, thêm/đổi tên thử rồi trả lại.
5. Tạo 1 đơn thử: 1 bộ cửa + 1 phụ kiện + 1 ảnh → lưu → mở lại đơn → **Xuất Excel** và **Xuất PDF** (kiểm tra ảnh ra đúng).
6. Mở `/revenue` → số liệu khớp đơn vừa xác nhận (nếu là đơn Sản xuất).

## D8. Xử lý sự cố thường gặp

| Hiện tượng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Vừa deploy code, màn hình lỗi cột/bảng không tồn tại | Chưa chạy migration | Chạy migration (D4) rồi tải lại |
| Ô “Nhóm cửa” trống, không chọn được mã cửa | Không còn phân loại nào ở nhóm **Dòng chính** | Vào **Cấu hình → A3** kiểm tra phân loại có `Dùng cho = Dòng chính (bộ cửa)`, và ở A1 có hàng hóa thuộc phân loại đó |
| Dòng phụ kiện hiện nhưng **thành tiền = 0** | Dòng chưa có **Số KH/Lượng** | Nhập KH/Lượng cho dòng đó (hoặc gán rule ở B1 để tự tính) |
| Dán ảnh mà ảnh không hiện | Trình duyệt chặn clipboard | Bấm vào ô ảnh rồi **Ctrl+V**, hoặc dùng nút **Dán ảnh** / **Thêm ảnh** |
| Đơn không vào doanh thu | Sai **loại đơn** hoặc **trạng thái** | Đơn phải là **Sản xuất** + **Đã xác nhận** |
| File PDF báo lỗi khi xuất | Hàm Python gặp ảnh/đơn quá nặng | Thử **Xuất PDF không kèm ảnh**, hoặc giảm cỡ ảnh ở bước 6 |

---

# PHẦN E — BÀN GIAO

| Hạng mục | Nội dung |
|---|---|
| **Mã nguồn** | Thư mục `door-production` (Next.js + Prisma + Python PDF) |
| **Bản cài đặt gần nhất** | `door-production-v135-phan-loai-tu-cau-hinh.zip` |
| **Tài liệu kèm theo** | Tài liệu này (`.md` + `.pdf`), 15 ảnh hướng dẫn trong thư mục `anh/`, và các tài liệu kỹ thuật theo từng bản ở Phần D6 |
| **Dữ liệu mẫu để test** | Danh mục 92 mã hàng, 6 đơn thật (backup 22/09/2026) + đơn demo có ảnh |
| **Việc cần làm khi nhận** | ① Chạy migration D5 theo thứ tự · ② Deploy code · ③ Chạy checklist D7 · ④ Kiểm tra biến môi trường D3 |

*Mọi thay đổi số liệu quan trọng (đổi phân loại, xoá hàng hóa, tạo lại Master Data) nên thực hiện khi không có người đang lập đơn, và nên sao lưu database trước.*
