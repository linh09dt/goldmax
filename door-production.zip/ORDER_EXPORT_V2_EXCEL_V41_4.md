# V41.4 - Excel V2 đồng bộ PDF V2

- Excel V2 đổi tiêu đề thành **THÔNG TIN ĐƠN HÀNG**.
- Header chia Logo / Công ty / Tiêu đề giống PDF V2; logo lớn hơn.
- Khung thông tin 3 cột, 2 dòng giống PDF V2.
- Tỷ lệ 17 cột đồng bộ PDF V2, mở rộng Ghi chú kỹ thuật và Hình ảnh SP.
- Dòng chi tiết nền rất nhạt; dòng chính zebra giống PDF V2.
- Tự tăng chiều cao dòng theo tên hàng/model/ghi chú để không cắt nội dung.
- Giữ hình ảnh sản phẩm trong Excel.
- Giữ checklist + tổng kết tài chính + bằng chữ.
- Bỏ toàn bộ khu vực ký tên ở cuối Excel V2 để đồng bộ PDF V2.
- Footer đổi thành Thông tin Đơn hàng.
- Không thay Excel/PDF cũ, không đổi DB/Supabase.
