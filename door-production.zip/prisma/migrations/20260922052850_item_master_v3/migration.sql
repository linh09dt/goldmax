-- CreateTable
CREATE TABLE "item_masters" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(160) NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "source" VARCHAR(30) NOT NULL DEFAULT 'THU_CONG',
    "last_source_file" VARCHAR(255),
    "last_imported_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "item_masters_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "item_master_imports" (
    "id" SERIAL NOT NULL,
    "file_name" VARCHAR(255) NOT NULL,
    "file_hash" VARCHAR(64) NOT NULL,
    "sheet_name" VARCHAR(120),
    "total_rows" INTEGER NOT NULL DEFAULT 0,
    "new_count" INTEGER NOT NULL DEFAULT 0,
    "changed_count" INTEGER NOT NULL DEFAULT 0,
    "unchanged_count" INTEGER NOT NULL DEFAULT 0,
    "skipped_count" INTEGER NOT NULL DEFAULT 0,
    "error_count" INTEGER NOT NULL DEFAULT 0,
    "issues" JSONB,
    "imported_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "item_master_imports_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "item_masters_code_key" ON "item_masters"("code");

-- CreateIndex
CREATE INDEX "item_masters_active_idx" ON "item_masters"("active");

-- CreateIndex
CREATE INDEX "item_masters_updated_at_idx" ON "item_masters"("updated_at");

-- CreateIndex
CREATE INDEX "item_master_imports_file_hash_idx" ON "item_master_imports"("file_hash");

-- CreateIndex
CREATE INDEX "item_master_imports_imported_at_idx" ON "item_master_imports"("imported_at");
