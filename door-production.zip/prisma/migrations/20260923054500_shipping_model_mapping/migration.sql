-- CreateTable
CREATE TABLE "shipping_model_mappings" (
    "id" SERIAL NOT NULL,
    "source_model" VARCHAR(160) NOT NULL,
    "shipping_model_code" VARCHAR(60) NOT NULL,
    "note" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "shipping_model_mappings_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "shipping_model_mappings_source_model_key" ON "shipping_model_mappings"("source_model");

-- CreateIndex
CREATE INDEX "shipping_model_mappings_active_shipping_model_code_idx" ON "shipping_model_mappings"("active", "shipping_model_code");
