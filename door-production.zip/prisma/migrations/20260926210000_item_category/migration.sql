-- V134: phân loại hàng hóa ở tab CẤU HÌNH
--   DOOR       = CẤP CỬA          (dòng chính / bộ cửa trong đơn)
--   ACCESSORY  = PHỤ KIỆN
--   PROCESSING = CHI PHÍ GIA CÔNG
--
-- Trước đây app đoán phân loại theo tên TENHANG (bắt đầu bằng "Cửa" ⇒ cửa).
-- Từ migration này phân loại là dữ liệu thật, sửa được trong tab Cấu hình.

ALTER TABLE "item_masters" ADD COLUMN "category" VARCHAR(20) NOT NULL DEFAULT 'ACCESSORY';

-- Phân loại dữ liệu đang có theo đúng quy ước cũ để không đổi hành vi đột ngột.
-- 1) TENHANG bắt đầu bằng "Cửa" (có/không dấu) ⇒ CẤP CỬA
UPDATE "item_masters"
SET "category" = 'DOOR'
WHERE "name" ILIKE 'cửa %' OR "name" ILIKE 'cua %' OR "name" ILIKE 'cửa' OR "name" ILIKE 'cua';

-- 2) Các nhóm chi phí gia công / khoét / phụ phí ⇒ CHI PHÍ GIA CÔNG
UPDATE "item_masters"
SET "category" = 'PROCESSING'
WHERE "category" <> 'DOOR'
  AND (
    "name" ILIKE '%gia công%' OR "name" ILIKE '%gia cong%'
    OR "name" ILIKE '%chi phí%' OR "name" ILIKE '%chi phi%'
    OR "name" ILIKE '%phụ phí%' OR "name" ILIKE '%phu phi%'
    OR "name" ILIKE '%khoét%' OR "name" ILIKE '%khoet%'
  );

CREATE INDEX "item_masters_category_idx" ON "item_masters"("category");
