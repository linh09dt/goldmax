-- ============================================================================
-- V142 — LỆNH SẢN XUẤT CHO TỪNG CÔNG ĐOẠN (mã lệnh lưu trong DB)
--
-- Nhà máy yêu cầu 26/09/2026: bộ cửa đang có lệnh CHA (bộ) + 3 lệnh CON
-- (cánh · khung · phào) nhưng MỖI CÔNG ĐOẠN CHƯA CÓ LỆNH RIÊNG.
-- Nay mỗi bộ phát ra:
--   1 lệnh CHA  (kind = 'BO')        — bộ cửa
--   3 lệnh CON  (kind = 'CANH' | 'KHUNG' | 'PHAO')
--   N lệnh CÔNG ĐOẠN (kind = 'CONG_DOAN') — 1 lệnh cho MỖI công đoạn của bộ (24 lệnh/bộ)
-- và MỖI LỆNH CÓ MÃ RIÊNG, in trên phiếu để phát cho tổ và tra cứu trong hệ thống.
--
-- Bảng này CHỈ lưu danh tính + mã lệnh + ngày phát (đúng quy ước của lệnh con ở
-- `production_component_orders`): SỐ LƯỢNG / TRẠNG THÁI / NGÀY KẾ HOẠCH đều SUY RA từ
-- `production_tasks` (lệnh công đoạn) hay từ bộ / lệnh con — KHÔNG lưu trùng để khỏi lệch số.
--
-- ⚠️ Chạy TRƯỚC khi deploy code (bài học V112). Chạy sau các migration V136/V139/V140/V141.
-- ⚠️ Vì file chạy tay này ĐÃ tạo bảng, nếu pipeline có chạy `prisma migrate deploy` thì phải đánh dấu:
--      npx prisma migrate resolve --applied 20260927000000_production_work_orders
--
-- MÃ LỆNH — khớp `src/lib/production/work-order.ts` (mẫu mặc định trong Cấu hình sản xuất):
--   LSX-<mã đơn>-<bộ số>-<seq 02 chữ số><chữ phần>     vd  LSX-26082201QN17DH01-1-40C
--   chữ phần: Cánh = C · Khung = K · Phào = P · cả bộ = B
--   Bộ KHÔNG có mã đơn (nhập bộ đang dở) → LSX-<id bộ>-<seq><chữ phần>
--   lệnh cha / lệnh con dùng seq = 00 (vd …-00B, …-00C)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) BẢNG LỆNH SẢN XUẤT
-- ----------------------------------------------------------------------------
CREATE TABLE "production_work_orders" (
    "id"         SERIAL NOT NULL,
    "code"       VARCHAR(220) NOT NULL,
    "set_id"     INTEGER NOT NULL,
    "task_id"    INTEGER,
    "kind"       VARCHAR(20) NOT NULL,
    "stage_code" VARCHAR(40),
    "scope"      VARCHAR(10),
    "seq"        INTEGER,
    "issued_at"  DATE,
    "issued_by"  VARCHAR(120),
    "note"       TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_work_orders_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_work_orders_code_key" ON "production_work_orders"("code");
CREATE UNIQUE INDEX "production_work_orders_task_id_key" ON "production_work_orders"("task_id");
CREATE INDEX "production_work_orders_set_id_kind_idx" ON "production_work_orders"("set_id", "kind");
CREATE INDEX "production_work_orders_kind_idx" ON "production_work_orders"("kind");
CREATE INDEX "production_work_orders_stage_code_idx" ON "production_work_orders"("stage_code");

ALTER TABLE "production_work_orders"
    ADD CONSTRAINT "production_work_orders_set_id_fkey"
    FOREIGN KEY ("set_id") REFERENCES "production_sets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "production_work_orders"
    ADD CONSTRAINT "production_work_orders_task_id_fkey"
    FOREIGN KEY ("task_id") REFERENCES "production_tasks"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Mỗi bộ chỉ có ĐÚNG 1 lệnh cha và 1 lệnh cho mỗi phần (lệnh công đoạn thì nhiều).
-- ⚠️ Chỉ số RIÊNG PHẦN này không khai được trong schema.prisma → coi là ràng buộc chỉ có ở DB.
CREATE UNIQUE INDEX "production_work_orders_set_id_kind_key"
    ON "production_work_orders"("set_id", "kind")
    WHERE "kind" <> 'CONG_DOAN';

-- ----------------------------------------------------------------------------
-- 2) LỆNH CHA cho các bộ đã có (idempotent)
-- ----------------------------------------------------------------------------
INSERT INTO "production_work_orders" ("code", "set_id", "kind", "seq", "created_at", "updated_at")
SELECT left(btrim(regexp_replace(regexp_replace(upper(
           CASE WHEN nullif(btrim(coalesce(s."order_code", '')), '') IS NULL
                THEN 'LSX-' || s."id"::text || '-00B'
                ELSE 'LSX-' || btrim(s."order_code") || '-'
                     || coalesce(nullif(btrim(coalesce(s."set_no", '')), ''), s."id"::text) || '-00B'
           END), '[^A-Z0-9_./-]', '', 'g'), '-{2,}', '-', 'g'), '-'), 220) AS "code",
       s."id", 'BO', NULL, now(), now()
FROM "production_sets" s
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 3) LỆNH CON (CÁNH / KHUNG / PHÀO) cho các bộ đã có (idempotent)
-- ----------------------------------------------------------------------------
INSERT INTO "production_work_orders" ("code", "set_id", "kind", "seq", "created_at", "updated_at")
SELECT left(btrim(regexp_replace(regexp_replace(upper(
           CASE WHEN nullif(btrim(coalesce(s."order_code", '')), '') IS NULL
                THEN 'LSX-' || s."id"::text || '-00' || co."short"
                ELSE 'LSX-' || btrim(s."order_code") || '-'
                     || coalesce(nullif(btrim(coalesce(s."set_no", '')), ''), s."id"::text)
                     || '-00' || co."short"
           END), '[^A-Z0-9_./-]', '', 'g'), '-{2,}', '-', 'g'), '-'), 220) AS "code",
       s."id", co."kind", NULL, now(), now()
FROM (
    SELECT o."set_id", o."kind",
           CASE o."kind" WHEN 'CANH' THEN 'C' WHEN 'KHUNG' THEN 'K' WHEN 'PHAO' THEN 'P' ELSE 'X' END AS "short"
    FROM "production_component_orders" o
) co
JOIN "production_sets" s ON s."id" = co."set_id"
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 4) LỆNH CHO TỪNG CÔNG ĐOẠN của các bộ đã có (idempotent)
--    Xếp hạng theo TỪNG BỘ và tính CẢ các mã đã có của bộ (cha/3 con) để hậu tố -2, -3…
--    giống hệt cách app sinh mã (`assignWorkOrderCodes`).
-- ----------------------------------------------------------------------------
INSERT INTO "production_work_orders" ("code", "set_id", "task_id", "kind", "stage_code", "scope", "seq", "created_at", "updated_at")
SELECT r."code", r."set_id", r."task_id", 'CONG_DOAN', r."stage_code", r."scope", r."seq", now(), now()
FROM (
    SELECT u."set_id", u."task_id", u."stage_code", u."scope", u."seq",
           CASE WHEN u."rn" = 1 THEN u."base"
                ELSE left(u."base", 220 - length('-' || u."rn"::text)) || '-' || u."rn"::text
           END AS "code"
    FROM (
        SELECT b."set_id", b."task_id", b."stage_code", b."scope", b."seq", b."base",
               row_number() OVER (
                   PARTITION BY b."set_id", b."base"
                   ORDER BY b."is_reserved", b."seq", b."scope", b."task_id"
               ) AS "rn"
        FROM (
            -- (a) mã đã có của bộ — giữ chỗ trước (kể cả lệnh công đoạn sinh ở lần chạy trước)
            SELECT w."set_id", NULL::int AS "task_id", w."stage_code", w."scope", w."seq",
                   w."code" AS "base", 0 AS "is_reserved"
            FROM "production_work_orders" w
            UNION ALL
            -- (b) công đoạn CHƯA có lệnh
            SELECT t."set_id", t."id" AS "task_id", t."stage_code", t."scope", t."seq",
                   left(btrim(regexp_replace(regexp_replace(upper(
                       CASE WHEN nullif(btrim(coalesce(s."order_code", '')), '') IS NULL
                            THEN 'LSX-' || s."id"::text || '-' || lpad(t."seq"::text, 2, '0') || t."short"
                            ELSE 'LSX-' || btrim(s."order_code") || '-'
                                 || coalesce(nullif(btrim(coalesce(s."set_no", '')), ''), s."id"::text)
                                 || '-' || lpad(t."seq"::text, 2, '0') || t."short"
                       END), '[^A-Z0-9_./-]', '', 'g'), '-{2,}', '-', 'g'), '-'), 220) AS "base",
                   1 AS "is_reserved"
            FROM (
                SELECT k."set_id", k."id", k."stage_code", k."scope", k."seq",
                       CASE upper(btrim(coalesce(k."scope", '')))
                         WHEN 'CANH' THEN 'C' WHEN 'KHUNG' THEN 'K' WHEN 'PHAO' THEN 'P' WHEN 'BO' THEN 'B'
                         ELSE 'X'
                       END AS "short"
                FROM "production_tasks" k
                WHERE NOT EXISTS (SELECT 1 FROM "production_work_orders" w2 WHERE w2."task_id" = k."id")
            ) t
            JOIN "production_sets" s ON s."id" = t."set_id"
        ) b
    ) u
    WHERE u."task_id" IS NOT NULL
) r
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 5) KIỂM TRA — BÁO LỖI TO nếu có bộ thiếu lệnh (không để im lặng)
--    Kỳ vọng mỗi bộ: 4 lệnh cố định + đúng 1 lệnh cho mỗi công đoạn.
--    Nếu báo lỗi: thường do 2 bộ CÙNG Bộ số trong một đơn (mã lệnh trùng) — sửa dữ liệu,
--    hoặc mở bộ đó và bấm "Sinh lại" (API action=rebuild) để sinh lại toàn bộ lệnh.
-- ----------------------------------------------------------------------------
DO $v142_check$ DECLARE thieu integer; BEGIN
    SELECT count(*) INTO thieu
    FROM "production_sets" s
    WHERE (SELECT count(*) FROM "production_work_orders" w WHERE w."set_id" = s."id")
        < 4 + (SELECT count(*) FROM "production_tasks" t WHERE t."set_id" = s."id");
    IF thieu > 0 THEN
        RAISE EXCEPTION 'V142: % bộ THIẾU lệnh sản xuất (cần 4 lệnh cố định + 1 lệnh mỗi công đoạn). Kiem tra Bo so trung trong cung don, hoac mo bo do bam "Sinh lai".', thieu;
    END IF;
END $v142_check$;
