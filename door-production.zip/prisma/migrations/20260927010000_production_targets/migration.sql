-- ============================================================================
-- V144 — MỐC SẢN XUẤT (ngày bắt đầu) + TARGET TỪNG CÔNG ĐOẠN
--
-- Nhà máy chốt 26/09/2026: **không nhập ngày cho từng công đoạn**. Chỉ nhập MỘT mốc
-- "Ngày bắt đầu sản xuất" ở bộ cửa → bấm "Đưa vào sản xuất" → bộ thành WIP ở công đoạn đầu,
-- và hệ thống TỰ SUY mốc (target) của MỌI công đoạn sau theo THỨ TỰ BƯỚC (`seq`) + SỐ GIỜ
-- của bước (1 ngày làm việc = số ca × giờ/ca = 2 × 8 = 16 giờ; bỏ Chủ nhật + ngày lễ).
-- Dùng target để CẢNH BÁO: công đoạn quá target chưa xong (CHẬM) và bộ xong muộn hơn hạn xưởng (KHÔNG KỊP).
--
-- `planned_start/planned_end` của công đoạn GIỮ NGUYÊN — sau này là "ngày kế hoạch sản xuất"
-- theo điều độ/lô gộp (thiết kế sau). Target là cột RIÊNG, không lẫn với điều độ.
--
-- ⚠️ Chạy TRƯỚC khi deploy code (bài học V112). Idempotent: chạy lại vô hại.
-- ============================================================================

ALTER TABLE "production_tasks" ADD COLUMN IF NOT EXISTS "target_start" DATE;
ALTER TABLE "production_tasks" ADD COLUMN IF NOT EXISTS "target_end"   DATE;
CREATE INDEX IF NOT EXISTS "production_tasks_target_end_idx" ON "production_tasks"("target_end");

ALTER TABLE "production_sets" ADD COLUMN IF NOT EXISTS "started_at" DATE;
ALTER TABLE "production_sets" ADD COLUMN IF NOT EXISTS "target_end" DATE;
CREATE INDEX IF NOT EXISTS "production_sets_target_end_idx" ON "production_sets"("target_end");

-- ----------------------------------------------------------------------------
-- KIỂM TRA SAU KHI CHẠY
--   SELECT column_name FROM information_schema.columns
--    WHERE table_name IN ('production_tasks','production_sets')
--      AND column_name IN ('target_start','target_end','started_at');
--   -- kỳ vọng: target_start, target_end (tasks) + started_at, target_end (sets)
-- ----------------------------------------------------------------------------
