-- V131 — Kích thước ảnh sản phẩm do người dùng chỉnh tay.
-- Lưu kích thước hiển thị mong muốn (đơn vị: pixel) cho ảnh của từng dòng hàng hóa
-- và từng dòng chi tiết/phụ kiện. NULL = dùng chế độ tự động (vừa ô) như trước.
ALTER TABLE "sales_order_items" ADD COLUMN IF NOT EXISTS "image_width" INTEGER;
ALTER TABLE "sales_order_items" ADD COLUMN IF NOT EXISTS "image_height" INTEGER;
ALTER TABLE "sales_order_item_details" ADD COLUMN IF NOT EXISTS "image_width" INTEGER;
ALTER TABLE "sales_order_item_details" ADD COLUMN IF NOT EXISTS "image_height" INTEGER;
