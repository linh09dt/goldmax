-- V133 — Nhiều ảnh cho một bộ cửa.
-- Mỗi bộ cửa (sales_order_items) có thể có nhiều ảnh; ảnh đầu tiên vẫn được ghi vào
-- sales_order_items.image_path để các chỗ đang dùng ảnh đơn (danh sách, chi tiết, in) không phải đổi.
CREATE TABLE IF NOT EXISTS "sales_order_item_images" (
    "id" SERIAL NOT NULL,
    "order_item_id" INTEGER NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "image_path" TEXT NOT NULL,
    "image_width" INTEGER,
    "image_height" INTEGER,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "sales_order_item_images_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "sales_order_item_images_order_item_id_sort_order_key"
    ON "sales_order_item_images"("order_item_id", "sort_order");
CREATE INDEX IF NOT EXISTS "sales_order_item_images_order_item_id_sort_order_idx"
    ON "sales_order_item_images"("order_item_id", "sort_order");

DO $$
BEGIN
    ALTER TABLE "sales_order_item_images"
        ADD CONSTRAINT "sales_order_item_images_order_item_id_fkey"
        FOREIGN KEY ("order_item_id") REFERENCES "sales_order_items"("id")
        ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Chuyển ảnh đơn hiện có thành ảnh số 1 của bộ cửa (chạy 1 lần, không tạo trùng).
INSERT INTO "sales_order_item_images" ("order_item_id", "sort_order", "image_path", "image_width", "image_height")
SELECT oi."id", 1, oi."image_path", oi."image_width", oi."image_height"
FROM "sales_order_items" oi
WHERE oi."image_path" IS NOT NULL
  AND btrim(oi."image_path") <> ''
  AND NOT EXISTS (
      SELECT 1 FROM "sales_order_item_images" img WHERE img."order_item_id" = oi."id"
  );
