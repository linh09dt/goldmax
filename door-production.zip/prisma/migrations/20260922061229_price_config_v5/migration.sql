-- AlterTable
ALTER TABLE "item_masters" ADD COLUMN     "dealer_price" DECIMAL(18,2),
ADD COLUMN     "price_imported_at" TIMESTAMP(3),
ADD COLUMN     "price_source_file" VARCHAR(255),
ADD COLUMN     "unit" VARCHAR(40);

-- CreateTable
CREATE TABLE "item_attribute_imports" (
    "id" SERIAL NOT NULL,
    "file_name" VARCHAR(255) NOT NULL,
    "file_hash" VARCHAR(64) NOT NULL,
    "sheet_name" VARCHAR(120),
    "total_price_rows" INTEGER NOT NULL DEFAULT 0,
    "updated_item_count" INTEGER NOT NULL DEFAULT 0,
    "missing_item_count" INTEGER NOT NULL DEFAULT 0,
    "option_count" INTEGER NOT NULL DEFAULT 0,
    "issue_count" INTEGER NOT NULL DEFAULT 0,
    "issues" JSONB,
    "imported_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "item_attribute_imports_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "master_options" (
    "id" SERIAL NOT NULL,
    "group_code" VARCHAR(60) NOT NULL,
    "code" VARCHAR(120) NOT NULL,
    "name" VARCHAR(200) NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "source" VARCHAR(30) NOT NULL DEFAULT 'THU_CONG',
    "last_source_file" VARCHAR(255),
    "last_imported_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "master_options_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "item_attribute_imports_file_hash_idx" ON "item_attribute_imports"("file_hash");

-- CreateIndex
CREATE INDEX "item_attribute_imports_imported_at_idx" ON "item_attribute_imports"("imported_at");

-- CreateIndex
CREATE INDEX "master_options_group_code_active_sort_order_idx" ON "master_options"("group_code", "active", "sort_order");

-- CreateIndex
CREATE UNIQUE INDEX "master_options_group_code_code_key" ON "master_options"("group_code", "code");

-- CreateIndex
CREATE INDEX "item_masters_price_imported_at_idx" ON "item_masters"("price_imported_at");
