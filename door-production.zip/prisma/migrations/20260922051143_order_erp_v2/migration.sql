-- AlterTable
ALTER TABLE "sales_order_items" ADD COLUMN     "image_path" TEXT,
ADD COLUMN     "model_check" VARCHAR(120),
ADD COLUMN     "price_check" VARCHAR(120),
ALTER COLUMN "source_row" DROP NOT NULL;

-- AlterTable
ALTER TABLE "sales_orders" ADD COLUMN     "delivery_payment" DECIMAL(18,2),
ADD COLUMN     "deposit_amount" DECIMAL(18,2),
ADD COLUMN     "discount_amount" DECIMAL(18,2),
ADD COLUMN     "discount_percent" DECIMAL(8,4),
ADD COLUMN     "receiver_name" VARCHAR(160),
ADD COLUMN     "receiver_phone" VARCHAR(40),
ADD COLUMN     "shipping_fee" DECIMAL(18,2),
ADD COLUMN     "status" VARCHAR(30) NOT NULL DEFAULT 'NHAP',
ADD COLUMN     "subtotal" DECIMAL(18,2),
ADD COLUMN     "total_after_discount" DECIMAL(18,2),
ADD COLUMN     "warehouse_receipt_deduction" DECIMAL(18,2),
ALTER COLUMN "last_imported_at" DROP NOT NULL,
ALTER COLUMN "last_imported_at" DROP DEFAULT;

-- CreateTable
CREATE TABLE "sales_order_item_details" (
    "id" SERIAL NOT NULL,
    "order_item_id" INTEGER NOT NULL,
    "row_order" INTEGER NOT NULL,
    "detail_type" VARCHAR(50),
    "set_no" VARCHAR(80),
    "product_name" TEXT,
    "product_code" VARCHAR(160),
    "model" VARCHAR(100),
    "opening_direction" VARCHAR(60),
    "trim_direction" VARCHAR(80),
    "paint_color" VARCHAR(100),
    "height_mm" INTEGER,
    "width_mm" INTEGER,
    "frame_mm" INTEGER,
    "clear_height_mm" INTEGER,
    "clear_width_mm" INTEGER,
    "panel_info" VARCHAR(160),
    "trim_bars_per_set" INTEGER,
    "trim_type" VARCHAR(80),
    "lock_model" VARCHAR(120),
    "window_bars" VARCHAR(160),
    "leaves_per_set" INTEGER,
    "quantity" INTEGER,
    "unit" VARCHAR(40),
    "pricing_quantity" DOUBLE PRECISION,
    "unit_price" DECIMAL(18,2),
    "amount" DECIMAL(18,2),
    "note" TEXT,
    "image_path" TEXT,
    "model_check" VARCHAR(120),
    "price_check" VARCHAR(120),
    "source_row" INTEGER,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sales_order_item_details_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sales_order_requirements" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER NOT NULL,
    "code" VARCHAR(60) NOT NULL,
    "question_text" TEXT NOT NULL,
    "answer" VARCHAR(120),
    "note" TEXT,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sales_order_requirements_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "sales_order_item_details_product_code_idx" ON "sales_order_item_details"("product_code");

-- CreateIndex
CREATE UNIQUE INDEX "sales_order_item_details_order_item_id_row_order_key" ON "sales_order_item_details"("order_item_id", "row_order");

-- CreateIndex
CREATE INDEX "sales_order_requirements_order_id_sort_order_idx" ON "sales_order_requirements"("order_id", "sort_order");

-- CreateIndex
CREATE UNIQUE INDEX "sales_order_requirements_order_id_code_key" ON "sales_order_requirements"("order_id", "code");

-- CreateIndex
CREATE INDEX "sales_orders_status_idx" ON "sales_orders"("status");

-- AddForeignKey
ALTER TABLE "sales_order_item_details" ADD CONSTRAINT "sales_order_item_details_order_item_id_fkey" FOREIGN KEY ("order_item_id") REFERENCES "sales_order_items"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sales_order_requirements" ADD CONSTRAINT "sales_order_requirements_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "sales_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
