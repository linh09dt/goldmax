-- AlterTable
ALTER TABLE "sales_orders" ADD COLUMN     "shipping_calculated_at" TIMESTAMP(3),
ADD COLUMN     "shipping_mountain_district" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "shipping_rates" (
    "id" SERIAL NOT NULL,
    "door_group" VARCHAR(60) NOT NULL,
    "model_name" VARCHAR(160) NOT NULL,
    "model_code" VARCHAR(60) NOT NULL,
    "quantity_tier" INTEGER NOT NULL,
    "north_le_100" DECIMAL(18,2) NOT NULL,
    "north_101_200" DECIMAL(18,2) NOT NULL,
    "north_over_200" DECIMAL(18,2) NOT NULL,
    "central" DECIMAL(18,2) NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "source" VARCHAR(40) NOT NULL DEFAULT 'EXCEL_2024',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "shipping_rates_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "shipping_calculations" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER NOT NULL,
    "region" VARCHAR(100) NOT NULL,
    "delivery_km" DECIMAL(12,2) NOT NULL,
    "mountain_district" BOOLEAN NOT NULL DEFAULT false,
    "band_label" VARCHAR(180) NOT NULL,
    "support_km" DECIMAL(12,2) NOT NULL,
    "raw_total" DECIMAL(18,2) NOT NULL,
    "rounded_total" DECIMAL(18,2) NOT NULL,
    "lines" JSONB NOT NULL,
    "source" VARCHAR(60) NOT NULL DEFAULT 'BANG_CUOC_EXCEL_2024',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "shipping_calculations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "shipping_rates_active_model_code_quantity_tier_idx" ON "shipping_rates"("active", "model_code", "quantity_tier");

-- CreateIndex
CREATE UNIQUE INDEX "shipping_rates_model_code_quantity_tier_key" ON "shipping_rates"("model_code", "quantity_tier");

-- CreateIndex
CREATE INDEX "shipping_calculations_order_id_created_at_idx" ON "shipping_calculations"("order_id", "created_at");

-- AddForeignKey
ALTER TABLE "shipping_calculations" ADD CONSTRAINT "shipping_calculations_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "sales_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
