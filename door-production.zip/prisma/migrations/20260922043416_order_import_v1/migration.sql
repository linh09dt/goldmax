-- CreateTable
CREATE TABLE "sales_orders" (
    "id" SERIAL NOT NULL,
    "order_code" VARCHAR(120) NOT NULL,
    "customer_code" VARCHAR(60),
    "customer_name" VARCHAR(200),
    "sales_employee_code" VARCHAR(60),
    "order_date" DATE,
    "required_delivery_date" DATE,
    "receiver_address" TEXT,
    "delivery_km" DOUBLE PRECISION,
    "region" VARCHAR(100),
    "group_no" INTEGER,
    "excel_update_date" DATE,
    "form_code" VARCHAR(60),
    "form_effective_date" DATE,
    "source_file_name" VARCHAR(255),
    "source_file_hash" VARCHAR(64),
    "last_imported_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sales_orders_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sales_order_items" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER NOT NULL,
    "line_no" INTEGER NOT NULL,
    "set_no" VARCHAR(80),
    "product_name" TEXT,
    "product_code" VARCHAR(160),
    "model" VARCHAR(100),
    "opening_direction" VARCHAR(60),
    "trim_direction" VARCHAR(80),
    "paint_color" VARCHAR(100),
    "height_mm" INTEGER,
    "width_mm" INTEGER,
    "frame_mm" INTEGER,
    "clear_height_mm" INTEGER,
    "clear_width_mm" INTEGER,
    "panel_info" VARCHAR(160),
    "trim_bars_per_set" INTEGER,
    "trim_type" VARCHAR(80),
    "lock_model" VARCHAR(120),
    "window_bars" VARCHAR(160),
    "leaves_per_set" INTEGER,
    "quantity" INTEGER,
    "unit" VARCHAR(40),
    "pricing_quantity" DOUBLE PRECISION,
    "unit_price" DECIMAL(18,2),
    "amount" DECIMAL(18,2),
    "note" TEXT,
    "source_row" INTEGER NOT NULL,
    "raw_block" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sales_order_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "order_imports" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER,
    "file_name" VARCHAR(255) NOT NULL,
    "file_hash" VARCHAR(64) NOT NULL,
    "action" VARCHAR(30) NOT NULL,
    "sheet_name" VARCHAR(120),
    "imported_items" INTEGER NOT NULL DEFAULT 0,
    "imported_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "order_imports_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "sales_orders_order_code_key" ON "sales_orders"("order_code");

-- CreateIndex
CREATE INDEX "sales_orders_customer_code_idx" ON "sales_orders"("customer_code");

-- CreateIndex
CREATE INDEX "sales_orders_required_delivery_date_idx" ON "sales_orders"("required_delivery_date");

-- CreateIndex
CREATE INDEX "sales_orders_last_imported_at_idx" ON "sales_orders"("last_imported_at");

-- CreateIndex
CREATE INDEX "sales_order_items_set_no_idx" ON "sales_order_items"("set_no");

-- CreateIndex
CREATE INDEX "sales_order_items_product_code_idx" ON "sales_order_items"("product_code");

-- CreateIndex
CREATE UNIQUE INDEX "sales_order_items_order_id_line_no_key" ON "sales_order_items"("order_id", "line_no");

-- CreateIndex
CREATE INDEX "order_imports_file_hash_idx" ON "order_imports"("file_hash");

-- CreateIndex
CREATE INDEX "order_imports_order_id_imported_at_idx" ON "order_imports"("order_id", "imported_at");

-- AddForeignKey
ALTER TABLE "sales_order_items" ADD CONSTRAINT "sales_order_items_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "sales_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "order_imports" ADD CONSTRAINT "order_imports_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "sales_orders"("id") ON DELETE SET NULL ON UPDATE CASCADE;
