-- V135: danh mục PHÂN LOẠI hàng hóa (thay cho 3 giá trị hard-code trong code).
--   usage = MAIN   → dùng làm DÒNG CHÍNH / bộ cửa khi lập đơn
--   usage = DETAIL → dùng làm DÒNG PHỤ KIỆN / CHI TIẾT
--   separate_group → khi lập đơn, nhóm hàng thuộc phân loại này nằm trong optgroup riêng
--
-- `item_masters.category` vẫn giữ MÃ phân loại (không phải tên) nên đổi tên phân loại
-- không phải sửa dữ liệu hàng hóa.

CREATE TABLE "item_categories" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(40) NOT NULL,
    "name" VARCHAR(80) NOT NULL,
    "usage" VARCHAR(10) NOT NULL DEFAULT 'DETAIL',
    "separate_group" BOOLEAN NOT NULL DEFAULT false,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "item_categories_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "item_categories_code_key" ON "item_categories"("code");
CREATE INDEX "item_categories_active_idx" ON "item_categories"("active");
CREATE INDEX "item_categories_sort_order_idx" ON "item_categories"("sort_order");

-- Nạp đúng 3 phân loại đang dùng (giữ nguyên mã để không phải đụng item_masters).
INSERT INTO "item_categories" ("code", "name", "usage", "separate_group", "sort_order")
VALUES
  ('DOOR',       'Cấp cửa',          'MAIN',   false, 10),
  ('ACCESSORY',  'Phụ kiện',         'DETAIL', false, 20),
  ('PROCESSING', 'Chi phí gia công', 'DETAIL', true,  30)
ON CONFLICT ("code") DO NOTHING;
