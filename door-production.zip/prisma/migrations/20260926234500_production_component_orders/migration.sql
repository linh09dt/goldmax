-- ============================================================================
-- V136.1 — LỆNH SẢN XUẤT CHA – CON
--
-- Nhà máy chốt 26/09/2026:
--   Lệnh CHA = BỘ CỬA. Lệnh CON = CÁNH / KHUNG / PHÀO.
--   Cắt – Chấn – Hàn – (Ép cánh) – Vân làm RIÊNG từng phần.
--   GỘP: Test cơ khí chỉ chạy khi cả 3 phần đã hàn xong.
--        Lắp kính + Vệ sinh/Đóng gói chỉ chạy khi cả 3 phần đã vân xong.
--   Sơn làm cho cả bộ một lượt, sau khi test đạt.
--   Riêng Vân: màu sơn 11 và 14 KHÔNG cần vân (nhà máy xác nhận 26/09/2026) → giữ skip_condition.
--
-- ⚠️ Migration này CHẠY SAU `20260926233000_production_planning`.
--    Chạy TRƯỚC khi deploy code (bài học V112).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) LỆNH SẢN XUẤT CON
--    Công đoạn của lệnh con = các `production_tasks` có `scope` = kind.
-- ----------------------------------------------------------------------------
CREATE TABLE "production_component_orders" (
    "id" SERIAL NOT NULL,
    "set_id" INTEGER NOT NULL,
    "kind" VARCHAR(10) NOT NULL,
    "qty_expected" DOUBLE PRECISION,
    "note" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_component_orders_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "production_component_orders_set_id_idx" ON "production_component_orders"("set_id");
CREATE UNIQUE INDEX "production_component_orders_set_id_kind_key" ON "production_component_orders"("set_id", "kind");

ALTER TABLE "production_component_orders"
    ADD CONSTRAINT "production_component_orders_set_id_fkey"
    FOREIGN KEY ("set_id") REFERENCES "production_sets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ----------------------------------------------------------------------------
-- 2) SỬA DANH MỤC CÔNG ĐOẠN theo mô hình mới
--    (danh mục đã được seed ở migration trước, nên phải UPDATE)
-- ----------------------------------------------------------------------------

-- 2.1 Vân: TÁCH RIÊNG cánh / khung / phào.
--     Giữ điều kiện bỏ qua theo màu sơn: nhà máy xác nhận 26/09/2026 **màu 11 và 14 KHÔNG cần vân**
--     (3 công đoạn Vân của bộ đó sẽ ở trạng thái BO_QUA; điều kiện "đủ 3 phần vân" coi BO_QUA là đã xong).
UPDATE "production_stages"
SET "scope_mode"     = 'PARTS',
    "scope_parts"    = 'KHUNG,CANH,PHAO',
    "skip_condition" = 'PAINT_COLOR:11,14',
    "note"           = 'Nhà máy chốt 26/09/2026: TÁCH RIÊNG vân cho cánh, khung, phào; khi CẢ 3 phần báo xong vân trên cùng bộ mới chuyển Vệ sinh + Đóng gói. Màu sơn 11 và 14 KHÔNG cần vân (tự bỏ qua). Dán film tay, buồng sấy riêng (VAN1/VAN5). PHẢI dán đủ hoàn chỉnh trước khi sấy (VAN2). KHÔNG cần gom lô (VAN6). Vân lỗi → tẩy sơn lại (VAN10).',
    "updated_at"     = now()
WHERE "code" = 'VAN';

-- 2.2 Bồi Lares: bắt buộc Thiết kế xong trước
UPDATE "production_stages"
SET "requires_stage" = 'THIET_KE',
    "updated_at"     = now()
WHERE "code" = 'BOI_LARES' AND ("requires_stage" IS DISTINCT FROM 'THIET_KE');

-- 2.3 Ghi rõ gate "đủ 3 phần vân xong" ở bước lắp kính
UPDATE "production_stages"
SET "note"       = "note" || ' GATE: chỉ chạy khi CẢ 3 phần (cánh/khung/phào) đã xong VÂN.',
    "updated_at" = now()
WHERE "code" = 'LAP_KINH' AND "note" NOT LIKE '%GATE:%';

-- ----------------------------------------------------------------------------
-- 3) Tạo 3 lệnh con cho các bộ đã có trong kế hoạch (idempotent)
--    Số lượng: CÁNH = số cánh × số bộ · KHUNG = số bộ · PHÀO = số phào × số bộ
-- ----------------------------------------------------------------------------
INSERT INTO "production_component_orders" ("set_id", "kind", "qty_expected", "updated_at")
SELECT s."id",
       v."kind",
       CASE v."kind"
         WHEN 'CANH'  THEN COALESCE(s."leaves_per_set", 1) * COALESCE(s."quantity", 1)
         WHEN 'KHUNG' THEN COALESCE(s."quantity", 1)
         WHEN 'PHAO'  THEN COALESCE(s."trim_bars_per_set", 1) * COALESCE(s."quantity", 1)
       END,
       now()
FROM "production_sets" s
CROSS JOIN (VALUES ('CANH'), ('KHUNG'), ('PHAO')) AS v("kind")
ON CONFLICT ("set_id", "kind") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 4) Chuyển dữ liệu: công đoạn Vân cũ (1 dòng cho cả bộ) → 3 dòng theo phần
--    Giữ nguyên trạng thái / ngày thực tế đã ghi.
-- ----------------------------------------------------------------------------
INSERT INTO "production_tasks" (
    "set_id", "order_item_id", "stage_code", "stage_kind", "scope", "seq", "work_center_code",
    "status", "qty_expected", "planned_start", "planned_end", "actual_start", "actual_end",
    "assignee", "is_rework", "rework_from_stage", "reason_code", "note", "updated_by", "updated_at"
)
SELECT t."set_id", t."order_item_id", t."stage_code", t."stage_kind",
       v."scope", t."seq", t."work_center_code", t."status",
       CASE v."scope"
         WHEN 'CANH'  THEN COALESCE(s."leaves_per_set", 1) * COALESCE(s."quantity", 1)
         WHEN 'KHUNG' THEN COALESCE(s."quantity", 1)
         WHEN 'PHAO'  THEN COALESCE(s."trim_bars_per_set", 1) * COALESCE(s."quantity", 1)
       END,
       t."planned_start", t."planned_end", t."actual_start", t."actual_end",
       t."assignee", t."is_rework", t."rework_from_stage", t."reason_code", t."note", t."updated_by", now()
FROM "production_tasks" t
JOIN "production_sets" s ON s."id" = t."set_id"
CROSS JOIN (VALUES ('CANH'), ('KHUNG'), ('PHAO')) AS v("scope")
WHERE t."stage_code" = 'VAN' AND t."scope" = 'BO'
ON CONFLICT ("set_id", "stage_code", "scope") DO NOTHING;

DELETE FROM "production_tasks" WHERE "stage_code" = 'VAN' AND "scope" = 'BO';
