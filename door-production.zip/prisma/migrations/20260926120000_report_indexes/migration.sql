-- V130 — Chỉ mục phục vụ nhóm báo cáo mới (đơn hàng / sản phẩm / nhân viên Sales / công nợ / tải sản xuất).
-- Bổ sung index cho các cột thường lọc — nhóm: order_date, created_at, sales_employee_code, region, model.
-- Idempotent (IF NOT EXISTS) để chạy an toàn trên database đã có dữ liệu.

CREATE INDEX IF NOT EXISTS "sales_orders_order_date_idx" ON "sales_orders" ("order_date");
CREATE INDEX IF NOT EXISTS "sales_orders_created_at_idx" ON "sales_orders" ("created_at");
CREATE INDEX IF NOT EXISTS "sales_orders_sales_employee_code_idx" ON "sales_orders" ("sales_employee_code");
CREATE INDEX IF NOT EXISTS "sales_orders_region_idx" ON "sales_orders" ("region");
CREATE INDEX IF NOT EXISTS "sales_order_items_model_idx" ON "sales_order_items" ("model");
