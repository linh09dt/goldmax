-- ERP V17: thêm tên sản phẩm diễn giải vào Master Data hàng hóa.
ALTER TABLE "item_masters"
  ADD COLUMN IF NOT EXISTS "product_description" TEXT;
