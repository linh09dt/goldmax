-- ERP V15: đảm bảo các cột Master Data hàng hóa cần thiết và bổ sung Giá bán lẻ.
-- Dùng IF NOT EXISTS để tương thích các máy đã chạy các migration V3/V5/V13 khác nhau.
ALTER TABLE "item_masters"
  ADD COLUMN IF NOT EXISTS "sales_name" VARCHAR(120),
  ADD COLUMN IF NOT EXISTS "sales_model" VARCHAR(180),
  ADD COLUMN IF NOT EXISTS "unit" VARCHAR(40),
  ADD COLUMN IF NOT EXISTS "dealer_price" DECIMAL(18,2),
  ADD COLUMN IF NOT EXISTS "retail_price" DECIMAL(18,2),
  ADD COLUMN IF NOT EXISTS "source" VARCHAR(30) NOT NULL DEFAULT 'THU_CONG',
  ADD COLUMN IF NOT EXISTS "last_source_file" VARCHAR(255),
  ADD COLUMN IF NOT EXISTS "last_imported_at" TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "price_source_file" VARCHAR(255),
  ADD COLUMN IF NOT EXISTS "price_imported_at" TIMESTAMP(3);

CREATE INDEX IF NOT EXISTS "item_masters_sales_name_idx" ON "item_masters"("sales_name");
CREATE INDEX IF NOT EXISTS "item_masters_sales_model_idx" ON "item_masters"("sales_model");
