-- V112: tách LOẠI ĐƠN (Đơn hàng mẫu / Sản xuất / Đơn làm lại) ra khỏi TRẠNG THÁI (Đơn nháp / Đã xác nhận).
-- Trước V112 trạng thái gộp cả hai: NHAP = "Đơn hàng mẫu", CHUYEN_SAN_XUAT = "Sản xuất".

ALTER TABLE "sales_orders" ADD COLUMN IF NOT EXISTS "order_type" VARCHAR(30) NOT NULL DEFAULT 'MAU';

-- Đơn cũ đã vào sản xuất → loại "Sản xuất" + trạng thái "Đã xác nhận".
UPDATE "sales_orders"
SET "status" = 'DA_XAC_NHAN', "order_type" = 'SAN_XUAT'
WHERE "status" IN ('CHUYEN_SAN_XUAT', 'DA_XAC_NHAN');

-- Đơn cũ chờ xác nhận → "Đơn nháp" + loại "Đơn hàng mẫu".
UPDATE "sales_orders"
SET "status" = 'NHAP', "order_type" = 'MAU'
WHERE "status" = 'CHO_XAC_NHAN';

-- Còn lại: 'NHAP' (đơn nháp) và 'HUY' (đơn đã huỷ) giữ nguyên trạng thái, loại mặc định "Đơn hàng mẫu".
UPDATE "sales_orders"
SET "order_type" = 'MAU'
WHERE "order_type" IS NULL;

CREATE INDEX IF NOT EXISTS "sales_orders_order_type_idx" ON "sales_orders"("order_type");
