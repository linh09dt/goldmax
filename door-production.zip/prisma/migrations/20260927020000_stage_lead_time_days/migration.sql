-- V145 — Công đoạn dùng SỐ NGÀY (đổi tên cột lead_time_hours → lead_time_days)
--
-- 1) Đổi tên cột (chỉ chạy 1 lần; nếu đã đổi thì bỏ qua).
-- 2) Quy giá trị CÒN LÀ GIỜ (≥ 8) về SỐ NGÀY đúng theo sổ giấy xưởng (TỔNG 12 ngày).
--    Dòng đã nhập theo ngày (< 8) KHÔNG bị sửa ⇒ chạy lại vẫn an toàn.
-- File tay-chạy tương ứng: migrate-production-v145-so-ngay-cong-doan.sql

DO $v145$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns
              WHERE table_schema = 'public' AND table_name = 'production_stages' AND column_name = 'lead_time_hours')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns
              WHERE table_schema = 'public' AND table_name = 'production_stages' AND column_name = 'lead_time_days') THEN
    ALTER TABLE "production_stages" RENAME COLUMN "lead_time_hours" TO "lead_time_days";
  END IF;
END
$v145$;

UPDATE "production_stages" AS s
SET "lead_time_days" = v.days,
    "updated_at"     = now()
FROM (VALUES
  ('THIET_KE', 1), ('BOI_LARES', 1), ('CHO_SAU_BOI_LARES', 0),
  ('CAT', 1), ('CAT_CANH', 1), ('CAT_KHUNG', 1), ('CAT_PHAO', 1),
  ('CHAN', 1), ('CHAN_CANH', 1), ('CHAN_KHUNG', 1), ('CHAN_PHAO', 1),
  ('HAN', 2), ('HAN_CANH', 2), ('HAN_KHUNG', 2), ('HAN_PHAO', 2),
  ('EP_CANH', 0), ('TEST_CO_KHI', 1), ('CHO_TRUOC_SON', 0),
  ('SON', 2), ('CHO_KHO_SAU_SON', 0),
  ('VAN', 2), ('VAN_CANH', 2), ('VAN_KHUNG', 2), ('VAN_PHAO', 2),
  ('CHO_SAU_VAN', 0), ('LAP_KINH', 0), ('DONG_GOI', 1), ('KHO_GIAO', 0)
) AS v(code, days)
WHERE s."code" = v.code
  AND COALESCE(s."lead_time_days", 0) >= 8;
