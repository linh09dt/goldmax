# ORDER FONT BOLD FIX V62

## Hiện tượng
Trên PDF xuất từ server (file `Bao-gia-V2-15 (10).pdf`), dòng **“Ghi chú:”** và **“Khách hàng xác nhận các thông tin sau:”** (và cả dòng tổng navy) **không đậm**, dù code đã đặt font bold.

## Nguyên nhân gốc (đã kiểm chứng bằng cách soi font nhúng trong PDF của bạn)
Soi font trong PDF bạn gửi:
```
'Ghi chú:'                            -> Roboto-Italic    (đáng lẽ: bold + italic)
'Khách hàng xác nhận các thông tin sau:' -> Roboto-Regular (đáng lẽ: bold)
'CÒN LẠI CẦN THANH TOÁN:'             -> Roboto-Regular   (đáng lẽ: bold)
```
Nguyên nhân: trên Vercel chỉ có gói `fontpkg-roboto==3.15`, và gói này chỉ chứa **font VARIABLE**
(`Roboto[wdth,wght].ttf`). Gọi `fontpkg.path("Roboto", weight=700)` **trả về đúng file regular**
→ ReportLab không đọc được trục `wght` nên luôn lấy instance mặc định (400) → **mọi chữ “bold” đều thành chữ thường**.
Chữ italic của “Ghi chú:” cũng rơi vào file italic variable (400) nên chỉ nghiêng mà không đậm.

## Cách khắc phục
1. **Tạo 4 font TĨNH** (Roboto-Regular/Bold/Italic/BoldItalic) từ chính font variable đó bằng `fonttools`
   (`instancer wght=700, wdth=100`, `updateFontNames=True`) → đặt tại **`python/fonts/`** (đi kèm code, được bundle vào Python Function).
2. `_find_font_file()` ưu tiên thư mục `python/fonts` (đường dẫn tính theo `__file__`).
3. `register_fonts()` ưu tiên theo thứ tự: **env → font tĩnh (python/fonts → public/fonts → hệ thống) → font NHÚNG base64 → fontpkg variable (cuối cùng)**;
   thêm `_first_distinct()` để **loại ứng viên trùng đúng file regular** (chặn hẳn kiểu lỗi cũ) và log cảnh báo nếu không tìm được font đậm.
4. **Nhúng base64 `Roboto-Bold` + `Roboto-BoldItalic`** ngay trong `python/reportlab_order_v2.py` làm phương án dự phòng
   (giống cách đang nhúng logo): nếu Vercel không bundle file `.ttf` thì ghi ra file tạm, **nếu không ghi được thì đưa thẳng `BytesIO`**
   (ReportLab nhận cả đường dẫn lẫn file object) → không bao giờ mất chữ đậm.
5. `vercel.json`: thêm `"includeFiles": "python/fonts/**"` cho cả 2 function PDF.
6. **“Khách hàng xác nhận các thông tin sau:”** đổi sang **chữ đen đậm** (màu `#111111` ở PDF, `FF1F2937` ở Excel) — không còn xám.
   “Ghi chú:” giữ đậm + nghiêng + gạch chân + đỏ.

## File sửa / thêm
- `python/reportlab_order_v2.py` (logic font + base64 + màu dòng xác nhận)
- `python/reportlab_order_preview.py` (màu dòng xác nhận; dùng chung FONTS)
- **Mới:** `python/fonts/Roboto-Regular.ttf`, `Roboto-Bold.ttf`, `Roboto-Italic.ttf`, `Roboto-BoldItalic.ttf` (font tĩnh, giấy phép Apache-2.0 của Roboto)
- `vercel.json` (includeFiles)
- `src/lib/order-export-v2.ts` (dòng xác nhận: bold + chữ đen)

## Kiểm chứng (soi font nhúng bằng pdfminer, không đoán bằng mắt)
| Trường hợp | Kết quả |
|---|---|
| Có `python/fonts/` (local & Vercel có bundle) | `Ghi chú:` → **Roboto-BoldItalic**, `Khách hàng xác nhận…` → **Roboto-Bold**, `CÒN LẠI CẦN THANH TOÁN:` → **Roboto-Bold** |
| **Không** có `python/fonts` (giả lập Vercel không bundle .ttf) | vẫn **Roboto-Bold / Roboto-BoldItalic** (dùng font nhúng) |
| Không có `python/fonts` **và** không ghi được file tạm (`TMPDIR` sai) | vẫn **Roboto-Bold / Roboto-BoldItalic** (nạp từ bộ nhớ) |
| Chạy thật `python3 python/reportlab_order_v2.py --input … --output …` | `Ghi chú:` Roboto-BoldItalic, `Khách hàng xác nhận…` Roboto-Bold |
| PDF preview | giống hệt |
| Excel | `Ghi chú:` bold+italic+underline `FFDC2626`; `Khách hàng xác nhận…` bold `FF1F2937` (đen) |

`npx tsc --noEmit`: pass · `python -m py_compile`: OK · eslint không phát sinh lỗi mới.

## Sau khi deploy
Cần **deploy lại** (cả Next route và Python function). Nếu còn nghi ngờ, kiểm tra log function: chỉ khi nào thấy dòng
`[PDF_V2] CẢNH BÁO: không tìm được font đậm (bold)…` thì mới là font đậm không có — bình thường sẽ không có cảnh báo này.
