# ORDER VIEW QUANTITY 2 DECIMALS V74

## Yêu cầu
Cột **KHỐI LƯỢNG** (KH/Lượng) của **các dòng cửa** trên giao diện hiển thị đến **2 số thập phân**.

## Cách làm
`src/app/orders/[id]/page.tsx`:
- Thêm `formatQuantity2()` — `Intl.NumberFormat("vi-VN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })`
  (đúng 2 số thập phân, dấu phẩy theo vi-VN, ví dụ `7.2875 → 7,29`).
- Ô KH/Lượng trong `ReadRow` chỉ đổi cho **dòng cửa** (dòng chính, `main = true`):
  `{main ? formatQuantity2(row.pricingQuantity) : formatNumber(row.pricingQuantity)}`.
  Dòng phụ kiện/chi tiết giữ nguyên như trước (tối đa 4 số thập phân).

## Không đụng tới (có chủ ý)
- **File xuất PDF/Excel**: vẫn in KHỐI LƯỢNG đủ 4 số thập phân (`8.7224`) để **khớp với thành tiền**
  (thành tiền = KH/Lượng × đơn giá; nếu in rút gọn 2 số mà tiền tính theo 4 số thì khách dễ thấy lệch).
  Nếu bạn muốn rút gọn cả file xuất thì nói, mình sửa (lưu ý điểm lệch nêu trên).
- Ô nhập KH/Lượng trong form tạo/sửa đơn: vẫn nhập đủ 4 số thập phân như trước
  (đổi sẽ làm thay đổi GIÁ TRỊ chứ không chỉ cách hiển thị).

## Kiểm chứng (chạy app thật)
- `npx tsc --noEmit`: 0 lỗi. `npx eslint "src/app/orders/[id]/page.tsx"`: 3 lỗi `no-explicit-any` + 1 warning `<img>`
  — **đều có sẵn từ bản gốc**, không phát sinh lỗi mới.
- Dựng PostgreSQL cục bộ + `next dev` (port 3211) rồi mở `/orders/2` bằng camoufox, đọc lại DOM:
  - Dòng cửa (bộ số 12104, "Cửa Đi 1 Cánh"): `KH/Lượng = 7,29` (giá trị thật trong DB `7.2875`) ✓
  - Dòng phụ kiện ("Khuôn biệt thự trụ đứng"): `KH/Lượng = 5,5` (giữ nguyên quy tắc cũ) ✓
  - Ảnh chụp: `view_khoi_luong_2so.png`.
- Đã tắt dev server + PostgreSQL sau khi kiểm thử.

## File thay đổi
- `src/app/orders/[id]/page.tsx`
