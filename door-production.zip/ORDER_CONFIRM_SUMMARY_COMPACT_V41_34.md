# V41.34 – Thu gọn Câu hỏi xác nhận + Tổng hợp giá trị đơn hàng

## Mục tiêu
Giảm chiều cao 2 khối phía dưới để dành thêm không gian nhìn cho bảng chi tiết từng bộ cửa.

## Thay đổi
- Giữ nguyên độ rộng các ô nhập hiện tại.
- Font trong 2 khối giảm khoảng 4px:
  - nội dung/ô nhập: ~10px,
  - câu hỏi/tiêu đề: ~12px.
- Giảm padding từng dòng câu hỏi từ 16px xuống 8px theo chiều dọc.
- Giảm khoảng cách giữa các dòng tổng hợp giá trị.
- Giảm padding header và phần nội dung 2 card.
- Giữ nguyên toàn bộ logic tính tiền, lựa chọn xác nhận và dữ liệu lưu.

## File sửa
- `src/components/order-form.tsx`
