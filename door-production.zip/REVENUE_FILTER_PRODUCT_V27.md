# ERP V27 - Bộ lọc doanh thu + doanh thu theo sản phẩm

## Bộ lọc tab Theo dõi doanh thu

- Ngày
- Tháng
- Năm
- Từ ngày / Đến ngày
- Đại lý: lấy từ Mã/Tên đại lý trên đơn hàng
- Khách hàng: lấy từ Người nhận trên đơn hàng

Ưu tiên thời gian khi có nhiều ô cùng nhập: Từ ngày/Đến ngày → Ngày → Tháng → Năm.
Tất cả KPI, bảng đơn hàng và bảng sản phẩm đều dùng cùng bộ lọc.

## Bảng Sản phẩm phát sinh doanh thu

Chỉ hiển thị hàng hóa có trong `item_masters` và có thành tiền > 0 trong các đơn hàng sau bộ lọc.
Gom theo MODEL Master Data và hiển thị:

- TENHANG
- Tên sản phẩm diễn giải
- MODEL
- ĐVT
- Số đơn phát sinh
- Tổng số lượng
- Tổng KH/Lượng
- Doanh thu

Không thay đổi schema database.
