# V114 — Dashboard bán hàng: người quản trị doanh nghiệp cần nhìn thấy gì

Tài liệu này trả lời câu hỏi "dashboard bán hàng cần có những gì để **người quản trị** nhìn vào là ra quyết định".
Cách tiếp cận: bắt đầu từ **6 câu hỏi của người quản trị**, mỗi câu hỏi → nhóm chỉ số → đối chiếu dữ liệu hiện có
(đã có / còn thiếu) → lộ trình làm.

Trạng thái hiện tại: **đợt 1 đã chạy** (xem `DASHBOARD_TONG_QUAN_V113.md`), phần dưới là thiết kế đầy đủ.

---

## A. Sáu câu hỏi của người quản trị → nhóm chỉ số

| Câu hỏi của sếp | Nhóm chỉ số cần có | Trạng thái |
|---|---|---|
| 1. **"Kỳ này bán được bao nhiêu?"** | Doanh thu (đơn Sản xuất + Đã xác nhận) · số đơn · giá trị đơn TB · sản lượng (m² / bộ cửa) · **so kỳ trước / cùng kỳ năm trước / mục tiêu** | Doanh thu, số đơn, đơn TB, sản lượng **đã có**; mục tiêu + cùng kỳ năm trước **chưa** |
| 2. **"Tiền có về không?"** | Đã thu (cọc) · còn phải thu · **tuổi nợ** (0–30/31–60/61–90/>90 ngày) · top đại lý nợ nhiều & nợ lâu · **dòng tiền dự kiến 30 ngày tới** (theo hạn giao đơn đã xác nhận) | Còn phải thu **đã có**; tuổi nợ + dòng tiền dự kiến **chưa** (tính được ngay từ dữ liệu hiện có) |
| 3. **"Bán cho ai, hàng gì?"** | Top đại lý · top NVKD · top nhóm cửa/model · **cơ cấu theo vùng miền** · tỉ trọng 3 loại đơn · sản phẩm lãi mỏng (cần giá vốn) | Top đại lý/NVKD/sản phẩm + cơ cấu loại đơn **đã có**; vùng miền **chưa**; lãi mỏng **thiếu dữ liệu** |
| 4. **"Có kịp giao không?"** | **Tải sản xuất theo tuần** (8 tuần tới: số bộ cửa phải giao mỗi tuần) · đơn quá hạn · đơn đến hạn 7 ngày · số bộ cửa đang chờ sản xuất · **thời gian TB từ tạo đơn → xác nhận** | Quá hạn + đến hạn **đã có**; tải theo tuần + thời gian xử lý **chưa** (tính được) |
| 5. **"Có rủi ro gì?"** | Tỉ lệ hủy · số & giá trị **đơn làm lại** (chi phí chất lượng) · đơn **thiếu dữ liệu** (thiếu ảnh SP / thiếu KH-Lượng / thiếu mã hàng) · đơn nháp để lâu · đại lý vừa nợ lâu vừa tăng đơn | Đơn làm lại + nháp lâu **đã có**; thiếu dữ liệu + hủy **chưa** (tính được) |
| 6. **"Nhân viên làm việc thế nào?"** | Số đơn & doanh thu theo NVKD · **tỉ lệ xác nhận** theo NVKD · thời gian xử lý TB · số đơn có ảnh SP đúng chuẩn | Số đơn/doanh thu theo NVKD **đã có**; 3 chỉ số còn lại **chưa** (tính được) |

---

## B. Bố cục màn hình (theo "nguyên tắc 5 giây")

Mắt sếp chỉ quét 5 giây đầu — vì vậy thứ tự trên màn hình phải theo mức độ "phải hành động":

```
1. ĐÈN TÍN HIỆU + 6 KPI  (kèm mục tiêu và % so kỳ trước)        ← luôn nằm trên màn hình đầu
2. TIỀN: còn phải thu | tuổi nợ | dòng tiền dự kiến 30 ngày
3. XU HƯỚNG: doanh thu 12 tháng (cột) + số đơn (đường) + đường mục tiêu
4. CƠ CẤU: loại đơn | trạng thái | vùng miền
5. XẾP HẠNG: đại lý | NVKD | nhóm cửa/model
6. VIỆC CẦN LÀM (worklist): quá hạn → đến hạn 7 ngày → nháp lâu → thiếu dữ liệu
7. TẢI SẢN XUẤT 8 TUẦN TỚI (cho xưởng)
```

**Bốn nguyên tắc bắt buộc**, nếu thiếu thì dashboard chỉ là "bảng số":

1. **Mọi con số phải có so sánh** — % so kỳ trước liền kề, so cùng kỳ năm trước, và **so mục tiêu** (kế hoạch tháng/năm). Không có so sánh thì không biết tốt hay xấu.
2. **Mọi con số phải bấm được** → dẫn tới danh sách đơn đã lọc sẵn (đang làm ở nút "Mở trong Quản lý đơn hàng").
3. **Có ngưỡng đèn**, không chỉ số: xanh/vàng/đỏ theo ngưỡng đã chốt (mục C).
4. **Có việc cần làm kèm chủ thể** — không chỉ "3 đơn quá hạn" mà là *đơn nào, của đại lý nào, quá mấy ngày, bấm vào là mở ra*.

---

## C. Ngưỡng đèn đề xuất (cần sếp chốt số)

| Chỉ số | Vàng | Đỏ |
|---|---|---|
| Nợ quá 60 ngày / tổng phải thu | > 3% | > 8% |
| Đơn quá hạn giao | 1–2 đơn | ≥ 3 đơn hoặc > 2% doanh thu tháng |
| Đơn nháp để lâu | > 7 ngày | > 15 ngày |
| Tỉ lệ đơn làm lại / số đơn | > 2% | > 5% |
| Tiến độ doanh thu so mục tiêu tháng (theo % ngày đã qua) | < 90% | < 75% |
| Đơn thiếu ảnh SP / thiếu KH-Lượng | > 5% | > 15% |

---

## D. Danh sách chỉ số đầy đủ (đối chiếu dữ liệu)

| # | Chỉ số | Công thức / nguồn | Trạng thái |
|---|---|---|---|
| 1 | Doanh thu | Σ `total_after_discount`, đơn `SAN_XUAT` + `DA_XAC_NHAN` | ✅ có |
| 2 | Doanh thu so kỳ trước | kỳ liền kề cùng độ dài | ✅ có |
| 3 | Doanh thu cùng kỳ năm trước | lùi 365 ngày | ⏳ tính được ngay |
| 4 | Mục tiêu doanh thu tháng/năm | lưu ở `system_settings` + ô nhập | ⏳ cần thêm (nhỏ) |
| 5 | Số đơn đã xác nhận / tỉ lệ xác nhận | đếm theo `status` | ✅ có |
| 6 | Sản lượng m², số bộ cửa | Σ `pricing_quantity`, đếm dòng hàng | ✅ có |
| 7 | Giá trị đơn trung bình | doanh thu / số đơn | ✅ có |
| 8 | Còn phải thu | Σ `delivery_payment` (đã xác nhận) | ✅ có |
| 9 | **Tuổi nợ** (0–30/31–60/61–90/>90) | theo `order_date` − số ngày đã qua, trừ cọc | ⏳ tính được ngay |
| 10 | **Dòng tiền dự kiến 30 ngày** | đơn đã xác nhận có `required_delivery_date` trong 30 ngày → Σ `delivery_payment` | ⏳ tính được ngay |
| 11 | Top đại lý / NVKD | Σ doanh thu theo `customer_code` / `sales_employee_code` | ✅ có |
| 12 | Top nhóm cửa / model | nối `sales_order_items` ↔ `item_master` (`name`, `sales_model`) | ⏳ tính được (có bảng giá đại lý/bán lẻ trong `item_master`) |
| 13 | Cơ cấu theo vùng miền | `region` | ⏳ tính được ngay |
| 14 | Cơ cấu 3 loại đơn | `order_type` | ✅ có |
| 15 | Đơn quá hạn / đến hạn 7 ngày | `required_delivery_date` vs hôm nay | ✅ có |
| 16 | **Tải sản xuất 8 tuần tới** | nhóm số bộ cửa theo tuần của `required_delivery_date` | ⏳ tính được ngay |
| 17 | Thời gian TB tạo đơn → xác nhận | `created_at` → lúc chuyển `DA_XAC_NHAN` (**cần lưu mốc `confirmed_at`**) | ⏳ cần thêm 1 cột |
| 18 | Tỉ lệ hủy / đơn làm lại | đếm `status='HUY'` và `order_type='LAM_LAI'` | ⏳ tính được ngay |
| 19 | Đơn thiếu dữ liệu | thiếu `image_path`, thiếu `pricing_quantity`, thiếu `product_code` | ⏳ tính được ngay |
| 20 | **Lợi nhuận gộp / biên LN** | cần **giá vốn** theo mã hàng — hiện DB chỉ có giá bán (`unit_price`, `dealer_price`, `retail_price`) | ❌ thiếu dữ liệu |
| 21 | **Công nợ chính xác & dòng tiền thực** | cần **phiếu thu** nhiều lần theo đơn (hiện chỉ có `deposit_amount`) | ❌ thiếu dữ liệu |
| 22 | **Tỉ lệ giao đúng hạn (OTD)** | cần **ngày giao thực tế** (hiện chỉ có ngày hẹn `required_delivery_date`) | ❌ thiếu dữ liệu |
| 23 | Tồn kho / vật tư | không có bảng tồn kho (mô hình đặt theo đơn nên có thể không cần) | ❌ thiếu dữ liệu |
| 24 | Phân quyền theo NVKD/đại lý | cần đăng nhập + vai trò | ❌ thiếu dữ liệu |

---

## E. Khoảng trống dữ liệu — nên bắt đầu ghi từ hôm nay

Ba thứ dưới đây không tính được từ dữ liệu hiện có, mà doanh nghiệp nào cũng cần. **Càng ghi sớm càng có lịch sử**:

1. **Giá vốn theo mã hàng** (1 cột trong danh mục hàng hóa) → mở ra *lợi nhuận gộp, biên LN, sản phẩm nào lãi mỏng*. Đây là chỉ số sếp hỏi nhiều thứ hai sau doanh thu.
2. **Ngày giao thực tế** (ghi khi giao hàng) → mở ra *tỉ lệ giao đúng hạn (OTD)* — đo được chất lượng thật của xưởng và của khâu hẹn ngày.
3. **Phiếu thu theo từng lần** (ai thu, thu bao nhiêu, ngày nào) → mở ra *công nợ chính xác, tuổi nợ thật, dòng tiền thực* và đối chiếu được với đại lý.

Ngoài ra nên có: **mục tiêu doanh thu** tháng/năm, **lý do hủy / lý do làm lại** (để phân tích chất lượng), và **mốc `confirmed_at`** (để đo thời gian xử lý đơn).

---

## F. Lộ trình đề xuất

**Đợt 1 — đã xong:** KPI cơ bản + xu hướng 12 tháng + cơ cấu loại đơn/trạng thái + xếp hạng + worklist quá hạn/đến hạn/nháp lâu.

**Đợt 2 — làm được ngay, không cần dữ liệu mới (đề xuất ưu tiên):**
1. **Tiền:** khối công nợ + tuổi nợ + dòng tiền dự kiến 30 ngày (sếp quan tâm nhất sau doanh thu).
2. **Tải sản xuất 8 tuần tới** (điều độ xưởng).
3. **Chất lượng đơn:** tỉ lệ hủy, đơn làm lại, đơn thiếu ảnh SP / thiếu KH-Lượng.
4. **Cơ cấu vùng miền + nhóm cửa/model**; so **cùng kỳ năm trước**; **mục tiêu** tháng/năm (ô nhập ở tab Cấu hình).
5. Ngưỡng đèn + worklist có nút hành động.

**Đợt 3 — cần bổ sung dữ liệu:**
6. Giá vốn → **lợi nhuận gộp / biên LN / top sản phẩm lãi mỏng**.
7. Phiếu thu → **công nợ & dòng tiền thực**, đối chiếu công nợ đại lý.
8. Ngày giao thực tế → **OTD & thời gian giao bình quân**.
9. Phân quyền NVKD/đại lý; xuất Excel/PDF; gửi báo cáo định kỳ (email/Telegram mỗi sáng); cache 60s.

---

## G. Tóm lại một câu

Dashboard cho người quản trị phải trả lời được 4 câu theo thứ tự: **"Bán được bao nhiêu (so với mục tiêu/kỳ trước) → Bao nhiêu tiền chưa về → Có kịp giao không → Việc gì phải xử lý hôm nay"** — và mọi con số đều phải bấm ra được danh sách đơn cụ thể. Ba dữ liệu còn thiếu cần bắt đầu ghi ngay là **giá vốn, ngày giao thực tế, phiếu thu**.
