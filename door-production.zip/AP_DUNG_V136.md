# ÁP DỤNG V136 → V138 — MODULE LÊN KẾ HOẠCH SẢN XUẤT

> **V138 (6 việc hoàn thiện): KHÔNG cần migration mới.** Chỉ chép đè code + tài liệu.
> Gồm: in phiếu lệnh SX A4 · màn chốt kế hoạch tuần · nút tạo lệnh từ trang đơn ·
> tự dọn lệnh khi bộ bị xoá khỏi đơn · sửa số lượng lệnh con · báo cáo OTD/% lỗi.
> Chi tiết: `KE_HOACH_SAN_XUAT_V138.md`. Hướng dẫn dùng: `HUONG_DAN_TAO_LENH_SAN_XUAT_V137.md` (+ bản in PDF).

Gói này chứa **toàn bộ** thay đổi của module Lên kế hoạch sản xuất.
Đọc `KE_HOACH_SAN_XUAT_V136.md` (mục 1–11 là thiết kế, mục 12 là những gì đã làm + kết quả kiểm chứng).

> ⚠️ **KHÔNG có file nào của module đơn hàng bị sửa.** Chỉ THÊM bảng mới và thêm menu.

---

## Bốn bước áp dụng (đúng thứ tự)

### Bước 1 — Chép đè file vào project hiện tại

Chép đè các mục sau (giữ nguyên cấu trúc thư mục):

```
prisma/schema.prisma
prisma/migrations/20260926233000_production_planning/migration.sql
migrate-production-v136.sql
src/lib/production/
src/components/production/
src/app/ke-hoach-san-xuat/
src/app/api/production/
src/components/erp-nav.tsx
src/generated/prisma/          ← Prisma client đã sinh lại (hoặc để npm run build tự sinh)
KE_HOACH_SAN_XUAT_V136.md
```

`npm run build` của bạn **đã có** `prisma generate` nên nếu bỏ qua `src/generated/prisma` cũng được.

### Bước 2 — Chạy MIGRATION TRƯỚC khi deploy code

> ⚠️ **Bắt buộc.** Code mới mà DB chưa có bảng sản xuất → **500 toàn app** (lỗi Prisma `P2022`) — đúng bài học V112.

**Có 2 migration, chạy ĐÚNG THỨ TỰ:**

```bash
npx prisma migrate deploy        # chạy lần lượt cả 2
```

**Hoặc** dán tay vào Supabase → SQL Editor theo thứ tự:
1. `migrate-production-v136.sql` → `20260926233000_production_planning`
2. `migrate-production-v136-1.sql` → `20260926234500_production_component_orders`

rồi ghi nhận vào lịch sử Prisma:

```bash
npx prisma migrate resolve --applied 20260926233000_production_planning
npx prisma migrate resolve --applied 20260926234500_production_component_orders
```

(qên `migrate resolve` thì lần sau Prisma thấy lệch lịch sử và có thể đề nghị reset DB.)

> 📌 **DB production hiện đã có 10 bảng của V136** (bạn đã chạy SQL tay) nhưng **chưa có bảng `production_component_orders`**.
> Vì vậy chỉ cần chạy **`migrate-production-v136-1.sql`** là đủ; file `v136` chỉ để tham chiếu / dựng DB mới.
> Kiểm nhanh: `select count(*) from production_component_orders;` → lỗi "does not exist" nghĩa là chưa chạy V136.1.

### Bước 3 — Deploy code

```bash
npm run build      # đã kiểm: 0 lỗi
# deploy Vercel như bình thường
```

### Bước 4 — Bật module lần đầu

1. Mở menu **Sản xuất → Cấu hình sản xuất**: kiểm 8 tổ + 16 công đoạn đã có sẵn (seed từ khảo sát).
   Sửa lại nếu nhà máy chốt số khác — nhất là **Tổ vân** đang để trống năng lực (câu VAN12 chưa trả lời).
2. Mở **Sản xuất → Kế hoạch sản xuất → Nhập bộ đang sản xuất dở** → bấm **Đưa TẤT CẢ vào kế hoạch**.
3. Mở từng bộ đang làm dở, đánh dấu công đoạn **đã xong / đang làm** (tiến độ % tự tính).
4. Về **Bảng kế hoạch** bấm **Xếp lịch tự động** để có lịch ngày + bảng tải theo tổ.

---

## Cần chốt lại 2 con số (đang dùng mặc định, sửa ở Cấu hình sản xuất)

| # | Việc | Đang dùng | Sửa ở đâu |
|---|---|---|---|
| 2.1 | Đơn vị thời gian | 24 giờ = 1 ngày làm việc, nghỉ Chủ nhật + lễ → 1 bộ ≈ **15–16 ngày làm việc** | Cấu hình chung → Ca/ngày, Giờ/ca, Gối công đoạn |
| 2.4 | Ngưỡng quá tải | Theo năng lực **từng tổ** (Máy 60 · Hàn 45 · Sơn 44 · Đóng gói 50 cánh/ngày), KHÔNG dùng mốc 80 | Cấu hình chung + tab Tổ & năng lực |
| 13.5① | Số phào = (số cánh + phào rời mặc định) × số bộ — **đã chốt**, mặc định cửa đi 3 / cửa sổ 4 | Cấu hình chung → **Số phào rời mặc định — cửa ĐI / cửa SỔ** |
| 13.5③ | Màu sơn 11/14 **không cần Vân** — đã chốt, giữ `PAINT_COLOR:11,14` | Cấu hình sản xuất → công đoạn Vân → ô **"Bỏ qua khi"** |

---

## Đã kiểm chứng thật (PostgreSQL 14 + chạy app thật)

15 migration chạy sạch · migration khớp Prisma 35/35 câu lệnh · seed 8 tổ/16 công đoạn/19 lý do ·
`tsc` 0 lỗi · `eslint` 0 lỗi · `npm run build` 0 lỗi ·
tạo 4 đơn thật → 5 bộ vào kế hoạch (đơn nháp bị loại) · đồng bộ 2 lần không trùng ·
sửa đơn (đổi id dòng hàng) rồi đồng bộ lại vẫn không trùng · màu 11/14 tự bỏ Vân ·
xếp lịch 107 công đoạn, khung/cánh/phào cùng ngày · cập nhật tiến độ → 47% rồi 100% → Hoàn thành → Đã giao · 7 trang HTTP 200.

Chi tiết đầy đủ: `KE_HOACH_SAN_XUAT_V136.md` mục 12.2.

---

## Chưa làm (đợt C/D)

- In **phiếu lệnh sản xuất A4** + danh sách việc dán xưởng (KH25/KH26).
- Ép ràng buộc **gom lô màu sơn ≥ 20 cánh** / **tối đa 2 lượt đổi khuôn/ngày** (hiện chỉ cảnh báo).
- Báo cáo **OTD · % lỗi · năng suất tổ · lý do trễ** (đợt D).
- Màn import **file chương trình máy cắt** (bảng + tab cấu hình đã có, seed trống).

---

## ⚠️ Bắt buộc khi thử trên máy local

Đừng chạy `npm run start` khi chưa có `.env.local`. `.env` đang trỏ **DB production Supabase**, nên app sẽ ghi thẳng vào dữ liệu thật (đã từng xảy ra trong lúc kiểm chứng V136.1 — xem V136 mục 13.4).

```bash
printf 'DATABASE_URL="postgresql://door_app:MAT_KHAU@localhost:5432/door_production_test"\nDIRECT_URL="postgresql://door_app:MAT_KHAU@localhost:5432/door_production_test"\n' > .env.local
curl -s http://localhost:3000/api/health/db   # PHẢI thấy door_production_test rồi mới thao tác
```
