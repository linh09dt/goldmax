# ERP V31 — Bộ lọc Danh sách đơn hàng + bỏ Đối tượng THCP

## Thay đổi

- Xóa cột `Đối tượng THCP` khỏi bảng Danh sách đơn hàng.
- Giữ nguyên full view và header sticky của V30.
- Thêm bộ lọc giống tab Theo dõi doanh thu:
  - Ngày
  - Tháng
  - Năm
  - Từ ngày
  - Đến ngày
  - Đại lý
  - Khách hàng
- Nút `Lọc` và `Xóa lọc`.
- KPI ở đầu trang tự tính lại theo kết quả đã lọc.
- `Đại lý` dùng Mã/Tên khách hàng trên đơn (`customerCode/customerName`) giống logic tab Theo dõi doanh thu.
- `Khách hàng` dùng Người nhận (`receiverName`) giống logic tab Theo dõi doanh thu.
- Ưu tiên bộ lọc thời gian: `Từ ngày/Đến ngày` → `Ngày` → `Tháng` → `Năm`.

## Cài đặt

Chép patch chồng lên V30 rồi chạy:

```cmd
Ctrl + C
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần migrate database.
