# V88 — Cấu hình tính toán: thêm 3 công thức KH/Lượng cho cột “Cách tính KH/Lượng”

## Yêu cầu

> “tab cấu hình tính toán, mình muốn thêm công thức KH/Lượng, hiện tại chỉ có công thức cao x rộng / 1000000, (cao * 2 + rộng / 1000), mình muốn thêm cao * 2 /1000, rộng/1000, (cao*2 + rộng *2)/1000 để mình lựa chọn thêm cấu hình”

## Cách làm

Thêm 3 giá trị mới cho cột **CÁCH TÍNH KH/LƯỢNG** trong bảng rule (tab Cấu hình → Cấu hình tính toán):

| Nhãn trong dropdown | Mã rule | Công thức (mm → mét) |
|---|---|---|
| Cao × Rộng / 1.000.000 | `DOOR_AREA` | cũ |
| (Cao × 2 + Rộng) / 1.000 | `TRIM_LINEAR` | cũ |
| **(Cao × 2 + Rộng × 2) / 1.000** | `PERIMETER_LINEAR` | **mới** — chu vi (4 cạnh) |
| **Cao × 2 / 1.000** | `DOUBLE_HEIGHT_LINEAR` | **mới** — chỉ 2 cạnh dọc |
| **Rộng / 1.000** | `WIDTH_LINEAR` | **mới** — chỉ cạnh ngang |
| Nhập tay · Theo số TK ô thoáng · Theo SL bộ cửa cha | `MANUAL` · `PANEL_COUNT` · `PARENT_QUANTITY` | cũ |

Ba công thức mới dùng được cho **mọi phạm vi** (Bộ cửa chính / Theo nhóm hàng / Theo Model), không chỉ nhóm Phào/Phao.

Sửa 4 chỗ (đủ để thêm một công thức mới, không cần migration DB):

1. `src/lib/calculation-config.ts` — thêm vào union `PricingQuantityRule` **và** vào `Set` `PRICING_RULES`. Set này là bộ lọc khi lưu/đọc cấu hình qua API; thiếu ở đây thì rule sẽ bị âm thầm hạ về `INHERIT` mỗi lần lưu.
2. `src/components/calculation-config.tsx` — thêm dòng vào `PRICING_OPTIONS` (nhãn hiển thị trong dropdown).
3. `src/components/order-form.tsx` — `calculatePricingQuantityByRule()`: cộng công thức thật.
4. `src/app/guide/page.tsx` — thêm dòng “Công thức KH/Lượng” trong mục B1 của Hướng dẫn sử dụng để người dùng biết có các lựa chọn nào.

Quy ước khi tính (giữ nguyên như 2 công thức cũ):
- Cao/Rộng phải > 0 và là số; giá trị không hợp lệ coi như chưa nhập.
- Không nhập được gì (`Cao × 2 / 1.000` mà thiếu Cao, `Rộng / 1.000` mà thiếu Rộng) → **xoá trống** ô KH/Lượng.
- Công thức dạng tổng thì lấy 0 cho phần thiếu (giống `TRIM_LINEAR` đang chạy): `(Cao × 2 + Rộng × 2) / 1.000` khi chỉ có Rộng 900 → 1,8.
- `MANUAL` trả `null` = không đụng vào ô KH/Lượng người dùng đã nhập tay.

## Kiểm chứng

Chạy trực tiếp hàm tính của app (bundle `order-form.tsx` bằng esbuild rồi gọi `calculatePricingQuantityByRule`) — 16/16 case đúng, gồm cả 2 công thức cũ (chống hồi quy):

| Rule | Cao | Rộng | Kết quả |
|---|---|---|---|
| `MANUAL` | 2000 | 900 | `null` (không đổi) |
| `DOOR_AREA` | 2000 | 900 | `1.8` |
| `TRIM_LINEAR` | 2000 | 900 | `4.9` |
| `PERIMETER_LINEAR` | 2000 | 900 | `5.8` |
| `DOUBLE_HEIGHT_LINEAR` | 2000 | 900 | `4` |
| `WIDTH_LINEAR` | 2000 | 900 | `0.9` |
| `PERIMETER_LINEAR` | 2000.5 | 900 | `5.801` |
| `DOUBLE_HEIGHT_LINEAR` | 1234 | 900 | `2.468` |
| `DOUBLE_HEIGHT_LINEAR` | — | 900 | `""` (xoá trống) |
| `WIDTH_LINEAR` | 2000 | — | `""` |
| `PERIMETER_LINEAR` | — | 900 | `1.8` |
| `PERIMETER_LINEAR` / `TRIM_LINEAR` | — | — | `""` |
| `TRIM_LINEAR` | 2000 | — | `4` |
| `PANEL_COUNT` (2TK) | — | — | `2` |
| `PARENT_QUANTITY` (SL 3) | — | — | `3` |

Kiểm tra lưu/đọc cấu hình qua `normalizeCalculationConfig`: rule mang `PERIMETER_LINEAR` / `DOUBLE_HEIGHT_LINEAR` / `WIDTH_LINEAR` giữ nguyên sau khi round-trip; giá trị lạ vẫn bị hạ về `INHERIT` như cũ.

- `npx tsc --noEmit` → 0 lỗi.
- `npx eslint` 4 file sửa → đúng 5 lỗi `react-hooks/set-state-in-effect` **đã có từ trước** (đã đối chiếu với bản gốc: y hệt, 5 lỗi), không phát sinh lỗi mới.

## Lưu ý

- **Không cần migration DB**: cấu hình nằm trong bảng settings dưới dạng JSON (`ORDER_CALCULATION_CONFIG_V1`), thêm giá trị mới chỉ là mở rộng danh sách cho phép.
- Cấu hình đã lưu của bạn **giữ nguyên** (11 rule cũ vẫn chạy đúng); muốn dùng công thức mới thì vào Cấu hình → Cấu hình tính toán → đổi cột CÁCH TÍNH KH/LƯỢNG của rule cần dùng (ví dụ rule “Phào Biệt Thự”, “Phao Rời”) rồi bấm Lưu cấu hình.
- Cột CÁCH TÍNH KH/LƯỢNG khá hẹp nên nhãn dài có thể bị cắt — rê chuột vào ô chọn để xem đầy đủ (title tooltip có sẵn từ V85).
- Khối ví dụ cuối trang Cấu hình vẫn ghi 2 công thức mặc định (Nhóm cửa / Phào–Phao); đây là mô tả **giá trị mặc định**, không phải toàn bộ danh sách lựa chọn.

## File thay đổi

- `src/lib/calculation-config.ts` — thêm `PERIMETER_LINEAR`, `DOUBLE_HEIGHT_LINEAR`, `WIDTH_LINEAR` vào type + `PRICING_RULES`, kèm chú thích công thức.
- `src/components/calculation-config.tsx` — thêm 3 lựa chọn vào dropdown CÁCH TÍNH KH/LƯỢNG.
- `src/components/order-form.tsx` — tính KH/Lượng cho 3 công thức mới.
- `src/app/guide/page.tsx` — bổ sung dòng “Công thức KH/Lượng” trong Hướng dẫn sử dụng.
