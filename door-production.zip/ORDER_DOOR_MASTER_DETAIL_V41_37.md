# V41.37 - Bộ cửa / phụ kiện dạng master-detail compact

## Mục tiêu
Thay phần nhập chi tiết theo từng bộ cửa bằng giao diện master-detail gọn, không cuộn ngang và chỉ mở một phụ kiện để chỉnh sửa tại một thời điểm.

## Thay đổi
- Bộ cửa chính hiển thị compact 2 hàng: Cao, Rộng, Khuôn, SL bộ, Ô thoáng, Hướng mở, Phào, Màu sơn, ĐVT, KH/Lượng, Đơn giá.
- Thông tin ít dùng chuyển vào `Thông số nâng cao` gồm KT thông thủy, model khóa, ghi chú, hình ảnh và chọn Nhóm cửa/Model.
- Phụ kiện/chi tiết hiển thị dạng danh sách master-detail với các cột: Chi tiết/Model, KT dùng tính, SL, ĐVT, KH/Lượng, Đơn giá, Thành tiền.
- Chỉ một phụ kiện được mở inline để chỉnh sửa tại một thời điểm.
- Thêm phụ kiện mới sẽ tự mở dòng vừa thêm.
- Phào đứng ưu tiên tóm tắt chiều Cao; phào ngang ưu tiên chiều Rộng; phào rời hiển thị cả Cao và Rộng.
- Dòng chưa đủ dữ liệu không hiển thị `0đ`:
  - thiếu giá: `Chưa có giá`
  - thiếu KH/Lượng: `Cần nhập KH/Lượng`
  - khóa/custom chưa có giá: `TC`
- Toàn bộ logic DB, API, tính giá, catalog, upload/paste ảnh và export giữ nguyên.

## File thay đổi
- `src/components/order-form.tsx`
