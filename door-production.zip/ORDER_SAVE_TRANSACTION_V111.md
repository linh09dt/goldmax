# V111 — Sửa lỗi "expired transaction" khi lưu đơn hàng

## Lỗi báo ra

```
Invalid `prisma.salesOrderItem.create()` invocation:
Transaction API error: A query cannot be executed on an expired transaction.
The timeout for this transaction was 5000 ms, however 5102 ms passed since the start of the transaction.
Consider increasing the interactive transaction timeout or doing less work in the transaction.
```

## Nguyên nhân (đã đo lại được đúng lỗi này)

`src/app/api/orders/route.ts` ghi DB **tuần tự từng dòng** trong một transaction tương tác, mà transaction của Prisma chỉ cho **5 giây**:

- 1 bộ cửa = **2 lượt round trip** (`salesOrderItem.create` + `salesOrderItemDetail.createMany`)
- cộng 5 lượt SQL cấp Bộ số (`SELECT FOR UPDATE`, `MAX`, `UPDATE`…), 1 lượt tạo đơn, BEGIN/COMMIT, các lượt kiểm tra trùng mã.

→ **Đo thực tế: 25 bộ cửa = 61 lượt round trip.** Với DB production là Supabase pooler ở Singapore (đo từ sandbox: **41 ms** chỉ riêng TCP; mỗi lượt thực tế ~85–100 ms), 61 lượt ≈ **5,2 giây** → quá 5 giây → lỗi trên. Đơn càng nhiều bộ cửa càng chắc chắn vỡ.

Tái hiện trong repo bằng cách giả lập độ trễ 100 ms mỗi lượt: **đúng y nguyên thông báo lỗi của khách** (`… however 5102 ms passed …`). Với 80 ms thì vẫn qua (5371 ms, sát nút) — giải thích vì sao lỗi chỉ xuất hiện với một số đơn.

## Đã sửa

1. **Gom mỗi bảng một lượt ghi** (thay vì 1 lượt/dòng):
   - `salesOrderItem.createManyAndReturn(...)` → 1 lượt cho **tất cả** bộ cửa, trả về id + lineNo.
   - `salesOrderItemDetail.createMany(...)` → 1 lượt cho tất cả dòng phụ kiện (ghép id qua `lineNo`).
   - `salesOrderRequirement.createMany(...)` → 1 lượt.
   - Áp dụng cho **cả 3 đường ghi**: tạo đơn (`POST /api/orders`), sửa đơn (`PUT /api/orders/[id]`), nhập Excel (`POST /api/orders/import`).
   - Thử `nested create` trước nhưng **không có tác dụng**: đo được Prisma vẫn gửi từng câu riêng khi dùng driver adapter (`@prisma/adapter-pg`) — nên phải gom theo bảng như trên.
2. **Gộp SQL cấp Bộ số** trong `src/lib/set-number.ts`: 5 câu → **2 câu**. Câu `UPDATE … RETURNING` tự khóa hàng bộ đếm và tính luôn `MAX(set_no)` bằng subquery trong `GREATEST`, nên vẫn **không cấp trùng** khi hai đơn lưu cùng lúc (giữ nguyên công thức `first = max(bộ đếm+1, floor, số lớn nhất đang dùng+1, số đang giữ+1)`).
3. **Nới hạn mức transaction** — `src/lib/db-transaction.ts` (`ORDER_WRITE_TRANSACTION = { maxWait: 15s, timeout: 30s }`) làm lưới an toàn cho đơn rất lớn / mạng rất chậm.

## Kiểm chứng (Postgres 14 thật + đếm round trip ở tầng driver)

Số lượt round trip **không còn phụ thuộc số bộ cửa**:

| Đường ghi | Trước | Sau |
|---|---|---|
| Tạo đơn, 25 bộ cửa (1 dòng cửa + 2 phụ kiện mỗi bộ) | **61 lượt** | **11 lượt** |
| Sửa đơn, 25 bộ cửa | 64 lượt | 15 lượt |
| Nhập Excel, 12 bộ cửa | ~32 lượt | 20 lượt |
| Nhập Excel, **30 bộ cửa** | ~68 lượt | **20 lượt** (không tăng) |

Thời gian thực đo (giả lập độ trễ mỗi lượt như DB remote):

| Độ trễ/lượt | Tạo đơn trước | Tạo đơn sau | Import 30 bộ trước | Import 30 bộ sau |
|---|---|---|---|---|
| 100 ms | **LỖI 5102 ms** (expired transaction) | **1.357 ms ✅** | ~6,8 s (vỡ) | 1.457 ms ✅ |
| 300 ms | — | 3.562 ms ✅ | — | — |

Kiểm tra dữ liệu sau khi ghi (25 bộ cửa): 25 items, **50 details**, 2 requirements, `setNo` liên tục và **giữ nguyên khi cập nhật**, `image_path` giữ đúng, `subtotal` đúng, `rawBlock` của import lưu đủ. Import 30 bộ cửa: 30 items / 60 details / 6 requirements / 1 dòng `order_imports`.

`npx tsc --noEmit` 0 lỗi · `npx eslint` 5 file đã sửa → sạch · `npm run build` → **Compiled successfully**.

## Trả lời câu hỏi "lỗi này xuất hiện khi chạy code v110b?"

**Không phải do V110b.** Đã kiểm tra đường phụ thuộc: các file của V110b (`excel-image-cell.ts`, `png-size.ts`, `order-export.ts`, `order-export-v2.ts`, `reportlab_order_v2.py`) chỉ được dùng bởi **route xuất file**, không có file nào nằm trong đường đi lưu đơn — route lưu chỉ import `prisma`, `order-persistence`, `set-number` (và nay thêm `db-transaction`). Lỗi này là vấn đề có sẵn của transaction ghi đơn, chỉ **lộ ra khi đơn đủ nhiều bộ cửa** (hoặc mạng tới DB chậm/chập chờn) — việc deploy V110b trùng thời điểm nên dễ tưởng là do V110b.

## File thay đổi

- `src/lib/db-transaction.ts` — **mới**: hạn mức transaction dùng chung.
- `src/lib/set-number.ts` — 5 câu SQL cấp Bộ số gộp còn 2.
- `src/app/api/orders/route.ts` — gom ghi khi tạo đơn.
- `src/app/api/orders/[id]/route.ts` — gom ghi khi sửa đơn.
- `src/app/api/orders/import/route.ts` — gom ghi khi nhập Excel.

## Lưu ý

- Không đổi schema DB, không cần migration, không đổi API/hình dạng dữ liệu trả về.
- **Nên làm thêm (chưa làm):** thêm index cho cột `set_no` để câu `MAX(set_no::bigint)` trong cấp Bộ số không phải quét cả bảng khi dữ liệu lớn:
  ```sql
  CREATE INDEX CONCURRENTLY IF NOT EXISTS sales_order_items_set_no_numeric_idx
    ON sales_order_items ((NULLIF("set_no", '')::bigint))
    WHERE "set_no" ~ '^[0-9]{1,18}$';
  ```
- Nếu sau này vẫn gặp timeout với đơn cực lớn, bước tiếp theo là gộp cả 3 bảng vào **một câu SQL** (`jsonb_to_recordset`) để còn đúng 1 lượt.
