# ORDER IMAGE PASTE V41.20

## Thay đổi
- Cột **Hình ảnh SP** hỗ trợ dán ảnh trực tiếp từ Clipboard bằng **Ctrl+V**.
- Hỗ trợ ảnh PNG/JPG/WEBP từ Snipping Tool, Paint, trình duyệt, Excel và các ứng dụng đưa ảnh vào Clipboard.
- Ảnh dán dùng lại API `/api/orders/images` và Supabase Storage hiện tại, không thay đổi kiến trúc lưu ảnh.
- Nếu dòng đã có ảnh, hệ thống hỏi xác nhận trước khi thay bằng ảnh dán mới.
- Vẫn giữ **Tải ảnh / Đổi ảnh** làm phương án dự phòng.
- Không thay đổi logic PDF V2, Excel V2, giá, đơn hàng hoặc database.

## Cách dùng
1. Copy ảnh.
2. Bấm vào ô **Hình ảnh SP** của đúng dòng.
3. Nhấn **Ctrl+V**.
4. Chờ ảnh tải lên và thumbnail xuất hiện.
