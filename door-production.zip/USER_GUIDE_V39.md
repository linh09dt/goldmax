# V39 - Hướng dẫn sử dụng

- Thêm menu `Hướng dẫn sử dụng` trong sidebar.
- Thêm trang `/guide`.
- Hướng dẫn quy trình sử dụng nhanh.
- Giải thích chức năng các nút tại:
  - Tổng quan
  - Quản lý đơn hàng
  - Tạo / sửa đơn hàng
  - Theo dõi doanh thu
  - Danh mục hàng hóa
  - Danh mục cấu hình
  - Tính cước vận chuyển
- Không thay đổi database, Supabase hoặc logic nghiệp vụ.
