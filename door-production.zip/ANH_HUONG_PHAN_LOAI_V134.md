# V134 — Rà soát ảnh hưởng: phân loại hàng hóa ảnh hưởng tới những tab / tác vụ nào?

Trả lời câu hỏi: *"ảnh hưởng đến tất cả các tab và tác vụ khi có sự thay đổi này không?"*

Cách rà: tìm **mọi nơi** đọc bảng `item_masters`, mọi nơi phân biệt cửa/phụ kiện, mọi nơi tạo hàng hóa,
rồi chạy thật 26 route để chắc chắn không có lỗi phát sinh.

## 1. Kết luận ngắn

- **Chỉ 2 chỗ đổi hành vi**: tab **Cấu hình → A1 Danh mục hàng hóa** và **form Tạo/Sửa đơn**. Cộng thêm 2 tác vụ phụ: **Xuất Master Data** (thêm 1 cột) và **Tạo lại Master Data từ Excel** (đã sửa để giữ phân loại).
- **Tất cả các tab/tác vụ còn lại không đổi**, vì chúng không đọc cột phân loại — chúng dùng `code`, `name`, giá, ĐVT (những trường V134 **không** sửa).
- Không có tab nào bị lỗi: 26/26 route trả **HTTP 200**, log không có lỗi runtime.

## 2. Bảng rà soát (đã chạy thật)

| Tab / tác vụ | Ảnh hưởng | Vì sao / bằng chứng |
|---|---|---|
| **Cấu hình → A1 Danh mục hàng hóa** | **CÓ (đổi giao diện)** | chia **3 khối theo cột Phân loại** + thêm cột "Phân loại" sửa được (`item-master.tsx`). Kiểm chứng: 92 dòng → `CẤP CỬA 52 / PHỤ KIỆN 35 / CHI PHÍ GIA CÔNG 5` |
| **Tạo đơn** | **CÓ** | `isDoorCatalogItem()` đọc cột phân loại (`order-form.tsx:154-155, 1723`) ⇒ ô "Nhóm cửa" chỉ 7 nhóm cửa; ô "Nhóm hàng" có `optgroup CHI PHÍ GIA CÔNG` |
| **Sửa đơn** | CÓ (giống Tạo đơn) | dùng chung component; đã kiểm chứng optgroup hiện đúng trên đơn 17 |
| Cấu hình → A2 Danh mục cấu hình | Không | chỉ đọc/ghi `master_options` |
| Cấu hình → B1 Cấu hình tính toán | Không | gợi ý nhóm lấy từ `item_masters.name` (`api/calculation-config/route.ts:28`), **tên không đổi** |
| Lưu đơn (persistence) | Không | dòng đơn chỉ lưu `productCode`, tên, giá…; **không** lưu phân loại (`order-persistence.ts`) |
| Danh sách đơn + xem nhanh (drill-down) | Không | không đọc `category` |
| Chi tiết đơn / bản in | Không | không đọc `category` |
| Xuất Excel / PDF đơn hàng | Không | dùng dữ liệu dòng của đơn |
| Báo cáo (5 trang) + xuất Excel báo cáo | Không | `reporting.ts` / `report-data.ts` không dùng phân loại |
| Doanh thu | Không | ghép mã/tên sản phẩm (`revenue/page.tsx:101`, `api/revenue/export:90`) |
| Vận chuyển | Không | chỉ dùng `code → name`; nhóm cước `doorGroup` là dữ liệu riêng của bảng cước (`shipping/page.tsx:44,76`, `lib/shipping.ts`) |
| Tìm kiếm nhanh Ctrl+K | Không | tìm theo code/name/diễn giải (`lib/search.ts:57`) |
| Nhập đơn từ Excel (mẫu đơn) | Không | `order-excel.ts` **không** đọc `item_masters`; dòng chính xác định bằng cột A (STT) (`order-excel.ts:162`) |
| Nhập giá/ĐVT (`attributes/import`) | Không | chỉ cập nhật ĐVT/giá, không đụng cột phân loại |
| **Xuất Master Data (Excel)** | **CÓ (thêm 1 cột)** | thêm cột `PHÂN LOẠI` với 3 nhãn Cấp cửa / Phụ kiện / Chi phí gia công (`api/items/export/route.ts:19`) |
| **Tạo lại Master Data từ Excel** | **CÓ — đã sửa** | trước: xoá danh mục rồi nạp lại ⇒ **mất phân loại đã đặt**. Nay **giữ phân loại theo MODEL** trước khi xoá (`api/items/master/rebuild/route.ts`), mã mới thì phân loại theo TENHANG |
| Xóa hàng hóa / sửa giá / ngưng dùng | Không | `PUT /api/items/[id]` chỉ đổi phân loại khi client gửi lên |

## 3. Kiểm chứng "Tạo lại Master Data" (chạy thật)

Chuẩn bị: đặt sai có chủ ý — mã **`PR` (Phao Rời)** chuyển sang **CẤP CỬA**, rồi tạo file Master Data
(`TENHANG` + `MODEL`) gồm 92 mã cũ + 2 mã mới (`Cửa Test Mới`, `Phào Test Mới`) và bấm "Tạo lại".

| Thời điểm | DOOR | ACCESSORY | PROCESSING |
|---|---|---|---|
| Trước khi tạo lại | 53 | 34 | 5 |
| Sau khi tạo lại (94 mã) | 54 | 35 | 5 |

- `PR` giữ **DOOR** ⇒ phân loại đã đặt **không bị mất** ✅
- `MODEL_CUA_MOI` ("Cửa Test Mới") → **DOOR**, `MODEL_PHAO_MOI` ("Phào Test Mới") → **ACCESSORY** ⇒ mã mới phân loại theo TENHANG ✅
- Sau kiểm thử: đã xoá 2 mã test, trả `PR` về Phụ kiện, khôi phục ĐVT/giá từ file backup ⇒ danh mục về đúng **92 mã / 52-35-5**.

## 4. Lỗi có SẴN (không do V134) — cần bạn biết

File **"Xuất Master Data"** hiện **không dùng lại được** làm file nguồn cho "Tạo lại Master Data":
- trong file xuất, cột `TENHANG` và `MODEL` **không nằm liền nhau** (có cột "TÊN SẢN PHẨM DIỄN GIẢI" ở giữa),
  mà bộ đọc Master Data yêu cầu cặp TENHANG + MODEL **liền kề** (`item-master-v14-excel.ts:107-124`).
- endpoint `POST /api/items/import` lại yêu cầu cột tên là **"Tên" / "Mã"** — hiện **không có nút nào trên giao diện gọi endpoint này**.

Kiểm chứng: POST chính file vừa xuất → `400 {"ok":false,"error":"Không tìm thấy cột 'Tên' và 'Mã' trong file danh mục hàng hóa."}`
⇒ Đây là hành vi **có từ trước V134** (bố cục file xuất vốn đã như vậy), không phải do cột `PHÂN LOẠI` mới thêm.

**Nói mình nếu bạn muốn**: mình sửa để file Xuất Master Data nhập lại được (đổi thứ tự cột cho TENHANG–MODEL liền nhau + đọc cột PHÂN LOẠI khi có) — việc này đổi bố cục file xuất nên mình không tự làm.

## 5. Rủi ro cần lưu ý khi dùng (không phải lỗi)

- Nếu bạn **đặt hết mọi mã cửa sang Phụ kiện/Chi phí gia công**, ô "Nhóm cửa" trong form tạo đơn sẽ trống (chỉ còn dòng "Chọn nhóm cửa"). App **không lỗi** (không có chỗ nào lấy phần tử đầu của danh sách làm mặc định), chỉ là không chọn được mã cửa cho tới khi bạn phân loại lại.
- Phân loại **không** ảnh hưởng tới tiền, KH/Lượng, báo cáo, cước vận chuyển — chỉ ảnh hưởng tới **nơi hiển thị/chọn hàng hóa**.

## 6. Danh sách route đã chạy kiểm tra (26/26 = HTTP 200)

`/` · `/orders` · `/orders/new` · `/orders/15` · `/orders/15/edit` · `/orders/15/print` · `/revenue` · `/reports` ·
`/reports/orders` · `/reports/products` · `/reports/sales-performance` · `/reports/receivables` · `/reports/production-load` ·
`/shipping` · `/settings?tab=items` · `/settings?tab=options` · `/settings?tab=pricing` · `/guide` ·
`/api/items` · `/api/items?category=DOOR` · `/api/items/export` · `/api/master-options` · `/api/calculation-config` ·
`/api/orders/export-list` · `/api/reports/orders/export` · `/api/search?q=khoa`
