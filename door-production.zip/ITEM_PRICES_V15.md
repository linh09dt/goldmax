# ERP V15 — ĐVT, Giá đại lý, Giá bán lẻ

## Phạm vi

Chỉ mở rộng Master Data hàng hóa và liên kết giá vào Đơn hàng. Không thay đổi logic bộ cửa, cước vận chuyển, chiết khấu 12%, lọc KH/Lượng hoặc cấu trúc xuất đơn.

## Master Data hàng hóa

Bổ sung và cho phép sửa trực tiếp:

- TENHANG
- MODEL
- ĐVT
- Giá đại lý
- Giá bán lẻ
- Trạng thái

`Tạo lại Master Data từ Excel` vẫn chỉ lấy TENHANG + MODEL từ file master. Sau khi reset, ĐVT/Giá đại lý/Giá bán lẻ được để trống để người dùng cấu hình lại.

## Liên kết với Đơn hàng

Khi chọn hàng hóa trong Tạo/Sửa đơn:

1. Tự điền TENHANG + MODEL.
2. Tự điền ĐVT từ Master Data.
3. Đơn giá mặc định lấy **Giá đại lý**; nếu chưa có Giá đại lý thì fallback **Giá bán lẻ**.
4. Ngay dưới ô Đơn giá có nút **Đại lý** và **Bán lẻ**. Bấm nút nào thì giá tương ứng được đưa vào Đơn giá của dòng.
5. Người dùng vẫn có thể sửa Đơn giá bằng tay.

Đơn hàng lưu **ĐVT + Đơn giá thực tế** vào dòng đơn hàng. Vì vậy nếu Master Data đổi giá sau này thì đơn đã lưu trước đó không tự đổi giá.

## Xuất Excel/PDF

Excel/PDF đơn hàng vẫn lấy từ dữ liệu đã lưu trên đơn:

- ĐVT = ĐVT của dòng đơn hàng.
- Đơn giá = giá Đại lý/Bán lẻ/giá sửa tay đã chọn lúc lập đơn.
- Thành tiền = KH/Lượng × Đơn giá (theo logic hiện tại).

Xuất Master Data `/api/items/export` bổ sung các cột ĐVT, GIÁ ĐẠI LÝ, GIÁ BÁN LẺ.

## Cập nhật database

Patch có migration an toàn với `IF NOT EXISTS`, phù hợp cả máy đã hoặc chưa có các cột giá từ các bản cũ.

Sau khi chép patch:

```cmd
npm run db:migrate
npm run db:generate
rmdir /s /q .next
npm run dev
```
