# ERP V8 - Xuất đơn hàng ra Excel

## Mục tiêu
Sau khi tạo/import đơn hàng, người dùng có thể bấm **Xuất Excel** tại màn hình chi tiết đơn hàng.

File xuất bám theo bố cục đơn hàng mẫu:
- Logo GOLDMAX, mã biểu mẫu, ngày hiệu lực.
- Mã/Tên khách hàng, NVKD, mã đơn hàng, ngày đặt/ngày giao.
- Người nhận, điện thoại, địa chỉ, số km, vùng miền, nhóm.
- Bảng chi tiết bộ cửa theo đúng thứ tự cột của mẫu.
- Mỗi bộ cửa: dòng sản phẩm chính + các dòng chi tiết/phụ kiện/phụ phí có dữ liệu ngay bên dưới.
- ĐVT, KH/Lượng, đơn giá, thành tiền, ghi chú.
- Ảnh sản phẩm nếu file ảnh local là PNG/JPG/JPEG.
- Cước vận chuyển.
- Câu hỏi xác nhận.
- Tổng tiền, chiết khấu, đặt cọc, khoản nhận tại kho, thanh toán khi giao.
- Khổ A4 ngang, lặp hàng tiêu đề 8-9 khi in, fit theo chiều ngang.

## URL
`GET /api/orders/:id/export`

Không thay đổi schema PostgreSQL, không cần migrate.
