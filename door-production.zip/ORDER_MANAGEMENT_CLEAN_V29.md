# ERP V29 — Tinh gọn tab Quản lý đơn hàng

- Xóa khối **Nhập đơn hàng từ Excel** khỏi `/orders`.
- Giữ chức năng nhập Excel tại `/orders/new` theo V21/V22.2.
- Không thay đổi KPI, danh sách đơn hàng, sửa/xóa, lọc KH/Lượng hay các logic khác.
- Không thay đổi database schema.
