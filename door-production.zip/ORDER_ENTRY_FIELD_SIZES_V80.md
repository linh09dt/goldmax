# KÍCH THƯỚC Ô NHẬP — VIEW TẠO ĐƠN HÀNG (mốc V80)

Số đo thật, lấy bằng cách đo trong trình duyệt ở 2 khổ màn hình.
Nhãn luôn **trải đúng bằng bề rộng ô nhập** nên chỉ cần chỉnh 1 lần cho cả nhãn + ô.

## A. THÔNG TIN ĐƠN HÀNG — 1 hàng, 13 ô

| # | Ô | Tỷ lệ code | @1280 | @1920 |
| --- | --- | --- | --- | --- |
| 1 | Mã đơn hàng * | `1.05fr` | 73 | 126 |
| 2 | Trạng thái * | `0.85fr` | 59 | 102 |
| 3 | Ngày cập nhật * | `0.9fr` | 62 | 108 |
| 4 | NVKD phụ trách * | `0.95fr` | 66 | 114 |
| 5 | Mã Đại Lý * | `1fr` | 69 | 120 |
| 6 | Tên khách hàng * | `1.2fr` | 83 | 144 |
| 7 | Ngày đặt hàng * | `0.9fr` | 62 | 108 |
| 8 | Ngày cần giao * | `0.95fr` | 66 | 114 |
| 9 | Người nhận | `0.9fr` | 62 | 108 |
| 10 | Số điện thoại * | `0.85fr` | 59 | 102 |
| 11 | Địa chỉ nhận hàng * | `1.5fr` | 104 | 180 |
| 12 | Vùng miền | `0.75fr` | 52 | 90 |
| 13 | Số Km | `0.8fr` | 55 | 96 |

Tổng fr = **12.6**

## B. BỘ CỬA — 1 hàng, 17 ô

| # | Ô | Tỷ lệ code | @1280 | @1920 |
| --- | --- | --- | --- | --- |
| 1 | Bộ số | `0.66fr` | 44 | 85 |
| 2 | Nhóm cửa | `0.9fr` | 59 | 112 |
| **3** | **Model** | `min 168px · 2.6fr` | **173** | **330** |
| 4 | Ô thoáng | `min 46px · 0.3fr` | 46 | 46 |
| 5 | Hướng mở | `min 46px · 0.34fr` | 46 | 46 |
| 6 | Phào | `0.6fr` | 40 | 77 |
| 7 | Màu sơn | `0.6fr` | 40 | 77 |
| 8 | Cao | `0.52fr` | 35 | 67 |
| 9 | Rộng | `0.52fr` | 35 | 67 |
| 10 | Khuôn | `0.52fr` | 35 | 67 |
| 11 | TT Cao | `0.6fr` | 40 | 77 |
| 12 | TT Rộng | `0.6fr` | 40 | 77 |
| 13 | SL bộ | `min 30px · 0.25fr` | 30 | 32 |
| 14 | ĐVT | `0.44fr` | 30 | 56 |
| 15 | KH/L (KH/Lượng) | `0.6fr` | 40 | 77 |
| 16 | Đơn giá | `0.62fr` | 40 | 76 |
| 17 | Thành tiền | `0.68fr` | 46 | 87 |

Tổng fr = **10.35** (4 ô có mức tối thiểu: Model 168px, Ô thoáng 46px, Hướng mở 46px, SL bộ 30px)

## C. PHỤ KIỆN / CHI TIẾT — mỗi dòng 1 hàng, 10 ô + nút Xóa

| # | Ô | Tỷ lệ code | @1280 | @1920 |
| --- | --- | --- | --- | --- |
| 1 | Nhóm hàng | `0.9fr` | 98 | 173 |
| 2 | Model | `1.1fr` | 120 | 212 |
| 3 | Cao | `0.55fr` | 61 | 107 |
| 4 | Rộng | `0.55fr` | 61 | 107 |
| 5 | Khuôn | `0.55fr` | 61 | 107 |
| 6 | ĐVT | `0.5fr` | 56 | 98 |
| 7 | KH/Lượng | `0.6fr` | 67 | 117 |
| 8 | Đơn giá | `0.8fr` | 87 | 153 |
| 9 | Thành tiền | `0.85fr` | 95 | 166 |
| 10 | Ghi chú (+ nút Xóa) | `1.2fr` | 91 | 191 |

Tổng fr = **7.6**

## D. Ô NGOÀI LƯỚI

| Ô | Kích thước | @1280 | @1920 |
| --- | --- | --- | --- |
| Ghi chú của bộ cửa | `1fr` (phần còn lại) | 1364 | 1364 |
| Hình ảnh SP | cố định `190px` | 190 | 190 |
| Panel "Tổng hợp giá trị" (phải) | `1.2fr / 0.8fr` | — | — |

## Cách chỉnh

Trong `src/components/order-form.tsx`:

| Khối | Dòng (xấp xỉ) | Class cần sửa |
| --- | --- | --- |
| Thông tin đơn hàng | ~471 | `xl:grid-cols-[1.05fr_0.85fr_0.9fr_0.95fr_1fr_1.2fr_0.9fr_0.95fr_0.9fr_0.85fr_1.5fr_0.75fr_0.8fr]` |
| Bộ cửa | ~707 | `xl:grid-cols-[0.66fr_0.9fr_minmax(168px,2.6fr)_minmax(46px,0.3fr)_minmax(46px,0.34fr)_0.6fr_0.6fr_0.52fr_0.52fr_0.52fr_0.6fr_0.6fr_minmax(30px,0.25fr)_0.44fr_0.6fr_0.62fr_0.68fr]` |
| Phụ kiện | ~858 | `xl:grid-cols-[0.9fr_1.1fr_0.55fr_0.55fr_0.55fr_0.5fr_0.6fr_0.8fr_0.85fr_1.2fr]` |

- `0.9fr` = **tỷ lệ**; `minmax(168px, 2.6fr)` = **tối thiểu 168px**, còn lại chia theo tỷ lệ.
- Muốn cố định đúng 1 số thì ghi thẳng px, ví dụ `120px` thay cho `0.9fr`.
- Công thức tự tính: `px ≈ (bề rộng khối − 6px × số khe) × fr ÷ tổng_fr`.
- Các ô nhỏ hơn ~40px sẽ bị cắt chữ trong ô nhập; nhỏ hơn ~46px thì nhãn in hoa phải viết tắt (ví dụ “TT Cao”, “KH/L”).
