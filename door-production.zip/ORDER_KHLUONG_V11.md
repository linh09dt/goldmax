# ERP V11 – Lọc dòng theo KH/Lượng

## Thay đổi
- Trang chi tiết đơn hàng `/orders/[id]` chỉ hiển thị các dòng có `KH/Lượng > 0`.
- Dòng chi tiết có KH/Lượng trống, `0`, `-`, `—` sẽ bị ẩn.
- Dòng sản phẩm chính cũng chỉ hiển thị khi có `KH/Lượng > 0`.
- Nếu một bộ cửa không có dòng chính hoặc dòng chi tiết nào có KH/Lượng thì toàn bộ bộ cửa đó không hiển thị trong phần chi tiết.
- Số lượng bộ cửa hiển thị và số dòng chi tiết được tính lại theo dữ liệu sau lọc.
- Không đổi database, import, tính giá, xuất Excel/PDF, sửa/xóa đơn hay các Master Data.

## Cài đặt
Giải nén chồng patch lên ERP V10, sau đó:

```cmd
rmdir /s /q .next
npm run dev
```

Không cần chạy migrate.
