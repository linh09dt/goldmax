# V119 — Đọc video “Quy trình sản xuất Cửa thép vân gỗ Alux | Alumax Việt Nam”

**Video:** `youtube.com/watch?v=vOsI-lF0_NM` · kênh *Cửa Thép Vân Gỗ Alux* (ALUMAX Việt Nam).
**Bản đầy đủ:** `artifacts/danh-gia-quy-trinh-cua-thep-v119.docx` (+ `.pdf`) · khung hình: `artifacts/v119-cua-thep-alux-khung-hinh.png`.

**Giới hạn:** YouTube chặn IP của môi trường này → không tải được video/phụ đề. Mình đã mở trang bằng trình duyệt chống phát hiện, lấy **tiêu đề + 4 khung hình thật**,
và lấy **bài viết cùng công ty** (`alux.com.vn/quy-trinh-san-xuat-cua-thep-van-go-alux/`) — là bản chữ của đúng nội dung video — để đọc quy trình.

---

## Quy trình cửa thép vân gỗ Alux (theo chính Alux công bố)

| # | Công đoạn | Nội dung chính | Thiết bị / vật liệu |
|---|---|---|---|
| 0 | **Chuẩn bị sản xuất** | Form “Đề nghị sản xuất” + **bản vẽ đã được phê duyệt** + đơn hàng **có xác nhận của khách**; phụ kiện mới phải có mẫu/bản vẽ đủ thông số | Form, bản vẽ, hợp đồng |
| 1 | Cắt kích thước & khoét lỗ | Nhận bản vẽ + **lệnh sản xuất** → kiểm tra máy → nhận phôi từ kho → cắt | Máy cắt CNC (Bystronic – Thụy Sỹ) |
| 2 | Gấp tạo hình (chấn) | Nhận bán thành phẩm từ bộ phận cắt → **kiểm tra khuôn & máy** → gấp | Máy chấn + khuôn (video: *Xact Smart 160*) |
| 3 | Xử lý bề mặt (nhúng hóa chất) | Kiểm tra nồng độ bể → xếp cấu kiện vào giá nhúng → nhúng vệ sinh → làm sạch hóa chất | Bể nhúng (màng phốt phát) |
| 4 | **Ép + hàn thành CÁNH cửa** | Nhận **keo + cốt cửa** từ kho → ép → hàn liên kết → **mài mối hàn, làm sạch ba via** | Máy ép; cốt Honeycomb paper / MgO |
| 5 | **Hàn ghép thành KHUNG cửa** | Nhận bán thành phẩm từ chấn → kiểm tra máy, vật tư → hàn → mài + làm sạch | Máy hàn |
| 6 | Sấy & sơn tĩnh điện | Làm sạch bụi → sơn theo màu | Dây chuyền sơn tĩnh điện |
| 7 | **Hoàn thiện vân gỗ** | Nhận keo + **giấy vân** → **dán vân** lên khung/cánh → **buồng sấy** (nhiệt độ & thời gian theo hướng dẫn) → vệ sinh | In chuyển ấn nóng 230°C |
| 8 | **Lắp ghép thành bộ & đóng gói** | Nhận **phụ kiện (khoá, bản lề, vít) từ kho** → lắp vào cánh + khuôn thành bộ hoàn chỉnh → đóng gói | Bản lề inox SUS304 tự sản xuất |

---

## 8 bài học cho module Lên kế hoạch sản xuất

1. **Mỗi công đoạn bắt đầu bằng “nhận lệnh sản xuất”** → app phải in **phiếu lệnh sản xuất** theo tổ; trạng thái bộ chỉ chuyển khi tổ xác nhận đã nhận lệnh.
2. **Có bước “chốt điều kiện vào sản xuất”** (form + bản vẽ đã duyệt + đơn đã xác nhận) → đúng câu **KH5** trong phiếu V118; app nên **chặn/cảnh báo** khi xếp lịch bộ chưa đủ điều kiện.
3. **Mỗi công đoạn có “kiểm tra máy/khuôn” trước khi làm** → app cần trạng thái **dừng máy** + danh mục **lý do dừng**, và trừ năng lực khi máy dừng.
4. **“Ép cốt” là công đoạn thật, có vật tư riêng (keo + cốt)** → xác nhận “Bồi Lares” của GOLDMAX; nếu là bồi cốt thì phải có **thời gian chờ keo khô** trong kế hoạch.
5. **Vân gỗ = dán + sấy theo thời gian quy định** → bước “Vân” cần trường *thời gian sấy/khô*, không xếp lắp kính ngay sau vân.
6. **Lắp phụ kiện là công đoạn chính thức, có “nhận phụ kiện từ kho”** → xác nhận lần nữa: **bảng công đoạn GOLDMAX đang thiếu bước lắp kính + phụ kiện** (V116 mục 5).
7. **Quy trình viết theo “Bước 1..n” cho từng công đoạn** → mình sẽ chuẩn hóa bảng V116 thành dạng: *điều kiện vào → các bước → điểm kiểm tra → điều kiện ra*.
8. **Một nhà máy có nhiều dòng sản phẩm khác công nghệ** (Alux làm cả cửa cuốn chống cháy, cửa gỗ nhựa composite, uốn vòm) → quy trình phải là **dữ liệu theo nhóm sản phẩm (process routing)**, không hard-code một chuỗi công đoạn.

## Khác biệt đừng copy máy móc

- Cửa thép có **dập huỳnh/pano** + **nhúng hóa chất**; cửa nhôm không có — nhưng nhôm có **bồi Lares**, **3 luồng khung/cánh/phào** và **lắp kính**.
- Cốt Honeycomb/MgO của thép tương ứng vai trò “cốt” trong cửa nhôm → nếu GOLDMAX làm cả cửa thép: **chung danh mục công đoạn, khác định tuyến theo nhóm sản phẩm**.
- Thời gian sấy/nhiệt độ là thông số của từng dây chuyền → lưu thành **cấu hình theo tổ**, không đặt trong code.

**Câu còn treo cần nhà máy xác nhận:** “**Bồi Lares**” là **bồi cốt** (lõi/vật liệu chèn) hay **bồi vân** (film/dán vân gỗ)? — xem V118 mục 1.2 (BL1–BL4) và mục 5.


---

## ĐÍNH CHÍNH (V121)

Dòng so sánh “Bồi Lares ≈ ép cốt” ở mục 3 và bài học 4 là **sai** — nhà máy đã xác nhận **“Bồi Lares” là công đoạn HẬU THIẾT KẾ: chuyển file thiết kế sang chương trình cho máy cắt chuyên dụng (CAM)**, không phải vật liệu/cốt. Vai trò “cốt” của cửa thép (Honeycomb/MgO) không có tương ứng trong bảng công đoạn cửa nhôm hiện tại — nếu có thì phải bổ sung riêng. Xem `dp/BOI_LARES_V121.md`.
