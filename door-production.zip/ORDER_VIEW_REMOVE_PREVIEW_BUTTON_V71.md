# ORDER VIEW REMOVE PDF PREVIEW BUTTON V71

## Yêu cầu
Xóa nút **"PDF Mẫu Mới"** trên màn xem đơn hàng.

## Thay đổi
`src/app/orders/[id]/page.tsx`:
- Bỏ `import { OrderPdfPreviewButton } from "@/components/order-pdf-preview-button";`
- Bỏ `<OrderPdfPreviewButton orderId={order.id} />` khỏi cụm nút thao tác (actions) của `ErpShell`.

Thanh nút sau khi sửa: `← Danh sách` · `Xuất Excel` · `Xuất PDF` │ `Sửa đơn` · `Xóa đơn`
(vạch phân cách giữa nhóm xuất file và nhóm thao tác đơn vẫn giữ).

## Không xóa phần khác (đúng phạm vi yêu cầu)
- `src/components/order-pdf-preview-button.tsx` và API `src/app/api/order_pdf_preview/route.ts` **vẫn giữ**:
  không còn xuất hiện trên giao diện, nhưng vẫn có thể gọi trực tiếp URL để test bản preview khi cần.
  (Nếu bạn muốn xóa hẳn cả component + API route thì nói, mình dọn tiếp.)

## Kiểm chứng (chạy app thật)
- `npx tsc --noEmit`: 0 lỗi. `npx eslint "src/app/orders/[id]/page.tsx"`: 3 lỗi `no-explicit-any` + 1 warning `<img>`
  — **đều là lỗi có sẵn từ bản gốc**, không phát sinh lỗi mới.
- Dựng PostgreSQL cục bộ + `next dev` (port 3210, DB `door_production`) rồi mở `/orders/2` bằng camoufox:
  - Trang trả HTTP 200, render bình thường.
  - Danh sách phần tử tương tác ở thanh nút chỉ còn: `← Danh sách`, `Xuất Excel`, `Xuất PDF`, `Sửa đơn`, `Xóa đơn`
    → **không còn nút "PDF Mẫu Mới"**.
  - Ảnh chụp kèm theo: `view_don_no_preview_button.png`.
- Đã tắt dev server và PostgreSQL sau khi kiểm thử.

## File thay đổi
- `src/app/orders/[id]/page.tsx`
