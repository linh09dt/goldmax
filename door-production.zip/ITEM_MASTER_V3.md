# Danh mục hàng hóa ERP V3

## Phạm vi thay đổi

Bản này chỉ bổ sung module Danh mục hàng hóa và liên kết Mã/Tên hàng hóa vào form Đơn hàng ERP V2. Không thay đổi logic lưu đơn hàng, import đơn hàng, tính tiền, câu hỏi xác nhận hoặc hình ảnh.

## Chức năng mới

- Menu **Danh mục hàng hóa** tại `/items`.
- Import Excel `.xlsx` có cột **Tên** và **Mã**.
- Đối chiếu theo **Mã hàng hóa**:
  - NEW: thêm mới.
  - CHANGED: cùng mã nhưng tên thay đổi → cập nhật tên.
  - UNCHANGED: không thay đổi dữ liệu nghiệp vụ.
  - Mã không xuất hiện trong file mới → không tự xóa, không tự ngưng sử dụng.
- Nếu cùng một mã xuất hiện nhiều lần với tên khác nhau trong cùng file, hệ thống không tự chọn dữ liệu; mã đó bị bỏ qua và hiển thị cảnh báo để người dùng xử lý.
- Thêm/sửa hàng hóa thủ công.
- Ngưng sử dụng / kích hoạt lại, không xóa vật lý.
- Tìm kiếm theo mã hoặc tên.
- Xuất danh mục ra Excel.
- Lịch sử các lần import.
- Form Đơn hàng: ô **Mã sản phẩm** và **Tên sản phẩm** có gợi ý từ Danh mục hàng hóa; khi chọn đúng một mã/tên duy nhất, hệ thống điền đồng bộ cả mã và tên.

## Cài đặt

Sau khi chép patch chồng vào source hiện tại:

```cmd
npm run db:generate
npm run db:migrate -- --name item_master_v3
npm run dev
```

Mở:

```text
http://localhost:3000/items
```

Nhập file `Danh mục hàng hóa.xlsx` tại màn hình này.

## Database mới

- `item_masters`: danh mục hàng hóa chuẩn.
- `item_master_imports`: lịch sử import và thống kê NEW / CHANGED / UNCHANGED / lỗi.

Mã hàng hóa là khóa nghiệp vụ duy nhất theo đúng ký tự được nhập. Hệ thống không tự đổi chữ hoa/chữ thường của mã.
