# V103 — Màn Theo dõi doanh thu chỉ tính đơn ĐÃ VÀO SẢN XUẤT

## Yêu cầu

> “chỉ hiện đơn sản xuất thôi”

## Đã làm

Màn `/revenue` (và file Excel xuất ra từ màn đó) nay **loại bỏ đơn chưa vào sản xuất**:

| Loại đơn | Trước (sau V102) | Nay |
|---|---|---|
| `CHUYEN_SAN_XUAT` (Lưu đơn hàng) | hiện | **hiện** |
| `DA_XAC_NHAN` (mã cũ của đơn đã sản xuất) | hiện | **hiện** |
| `NHAP` (Đơn hàng mẫu — Lưu nháp) | hiện | **ẩn** |
| `CHO_XAC_NHAN` (mã cũ) | hiện | **ẩn** |
| `HUY` (đã hủy) | hiện | **ẩn** |
| trống / mã lạ | hiện | **ẩn** |

Áp dụng đồng bộ ở **4 chỗ** để không lệch số liệu:

1. **Bảng doanh thu theo đơn** — chỉ còn đơn đã sản xuất.
2. **5 ô tổng** (Tổng tiền đơn hàng · Chiết khấu · Sau CK · Đặt cọc · Còn lại) — cộng đúng phần đã lọc.
3. **Bảng “Sản phẩm phát sinh doanh thu”** — dựng từ chính các đơn đã lọc nên cũng chỉ còn sản phẩm của đơn đã sản xuất.
4. **File “Xuất Excel”** — chỉ xuất đơn đã sản xuất, khớp với màn hình.

Thêm 2 điểm nhỏ cho rõ ràng:

- **Danh sách chọn “Đại lý” / “Khách hàng”** ở thanh lọc cũng chỉ lấy từ đơn đã sản xuất → không còn đại lý chọn vào mà bảng trống.
- **Ghi chú ngay dưới tiêu đề bảng**: “Chỉ tính đơn đã vào sản xuất — đơn hàng mẫu và đơn đã hủy không tính doanh thu.”; câu báo rỗng cũng đổi thành “Không có đơn đã vào sản xuất phù hợp bộ lọc.”

**Gom hằng số về một nơi:** danh sách mã trạng thái (`SAMPLE_STATUS_CODES`, `PRODUCTION_STATUS_CODES`) từ nay khai báo duy nhất trong `src/lib/order-form.ts` (kèm cả mã cũ), các chỗ khác dùng lại — màn đơn hàng (V100) vẫn chạy y như trước.

## Kiểm chứng (chạy thật)

Dựng Prisma giả **có áp điều kiện lọc** (chỉ trả về đơn khớp `where` — nên nếu code không truyền điều kiện trạng thái thì đơn mẫu sẽ lộ ra ngay), dữ liệu 6 đơn: 2 đơn sản xuất (`CHUYEN_SAN_XUAT` + `DA_XAC_NHAN`), 1 đơn `NHAP`, 1 đơn `CHO_XAC_NHAN`, 1 đơn `HUY`, 1 đơn không trạng thái; trong đó có **1 đại lý chỉ toàn đơn mẫu** và 1 khách chỉ có đơn mẫu.

**a) Màn hình — 13/13 đúng:**

```
OK   có đơn sản xuất 26092202HD04DH24              OK   KHÔNG hiện đơn đã hủy
OK   có đơn cũ DA_XAC_NHAN                         OK   KHÔNG hiện đơn không có trạng thái
OK   KHÔNG hiện đơn hàng mẫu (NHAP)                OK   mọi dòng đều là "Sản xuất" (2 dòng)
OK   KHÔNG hiện đơn mẫu mã cũ (CHO_XAC_NHAN)       OK   danh sách đại lý không có đại lý chỉ toàn đơn mẫu
OK   tổng tiền = 16.736.696 + 5.000.000 = 21.736.696     OK   danh sách khách hàng không có khách chỉ toàn đơn mẫu
OK   tổng sau CK = 19.728.292                      OK   có ghi chú giải thích trên bảng
```

**b) File Excel — 5/5 đúng:** sheet “Doanh thu đơn hàng” chỉ còn **2 dòng** đúng 2 mã đơn sản xuất, cột “Loại đơn hàng” đều là “Sản xuất”, không có mã đơn mẫu/hủy nào.

**c) Khi không còn đơn sản xuất nào — 2/2 đúng:** báo đúng câu mới và **không lộ** đơn hàng mẫu.

**d) Ảnh chụp từ code thật:** `revenue-production-only-v103.png`.

**đ) `npm run build` → PASS**, `npx tsc --noEmit` → 0 lỗi, `npx eslint` → 0 errors (1 warning cũ có từ bản gốc ở `order-form.ts`, không phát sinh mới).

## Lưu ý

- **Không đổi dữ liệu, không cần migration**: đơn hàng mẫu vẫn nằm nguyên trong bảng, chỉ không được tính vào doanh thu. Bấm “Lưu đơn hàng” cho đơn mẫu là đơn tự vào doanh thu.
- Vì chỉ còn đơn đã sản xuất nên **cột “Loại ĐH” giờ luôn là “Sản xuất”**. Muốn **bỏ hẳn cột này** cho rộng bảng thì nói — mình bỏ và chia lại bề rộng các cột.
- Nếu bạn muốn **xem được cả đơn mẫu khi cần** (thay vì ẩn hẳn), mình có thể đổi thành một nút lọc nhỏ trên thanh lọc kiểu `[Chỉ đơn sản xuất ▾]` — mặc định vẫn là chỉ đơn sản xuất.

## File thay đổi

- `src/lib/order-form.ts` — thêm `SAMPLE_STATUS_CODES`, `PRODUCTION_STATUS_CODES` (một nơi khai báo duy nhất).
- `src/lib/order-list-filters.ts` — dùng lại 2 hằng số trên thay vì tự khai báo.
- `src/app/revenue/page.tsx` — lọc chỉ đơn đã sản xuất (bảng + danh sách đại lý/khách hàng) + ghi chú dưới tiêu đề + câu báo rỗng mới.
- `src/app/api/revenue/export/route.ts` — file Excel cũng chỉ xuất đơn đã sản xuất.
