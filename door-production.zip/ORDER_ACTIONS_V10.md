# ERP V10 — Sửa / Xóa đơn hàng

## Phạm vi thay đổi

- Thêm cột **Thao tác** trong `/orders`:
  - **Sửa** → mở `/orders/[id]/edit`
  - **Xóa đơn** → xác nhận trước khi xóa
- Thêm nút **Xóa đơn** trên trang chi tiết `/orders/[id]`.
- Bổ sung `DELETE /api/orders/[id]`.

## Logic xóa

Khi xác nhận xóa:

- Xóa đơn hàng khỏi `sales_orders`.
- PostgreSQL/Prisma cascade xóa:
  - bộ cửa,
  - dòng chi tiết,
  - yêu cầu xác nhận,
  - lịch sử tính cước của đơn.
- Lịch sử import Excel được giữ lại để truy vết (`order_id` được SetNull theo schema hiện tại).
- Sau khi xóa ở trang chi tiết, hệ thống quay về danh sách đơn hàng.
- Sau khi xóa ở danh sách, bảng tự refresh.

## Cài đặt

Giải nén patch chồng lên ERP V9 hiện tại, sau đó chạy:

```cmd
rmdir /s /q .next
npm run dev
```

Không thay đổi schema PostgreSQL nên **không cần migrate**.
