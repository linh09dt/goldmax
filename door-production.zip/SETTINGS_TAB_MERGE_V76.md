# SETTINGS TAB MERGE V76

## Yêu cầu

Gộp 3 tab **Danh mục hàng hóa**, **Danh mục cấu hình**, **Cấu hình tính toán** vào **một tab duy nhất tên là CẤU HÌNH**,
sắp xếp lại theo hướng ERP cho dễ dùng: bố cục, font chữ, thứ tự khu vực và cách chuyển khu vực.

## Kiến trúc thông tin mới

Menu chính còn **một mục “Cấu hình”** (`/settings`). Bên trong chia 2 nhóm theo đúng thứ tự nghiệp vụ — **khai báo dữ liệu nền trước, gán quy tắc tính sau**:

| Nhóm | Mã | Khu vực | Nội dung |
| --- | --- | --- | --- |
| **Dữ liệu nền** | **A1** | Danh mục hàng hóa | TENHANG, MODEL, tên diễn giải, ĐVT, giá đại lý, giá bán lẻ (Master Data) |
| | **A2** | Danh mục cấu hình | Màu sơn, Hướng mở, Hướng phào, Ô thoáng/Pano/Nan chớp, Mã Đại Lý |
| **Quy tắc tính toán** | **B1** | Cấu hình tính toán | KH/Lượng, phụ thu Khuôn, đơn giá cửa, số bắt đầu Bộ số |

Mỗi khu vực có **mã A1 / A2 / B1** hiển thị ở menu phụ, ở tiêu đề khu vực và ở breadcrumb (`Cấu hình / A1`) để người dùng đối chiếu với Hướng dẫn sử dụng.

## Bố cục & font chữ

- **Menu chính (sidebar)** chia nhóm rõ ràng: *Điều hành* (Tổng quan, Quản lý đơn hàng, Theo dõi doanh thu) · *Danh mục & cấu hình* (Cấu hình) · *Công cụ* (Tính cước vận chuyển, Hướng dẫn sử dụng). Mục đang mở được tô nền + có icon riêng, không còn 8 dòng menu phẳng.
- **Menu phụ trong tab Cấu hình**: cột trái dính theo màn hình (sticky) ở màn lớn, hiển thị mã khu vực + mô tả + số liệu vừa tải; màn nhỏ tự chuyển thành dải nút cuộn ngang.
- **Đổi khu vực không tải lại dữ liệu**: khu vực đã mở được giữ nguyên trạng thái khi chuyển qua lại; URL cập nhật `?tab=items|options|pricing` nên F5 hoặc gửi link vẫn mở đúng khu vực.
- **Font chữ**: dùng font hệ thống rõ nét cho tiếng Việt (`Segoe UI` → Inter → system-ui → Arial), cỡ nền 14px, `antialiased`; toàn bộ bảng dữ liệu dùng **số dạng bảng (tabular-nums)** và số căn phải để dễ so sánh giá.
- **Bảng dữ liệu** dùng chung một chuẩn: header đậm chữ trắng, dòng kẻ mảnh, hover xanh nhạt, cuộn ngang trong khung (`erp-table`).
- **Thẻ và tiêu đề** dùng chung: tiêu đề trang → tiêu đề nhóm → tiêu đề thẻ → nhãn ô nhập (11px chữ hoa) → ghi chú xám 12px. Nhãn ô nhập nằm trên ô (trước đây nhiều màn chỉ có placeholder, dễ mất ngữ cảnh khi đã nhập).
- **Khối trạng thái** chuẩn hoá: thông báo thành công/lỗi, cảnh báo, hướng dẫn đều dùng một kiểu `SettingsNote` (info/success/warning/danger).

## Thay đổi theo từng khu vực

- **A1 Danh mục hàng hóa**: tiêu đề + mô tả + 2 nút hành động (Tạo lại Master Data từ Excel, Xuất Master Data) đưa lên đầu khu vực; thêm dải số liệu ngay trên bảng (tổng MODEL, đang sử dụng, số nhóm TENHANG); form “Thêm hàng hóa thủ công” có nhãn từng ô; bảng nhóm TENHANG giữ nguyên tính năng mở/thu gọn; lịch sử tạo Master Data tách xuống cuối.
- **A2 Danh mục cấu hình**: 5 thẻ nhóm lớn được thay bằng dải chọn nhóm gọn (kèm số đang dùng); form thêm giá trị và bảng sửa trực tiếp giữ nguyên chức năng, thêm nhãn cột rõ ràng.
- **B1 Cấu hình tính toán**: các nút (Tạo lại cấu hình gợi ý, + Thêm rule, Lưu cấu hình) đưa lên tiêu đề khu vực; hiện trạng “Cấu hình đã lưu / đang dùng gợi ý” ngay cạnh nút Lưu; gom **Làm tròn KH/Lượng** + **Số bắt đầu áp dụng Bộ số** + giải thích **Cơ chế Bộ số** (V75) vào một thẻ “Thông số chung”; khối phụ thu Khuôn in mốc đang áp dụng theo đúng số đã cấu hình; bảng rule giữ nguyên toàn bộ chức năng.

## Tương thích

- `/items` → `/settings?tab=items`, `/master-options` → `/settings?tab=options`, `/calculation-config` → `/settings?tab=pricing` (redirect 307). Bookmark và link cũ vẫn dùng được.
- Trang **Hướng dẫn sử dụng**: mục 5 gộp thành “5. Cấu hình” với 3 tiểu mục A1/A2/B1, bước 1 của quy trình trỏ về tab Cấu hình, mục vận chuyển đánh số lại thành 6.
- **Không thay đổi**: logic nghiệp vụ, API, Prisma schema, `.env`, công thức tính, in PDF/Excel, màn Tạo/Sửa đơn.

## Kiểm chứng

- `npx tsc --noEmit`: 0 lỗi.
- `npx eslint` trên 12 file thay đổi/mới: **4 errors — đúng bằng bản gốc** (1 `no-html-link-for-pages` và 3 `react-hooks/set-state-in-effect` có sẵn ở 3 component cũ), không phát sinh lỗi mới.
- `next dev` + chụp ảnh bằng trình duyệt tại `/settings`, `/settings?tab=options`, `/settings?tab=pricing`: bố cục, menu phụ, bảng và số liệu hiển thị đúng; menu “Cấu hình” sáng đúng trạng thái.
- Kiểm tra redirect: `/items`, `/master-options`, `/calculation-config` đều trả 307 về đúng khu vực; `/`, `/orders`, `/guide` trả 200.

## File thay đổi

Mới:
- `src/app/settings/page.tsx`
- `src/components/settings/settings-workspace.tsx`
- `src/components/settings/settings-tabs.ts`
- `src/components/settings/settings-ui.tsx`
- `src/components/erp-nav.tsx`

Sửa:
- `src/components/erp-shell.tsx` (menu nhóm + trạng thái đang mở, phụ đề trang)
- `src/components/item-master.tsx`, `src/components/master-options.tsx`, `src/components/calculation-config.tsx` (bố cục + font + bảng chuẩn)
- `src/app/globals.css` (font hệ thống, bộ class ERP dùng chung)
- `src/app/items/page.tsx`, `src/app/master-options/page.tsx`, `src/app/calculation-config/page.tsx` (redirect)
- `src/app/guide/page.tsx` (gộp mục hướng dẫn)
