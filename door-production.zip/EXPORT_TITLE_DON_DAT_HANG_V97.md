# V97 — Tiêu đề file xuất: “THÔNG TIN ĐƠN HÀNG” → “ĐƠN ĐẶT HÀNG”

## Yêu cầu

> “xuất file, sửa THÔNG TIN ĐƠN HÀNG thành ĐƠN ĐẶT HÀNG”

## Đã sửa

### Tiêu đề trên tài liệu (4 đường xuất + trang in)

| Nơi | Trước | Sau |
|---|---|---|
| PDF V2 (`python/reportlab_order_v2.py`) | `TITLE = "THÔNG TIN ĐƠN HÀNG"` | `TITLE = "ĐƠN ĐẶT HÀNG"` |
| PDF mẫu / preview (`python/reportlab_order_preview.py`) | `"THÔNG TIN ĐƠN HÀNG"` | `"ĐƠN ĐẶT HÀNG"` |
| Excel V1 (`src/lib/order-export.ts`) | ô `C2 = "THÔNG TIN ĐƠN HÀNG"` | ô `C2 = "ĐƠN ĐẶT HÀNG"` |
| Excel V2 (`src/lib/order-export-v2.ts`) | ô `M1 = "THÔNG TIN ĐƠN HÀNG"` | ô `M1 = "ĐƠN ĐẶT HÀNG"` |
| Trang in / Lưu PDF (`src/app/orders/[id]/print/page.tsx`) | `<h2>THÔNG TIN ĐƠN HÀNG</h2>` | `<h2>ĐƠN ĐẶT HÀNG</h2>` |

### Các chỗ cùng câu đó trong file xuất (đổi luôn cho khớp)

| Nơi | Sau |
|---|---|
| Chân trang PDF V2 | “CÔNG TY … GOLDMAX VIỆT NAM - **Đơn đặt hàng** #mã-đơn” |
| Tiêu đề tài liệu (metadata) PDF V2 | `ĐƠN ĐẶT HÀNG - {mã đơn}` · subject “Đơn đặt hàng GOLDMAX V2” |
| Chân trang Excel V2 | “… - **Đơn đặt hàng** #mã-đơn · Trang x / y” |
| Tên sheet Excel V1 / V2 | **Đơn đặt hàng** / **Đơn đặt hàng V2** |
| Tên file PDF dự phòng (khi máy chủ không trả tên file) | `Don-dat-hang-V2-{id}.pdf` |

## Kiểm chứng (tạo file thật rồi đọc lại nội dung)

| File xuất | Kiểm tra | Kết quả |
|---|---|---|
| PDF V2 | hằng `TITLE`, metadata `/Title`, `/Subject` | `ĐƠN ĐẶT HÀNG`, `ĐƠN ĐẶT HÀNG - 26092201LD01DH04`, `Đơn đặt hàng GOLDMAX V2` |
| PDF V2 | trích text trang 1 | có **ĐƠN ĐẶT HÀNG**, **không còn** “THÔNG TIN ĐƠN HÀNG” |
| PDF preview | trích text trang 1 | có **ĐƠN ĐẶT HÀNG**, không còn chuỗi cũ |
| Excel V1 | ô C2 + tên sheet | `ĐƠN ĐẶT HÀNG` · sheet `Đơn đặt hàng` |
| Excel V2 | ô M1 + chân trang + tên sheet | `ĐƠN ĐẶT HÀNG` · “… - Đơn đặt hàng #26092201LD01DH04” · sheet `Đơn đặt hàng V2` |

- `python3 -m py_compile` 2 file Python → OK. `npx tsc --noEmit` → 0 lỗi.
- `npx eslint` 4 file TS sửa → **17 errors / 2 warnings, đúng bằng bản gốc** (đã đối chiếu lại bản trước khi sửa: y hệt, toàn bộ là `no-explicit-any` có sẵn), không phát sinh lỗi mới.

## Lưu ý

- **Giao diện trong app chưa đổi**: màn Tạo đơn và trang Chi tiết đơn vẫn có tiêu đề khối “Thông tin đơn hàng” (chữ thường, không phải tiêu đề file xuất). Yêu cầu lần này là cho **file xuất**, nên mình chỉ sửa ở đó. Muốn đổi luôn trong app thì nói mình.
- **Tên file tải về** vẫn là `Bao-gia-V2-{mã}.pdf` / `bao-gia-v2-{id}.xlsx` — tên này đang là “Báo giá”, không phải “Thông tin đơn hàng”, nên mình giữ nguyên. Nếu bạn muốn đổi thành “Don-dat-hang-V2-…” thì chỉ cần một câu.
- Các file `.md` tài liệu cũ trong dự án (`ORDER_EXPORT_*.md`, `PDF_V2_*.md`…) vẫn nhắc tiêu đề cũ — đó là ghi chép lịch sử từng lần sửa, mình không sửa lại.

## File thay đổi

- `python/reportlab_order_v2.py` — hằng `TITLE`, chân trang, metadata tài liệu.
- `python/reportlab_order_preview.py` — tiêu đề PDF mẫu.
- `src/lib/order-export.ts` — tiêu đề ô C2 + tên sheet.
- `src/lib/order-export-v2.ts` — tiêu đề ô M1 + chân trang + tên sheet.
- `src/app/orders/[id]/print/page.tsx` — tiêu đề trang in.
- `src/components/order-export-buttons.tsx` — tên file PDF dự phòng.
