# V41.40 – Bộ cửa 22 trường theo lưới 11 cột x 2 dòng

## Thay đổi
Chỉ chỉnh giao diện nhập **Bộ cửa** trong `src/components/order-form.tsx`.

### Desktop 11 cột x 2 dòng
**Dòng 1, trái → phải**
1. Bộ số
2. Nhóm cửa
3. Model
4. Tên sản phẩm
5. Ô thoáng
6. Hướng mở
7. Phào
8. Màu sơn
9. Cao
10. Rộng
11. Khuôn

**Dòng 2, trái → phải**
1. KT thông thủy - Cao
2. KT thông thủy - Rộng
3. SL bộ
4. ĐVT
5. KH/Lượng
6. Đơn giá
7. Model khóa
8. Loại phào
9. Thanh phào / bộ
10. Nan ô thoáng
11. Cánh / bộ

### Ghi chú / Hình ảnh
- `Ghi chú` và `Hình ảnh SP` giữ riêng phía dưới 2 dòng chính để không làm vỡ lưới 11 cột.
- Ảnh vẫn giữ logic upload/paste hiện tại.

### Responsive
- Desktop XL: 11 cột.
- Tablet: 4 cột.
- Mobile: 2 cột.
- Không horizontal scroll.

## Không thay đổi
- DB/API
- Logic giá
- Catalog
- Phụ kiện / chi tiết
- PDF / Excel
