--
-- PostgreSQL database dump
--

\restrict t1v96gDlqMEaS4OWnIeqwqQRPzUatWTmnhqmRjbdd7r6G3kbyIJMOqcV3BRPZNh

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone',
    'recovery_code'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_realtime_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_realtime_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_realtime_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_realtime_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_realtime_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
    revoke trigger on cron.job_run_details from postgres;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
begin
    if not exists (
        select 1
        from pg_catalog.pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8.0', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
            set search_path to ''
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) OWNER TO supabase_admin;

--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_realtime_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_realtime_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_realtime_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_realtime_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_realtime_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) OWNER TO supabase_realtime_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_realtime_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_realtime_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_realtime_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_realtime_admin;

--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) OWNER TO supabase_realtime_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    -- Normalize selected_columns order so ARRAY['a','b'] and ARRAY['b','a'] are treated
    -- as the same subscription group in apply_rls. Preserve an empty array as '{}'
    -- ("primary keys only") so it stays distinct from NULL ("all columns"); array_agg
    -- over an empty set would otherwise collapse '{}' back to NULL.
    if new.selected_columns is not null then
        new.selected_columns = coalesce(
            (
                select array_agg(c order by c)
                from unnest(new.selected_columns) c
            ),
            '{}'::text[]
        );
    end if;

    return new;
end;
$$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_realtime_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_realtime_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION realtime.wal2json_escape_identifier(name text) OWNER TO supabase_realtime_admin;

--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION storage.allow_any_operation(expected_operations text[]) OWNER TO supabase_storage_admin;

--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION storage.allow_only_operation(expected_operation text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_lifecycle_service_role(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_lifecycle_service_role() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog'
    AS $$
BEGIN
  IF current_user::text IS DISTINCT FROM TG_ARGV[0]
     AND (
       OLD.lifecycle_configuration IS DISTINCT FROM NEW.lifecycle_configuration
       OR OLD.lifecycle_configuration_generation IS DISTINCT FROM NEW.lifecycle_configuration_generation
     ) THEN
    -- AFTER runs only after caller RLS has accepted the proposed row. The API
    -- recognizes this specific error after rolling back its permission probe;
    -- direct non-service writes still fail and cannot persist the change.
    RAISE EXCEPTION 'bucket control columns may only be changed by the configured storage service role'
      USING ERRCODE = 'PST01',
            SCHEMA = TG_TABLE_SCHEMA,
            TABLE = TG_TABLE_NAME,
            CONSTRAINT = TG_NAME;
  END IF;

  RETURN NULL;
END;
$$;


ALTER FUNCTION storage.enforce_bucket_lifecycle_service_role() OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN p_delimiter <> ''
         AND position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(
        p_key,
        length(p_prefix)
            + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1))
            + length(p_delimiter) - 1
    )
    ELSE NULL
END;
$$;


ALTER FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket(noncurrent_versions text DEFAULT 'include'::text, delete_markers text DEFAULT 'include'::text) RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    -- COALESCE first: NULL NOT IN (...) evaluates to NULL (not TRUE), so a
    -- bare NOT IN check silently leaves an explicit NULL argument unreset.
    noncurrent_versions := COALESCE(noncurrent_versions, 'include');
    delete_markers := COALESCE(delete_markers, 'include');
    IF noncurrent_versions NOT IN ('exclude', 'only', 'include') THEN
        noncurrent_versions := 'include';
    END IF;
    IF delete_markers NOT IN ('exclude', 'only', 'include') THEN
        delete_markers := 'include';
    END IF;

    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        where (noncurrent_versions != 'exclude' OR obj.archived_at IS NULL)
          and (noncurrent_versions != 'only' OR obj.archived_at IS NOT NULL)
          and (delete_markers != 'exclude' OR NOT obj.is_delete_marker)
          and (delete_markers != 'only' OR obj.is_delete_marker)
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket(noncurrent_versions text, delete_markers text) OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text, raw_prefix_param text DEFAULT NULL::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE sql STABLE
    AS $_$
WITH candidates AS (
    SELECT
        upload.key AS object_key,
        CASE
            WHEN position($3 IN substring(upload.key FROM length(coalesce($7, $2)) + 1)) > 0
            THEN left(
                upload.key,
                length(coalesce($7, $2))
                    + position($3 IN substring(upload.key FROM length(coalesce($7, $2)) + 1))
                    + length($3) - 1
            )
            ELSE upload.key
        END AS result_key,
        upload.id,
        upload.created_at,
        position($3 IN substring(upload.key FROM length(coalesce($7, $2)) + 1)) > 0 AS is_common_prefix
    FROM storage.s3_multipart_uploads AS upload
    WHERE upload.bucket_id = $1
      AND upload.key COLLATE "C" LIKE $2 || '%'
), filtered AS (
    SELECT candidate.*
    FROM candidates AS candidate
    WHERE $5 = ''
       OR candidate.result_key COLLATE "C" > $5
       OR (
           candidate.result_key COLLATE "C" = $5
           AND NOT candidate.is_common_prefix
           AND $6 <> ''
           -- A completed or aborted marker repeats the remaining same-key uploads.
           AND COALESCE(
               (candidate.created_at, candidate.id COLLATE "C") > (
                   SELECT marker.created_at, marker.id COLLATE "C"
                   FROM storage.s3_multipart_uploads AS marker
                   WHERE marker.bucket_id = $1
                     AND marker.key COLLATE "C" = $5
                     AND marker.id = $6
               ),
               TRUE
           )
       )
), ranked AS (
    SELECT
        filtered.*,
        row_number() OVER (
            PARTITION BY filtered.result_key COLLATE "C"
            ORDER BY filtered.created_at, filtered.id COLLATE "C"
        ) AS prefix_rank
    FROM filtered
)
SELECT ranked.result_key, ranked.id, ranked.created_at
FROM ranked
WHERE NOT ranked.is_common_prefix OR ranked.prefix_rank = 1
ORDER BY ranked.result_key COLLATE "C", ranked.created_at, ranked.id COLLATE "C"
LIMIT $4;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text, raw_prefix_param text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text, text, text, timestamp with time zone, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, noncurrent_versions text DEFAULT 'exclude'::text, delete_markers text DEFAULT 'exclude'::text, next_token_archived_at timestamp with time zone DEFAULT NULL::timestamp with time zone, next_token_version text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, version text, archived_at timestamp with time zone, is_delete_marker boolean, is_versioned boolean)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_start_relative TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;
    v_version_filter TEXT;

    -- true when noncurrent_versions can return >1 row per name; keeps them
    -- ordered most-recent-first and lets pagination resume mid-key
    v_multi_row BOOLEAN;
    v_name_order TEXT;
    v_exact_range_predicate TEXT;
    v_strict_range_predicate TEXT;
    v_inclusive_range_predicate TEXT;

    -- Seek state for the current name. archived_at is normalized to JavaScript's
    -- millisecond precision and version breaks ties within the same millisecond.
    -- Current rows use 'infinity'; NULL means no tiebreak has been established.
    v_next_seek TEXT;
    v_next_seek_at TIMESTAMPTZ;
    v_next_seek_version TEXT;
    v_next_seek_strict BOOLEAN := false;
    v_cursor_is_folder BOOLEAN;
    v_count INT := 0;
    v_previous_seek TEXT;
    v_previous_seek_at TIMESTAMPTZ;
    v_previous_seek_version TEXT;
    v_previous_count INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;
    v_batch_query_strict TEXT;
    v_delete_marker_peek_query TEXT;
    v_delete_marker_peek_query_strict TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);
    v_next_seek_at := NULL;
    v_next_seek_version := '';

    -- COALESCE first: NULL NOT IN (...) evaluates to NULL (not TRUE), so a
    -- bare NOT IN check silently leaves an explicit NULL argument unreset.
    noncurrent_versions := COALESCE(noncurrent_versions, 'exclude');
    delete_markers := COALESCE(delete_markers, 'exclude');
    IF noncurrent_versions NOT IN ('exclude', 'only', 'include') THEN
        noncurrent_versions := 'exclude';
    END IF;
    IF delete_markers NOT IN ('exclude', 'only', 'include') THEN
        delete_markers := 'exclude';
    END IF;

    v_multi_row := noncurrent_versions IN ('only', 'include');
    v_name_order := CASE WHEN v_is_asc THEN 'ASC' ELSE 'DESC' END;

    v_version_filter := '';
    IF noncurrent_versions = 'exclude' THEN
        v_version_filter := v_version_filter || ' AND o.archived_at IS NULL';
    ELSIF noncurrent_versions = 'only' THEN
        v_version_filter := v_version_filter || ' AND o.archived_at IS NOT NULL';
    END IF;
    IF delete_markers = 'exclude' THEN
        v_version_filter := v_version_filter || ' AND NOT o.is_delete_marker';
    ELSIF delete_markers = 'only' THEN
        v_version_filter := v_version_filter || ' AND o.is_delete_marker';
    END IF;

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Keep caller-provided cursors inside the requested prefix range.
    IF v_start <> '' AND v_upper_bound IS NOT NULL THEN
        IF v_is_asc THEN
            IF v_start COLLATE "C" < v_prefix COLLATE "C" THEN
                v_start := '';
            ELSIF v_start COLLATE "C" >= v_upper_bound COLLATE "C" THEN
                RETURN;
            END IF;
        ELSE
            IF v_start COLLATE "C" < v_prefix COLLATE "C" THEN
                RETURN;
            ELSIF v_start COLLATE "C" >= v_upper_bound COLLATE "C" THEN
                v_start := '';
            END IF;
        END IF;
    END IF;

    v_start_relative := substring(v_start FROM length(v_prefix) + 1);

    -- Direction affects only the indexed name range and its ordering. Cursor
    -- state transitions and within-key version ordering stay shared.
    IF v_is_asc THEN
        v_exact_range_predicate := 'TRUE';
        v_strict_range_predicate := 'o.name COLLATE "C" > $2';
        v_inclusive_range_predicate := 'o.name COLLATE "C" >= $2';
        IF v_upper_bound IS NOT NULL THEN
            v_exact_range_predicate := 'o.name COLLATE "C" < $3';
            v_strict_range_predicate := v_strict_range_predicate || ' AND o.name COLLATE "C" < $3';
            v_inclusive_range_predicate := v_inclusive_range_predicate || ' AND o.name COLLATE "C" < $3';
        END IF;
    ELSE
        v_exact_range_predicate := 'TRUE';
        v_strict_range_predicate := 'o.name COLLATE "C" < $2';
        v_inclusive_range_predicate := 'o.name COLLATE "C" < $2';
        IF v_prefix <> '' THEN
            v_exact_range_predicate := 'o.name COLLATE "C" >= $3';
            v_strict_range_predicate := v_strict_range_predicate || ' AND o.name COLLATE "C" >= $3';
            v_inclusive_range_predicate := v_inclusive_range_predicate || ' AND o.name COLLATE "C" >= $3';
        END IF;
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    -- The multi-row order matches the externally serialized cursor exactly:
    -- archived_at at millisecond precision, then version as the final tiebreak.
    --
    -- When v_multi_row, the seek is a keyset tuple comparison ("name > $2 OR
    -- (name = $2 AND tiebreak)") - Postgres won't split that OR into indexable
    -- form (confirmed even with fully literal values), so as one WHERE clause
    -- it forces a full bucket scan filtered row-by-row. Splitting it into two
    -- independently-indexable branches (exact name match with the tiebreak
    -- filter, vs. strictly-past names) combined with UNION ALL lets each
    -- branch keep name as a real index condition; the outer ORDER BY/LIMIT
    -- re-merges them into the same page the single query used to produce.
    IF v_multi_row THEN
        v_batch_query := format(
            $sql$
            SELECT *
            FROM (
                (
                    SELECT o.name, o.id, o.updated_at, o.created_at,
                           o.last_accessed_at, o.metadata, o.version,
                           o.archived_at, o.is_delete_marker, o.is_versioned
                    FROM storage.objects o
                    WHERE o.bucket_id = $1
                      AND o.name COLLATE "C" = $2
                      AND %s
                      AND NOT $7::boolean
                      AND (
                          $5::timestamptz IS NULL
                          OR COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) < $5
                          OR (
                              COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) = $5
                              AND COALESCE(o.version, '') > $6
                          )
                      )
                      %s
                    ORDER BY
                        COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) DESC,
                        COALESCE(o.version, '') ASC
                    LIMIT $4
                )
                UNION ALL
                (
                    SELECT o.name, o.id, o.updated_at, o.created_at,
                           o.last_accessed_at, o.metadata, o.version,
                           o.archived_at, o.is_delete_marker, o.is_versioned
                    FROM storage.objects o
                    WHERE o.bucket_id = $1
                      AND %s
                      %s
                    ORDER BY
                        o.name COLLATE "C" %s,
                        COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) DESC,
                        COALESCE(o.version, '') ASC
                    LIMIT $4
                )
            ) sub
            ORDER BY
                sub.name COLLATE "C" %s,
                COALESCE(date_trunc('milliseconds', sub.archived_at), 'infinity'::timestamptz) DESC,
                COALESCE(sub.version, '') ASC
            LIMIT $4
            $sql$,
            v_exact_range_predicate,
            v_version_filter,
            v_strict_range_predicate,
            v_version_filter,
            v_name_order,
            v_name_order
        );
    ELSE
        v_batch_query := format(
            $sql$
            SELECT o.name, o.id, o.updated_at, o.created_at,
                   o.last_accessed_at, o.metadata, o.version,
                   o.archived_at, o.is_delete_marker, o.is_versioned
            FROM storage.objects o
            WHERE o.bucket_id = $1
              AND %s
              %s
            ORDER BY o.name COLLATE "C" %s, o.archived_at DESC
            LIMIT $4
            $sql$,
            v_inclusive_range_predicate,
            v_version_filter,
            v_name_order
        );

        -- Strict counterpart of the query above: used once the single-row
        -- ASC batch advance (below) has left v_next_seek pointing at the
        -- last row already emitted, so an inclusive predicate would
        -- re-match it forever. Only single-row mode ever sets strict mode,
        -- so this variant is never needed when v_multi_row.
        v_batch_query_strict := format(
            $sql$
            SELECT o.name, o.id, o.updated_at, o.created_at,
                   o.last_accessed_at, o.metadata, o.version,
                   o.archived_at, o.is_delete_marker, o.is_versioned
            FROM storage.objects o
            WHERE o.bucket_id = $1
              AND %s
              %s
            ORDER BY o.name COLLATE "C" %s, o.archived_at DESC
            LIMIT $4
            $sql$,
            v_strict_range_predicate,
            v_version_filter,
            v_name_order
        );
    END IF;

    -- The static peek predicates cannot use the partial delete-marker index
    -- once PL/pgSQL switches to a generic plan because whether
    -- is_delete_marker is required remains parameter-dependent. Reuse the
    -- already-specialized batch query with a one-row limit for this sparse
    -- filter so the plan sees a literal `o.is_delete_marker` predicate.
    IF delete_markers = 'only' THEN
        v_delete_marker_peek_query :=
            'SELECT marker_page.name FROM (' || v_batch_query || ') marker_page LIMIT 1';
        IF NOT v_multi_row THEN
            v_delete_marker_peek_query_strict :=
                'SELECT marker_page.name FROM (' || v_batch_query_strict || ') marker_page LIMIT 1';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor performs one specialized initial seek so
            -- partial current-version and delete-marker indexes remain available.
            EXECUTE format(
                'SELECT o.name FROM storage.objects o WHERE o.bucket_id = $1%s%s ORDER BY o.name COLLATE "C" DESC LIMIT 1',
                CASE WHEN v_upper_bound IS NOT NULL
                    THEN ' AND o.name COLLATE "C" >= $2 AND o.name COLLATE "C" < $3'
                    ELSE ''
                END,
                v_version_filter
            )
            INTO v_next_seek
            USING _bucket_id, v_prefix, v_upper_bound;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Folder continuation tokens retain their trailing delimiter. A
        -- delimiter-less startAfter is always a literal key boundary.
        v_cursor_is_folder := delimiter_param <> ''
            AND v_start_relative <> ''
            AND right(v_start_relative, length(delimiter_param)) = delimiter_param;

        IF v_cursor_is_folder THEN
            v_next_seek := CASE
                WHEN right(v_start, length(delimiter_param)) = delimiter_param
                    THEN v_start
                ELSE v_start || delimiter_param
            END;
            IF v_is_asc THEN
                v_next_seek := left(v_next_seek, -1)
                    || chr(ascii(right(v_next_seek, 1)) + 1);
            END IF;
            v_next_seek_strict := NOT v_is_asc;
        ELSE
            -- leaf object: when v_multi_row, stay on v_start with the
            -- caller-supplied tiebreak so a page boundary mid-key resumes
            -- that key's remaining rows instead of skipping them. Truncate
            -- to milliseconds like every other v_next_seek_at assignment -
            -- harmless today since object.ts's cursor always round-trips
            -- through JS Date first, but this shouldn't rely on that.
            IF v_multi_row THEN
                v_next_seek := v_start;
                v_next_seek_at := date_trunc('milliseconds', next_token_archived_at);
                v_next_seek_version := coalesce(next_token_version, '');
                v_next_seek_strict := coalesce(next_token, '') = '';
            ELSIF v_is_asc THEN
                v_next_seek := v_start;
                v_next_seek_strict := true;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        v_previous_seek := v_next_seek;
        v_previous_seek_at := v_next_seek_at;
        v_previous_seek_version := v_next_seek_version;
        v_previous_count := v_count;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        -- v_multi_row is branched here (rather than folded into the WHERE
        -- clause as a bound parameter) so each concrete query keeps an
        -- unconditional seek predicate - once PL/pgSQL switches to its
        -- cached generic plan (after 5 calls), a parameter-gated
        -- "(NOT v_multi_row AND name >= $x) OR (v_multi_row AND ...)"
        -- predicate stops the planner from using name as an index
        -- condition at all, degrading every subsequent peek to a full
        -- index scan filtered row-by-row instead of a bounded range scan.
        -- v_multi_row's seek predicate is a keyset tuple comparison
        -- ("name > x OR (name = x AND tiebreak)") - Postgres does not
        -- split this OR into indexable form even with fully literal
        -- values, so it falls back to a full scan filtered row-by-row.
        -- Splitting it into two independently-indexable branches (exact
        -- name match with the tiebreak filter, vs. strictly-past name)
        -- combined with UNION ALL lets each branch keep name as a real
        -- index condition; the outer ORDER BY/LIMIT picks whichever of
        -- the (at most 2) rows sorts first.
        IF delete_markers = 'only' THEN
            EXECUTE CASE WHEN v_next_seek_strict AND NOT v_multi_row
                THEN v_delete_marker_peek_query_strict
                ELSE v_delete_marker_peek_query
            END
                INTO v_peek_name
                USING _bucket_id, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END,
                    1, v_next_seek_at, v_next_seek_version, v_next_seek_strict;
        ELSIF v_multi_row THEN
            IF v_is_asc THEN
                IF v_upper_bound IS NOT NULL THEN
                    SELECT sub.name INTO v_peek_name FROM (
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" = v_next_seek
                           AND o.name COLLATE "C" < v_upper_bound
                           AND NOT v_next_seek_strict
                           AND (v_next_seek_at IS NULL
                                OR COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) < v_next_seek_at
                                OR (COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) = v_next_seek_at
                                    AND COALESCE(o.version, '') > v_next_seek_version))
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) DESC, COALESCE(o.version, '') ASC LIMIT 1)
                        UNION ALL
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" > v_next_seek AND o.name COLLATE "C" < v_upper_bound
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY o.name COLLATE "C" ASC LIMIT 1)
                    ) sub ORDER BY sub.name COLLATE "C" ASC LIMIT 1;
                ELSE
                    SELECT sub.name INTO v_peek_name FROM (
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" = v_next_seek
                           AND NOT v_next_seek_strict
                           AND (v_next_seek_at IS NULL
                                OR COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) < v_next_seek_at
                                OR (COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) = v_next_seek_at
                                    AND COALESCE(o.version, '') > v_next_seek_version))
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) DESC, COALESCE(o.version, '') ASC LIMIT 1)
                        UNION ALL
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" > v_next_seek
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY o.name COLLATE "C" ASC LIMIT 1)
                    ) sub ORDER BY sub.name COLLATE "C" ASC LIMIT 1;
                END IF;
            ELSE
                IF v_upper_bound IS NOT NULL THEN
                    SELECT sub.name INTO v_peek_name FROM (
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" = v_next_seek
                           AND o.name COLLATE "C" >= v_prefix
                           AND NOT v_next_seek_strict
                           AND (v_next_seek_at IS NULL
                                OR COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) < v_next_seek_at
                                OR (COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) = v_next_seek_at
                                    AND COALESCE(o.version, '') > v_next_seek_version))
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) DESC, COALESCE(o.version, '') ASC LIMIT 1)
                        UNION ALL
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY o.name COLLATE "C" DESC LIMIT 1)
                    ) sub ORDER BY sub.name COLLATE "C" DESC LIMIT 1;
                ELSE
                    SELECT sub.name INTO v_peek_name FROM (
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" = v_next_seek
                           AND NOT v_next_seek_strict
                           AND (v_next_seek_at IS NULL
                                OR COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) < v_next_seek_at
                                OR (COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) = v_next_seek_at
                                    AND COALESCE(o.version, '') > v_next_seek_version))
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY COALESCE(date_trunc('milliseconds', o.archived_at), 'infinity'::timestamptz) DESC, COALESCE(o.version, '') ASC LIMIT 1)
                        UNION ALL
                        (SELECT o.name FROM storage.objects o
                         WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                           AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                           AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                           AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                           AND (delete_markers != 'only' OR o.is_delete_marker)
                         ORDER BY o.name COLLATE "C" DESC LIMIT 1)
                    ) sub ORDER BY sub.name COLLATE "C" DESC LIMIT 1;
                END IF;
            END IF;
        ELSE
            -- Single-row mode is always noncurrent_versions='exclude'. Keep
            -- this predicate literal so generic plans use the current index.
            IF v_is_asc THEN
                IF v_next_seek_strict AND v_upper_bound IS NOT NULL THEN
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = _bucket_id
                      AND o.name COLLATE "C" > v_next_seek
                      AND o.name COLLATE "C" < v_upper_bound
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                      AND (delete_markers != 'only' OR o.is_delete_marker)
                    ORDER BY o.name COLLATE "C" ASC LIMIT 1;
                ELSIF v_next_seek_strict THEN
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = _bucket_id
                      AND o.name COLLATE "C" > v_next_seek
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                      AND (delete_markers != 'only' OR o.is_delete_marker)
                    ORDER BY o.name COLLATE "C" ASC LIMIT 1;
                ELSIF v_upper_bound IS NOT NULL THEN
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = _bucket_id
                      AND o.name COLLATE "C" >= v_next_seek
                      AND o.name COLLATE "C" < v_upper_bound
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                      AND (delete_markers != 'only' OR o.is_delete_marker)
                    ORDER BY o.name COLLATE "C" ASC LIMIT 1;
                ELSE
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = _bucket_id
                      AND o.name COLLATE "C" >= v_next_seek
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                      AND (delete_markers != 'only' OR o.is_delete_marker)
                    ORDER BY o.name COLLATE "C" ASC LIMIT 1;
                END IF;
            ELSE
                IF v_upper_bound IS NOT NULL THEN
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = _bucket_id
                      AND o.name COLLATE "C" < v_next_seek
                      AND o.name COLLATE "C" >= v_prefix
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                      AND (delete_markers != 'only' OR o.is_delete_marker)
                    ORDER BY o.name COLLATE "C" DESC LIMIT 1;
                ELSE
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = _bucket_id
                      AND o.name COLLATE "C" < v_next_seek
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                      AND (delete_markers != 'only' OR o.is_delete_marker)
                    ORDER BY o.name COLLATE "C" DESC LIMIT 1;
                END IF;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := v_common_prefix;
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            version := NULL;
            archived_at := NULL;
            is_delete_marker := NULL;
            is_versioned := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1)
                    || chr(ascii(right(v_common_prefix, 1)) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
            v_next_seek_at := NULL;
            v_next_seek_version := '';
            v_next_seek_strict := NOT v_is_asc;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE CASE WHEN v_next_seek_strict AND NOT v_multi_row THEN v_batch_query_strict ELSE v_batch_query END
                USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size, v_next_seek_at, v_next_seek_version,
                v_next_seek_strict
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it. Reset
                    -- strict mode too it may have been set by an earlier
                    -- row in this same batch (see the single-row ASC advance
                    -- below), and v_next_seek here is the folder-triggering
                    -- row's own name, which the next peek must find inclusively.
                    v_next_seek := CASE
                        WHEN v_is_asc THEN v_current.name
                        ELSE v_current.name || delimiter_param
                    END;
                    v_next_seek_at := NULL;
                    v_next_seek_version := '';
                    v_next_seek_strict := false;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                version := v_current.version;
                archived_at := v_current.archived_at;
                is_delete_marker := v_current.is_delete_marker;
                is_versioned := v_current.is_versioned;
                RETURN NEXT;
                v_count := v_count + 1;

                -- when v_multi_row, stay on this name and record its
                -- archived_at as the new tiebreak so remaining rows for the
                -- same key are picked up before moving to the next name
                IF v_multi_row THEN
                    v_next_seek := v_current.name;
                    v_next_seek_at := COALESCE(date_trunc('milliseconds', v_current.archived_at), 'infinity'::timestamptz);
                    v_next_seek_version := COALESCE(v_current.version, '');
                    v_next_seek_strict := false;
                ELSIF v_is_asc THEN
                    -- Appending the delimiter as a fake lexical successor
                    -- would skip a real key like `name || '!'` (or any
                    -- character sorting below the delimiter), which sorts
                    -- between `name` and `name || delimiter`. Track the real
                    -- name and mark the next comparison strict instead.
                    v_next_seek := v_current.name;
                    v_next_seek_strict := true;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;

        IF v_count = v_previous_count
           AND v_next_seek IS NOT DISTINCT FROM v_previous_seek
           AND v_next_seek_at IS NOT DISTINCT FROM v_previous_seek_at
           AND v_next_seek_version IS NOT DISTINCT FROM v_previous_seek_version THEN
            RAISE EXCEPTION 'storage.list_objects_with_delimiter made no progress at seek (%, %, %)',
                v_next_seek, v_next_seek_at, v_next_seek_version;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text, sort_order text, noncurrent_versions text, delete_markers text, next_token_archived_at timestamp with time zone, next_token_version text) OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: protect_bucket_control_columns(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.protect_bucket_control_columns() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  configuration_changed boolean;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.lifecycle_configuration IS NOT NULL
       OR NEW.lifecycle_configuration_generation IS NOT NULL THEN
      IF NOT pg_has_role(current_user, TG_ARGV[0], 'MEMBER') THEN
        RAISE EXCEPTION 'only members of the configured storage service role may insert lifecycle policy state'
          USING ERRCODE = '42501',
                HINT = format(
                  'Insert with both lifecycle columns NULL and configure lifecycle through the Storage API afterward, or insert as a member of %I.',
                  TG_ARGV[0]
                );
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  configuration_changed =
    OLD.lifecycle_configuration IS DISTINCT FROM NEW.lifecycle_configuration
    OR OLD.lifecycle_configuration_generation IS DISTINCT FROM NEW.lifecycle_configuration_generation;

  IF NOT configuration_changed THEN
    RETURN NEW;
  END IF;

  IF NEW.type IS DISTINCT FROM 'STANDARD' THEN
    RAISE EXCEPTION 'bucket versioning and lifecycle controls require a Standard bucket'
      USING ERRCODE = '0A000';
  END IF;

  IF NEW.lifecycle_configuration IS NULL
     AND NEW.lifecycle_configuration_generation IS NULL THEN
    RETURN NEW;
  END IF;

  IF NEW.lifecycle_configuration IS NULL
     OR NEW.lifecycle_configuration_generation IS NULL
     OR OLD.lifecycle_configuration IS NOT DISTINCT FROM NEW.lifecycle_configuration
     OR OLD.lifecycle_configuration_generation IS NOT DISTINCT FROM NEW.lifecycle_configuration_generation THEN
    RAISE EXCEPTION 'a changed lifecycle policy requires a new non-null generation'
      USING ERRCODE = '22023';
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION storage.protect_bucket_control_columns() OWNER TO supabase_storage_admin;

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.protect_delete() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text, noncurrent_versions text DEFAULT 'exclude'::text, delete_markers text DEFAULT 'exclude'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb, version text, archived_at timestamp with time zone, is_delete_marker boolean, is_versioned boolean)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_prefix_len INT;
    v_prefix_start INT;
    v_combined_levels INT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;
    v_version_filter TEXT;
    v_multi_row BOOLEAN;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;
    v_delete_marker_peek_query TEXT;
    v_delete_marker_peek_query_strict TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_next_seek_at TIMESTAMPTZ;
    v_next_seek_version TEXT;
    v_next_seek_strict BOOLEAN := false;
    v_count INT := 0;
    v_skipped INT := 0;
    v_previous_seek TEXT;
    v_previous_seek_at TIMESTAMPTZ;
    v_previous_seek_version TEXT;
    v_previous_count INT;
    v_previous_skipped INT;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_prefix_len := length(coalesce(prefix, ''));
    v_prefix_start := coalesce(array_length(string_to_array(coalesce(prefix, ''), v_delimiter), 1), 1);
    v_combined_levels := coalesce(array_length(string_to_array(v_prefix, v_delimiter), 1), 1);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);
    v_next_seek_at := NULL;
    v_next_seek_version := '';

    -- COALESCE first: NULL NOT IN (...) evaluates to NULL (not TRUE), so a
    -- bare NOT IN check silently leaves an explicit NULL argument unreset.
    noncurrent_versions := COALESCE(noncurrent_versions, 'exclude');
    delete_markers := COALESCE(delete_markers, 'exclude');
    IF noncurrent_versions NOT IN ('exclude', 'only', 'include') THEN
        noncurrent_versions := 'exclude';
    END IF;
    IF delete_markers NOT IN ('exclude', 'only', 'include') THEN
        delete_markers := 'exclude';
    END IF;

    v_multi_row := noncurrent_versions IN ('only', 'include');

    v_version_filter := '';
    IF noncurrent_versions = 'exclude' THEN
        v_version_filter := v_version_filter || ' AND o.archived_at IS NULL';
    ELSIF noncurrent_versions = 'only' THEN
        v_version_filter := v_version_filter || ' AND o.archived_at IS NOT NULL';
    END IF;
    IF delete_markers = 'exclude' THEN
        v_version_filter := v_version_filter || ' AND NOT o.is_delete_marker';
    ELSIF delete_markers = 'only' THEN
        v_version_filter := v_version_filter || ' AND o.is_delete_marker';
    END IF;

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT array_to_string(path_tokens[$1:$2], '/') AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $3 || '%%'
                  AND bucket_id = $4
                  AND array_length(objects.path_tokens, 1) <> $2
                  AND ($7 != 'exclude' OR objects.archived_at IS NULL)
                  AND ($7 != 'only' OR objects.archived_at IS NOT NULL)
                  AND ($8 != 'exclude' OR NOT objects.is_delete_marker)
                  AND ($8 != 'only' OR objects.is_delete_marker)
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata,
                   NULL::text AS version,
                   NULL::timestamptz AS archived_at,
                   NULL::boolean AS is_delete_marker,
                   NULL::boolean AS is_versioned FROM folders)
            UNION ALL
            (SELECT array_to_string(path_tokens[$1:$2], '/') AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata,
                   version, archived_at, is_delete_marker, is_versioned
             FROM storage.objects
             WHERE objects.name ILIKE $3 || '%%'
               AND bucket_id = $4
               AND array_length(objects.path_tokens, 1) = $2
               AND ($7 != 'exclude' OR objects.archived_at IS NULL)
               AND ($7 != 'only' OR objects.archived_at IS NOT NULL)
               AND ($8 != 'exclude' OR NOT objects.is_delete_marker)
               AND ($8 != 'only' OR objects.is_delete_marker)
             -- name, then version, as tiebreaks so two versions of the same
             -- key tying on the sort column still sort deterministically
             ORDER BY %I %s, name COLLATE "C" %s, COALESCE(version, '') %s)
            LIMIT $5 OFFSET $6
            $sql$, v_sort_order, v_order_by, v_sort_order, v_sort_order, v_sort_order
        ) USING v_prefix_start, v_combined_levels, v_prefix, bucketname, v_limit, offsets, noncurrent_versions, delete_markers;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build a resume-safe batch query. The exact-name branch returns remaining
    -- versions after the current (archived_at, version) boundary; the strict
    -- name branch returns subsequent keys. UNION ALL keeps both predicates
    -- independently indexable.
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT * FROM (' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" = $2 AND ($5::timestamptz IS NULL OR COALESCE(o.archived_at, ''infinity''::timestamptz) < $5 OR (COALESCE(o.archived_at, ''infinity''::timestamptz) = $5 AND COALESCE(o.version, '''') > $6))' ||
                v_version_filter || ' ORDER BY COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4) UNION ALL ' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" > $2 AND lower(o.name) COLLATE "C" < $3' || v_version_filter ||
                ' ORDER BY lower(o.name) COLLATE "C" ASC, COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4)' ||
                ') sub ORDER BY lower(sub.name) COLLATE "C" ASC, COALESCE(sub.archived_at, ''infinity''::timestamptz) DESC, COALESCE(sub.version, '''') ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT * FROM (' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" = $2 AND ($5::timestamptz IS NULL OR COALESCE(o.archived_at, ''infinity''::timestamptz) < $5 OR (COALESCE(o.archived_at, ''infinity''::timestamptz) = $5 AND COALESCE(o.version, '''') > $6))' ||
                v_version_filter || ' ORDER BY COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4) UNION ALL ' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" > $2' || v_version_filter ||
                ' ORDER BY lower(o.name) COLLATE "C" ASC, COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4)' ||
                ') sub ORDER BY lower(sub.name) COLLATE "C" ASC, COALESCE(sub.archived_at, ''infinity''::timestamptz) DESC, COALESCE(sub.version, '''') ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT * FROM (' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" = $2 AND ($5::timestamptz IS NULL OR COALESCE(o.archived_at, ''infinity''::timestamptz) < $5 OR (COALESCE(o.archived_at, ''infinity''::timestamptz) = $5 AND COALESCE(o.version, '''') > $6))' ||
                v_version_filter || ' ORDER BY COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4) UNION ALL ' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 AND lower(o.name) COLLATE "C" >= $3' || v_version_filter ||
                ' ORDER BY lower(o.name) COLLATE "C" DESC, COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4)' ||
                ') sub ORDER BY lower(sub.name) COLLATE "C" DESC, COALESCE(sub.archived_at, ''infinity''::timestamptz) DESC, COALESCE(sub.version, '''') ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT * FROM (' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" = $2 AND ($5::timestamptz IS NULL OR COALESCE(o.archived_at, ''infinity''::timestamptz) < $5 OR (COALESCE(o.archived_at, ''infinity''::timestamptz) = $5 AND COALESCE(o.version, '''') > $6))' ||
                v_version_filter || ' ORDER BY COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4) UNION ALL ' ||
                '(SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata, o.version, o.archived_at, o.is_delete_marker, o.is_versioned FROM storage.objects o ' ||
                'WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2' || v_version_filter ||
                ' ORDER BY lower(o.name) COLLATE "C" DESC, COALESCE(o.archived_at, ''infinity''::timestamptz) DESC, COALESCE(o.version, '''') ASC LIMIT $4)' ||
                ') sub ORDER BY lower(sub.name) COLLATE "C" DESC, COALESCE(sub.archived_at, ''infinity''::timestamptz) DESC, COALESCE(sub.version, '''') ASC LIMIT $4';
        END IF;
    END IF;

    -- Keep the delete-marker predicate literal so the cached generic
    -- plan can use idx_objects_delete_markers during the main-loop peek.
    IF delete_markers = 'only' THEN
        IF v_multi_row THEN
            v_delete_marker_peek_query :=
                'SELECT marker_page.name FROM (' || v_batch_query || ') marker_page LIMIT 1';
        ELSIF v_is_asc THEN
            -- Two separate literal query strings, not one gated by a bound
            -- boolean: folding "$n AND op1 OR NOT $n AND op2" into a single
            -- query defeats the generic plan's ability to push either
            -- comparison into the index. Branching in PL/pgSQL control flow
            -- instead keeps each query's index condition intact.
            v_delete_marker_peek_query :=
                'SELECT o.name FROM storage.objects o WHERE o.bucket_id = $1 ' ||
                'AND lower(o.name) COLLATE "C" >= $2' ||
                CASE WHEN v_upper_bound IS NOT NULL
                    THEN ' AND lower(o.name) COLLATE "C" < $3'
                    ELSE ''
                END ||
                v_version_filter ||
                ' ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1';
            -- Strict variant: used once the single-row ASC batch advance
            -- (below) has left v_next_seek pointing at the last row already
            -- emitted, so a plain >= would re-match it forever.
            v_delete_marker_peek_query_strict :=
                'SELECT o.name FROM storage.objects o WHERE o.bucket_id = $1 ' ||
                'AND lower(o.name) COLLATE "C" > $2' ||
                CASE WHEN v_upper_bound IS NOT NULL
                    THEN ' AND lower(o.name) COLLATE "C" < $3'
                    ELSE ''
                END ||
                v_version_filter ||
                ' ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1';
        ELSE
            v_delete_marker_peek_query :=
                'SELECT o.name FROM storage.objects o WHERE o.bucket_id = $1 ' ||
                'AND lower(o.name) COLLATE "C" < $2' ||
                CASE WHEN v_upper_bound IS NOT NULL
                    THEN ' AND lower(o.name) COLLATE "C" >= $3'
                    ELSE ''
                END ||
                v_version_filter ||
                ' ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC performs one specialized initial seek so partial current-version
        -- and delete-marker indexes remain available.
        EXECUTE format(
            'SELECT o.name FROM storage.objects o WHERE o.bucket_id = $1%s%s ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1',
            CASE WHEN v_upper_bound IS NOT NULL
                THEN ' AND lower(o.name) COLLATE "C" >= $2 AND lower(o.name) COLLATE "C" < $3'
                ELSE ''
            END,
            v_version_filter
        )
        INTO v_peek_name
        USING bucketname, v_prefix_lower, v_upper_bound;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch and
    -- the delete-marker-only path
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        v_previous_seek := v_next_seek;
        v_previous_seek_at := v_next_seek_at;
        v_previous_seek_version := v_next_seek_version;
        v_previous_count := v_count;
        v_previous_skipped := v_skipped;

        -- STEP 1: PEEK
        v_peek_name := NULL;
        IF delete_markers = 'only' THEN
            EXECUTE CASE WHEN v_next_seek_strict
                THEN v_delete_marker_peek_query_strict
                ELSE v_delete_marker_peek_query
            END
                INTO v_peek_name
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END,
                    1, v_next_seek_at, v_next_seek_version;
        ELSIF v_multi_row AND v_next_seek_at IS NOT NULL THEN
            SELECT o.name INTO v_peek_name
            FROM storage.objects o
            WHERE o.bucket_id = bucketname
              AND lower(o.name) COLLATE "C" = v_next_seek
              AND (COALESCE(o.archived_at, 'infinity'::timestamptz) < v_next_seek_at
                   OR (COALESCE(o.archived_at, 'infinity'::timestamptz) = v_next_seek_at
                       AND COALESCE(o.version, '') > v_next_seek_version))
              AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
              AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
              AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
              AND (delete_markers != 'only' OR o.is_delete_marker)
            ORDER BY COALESCE(o.archived_at, 'infinity'::timestamptz) DESC,
                     COALESCE(o.version, '') ASC
            LIMIT 1;

            -- The current key is exhausted. Clear its version boundary and
            -- make the following ASC name peek strict. Appending '/' is not a
            -- valid lexical successor because keys ending in characters such
            -- as '!' sort between the exhausted name and name || '/'.
            IF v_peek_name IS NULL THEN
                IF v_is_asc THEN
                    v_next_seek_strict := true;
                END IF;
                v_next_seek_at := NULL;
                v_next_seek_version := '';
            END IF;
        END IF;

        -- Single-row mode is always noncurrent_versions='exclude'. Keep the
        -- current-row predicate literal so generic plans use the current index.
        IF delete_markers != 'only' AND v_peek_name IS NULL AND NOT v_multi_row THEN
            IF v_is_asc THEN
                IF v_next_seek_strict AND v_upper_bound IS NOT NULL THEN
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" > v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                    ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
                ELSIF v_next_seek_strict THEN
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" > v_next_seek
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                    ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
                ELSIF v_upper_bound IS NOT NULL THEN
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                    ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
                ELSE
                    SELECT o.name INTO v_peek_name FROM storage.objects o
                    WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                      AND o.archived_at IS NULL
                      AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                    ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
                END IF;
            ELSIF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                  AND o.archived_at IS NULL
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                  AND o.archived_at IS NULL
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        ELSIF delete_markers != 'only' AND v_peek_name IS NULL AND v_is_asc THEN
            IF v_next_seek_strict AND v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" > v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                  AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                  AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                  AND (delete_markers != 'only' OR o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSIF v_next_seek_strict THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" > v_next_seek
                  AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                  AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                  AND (delete_markers != 'only' OR o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSIF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                  AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                  AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                  AND (delete_markers != 'only' OR o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                  AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                  AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                  AND (delete_markers != 'only' OR o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSIF delete_markers != 'only' AND v_peek_name IS NULL THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                  AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                  AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                  AND (delete_markers != 'only' OR o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                  AND (noncurrent_versions != 'exclude' OR o.archived_at IS NULL)
                  AND (noncurrent_versions != 'only' OR o.archived_at IS NOT NULL)
                  AND (delete_markers != 'exclude' OR NOT o.is_delete_marker)
                  AND (delete_markers != 'only' OR o.is_delete_marker)
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- If the peek landed on a different key than we were tracking, any
        -- version boundary belongs to the OLD key and must not leak into the
        -- new one - e.g. the deleteMarkers='only' peek doesn't know or care
        -- whether it's continuing the same key or jumping to a new one, so
        -- it never clears these itself.
        IF lower(v_peek_name) IS DISTINCT FROM v_next_seek THEN
            v_next_seek_at := NULL;
            v_next_seek_version := '';
        END IF;

        -- The peek is authoritative for the next key to process. This is
        -- especially important after exhausting a multi-version key: the
        -- version boundary has been cleared, so executing the batch against
        -- a stale v_next_seek would replay every version of that old key.
        v_next_seek := lower(v_peek_name);
        v_next_seek_strict := false;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := substring(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter) from v_prefix_len + 1);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                version := NULL;
                archived_at := NULL;
                is_delete_marker := NULL;
                is_versioned := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
            v_next_seek_at := NULL;
            v_next_seek_version := '';
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size,
                    v_next_seek_at, v_next_seek_version
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it. Reset
                    -- strict mode too - it may have been set by an earlier
                    -- row in this same batch (see the single-row ASC advance
                    -- below), and v_next_seek here is the folder-triggering
                    -- row's own name, which the next peek must find inclusively.
                    v_next_seek := CASE
                        WHEN v_is_asc THEN lower(v_current.name)
                        ELSE lower(v_current.name) || v_delimiter
                    END;
                    v_next_seek_at := NULL;
                    v_next_seek_version := '';
                    v_next_seek_strict := false;
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := substring(v_current.name from v_prefix_len + 1);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    version := v_current.version;
                    archived_at := v_current.archived_at;
                    is_delete_marker := v_current.is_delete_marker;
                    is_versioned := v_current.is_versioned;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Multi-row mode must remain on this key until all of its
                -- versions have crossed the internal batch boundary.
                IF v_multi_row THEN
                    v_next_seek := lower(v_current.name);
                    v_next_seek_at := COALESCE(v_current.archived_at, 'infinity'::timestamptz);
                    v_next_seek_version := COALESCE(v_current.version, '');
                ELSIF v_is_asc THEN
                    -- Appending the delimiter as a fake lexical successor would
                    -- skip a real key like `name || '!'` (or any character
                    -- sorting below the delimiter), which sorts between `name`
                    -- and `name || delimiter`. Track the real name and mark the
                    -- next comparison strict instead - same fix as the
                    -- exhausted-key case above.
                    v_next_seek := lower(v_current.name);
                    v_next_seek_strict := true;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;

        IF v_count = v_previous_count
           AND v_skipped = v_previous_skipped
           AND v_next_seek IS NOT DISTINCT FROM v_previous_seek
           AND v_next_seek_at IS NOT DISTINCT FROM v_previous_seek_at
           AND v_next_seek_version IS NOT DISTINCT FROM v_previous_seek_version THEN
            RAISE EXCEPTION 'storage.search made no progress at seek (%, %, %)',
                v_next_seek, v_next_seek_at, v_next_seek_version;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text, noncurrent_versions text, delete_markers text) OWNER TO supabase_storage_admin;

--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text, noncurrent_versions text DEFAULT 'exclude'::text, delete_markers text DEFAULT 'exclude'::text, p_start_after_version text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb, version text, archived_at timestamp with time zone, is_delete_marker boolean, is_versioned boolean)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
    v_prefix_pattern text;
    v_sort_order text;
    v_sort_column text;
    v_version_tiebreak text;
BEGIN
    v_prefix := coalesce(p_prefix, '');
    -- Keep the raw prefix for common-prefix calculations and escape only LIKE metacharacters.
    v_prefix_pattern := replace(v_prefix, chr(92), chr(92) || chr(92));
    v_prefix_pattern := replace(v_prefix_pattern, '%', chr(92) || '%');
    v_prefix_pattern := replace(v_prefix_pattern, '_', chr(92) || '_');

    -- COALESCE first: NULL NOT IN (...) evaluates to NULL (not TRUE), so a
    -- bare NOT IN check silently leaves an explicit NULL argument unreset.
    noncurrent_versions := COALESCE(noncurrent_versions, 'exclude');
    delete_markers := COALESCE(delete_markers, 'exclude');
    IF noncurrent_versions NOT IN ('exclude', 'only', 'include') THEN
        noncurrent_versions := 'exclude';
    END IF;
    IF delete_markers NOT IN ('exclude', 'only', 'include') THEN
        delete_markers := 'exclude';
    END IF;

    -- $9 is only populated in multi-row mode; it's always '' otherwise, so
    -- only use each row's real version as a tiebreak in multi-row mode.
    v_version_tiebreak := CASE WHEN noncurrent_versions IN ('only', 'include') THEN 'COALESCE(version, '''')' ELSE '''''' END;

    -- Defense-in-depth: this function is independently reachable and must
    -- not trust p_sort_order/p_sort_column to already be validated by a
    -- caller. Normalize to the same strict allow-list storage.search_v2
    -- uses before interpolating anything into dynamic SQL below.
    v_sort_order := lower(coalesce(p_sort_order, 'asc'));
    IF v_sort_order NOT IN ('asc', 'desc') THEN
        v_sort_order := 'asc';
    END IF;

    v_sort_column := lower(coalesce(p_sort_column, 'updated_at'));
    IF v_sort_column NOT IN ('updated_at', 'created_at') THEN
        v_sort_column := 'updated_at';
    END IF;

    IF v_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                o.version AS obj_version,
                o.archived_at AS obj_archived_at,
                o.is_delete_marker AS obj_is_delete_marker,
                o.is_versioned AS obj_is_versioned,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $10 || '%%'
              AND ($7 != 'exclude' OR o.archived_at IS NULL)
              AND ($7 != 'only' OR o.archived_at IS NOT NULL)
              AND ($8 != 'exclude' OR NOT o.is_delete_marker)
              AND ($8 != 'only' OR o.is_delete_marker)
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                common_prefix AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                NULL::text AS version,
                NULL::timestamptz AS archived_at,
                NULL::boolean AS is_delete_marker,
                NULL::boolean AS is_versioned,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                obj_version AS version,
                obj_archived_at AS archived_at,
                obj_is_delete_marker AS is_delete_marker,
                obj_is_versioned AS is_versioned,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz),
                    name COLLATE "C",
                    %s
                ) %s ROW(
                    -- truncated the same way as the stored value above
                    date_trunc('milliseconds', COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz)),
                    $5,
                    $9
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata,
            version,
            archived_at,
            is_delete_marker,
            is_versioned
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s,
            COALESCE(version, '') %s
        LIMIT $4
    $sql$,
        v_sort_column,
        v_version_tiebreak,
        v_cursor_op,
        v_sort_column,
        v_sort_order,
        v_sort_order,
        v_sort_order
    );

    -- version is the third tiebreak component for two versions of the same
    -- key tying on both timestamp and name (see filtered CTE / ORDER BY above)
    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after, noncurrent_versions, delete_markers, coalesce(p_start_after_version, ''), v_prefix_pattern;
END;
$_$;


ALTER FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text, noncurrent_versions text, delete_markers text, p_start_after_version text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text, text, text, timestamp with time zone, text, boolean); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text, noncurrent_versions text DEFAULT 'exclude'::text, delete_markers text DEFAULT 'exclude'::text, start_after_archived_at timestamp with time zone DEFAULT NULL::timestamp with time zone, start_after_version text DEFAULT ''::text, start_after_is_continuation boolean DEFAULT false) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb, version text, archived_at timestamp with time zone, is_delete_marker boolean, is_versioned boolean)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata,
            l.version,
            l.archived_at,
            l.is_delete_marker,
            l.is_versioned
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            CASE WHEN start_after_is_continuation THEN '' ELSE start_after END,
            CASE WHEN start_after_is_continuation THEN start_after ELSE '' END,
            v_sort_ord,
            noncurrent_versions,
            delete_markers,
            start_after_archived_at,
            start_after_version
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after,
            noncurrent_versions, delete_markers, start_after_version
        );
    END IF;
END;
$$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text, noncurrent_versions text, delete_markers text, start_after_archived_at timestamp with time zone, start_after_version text, start_after_is_continuation boolean) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


ALTER TABLE auth.custom_oauth_providers OWNER TO supabase_auth_admin;

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: mfa_recovery_code_sets; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_recovery_code_sets (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    mfa_factor_id uuid NOT NULL,
    failed_verification_count integer DEFAULT 0 NOT NULL,
    verification_locked_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mfa_recovery_code_sets_failed_verification_count_check CHECK ((failed_verification_count >= 0))
);


ALTER TABLE auth.mfa_recovery_code_sets OWNER TO supabase_auth_admin;

--
-- Name: mfa_recovery_codes; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_recovery_codes (
    id uuid NOT NULL,
    mfa_recovery_code_set_id uuid NOT NULL,
    code_hash text NOT NULL,
    consumed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE auth.mfa_recovery_codes OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE auth.oauth_client_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: scim_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.scim_tokens (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    token_hash text NOT NULL,
    prefix text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    CONSTRAINT scim_tokens_expires_at_future CHECK (((expires_at IS NULL) OR (expires_at > created_at))),
    CONSTRAINT scim_tokens_revoked_after_created CHECK (((revoked_at IS NULL) OR (revoked_at >= created_at))),
    CONSTRAINT scim_tokens_token_hash_check CHECK ((token_hash ~ '^[0-9a-f]{64}$'::text))
);


ALTER TABLE auth.scim_tokens OWNER TO supabase_auth_admin;

--
-- Name: scim_users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.scim_users (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    user_id uuid,
    resource jsonb NOT NULL,
    user_name text GENERATED ALWAYS AS (lower((resource ->> 'userName'::text))) STORED NOT NULL,
    external_id text GENERATED ALWAYS AS ((resource ->> 'externalId'::text)) STORED,
    active boolean GENERATED ALWAYS AS (COALESCE(((resource ->> 'active'::text))::boolean, true)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE auth.scim_users OWNER TO supabase_auth_admin;

--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


ALTER TABLE auth.webauthn_challenges OWNER TO supabase_auth_admin;

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


ALTER TABLE auth.webauthn_credentials OWNER TO supabase_auth_admin;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: item_attribute_imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_attribute_imports (
    id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    file_hash character varying(64) NOT NULL,
    sheet_name character varying(120),
    total_price_rows integer DEFAULT 0 NOT NULL,
    updated_item_count integer DEFAULT 0 NOT NULL,
    missing_item_count integer DEFAULT 0 NOT NULL,
    option_count integer DEFAULT 0 NOT NULL,
    issue_count integer DEFAULT 0 NOT NULL,
    issues jsonb,
    imported_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.item_attribute_imports OWNER TO postgres;

--
-- Name: item_attribute_imports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_attribute_imports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_attribute_imports_id_seq OWNER TO postgres;

--
-- Name: item_attribute_imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_attribute_imports_id_seq OWNED BY public.item_attribute_imports.id;


--
-- Name: item_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_categories (
    id integer NOT NULL,
    code character varying(40) NOT NULL,
    name character varying(80) NOT NULL,
    usage character varying(10) DEFAULT 'DETAIL'::character varying NOT NULL,
    separate_group boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.item_categories OWNER TO postgres;

--
-- Name: item_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_categories_id_seq OWNER TO postgres;

--
-- Name: item_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_categories_id_seq OWNED BY public.item_categories.id;


--
-- Name: item_master_imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_master_imports (
    id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    file_hash character varying(64) NOT NULL,
    sheet_name character varying(120),
    total_rows integer DEFAULT 0 NOT NULL,
    new_count integer DEFAULT 0 NOT NULL,
    changed_count integer DEFAULT 0 NOT NULL,
    unchanged_count integer DEFAULT 0 NOT NULL,
    skipped_count integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    issues jsonb,
    imported_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.item_master_imports OWNER TO postgres;

--
-- Name: item_master_imports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_master_imports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_master_imports_id_seq OWNER TO postgres;

--
-- Name: item_master_imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_master_imports_id_seq OWNED BY public.item_master_imports.id;


--
-- Name: item_masters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_masters (
    id integer NOT NULL,
    code character varying(160) NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    source character varying(30) DEFAULT 'THU_CONG'::character varying NOT NULL,
    last_source_file character varying(255),
    last_imported_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    dealer_price numeric(18,2),
    price_imported_at timestamp(3) without time zone,
    price_source_file character varying(255),
    unit character varying(40),
    sales_name character varying(120),
    sales_model character varying(180),
    retail_price numeric(18,2),
    product_description text,
    category character varying(20) DEFAULT 'ACCESSORY'::character varying NOT NULL
);


ALTER TABLE public.item_masters OWNER TO postgres;

--
-- Name: item_masters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_masters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_masters_id_seq OWNER TO postgres;

--
-- Name: item_masters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_masters_id_seq OWNED BY public.item_masters.id;


--
-- Name: master_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_options (
    id integer NOT NULL,
    group_code character varying(60) NOT NULL,
    code character varying(120) NOT NULL,
    name character varying(200) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    source character varying(30) DEFAULT 'THU_CONG'::character varying NOT NULL,
    last_source_file character varying(255),
    last_imported_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.master_options OWNER TO postgres;

--
-- Name: master_options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.master_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.master_options_id_seq OWNER TO postgres;

--
-- Name: master_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.master_options_id_seq OWNED BY public.master_options.id;


--
-- Name: order_imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_imports (
    id integer NOT NULL,
    order_id integer,
    file_name character varying(255) NOT NULL,
    file_hash character varying(64) NOT NULL,
    action character varying(30) NOT NULL,
    sheet_name character varying(120),
    imported_items integer DEFAULT 0 NOT NULL,
    imported_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.order_imports OWNER TO postgres;

--
-- Name: order_imports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_imports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_imports_id_seq OWNER TO postgres;

--
-- Name: order_imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_imports_id_seq OWNED BY public.order_imports.id;


--
-- Name: production_calendar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_calendar (
    id integer NOT NULL,
    date date NOT NULL,
    is_working_day boolean DEFAULT true NOT NULL,
    note character varying(160),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_calendar OWNER TO postgres;

--
-- Name: production_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_calendar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_calendar_id_seq OWNER TO postgres;

--
-- Name: production_calendar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_calendar_id_seq OWNED BY public.production_calendar.id;


--
-- Name: production_component_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_component_orders (
    id integer NOT NULL,
    set_id integer NOT NULL,
    kind character varying(10) NOT NULL,
    qty_expected double precision,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_component_orders OWNER TO postgres;

--
-- Name: production_component_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_component_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_component_orders_id_seq OWNER TO postgres;

--
-- Name: production_component_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_component_orders_id_seq OWNED BY public.production_component_orders.id;


--
-- Name: production_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_logs (
    id integer NOT NULL,
    entity character varying(20) NOT NULL,
    entity_id integer NOT NULL,
    action character varying(40) NOT NULL,
    field character varying(60),
    old_value text,
    new_value text,
    by_name character varying(120),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.production_logs OWNER TO postgres;

--
-- Name: production_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_logs_id_seq OWNER TO postgres;

--
-- Name: production_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_logs_id_seq OWNED BY public.production_logs.id;


--
-- Name: production_machine_downtimes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_machine_downtimes (
    id integer NOT NULL,
    work_center_code character varying(40) NOT NULL,
    machine character varying(120),
    from_at timestamp(3) without time zone NOT NULL,
    to_at timestamp(3) without time zone,
    reason_code character varying(40),
    note text,
    created_by character varying(120),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_machine_downtimes OWNER TO postgres;

--
-- Name: production_machine_downtimes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_machine_downtimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_machine_downtimes_id_seq OWNER TO postgres;

--
-- Name: production_machine_downtimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_machine_downtimes_id_seq OWNED BY public.production_machine_downtimes.id;


--
-- Name: production_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_plans (
    id integer NOT NULL,
    code character varying(60) NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL,
    status character varying(20) DEFAULT 'NHAP'::character varying NOT NULL,
    created_by character varying(120),
    approved_by character varying(120),
    approved_at timestamp(3) without time zone,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_plans OWNER TO postgres;

--
-- Name: production_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_plans_id_seq OWNER TO postgres;

--
-- Name: production_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_plans_id_seq OWNED BY public.production_plans.id;


--
-- Name: production_programs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_programs (
    id integer NOT NULL,
    model character varying(100) NOT NULL,
    file_name character varying(255),
    version integer DEFAULT 1 NOT NULL,
    machine character varying(120),
    made_by character varying(120),
    made_at timestamp(3) without time zone,
    duration_minutes integer,
    reusable boolean DEFAULT true NOT NULL,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_programs OWNER TO postgres;

--
-- Name: production_programs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_programs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_programs_id_seq OWNER TO postgres;

--
-- Name: production_programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_programs_id_seq OWNED BY public.production_programs.id;


--
-- Name: production_reasons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_reasons (
    id integer NOT NULL,
    code character varying(40) NOT NULL,
    name character varying(160) NOT NULL,
    "group" character varying(20) DEFAULT 'TAM_DUNG'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_reasons OWNER TO postgres;

--
-- Name: production_reasons_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_reasons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_reasons_id_seq OWNER TO postgres;

--
-- Name: production_reasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_reasons_id_seq OWNED BY public.production_reasons.id;


--
-- Name: production_sets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_sets (
    id integer NOT NULL,
    order_id integer NOT NULL,
    order_item_id integer,
    order_code character varying(120),
    set_no character varying(80),
    order_type character varying(30) DEFAULT 'SAN_XUAT'::character varying NOT NULL,
    customer_name character varying(200),
    product_name text,
    model character varying(100),
    opening_direction character varying(60),
    paint_color character varying(100),
    veneer_code character varying(100),
    height_mm integer,
    width_mm integer,
    leaves_per_set integer,
    trim_bars_per_set integer,
    quantity integer,
    pricing_quantity double precision,
    canh_equivalent integer DEFAULT 1 NOT NULL,
    due_date date,
    plan_id integer,
    priority integer DEFAULT 5 NOT NULL,
    status character varying(30) DEFAULT 'CHO_XEP_LICH'::character varying NOT NULL,
    percent_done integer DEFAULT 0 NOT NULL,
    planned_start date,
    planned_end date,
    actual_completed_at timestamp(3) without time zone,
    actual_delivered_at timestamp(3) without time zone,
    program_ready boolean DEFAULT false NOT NULL,
    material_ready boolean DEFAULT false NOT NULL,
    pack_count integer,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_sets OWNER TO postgres;

--
-- Name: production_sets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_sets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_sets_id_seq OWNER TO postgres;

--
-- Name: production_sets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_sets_id_seq OWNED BY public.production_sets.id;


--
-- Name: production_stages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_stages (
    id integer NOT NULL,
    code character varying(40) NOT NULL,
    name character varying(160) NOT NULL,
    kind character varying(20) DEFAULT 'GIA_CONG'::character varying NOT NULL,
    scope_mode character varying(20) DEFAULT 'BO'::character varying NOT NULL,
    scope_parts character varying(60),
    work_center_code character varying(40),
    seq integer DEFAULT 0 NOT NULL,
    lead_time_hours double precision,
    setup_minutes integer,
    capacity_per_day double precision,
    capacity_unit character varying(10) DEFAULT 'CANH'::character varying NOT NULL,
    batch_key character varying(30),
    batch_min_qty integer,
    changeover_max_per_day integer,
    is_qc_point boolean DEFAULT false NOT NULL,
    rework_to_stage character varying(40),
    skip_condition character varying(160),
    requires_stage character varying(40),
    active boolean DEFAULT true NOT NULL,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_stages OWNER TO postgres;

--
-- Name: production_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_stages_id_seq OWNER TO postgres;

--
-- Name: production_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_stages_id_seq OWNED BY public.production_stages.id;


--
-- Name: production_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_tasks (
    id integer NOT NULL,
    set_id integer NOT NULL,
    order_item_id integer,
    stage_code character varying(40) NOT NULL,
    stage_kind character varying(20) DEFAULT 'GIA_CONG'::character varying NOT NULL,
    scope character varying(10) DEFAULT 'BO'::character varying NOT NULL,
    seq integer DEFAULT 0 NOT NULL,
    work_center_code character varying(40),
    status character varying(20) DEFAULT 'CHUA_LAM'::character varying NOT NULL,
    qty_expected double precision,
    qty_done double precision,
    planned_start date,
    planned_end date,
    actual_start timestamp(3) without time zone,
    actual_end timestamp(3) without time zone,
    assignee character varying(120),
    is_rework boolean DEFAULT false NOT NULL,
    rework_from_stage character varying(40),
    reason_code character varying(40),
    note text,
    updated_by character varying(120),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_tasks OWNER TO postgres;

--
-- Name: production_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_tasks_id_seq OWNER TO postgres;

--
-- Name: production_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_tasks_id_seq OWNED BY public.production_tasks.id;


--
-- Name: production_work_centers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_work_centers (
    id integer NOT NULL,
    code character varying(40) NOT NULL,
    name character varying(120) NOT NULL,
    kind character varying(20) DEFAULT 'TO'::character varying NOT NULL,
    people_count integer,
    shifts_per_day integer,
    hours_per_shift double precision,
    capacity_per_day double precision,
    capacity_unit character varying(10) DEFAULT 'CANH'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.production_work_centers OWNER TO postgres;

--
-- Name: production_work_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_work_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_work_centers_id_seq OWNER TO postgres;

--
-- Name: production_work_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_work_centers_id_seq OWNED BY public.production_work_centers.id;


--
-- Name: sales_order_item_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order_item_details (
    id integer NOT NULL,
    order_item_id integer NOT NULL,
    row_order integer NOT NULL,
    detail_type character varying(50),
    set_no character varying(80),
    product_name text,
    product_code character varying(160),
    model character varying(100),
    opening_direction character varying(60),
    trim_direction character varying(80),
    paint_color character varying(100),
    height_mm integer,
    width_mm integer,
    frame_mm integer,
    clear_height_mm integer,
    clear_width_mm integer,
    panel_info character varying(160),
    trim_bars_per_set integer,
    trim_type character varying(80),
    lock_model character varying(120),
    window_bars character varying(160),
    leaves_per_set integer,
    quantity integer,
    unit character varying(40),
    pricing_quantity double precision,
    unit_price numeric(18,2),
    amount numeric(18,2),
    note text,
    image_path text,
    model_check character varying(120),
    price_check character varying(120),
    source_row integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    image_width integer,
    image_height integer
);


ALTER TABLE public.sales_order_item_details OWNER TO postgres;

--
-- Name: sales_order_item_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_order_item_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_order_item_details_id_seq OWNER TO postgres;

--
-- Name: sales_order_item_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_order_item_details_id_seq OWNED BY public.sales_order_item_details.id;


--
-- Name: sales_order_item_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order_item_images (
    id integer NOT NULL,
    order_item_id integer NOT NULL,
    sort_order integer DEFAULT 1 NOT NULL,
    image_path text NOT NULL,
    image_width integer,
    image_height integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sales_order_item_images OWNER TO postgres;

--
-- Name: sales_order_item_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_order_item_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_order_item_images_id_seq OWNER TO postgres;

--
-- Name: sales_order_item_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_order_item_images_id_seq OWNED BY public.sales_order_item_images.id;


--
-- Name: sales_order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    line_no integer NOT NULL,
    set_no character varying(80),
    product_name text,
    product_code character varying(160),
    model character varying(100),
    opening_direction character varying(60),
    trim_direction character varying(80),
    paint_color character varying(100),
    height_mm integer,
    width_mm integer,
    frame_mm integer,
    clear_height_mm integer,
    clear_width_mm integer,
    panel_info character varying(160),
    trim_bars_per_set integer,
    trim_type character varying(80),
    lock_model character varying(120),
    window_bars character varying(160),
    leaves_per_set integer,
    quantity integer,
    unit character varying(40),
    pricing_quantity double precision,
    unit_price numeric(18,2),
    amount numeric(18,2),
    note text,
    source_row integer,
    raw_block jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    image_path text,
    model_check character varying(120),
    price_check character varying(120),
    image_width integer,
    image_height integer
);


ALTER TABLE public.sales_order_items OWNER TO postgres;

--
-- Name: sales_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_order_items_id_seq OWNER TO postgres;

--
-- Name: sales_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_order_items_id_seq OWNED BY public.sales_order_items.id;


--
-- Name: sales_order_requirements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order_requirements (
    id integer NOT NULL,
    order_id integer NOT NULL,
    code character varying(60) NOT NULL,
    question_text text NOT NULL,
    answer character varying(120),
    note text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sales_order_requirements OWNER TO postgres;

--
-- Name: sales_order_requirements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_order_requirements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_order_requirements_id_seq OWNER TO postgres;

--
-- Name: sales_order_requirements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_order_requirements_id_seq OWNED BY public.sales_order_requirements.id;


--
-- Name: sales_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_orders (
    id integer NOT NULL,
    order_code character varying(120) NOT NULL,
    customer_code character varying(60),
    customer_name character varying(200),
    sales_employee_code character varying(60),
    order_date date,
    required_delivery_date date,
    receiver_address text,
    delivery_km double precision,
    region character varying(100),
    group_no integer,
    excel_update_date date,
    form_code character varying(60),
    form_effective_date date,
    source_file_name character varying(255),
    source_file_hash character varying(64),
    last_imported_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    delivery_payment numeric(18,2),
    deposit_amount numeric(18,2),
    discount_amount numeric(18,2),
    discount_percent numeric(8,4),
    receiver_name character varying(160),
    receiver_phone character varying(40),
    shipping_fee numeric(18,2),
    status character varying(30) DEFAULT 'NHAP'::character varying NOT NULL,
    subtotal numeric(18,2),
    total_after_discount numeric(18,2),
    warehouse_receipt_deduction numeric(18,2),
    shipping_calculated_at timestamp(3) without time zone,
    shipping_mountain_district boolean DEFAULT false NOT NULL,
    order_type character varying(30) DEFAULT 'MAU'::character varying NOT NULL
);


ALTER TABLE public.sales_orders OWNER TO postgres;

--
-- Name: sales_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_orders_id_seq OWNER TO postgres;

--
-- Name: sales_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_orders_id_seq OWNED BY public.sales_orders.id;


--
-- Name: shipping_calculations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_calculations (
    id integer NOT NULL,
    order_id integer NOT NULL,
    region character varying(100) NOT NULL,
    delivery_km numeric(12,2) NOT NULL,
    mountain_district boolean DEFAULT false NOT NULL,
    band_label character varying(180) NOT NULL,
    support_km numeric(12,2) NOT NULL,
    raw_total numeric(18,2) NOT NULL,
    rounded_total numeric(18,2) NOT NULL,
    lines jsonb NOT NULL,
    source character varying(60) DEFAULT 'BANG_CUOC_EXCEL_2024'::character varying NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.shipping_calculations OWNER TO postgres;

--
-- Name: shipping_calculations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_calculations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shipping_calculations_id_seq OWNER TO postgres;

--
-- Name: shipping_calculations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_calculations_id_seq OWNED BY public.shipping_calculations.id;


--
-- Name: shipping_model_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_model_mappings (
    id integer NOT NULL,
    source_model character varying(160) NOT NULL,
    shipping_model_code character varying(60) NOT NULL,
    note text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.shipping_model_mappings OWNER TO postgres;

--
-- Name: shipping_model_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_model_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shipping_model_mappings_id_seq OWNER TO postgres;

--
-- Name: shipping_model_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_model_mappings_id_seq OWNED BY public.shipping_model_mappings.id;


--
-- Name: shipping_rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_rates (
    id integer NOT NULL,
    door_group character varying(60) NOT NULL,
    model_name character varying(160) NOT NULL,
    model_code character varying(60) NOT NULL,
    quantity_tier integer NOT NULL,
    north_le_100 numeric(18,2) NOT NULL,
    north_101_200 numeric(18,2) NOT NULL,
    north_over_200 numeric(18,2) NOT NULL,
    central numeric(18,2) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    source character varying(40) DEFAULT 'EXCEL_2024'::character varying NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.shipping_rates OWNER TO postgres;

--
-- Name: shipping_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shipping_rates_id_seq OWNER TO postgres;

--
-- Name: shipping_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_rates_id_seq OWNED BY public.shipping_rates.id;


--
-- Name: survey_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.survey_answers (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    answer text,
    choice character varying(40),
    updated_by character varying(120),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.survey_answers OWNER TO postgres;

--
-- Name: survey_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.survey_answers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.survey_answers_id_seq OWNER TO postgres;

--
-- Name: survey_answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.survey_answers_id_seq OWNED BY public.survey_answers.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea,
    skip_broadcast boolean DEFAULT false NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


ALTER TABLE realtime.subscription OWNER TO supabase_realtime_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL,
    versioning_status text DEFAULT 'DISABLED'::text NOT NULL,
    lifecycle_configuration jsonb,
    lifecycle_configuration_generation uuid,
    CONSTRAINT buckets_lifecycle_configuration_pair_check CHECK (((lifecycle_configuration IS NULL) = (lifecycle_configuration_generation IS NULL))),
    CONSTRAINT buckets_lifecycle_configuration_shape_check CHECK (((lifecycle_configuration IS NULL) OR ((jsonb_typeof(lifecycle_configuration) = 'object'::text) AND (lifecycle_configuration ? 'rules'::text) AND
CASE
    WHEN (jsonb_typeof((lifecycle_configuration -> 'rules'::text)) = 'array'::text) THEN ((jsonb_array_length((lifecycle_configuration -> 'rules'::text)) >= 1) AND (jsonb_array_length((lifecycle_configuration -> 'rules'::text)) <= 1000))
    ELSE false
END))),
    CONSTRAINT buckets_lifecycle_configuration_standard_only_check CHECK (((type = 'STANDARD'::storage.buckettype) OR ((lifecycle_configuration IS NULL) AND (lifecycle_configuration_generation IS NULL)))),
    CONSTRAINT buckets_versioning_dark_check CHECK ((versioning_status = 'DISABLED'::text)),
    CONSTRAINT buckets_versioning_standard_only_check CHECK (((type = 'STANDARD'::storage.buckettype) OR (versioning_status = 'DISABLED'::text))),
    CONSTRAINT buckets_versioning_status_check CHECK ((versioning_status = ANY (ARRAY['DISABLED'::text, 'ENABLED'::text, 'SUSPENDED'::text])))
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_vectors OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    archived_at timestamp with time zone,
    is_delete_marker boolean DEFAULT false NOT NULL,
    is_versioned boolean DEFAULT false NOT NULL
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.vector_indexes OWNER TO supabase_storage_admin;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: item_attribute_imports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_attribute_imports ALTER COLUMN id SET DEFAULT nextval('public.item_attribute_imports_id_seq'::regclass);


--
-- Name: item_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_categories ALTER COLUMN id SET DEFAULT nextval('public.item_categories_id_seq'::regclass);


--
-- Name: item_master_imports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_master_imports ALTER COLUMN id SET DEFAULT nextval('public.item_master_imports_id_seq'::regclass);


--
-- Name: item_masters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_masters ALTER COLUMN id SET DEFAULT nextval('public.item_masters_id_seq'::regclass);


--
-- Name: master_options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_options ALTER COLUMN id SET DEFAULT nextval('public.master_options_id_seq'::regclass);


--
-- Name: order_imports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_imports ALTER COLUMN id SET DEFAULT nextval('public.order_imports_id_seq'::regclass);


--
-- Name: production_calendar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_calendar ALTER COLUMN id SET DEFAULT nextval('public.production_calendar_id_seq'::regclass);


--
-- Name: production_component_orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_component_orders ALTER COLUMN id SET DEFAULT nextval('public.production_component_orders_id_seq'::regclass);


--
-- Name: production_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_logs ALTER COLUMN id SET DEFAULT nextval('public.production_logs_id_seq'::regclass);


--
-- Name: production_machine_downtimes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_machine_downtimes ALTER COLUMN id SET DEFAULT nextval('public.production_machine_downtimes_id_seq'::regclass);


--
-- Name: production_plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_plans ALTER COLUMN id SET DEFAULT nextval('public.production_plans_id_seq'::regclass);


--
-- Name: production_programs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_programs ALTER COLUMN id SET DEFAULT nextval('public.production_programs_id_seq'::regclass);


--
-- Name: production_reasons id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_reasons ALTER COLUMN id SET DEFAULT nextval('public.production_reasons_id_seq'::regclass);


--
-- Name: production_sets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_sets ALTER COLUMN id SET DEFAULT nextval('public.production_sets_id_seq'::regclass);


--
-- Name: production_stages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_stages ALTER COLUMN id SET DEFAULT nextval('public.production_stages_id_seq'::regclass);


--
-- Name: production_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_tasks ALTER COLUMN id SET DEFAULT nextval('public.production_tasks_id_seq'::regclass);


--
-- Name: production_work_centers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_work_centers ALTER COLUMN id SET DEFAULT nextval('public.production_work_centers_id_seq'::regclass);


--
-- Name: sales_order_item_details id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_item_details ALTER COLUMN id SET DEFAULT nextval('public.sales_order_item_details_id_seq'::regclass);


--
-- Name: sales_order_item_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_item_images ALTER COLUMN id SET DEFAULT nextval('public.sales_order_item_images_id_seq'::regclass);


--
-- Name: sales_order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_items ALTER COLUMN id SET DEFAULT nextval('public.sales_order_items_id_seq'::regclass);


--
-- Name: sales_order_requirements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_requirements ALTER COLUMN id SET DEFAULT nextval('public.sales_order_requirements_id_seq'::regclass);


--
-- Name: sales_orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_orders ALTER COLUMN id SET DEFAULT nextval('public.sales_orders_id_seq'::regclass);


--
-- Name: shipping_calculations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_calculations ALTER COLUMN id SET DEFAULT nextval('public.shipping_calculations_id_seq'::regclass);


--
-- Name: shipping_model_mappings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_model_mappings ALTER COLUMN id SET DEFAULT nextval('public.shipping_model_mappings_id_seq'::regclass);


--
-- Name: shipping_rates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_rates ALTER COLUMN id SET DEFAULT nextval('public.shipping_rates_id_seq'::regclass);


--
-- Name: survey_answers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.survey_answers ALTER COLUMN id SET DEFAULT nextval('public.survey_answers_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: mfa_recovery_code_sets; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_recovery_code_sets (id, user_id, mfa_factor_id, failed_verification_count, verification_locked_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_recovery_codes; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_recovery_codes (id, mfa_recovery_code_set_id, code_hash, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
20260821000000
20260821010000
20260824000000
20260824000001
20260831180000
\.


--
-- Data for Name: scim_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.scim_tokens (id, sso_provider_id, token_hash, prefix, created_at, expires_at, revoked_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: scim_users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.scim_users (id, sso_provider_id, user_id, resource, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
252c705d-b0c2-4442-9208-270982d63096	083d665e30edbcc8892d6b88bf4ab7658ff885b0044c896296cf1e90721e7a90	2026-09-22 04:20:16.475863+00	20260922042016_init	\N	\N	2026-09-22 04:20:16.456026+00	1
65574800-a205-4c64-87b0-f8a88b7745ec	6bea1b3ff2cdf5737f4655a79c5be9d696fce0cfc3ecfe711a9347bfd61f2f7f	2026-09-22 04:34:16.889386+00	20260922043416_order_import_v1	\N	\N	2026-09-22 04:34:16.779684+00	1
86a96cbc-cc15-4c2f-a009-5fcf994282d8	f9ed68635a1b5f5d184aa7cc3bac3309e2203fc9f740dc17a19e8fedded8d974	2026-09-22 05:11:43.40797+00	20260922051143_order_erp_v2	\N	\N	2026-09-22 05:11:43.322494+00	1
bf423fae-2852-43fe-8719-6d0524a49cf0	6e74b4353e60fb28d9091ed4dab0091fed024f6d27a112c412d021cf72bf4f86	2026-09-22 05:28:50.106415+00	20260922052850_item_master_v3	\N	\N	2026-09-22 05:28:50.02931+00	1
67a026cb-28cb-414a-9d92-77a8df6e7e2f	92ada83870157ba52a2e25b3e1fb9ebb37ba24587306f5194070d5a428079420	2026-09-22 06:12:29.505869+00	20260922061229_price_config_v5	\N	\N	2026-09-22 06:12:29.387992+00	1
2d5ab957-5fed-4525-ab16-fc9ad66a95f1	14bd47509a1d177c4f3bd5687f8489db9d9d7b507b8479d6bcf33620fe5a7a56	2026-09-22 06:33:33.140855+00	20260922063333_shipping_freight_v6	\N	\N	2026-09-22 06:33:33.088875+00	1
ec832077-8aac-46cf-9cd1-aee4547e36dc	ebc7e89c6ecc75d03e25d8f167a50eb66afde2f22249d3067175c68bbe3df84b	2026-09-22 11:14:09.819754+00	20260922170500_item_prices_v15	\N	\N	2026-09-22 11:14:09.770803+00	1
dad617ea-c365-45b2-a241-6ab2456e3954	cd1add8b4a27d05cdbba4e6a340299ecccf8c8e0f03d87ae3c68215efaafef5b	2026-09-22 12:57:11.487136+00	20260922193000_item_product_description_v17	\N	\N	2026-09-22 12:57:11.483681+00	1
d5916197-1010-4d9f-9672-df0f832e6d05	49ebb350f6527ba6beb98ec4e407fddd1e11836df10cb03af835ab7ebb7c4864	\N	20260923054500_shipping_model_mapping	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260923054500_shipping_model_mapping\n\nDatabase error code: 42P07\n\nDatabase error:\nERROR: relation "shipping_model_mappings" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P07), message: "relation \\"shipping_model_mappings\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("heap.c"), line: Some(1160), routine: Some("heap_create_with_catalog") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260923054500_shipping_model_mapping"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260923054500_shipping_model_mapping"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	\N	2026-09-26 08:30:24.236354+00	0
\.


--
-- Data for Name: item_attribute_imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_attribute_imports (id, file_name, file_hash, sheet_name, total_price_rows, updated_item_count, missing_item_count, option_count, issue_count, issues, imported_at) FROM stdin;
1	đơn giá , đơn vị tính, màu.xlsx	22ac2f7359823a19ca70796e796e991c31b131b06ef13be5945f0fa1a0cb5961	danh mục hàng hóa	87	1	84	32	85	[{"code": "CS4-HPK", "rows": [50, 53], "type": "DUPLICATE_PRICE_CODE", "message": "Mã 'CS4-HPK' xuất hiện nhiều lần với ĐVT hoặc giá khác nhau ở dòng 50, 53. Hệ thống không tự chọn và sẽ bỏ qua mã này."}, {"code": "GM1-HP", "rows": [2], "type": "MISSING_ITEM", "message": "Dòng 2: mã 'GM1-HP' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H1", "rows": [3], "type": "MISSING_ITEM", "message": "Dòng 3: mã 'GM1-H1' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H2", "rows": [4], "type": "MISSING_ITEM", "message": "Dòng 4: mã 'GM1-H2' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H3", "rows": [5], "type": "MISSING_ITEM", "message": "Dòng 5: mã 'GM1-H3' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H4", "rows": [6], "type": "MISSING_ITEM", "message": "Dòng 6: mã 'GM1-H4' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H5", "rows": [7], "type": "MISSING_ITEM", "message": "Dòng 7: mã 'GM1-H5' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H6", "rows": [8], "type": "MISSING_ITEM", "message": "Dòng 8: mã 'GM1-H6' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H7", "rows": [9], "type": "MISSING_ITEM", "message": "Dòng 9: mã 'GM1-H7' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-H8", "rows": [10], "type": "MISSING_ITEM", "message": "Dòng 10: mã 'GM1-H8' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-HTD", "rows": [11], "type": "MISSING_ITEM", "message": "Dòng 11: mã 'GM1-HTD' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-HPD", "rows": [12], "type": "MISSING_ITEM", "message": "Dòng 12: mã 'GM1-HPD' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H1", "rows": [13], "type": "MISSING_ITEM", "message": "Dòng 13: mã 'GM2-H1' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H2", "rows": [14], "type": "MISSING_ITEM", "message": "Dòng 14: mã 'GM2-H2' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H3", "rows": [15], "type": "MISSING_ITEM", "message": "Dòng 15: mã 'GM2-H3' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H4", "rows": [16], "type": "MISSING_ITEM", "message": "Dòng 16: mã 'GM2-H4' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H5", "rows": [17], "type": "MISSING_ITEM", "message": "Dòng 17: mã 'GM2-H5' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H6", "rows": [18], "type": "MISSING_ITEM", "message": "Dòng 18: mã 'GM2-H6' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H7", "rows": [19], "type": "MISSING_ITEM", "message": "Dòng 19: mã 'GM2-H7' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H8", "rows": [20], "type": "MISSING_ITEM", "message": "Dòng 20: mã 'GM2-H8' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-HTD", "rows": [21], "type": "MISSING_ITEM", "message": "Dòng 21: mã 'GM2-HTD' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-HP", "rows": [22], "type": "MISSING_ITEM", "message": "Dòng 22: mã 'GM2-HP' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H3-HP", "rows": [23], "type": "MISSING_ITEM", "message": "Dòng 23: mã 'GM2-H3-HP' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H4-HPK", "rows": [24], "type": "MISSING_ITEM", "message": "Dòng 24: mã 'GM2-H4-HPK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-H5-H9", "rows": [25], "type": "MISSING_ITEM", "message": "Dòng 25: mã 'GM2-H5-H9' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H4-H9-3TK", "rows": [26], "type": "MISSING_ITEM", "message": "Dòng 26: mã 'GM4-H4-H9-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H4-HPK-3TK", "rows": [27], "type": "MISSING_ITEM", "message": "Dòng 27: mã 'GM4-H4-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H4K-H9-3TK", "rows": [28], "type": "MISSING_ITEM", "message": "Dòng 28: mã 'GM4-H4K-H9-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H4-H1-3TK", "rows": [29], "type": "MISSING_ITEM", "message": "Dòng 29: mã 'GM4-H4-H1-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H4K-HPK-3TK", "rows": [30], "type": "MISSING_ITEM", "message": "Dòng 30: mã 'GM4-H4K-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H3-H9-3TK", "rows": [31], "type": "MISSING_ITEM", "message": "Dòng 31: mã 'GM4-H3-H9-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H3-H1-3TK", "rows": [32], "type": "MISSING_ITEM", "message": "Dòng 32: mã 'GM4-H3-H1-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H3-HPK-3TK", "rows": [33], "type": "MISSING_ITEM", "message": "Dòng 33: mã 'GM4-H3-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H2-H9-3TK", "rows": [34], "type": "MISSING_ITEM", "message": "Dòng 34: mã 'GM4-H2-H9-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H2-HPK-3TK", "rows": [35], "type": "MISSING_ITEM", "message": "Dòng 35: mã 'GM4-H2-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H5-H9-TK", "rows": [36], "type": "MISSING_ITEM", "message": "Dòng 36: mã 'GM4-H5-H9-TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H5-HPK-3TK", "rows": [37], "type": "MISSING_ITEM", "message": "Dòng 37: mã 'GM4-H5-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H7-H9-3TK", "rows": [38], "type": "MISSING_ITEM", "message": "Dòng 38: mã 'GM4-H7-H9-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H7-HPK-3TK", "rows": [39], "type": "MISSING_ITEM", "message": "Dòng 39: mã 'GM4-H7-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H8-H9-3TK", "rows": [40], "type": "MISSING_ITEM", "message": "Dòng 40: mã 'GM4-H8-H9-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-H8-HPK-3TK", "rows": [41], "type": "MISSING_ITEM", "message": "Dòng 41: mã 'GM4-H8-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM1-HPK-3TK", "rows": [42], "type": "MISSING_ITEM", "message": "Dòng 42: mã 'GM1-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-HPK-3TK", "rows": [43], "type": "MISSING_ITEM", "message": "Dòng 43: mã 'GM2-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM4-HPK-HPK-3TK", "rows": [44], "type": "MISSING_ITEM", "message": "Dòng 44: mã 'GM4-HPK-HPK-3TK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "GM2-HPK-2VK", "rows": [45], "type": "MISSING_ITEM", "message": "Dòng 45: mã 'GM2-HPK-2VK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "CS1-H10", "rows": [46], "type": "MISSING_ITEM", "message": "Dòng 46: mã 'CS1-H10' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "CS1-HPK", "rows": [47], "type": "MISSING_ITEM", "message": "Dòng 47: mã 'CS1-HPK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "CS2-H10", "rows": [48], "type": "MISSING_ITEM", "message": "Dòng 48: mã 'CS2-H10' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "CS3-H10", "rows": [49], "type": "MISSING_ITEM", "message": "Dòng 49: mã 'CS3-H10' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "CS2-HPK", "rows": [51], "type": "MISSING_ITEM", "message": "Dòng 51: mã 'CS2-HPK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "CS3-HPK", "rows": [52], "type": "MISSING_ITEM", "message": "Dòng 52: mã 'CS3-HPK' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Ô thoáng hộp 30x60", "rows": [55], "type": "MISSING_ITEM", "message": "Dòng 55: mã 'Ô thoáng hộp 30x60' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Ô thoáng nẹp cài 10x60", "rows": [56], "type": "MISSING_ITEM", "message": "Dòng 56: mã 'Ô thoáng nẹp cài 10x60' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Ô thoáng nan chớp", "rows": [57], "type": "MISSING_ITEM", "message": "Dòng 57: mã 'Ô thoáng nan chớp' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Ô thoáng pano đặc", "rows": [58], "type": "MISSING_ITEM", "message": "Dòng 58: mã 'Ô thoáng pano đặc' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "kính ô thoáng", "rows": [59], "type": "MISSING_ITEM", "message": "Dòng 59: mã 'kính ô thoáng' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Ô thoáng Vòm", "rows": [60], "type": "MISSING_ITEM", "message": "Dòng 60: mã 'Ô thoáng Vòm' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khuôn kép ( từ 180 đến\\n250mm)", "rows": [61], "type": "MISSING_ITEM", "message": "Dòng 61: mã 'Khuôn kép ( từ 180 đến\\n250mm)' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Kính tròn bán nguyệt", "rows": [62], "type": "MISSING_ITEM", "message": "Dòng 62: mã 'Kính tròn bán nguyệt' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Kính cường lực 170x1720", "rows": [63], "type": "MISSING_ITEM", "message": "Dòng 63: mã 'Kính cường lực 170x1720' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "KÍNH TRÊN CÁNH", "rows": [64], "type": "MISSING_ITEM", "message": "Dòng 64: mã 'KÍNH TRÊN CÁNH' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Kính cường lực 250x1720", "rows": [65], "type": "MISSING_ITEM", "message": "Dòng 65: mã 'Kính cường lực 250x1720' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Phào biệt thự 120    PB -120", "rows": [66], "type": "MISSING_ITEM", "message": "Dòng 66: mã 'Phào biệt thự 120    PB -120' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Phào biệt thự đứng 260", "rows": [67], "type": "MISSING_ITEM", "message": "Dòng 67: mã 'Phào biệt thự đứng 260' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Phào biệt thự ngang 260", "rows": [68], "type": "MISSING_ITEM", "message": "Dòng 68: mã 'Phào biệt thự ngang 260' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Phào biệt thự đỉnh200", "rows": [69], "type": "MISSING_ITEM", "message": "Dòng 69: mã 'Phào biệt thự đỉnh200' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Phào biệt thự đứng 200", "rows": [70], "type": "MISSING_ITEM", "message": "Dòng 70: mã 'Phào biệt thự đứng 200' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Phào biệt thự ngang200", "rows": [71], "type": "MISSING_ITEM", "message": "Dòng 71: mã 'Phào biệt thự ngang200' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Phào biệt thự đỉnh150", "rows": [72], "type": "MISSING_ITEM", "message": "Dòng 72: mã 'Phào biệt thự đỉnh150' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khóa GM 200", "rows": [73], "type": "MISSING_ITEM", "message": "Dòng 73: mã 'Khóa GM 200' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khóa GM 330", "rows": [74], "type": "MISSING_ITEM", "message": "Dòng 74: mã 'Khóa GM 330' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khóa GM 400", "rows": [75], "type": "MISSING_ITEM", "message": "Dòng 75: mã 'Khóa GM 400' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khóa GM 600", "rows": [76], "type": "MISSING_ITEM", "message": "Dòng 76: mã 'Khóa GM 600' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khóa tay trúc GM800", "rows": [77], "type": "MISSING_ITEM", "message": "Dòng 77: mã 'Khóa tay trúc GM800' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khoá inox 4 chốt tròn K02", "rows": [78], "type": "MISSING_ITEM", "message": "Dòng 78: mã 'Khoá inox 4 chốt tròn K02' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Tay nắm giả khóa inox 4\\nchốt tròn K02", "rows": [79], "type": "MISSING_ITEM", "message": "Dòng 79: mã 'Tay nắm giả khóa inox 4\\nchốt tròn K02' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khoét khóa", "rows": [80], "type": "MISSING_ITEM", "message": "Dòng 80: mã 'Khoét khóa' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Doorsilk Inox 201", "rows": [81], "type": "MISSING_ITEM", "message": "Dòng 81: mã 'Doorsilk Inox 201' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Doorsilk Inox 304", "rows": [82], "type": "MISSING_ITEM", "message": "Dòng 82: mã 'Doorsilk Inox 304' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Mắt thần", "rows": [83], "type": "MISSING_ITEM", "message": "Dòng 83: mã 'Mắt thần' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Bản lề sàn thủy lực", "rows": [84], "type": "MISSING_ITEM", "message": "Dòng 84: mã 'Bản lề sàn thủy lực' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khóa sàn nổi ngoài cánh", "rows": [85], "type": "MISSING_ITEM", "message": "Dòng 85: mã 'Khóa sàn nổi ngoài cánh' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Khóa sàn âm trong cánh", "rows": [86], "type": "MISSING_ITEM", "message": "Dòng 86: mã 'Khóa sàn âm trong cánh' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Tay nắm cửa thủy lực", "rows": [87], "type": "MISSING_ITEM", "message": "Dòng 87: mã 'Tay nắm cửa thủy lực' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}, {"code": "Tay co thủy lực", "rows": [88], "type": "MISSING_ITEM", "message": "Dòng 88: mã 'Tay co thủy lực' chưa có trong Danh mục hàng hóa. Hệ thống không tự tạo mã mới từ file đơn giá."}]	2026-09-22 06:13:07.714
2	đơn giá , đơn vị tính, màu.xlsx	22ac2f7359823a19ca70796e796e991c31b131b06ef13be5945f0fa1a0cb5961	danh mục hàng hóa	87	422	320	32	1	[{"code": "CS4-HPK", "rows": [50, 53], "type": "DUPLICATE_PRICE_CODE", "message": "Mã 'CS4-HPK' xuất hiện nhiều lần với ĐVT hoặc giá khác nhau ở dòng 50, 53. Hệ thống không tự chọn và sẽ bỏ qua mã này."}]	2026-09-22 06:57:08.769
\.


--
-- Data for Name: item_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_categories (id, code, name, usage, separate_group, sort_order, active, created_at, updated_at) FROM stdin;
2	ACCESSORY	Phụ kiện	DETAIL	f	20	t	2026-09-26 04:16:47.016	2026-09-26 04:16:47.016
3	PROCESSING	Chi phí gia công	DETAIL	t	30	t	2026-09-26 04:16:47.016	2026-09-26 04:16:47.016
1	DOOR	Cửa	MAIN	f	10	t	2026-09-26 04:16:47.016	2026-09-26 04:17:12.547
\.


--
-- Data for Name: item_master_imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_master_imports (id, file_name, file_hash, sheet_name, total_rows, new_count, changed_count, unchanged_count, skipped_count, error_count, issues, imported_at) FROM stdin;
3	danh muc hang hoa.xlsx	6315c1ffbb1d157e7eb94c7381310abc11815b9a1e3f5e9581a161fd22cfe4f2	danh mục hàng hóa	86	86	0	0	0	0	[]	2026-09-22 10:02:46.539
\.


--
-- Data for Name: item_masters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_masters (id, code, name, active, source, last_source_file, last_imported_at, created_at, updated_at, dealer_price, price_imported_at, price_source_file, unit, sales_name, sales_model, retail_price, product_description, category) FROM stdin;
824	PR	Phào Rời	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-26 07:11:49.334	70000.00	\N	\N	Md	Phào Rời	PR	94500.00	Phào mặt trong	ACCESSORY
814	Ô thoáng pano đặc	Ô Thoáng	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:27:52.543	350000.00	\N	\N	Ô	Ô Thoáng	Ô thoáng pano đặc	472500.00	Ô thoáng pano đặc	ACCESSORY
836	Bản lề sàn thủy lực	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:40:05.208	2026-09-25 00:16:39.626	\N	\N	\N	Bộ	Khóa	Bản lề sàn thủy lực	\N	Bản lề sàn thủy lực	ACCESSORY
804	Khóa tay trúc GM805	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:16:56.457	1100000.00	\N	\N	Bộ	Khóa	Khóa tay trúc GM805	2940000.00	Khóa tay trúc GM805	ACCESSORY
801	Khóa GM 330	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:17:14	770000.00	\N	\N	Bộ	Khóa	Khóa GM 330	1365000.00	Khóa GM 330	ACCESSORY
799	Khóa HH5810	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:17:51.804	550000.00	\N	\N	Bộ	Khóa	Khóa HH5810	682500.00	Khóa HH5810	ACCESSORY
800	Khóa HH8510	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:18:05.935	850000.00	\N	\N	Bộ	Khóa	Khóa HH8510	1312500.00	Khóa HH8510	ACCESSORY
805	Khóa hợp kim GM801	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:18:17.557	1000000.00	\N	\N	Bộ	Khóa	Khóa hợp kim GM801	2625000.00	Khóa hợp kim GM801	ACCESSORY
806	Khoá inox 4 chốt tròn K02	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:18:29.045	750000.00	\N	\N	Bộ	Khóa	Khoá inox 4 chốt tròn K02	1470000.00	Khoá inox 4 chốt tròn K02	ACCESSORY
839	Khóa sàn âm trong cánh	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:40:38.887	2026-09-25 00:37:40.793	600000.00	\N	\N	Bộ	Khóa	Khóa sàn âm trong cánh	\N	Khóa sàn âm trong cánh	ACCESSORY
840	Khóa sàn nổi ngoài cánh	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:40:47.797	2026-09-25 00:38:07.477	400000.00	\N	\N	Bộ	Khóa	Khóa sàn nổi ngoài cánh	\N	Khóa sàn nổi ngoài cánh	ACCESSORY
837	Doorsilk Inox 201	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:40:18.868	2026-09-25 00:40:19.585	200000.00	\N	\N	Bộ	Khóa	Doorsilk Inox 201	\N	Doorsilk Inox 201	ACCESSORY
838	Doorsilk Inox 304	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:40:28.966	2026-09-25 00:40:42.174	220000.00	\N	\N	Bộ	Khóa	Doorsilk Inox 304	\N	Doorsilk Inox 304	ACCESSORY
834	Cửa vòm	Vòm	t	THU_CONG	\N	\N	2026-09-22 12:46:53.189	2026-09-25 01:14:20.439	450000.00	\N	\N	m2	Vòm	Cửa vòm	682500.00	Cửa vòm	ACCESSORY
817	Khuôn biệt thự trụ đứng 300	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 01:51:19.065	\N	\N	\N	Md	Phào Biệt Thự	Khuôn biệt thự trụ đứng 300	\N	Khuôn biệt thự trụ đứng 300mm	ACCESSORY
788	CS1-H10	Cửa Sổ	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:11:34.186	3150000.00	\N	\N	m2	Cửa Sổ	CS1-H10	4536000.00	Cửa Sổ	DOOR
789	CS1-HPK	Cửa Sổ	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:11:38.223	3150000.00	\N	\N	m2	Cửa Sổ	CS1-HPK	4536000.00	Cửa Sổ	DOOR
830	Ô thoáng nan chớp	Ô Thoáng	t	THU_CONG	\N	\N	2026-09-22 12:35:13.771	2026-09-22 13:27:30.19	350000.00	\N	\N	Ô	Ô Thoáng	Ô thoáng nan chớp	420000.00	Ô thoáng nan chớp	ACCESSORY
832	Ô thoáng hộp 30x60	Ô Thoáng	t	THU_CONG	\N	\N	2026-09-22 12:36:08.537	2026-09-22 13:27:44.409	150000.00	\N	\N	Ô	Ô Thoáng	Ô thoáng hộp 30x60	\N	Ô thoáng hộp 30x60	ACCESSORY
833	Song tròn Ø27 hoặc vuông 30x30 trên ô thoáng	Song Tròn	t	THU_CONG	\N	\N	2026-09-22 12:39:12.574	2026-09-22 13:30:03.822	55000.00	\N	\N	Md	Song Tròn	Song tròn Ø27 hoặc vuông 30x30 trên ô thoáng	73500.00	Song tròn Ø27 hoặc vuông 30x30 trên ô thoáng	ACCESSORY
821	Phào biệt thự 120	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:45:50.71	250000.00	\N	\N	Md	Phào Biệt Thự	Phào biệt thự 120	472500.00	Khuôn biệt thự 120	ACCESSORY
818	Phào biệt thự đỉnh150	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:45:58.542	500000.00	\N	\N	Md	Phào Biệt Thự	Phào biệt thự đỉnh150	819000.00	Khuôn biệt thự đỉnh 150mm	ACCESSORY
798	Khóa GM 205	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:16:25.2	480000.00	\N	\N	Bộ	Khóa	Khóa GM 205	840000.00	Khóa GM 205	ACCESSORY
802	Khóa GM 400	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:17:25.818	2300000.00	\N	\N	Bộ	Khóa	Khóa GM 400	4725000.00	Khóa GM 400	ACCESSORY
803	Khóa GM 600	Khóa	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:17:37.638	4800000.00	\N	\N	Bộ	Khóa	Khóa GM 600	7875000.00	Khóa GM 600	ACCESSORY
841	Khoét khóa	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:41:03.225	2026-09-25 00:38:40.188	100000.00	\N	\N	Bộ	Khóa	Khoét khóa	\N	Khoét khóa	ACCESSORY
842	Mắt thần	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:41:17.35	2026-09-25 00:39:04.774	75000.00	\N	\N	Bộ	Khóa	Mắt thần	\N	Mắt thần	ACCESSORY
843	Tay co thủy lực	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:41:28.504	2026-09-25 00:39:20.033	350000.00	\N	\N	Bộ	Khóa	Tay co thủy lực	\N	Tay co thủy lực	ACCESSORY
844	Tay nắm cửa thủy lực	Khóa	t	THU_CONG	\N	\N	2026-09-22 13:41:38.887	2026-09-25 00:39:42.592	1000000.00	\N	\N	Bộ	Khóa	Tay nắm cửa thủy lực	\N	Tay nắm cửa thủy lực	ACCESSORY
847	Phào biệt thự đứng 200	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 13:45:01.47	2026-09-25 00:41:06.367	550000.00	\N	\N	Md	Phào Biệt Thự	Phào biệt thự đứng 200	\N	Phào biệt thự đứng 200	ACCESSORY
848	Phào biệt thự ngang 260	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 13:45:15.133	2026-09-25 00:41:36.998	600000.00	\N	\N	Md	Phào Biệt Thự	Phào biệt thự ngang 260	\N	Phào biệt thự ngang 260	ACCESSORY
846	Ô thoáng Vòm	Ô Thoáng	t	THU_CONG	\N	\N	2026-09-22 13:43:06.177	2026-09-25 00:44:47.41	350000.00	\N	\N	m2	Ô Thoáng	Ô thoáng Vòm	\N	Ô thoáng Vòm	ACCESSORY
845	Ô thoáng nẹp cài 10x60	Ô Thoáng	t	THU_CONG	\N	\N	2026-09-22 13:42:55.368	2026-09-25 00:45:11.786	50000.00	\N	\N	Ô	Ô Thoáng	Ô thoáng nẹp cài 10x60	\N	Ô thoáng nẹp cài 10x60	ACCESSORY
831	Ô Thoáng Kính	Ô Thoáng	t	THU_CONG	\N	\N	2026-09-22 12:35:34.676	2026-09-25 01:08:19.653	90000.00	\N	\N	Ô	Ô Thoáng	Ô Thoáng Kính	\N	Ô Thoáng Kính	ACCESSORY
850	Khuôn biệt thự trụ ngang 200	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-25 01:48:35.097	2026-09-25 01:48:35.097	\N	\N	\N	Md	Phào Biệt Thự	Khuôn biệt thự trụ ngang 200	\N	Khuôn biệt thự trụ ngang 200mm	ACCESSORY
819	Khuôn biệt thự trụ đứng 260	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 01:49:13.093	\N	\N	\N	Md	Phào Biệt Thự	Khuôn biệt thự trụ đứng 260	\N	Khuôn biệt thự trụ đứng 260mm	ACCESSORY
820	Khuôn biệt thự trụ đứng 200	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 01:50:42.563	580000.00	\N	\N	Md	Phào Biệt Thự	Khuôn biệt thự trụ đứng 200	871500.00	Khuôn biệt thự trụ đứng 200mm	ACCESSORY
823	Phào biệt thự đỉnh 200	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 01:50:54.312	580000.00	\N	\N	Md	Phào Biệt Thự	Phào biệt thự đỉnh 200	871500.00	Khuôn biệt thự đỉnh  200mm	ACCESSORY
851	Khuôn biệt thự trụ ngang 300	Phào Biệt Thự	t	THU_CONG	\N	\N	2026-09-25 01:51:41.542	2026-09-25 01:51:41.542	\N	\N	\N	\N	Phào Biệt Thự	Khuôn biệt thự trụ ngang 300	\N	Khuôn biệt thự trụ ngang 300mm	ACCESSORY
790	CS2-H10	Cửa Sổ	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:11:42.344	2950000.00	\N	\N	m2	Cửa Sổ	CS2-H10	4305000.00	Cửa Sổ	DOOR
791	CS2-HPK	Cửa Sổ	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:11:46.501	3050000.00	\N	\N	m2	Cửa Sổ	CS2-HPK	4462500.00	Cửa Sổ	DOOR
746	GM1-H3	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:33.646	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H3	2887500.00	Cửa Đi 1 Cánh	DOOR
749	GM1-H6	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:42.901	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H6	2887500.00	Cửa Đi 1 Cánh	DOOR
794	CS4-L-H10-HPK-3PN	Cửa Sổ	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:12:02.907	3050000.00	\N	\N	m2	Cửa Sổ	CS4-L-H10-HPK-3PN	4462500.00	Cửa Sổ	DOOR
768	GM4-H1-H1	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:27.917	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H1-H1	3360000.00	Cửa Đi 4 Cánh	DOOR
769	GM4-H2-H9	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:31.834	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H2-H9	3360000.00	Cửa Đi 4 Cánh	DOOR
771	GM4-H3-H1	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:38.852	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H3-H1	3360000.00	Cửa Đi 4 Cánh	DOOR
751	GM1-H8	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:51.508	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H8	2887500.00	Cửa Đi 1 Cánh	DOOR
752	GM1-HP	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:54.959	1860000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-HP	2625000.00	Cửa Đi 1 Cánh	DOOR
753	GM1-HPD	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:58.054	1860000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-HPD	2625000.00	Cửa Đi 1 Cánh	DOOR
757	GM2-Đ-H3-2NC	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:06.535	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-Đ-H3-2NC	3250000.00	Cửa Đi 2 Cánh	DOOR
759	GM2-Đ-H4'-2TK	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:11.029	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-Đ-H4'-2TK	3250000.00	Cửa Đi 2 Cánh	DOOR
756	GM2-H2	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:20.445	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H2	3250000.00	Cửa Đi 2 Cánh	DOOR
773	GM4-H4-H1	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:42.244	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H4-H1	3360000.00	Cửa Đi 4 Cánh	DOOR
761	GM2-H5	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:32.92	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H5	3250000.00	Cửa Đi 2 Cánh	DOOR
764	GM2-H7	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:43.402	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H7	3250000.00	Cửa Đi 2 Cánh	DOOR
765	GM2-H8	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:47.653	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H8	3250000.00	Cửa Đi 2 Cánh	DOOR
766	GM2-HP	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:56.03	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-HP	3250000.00	Cửa Đi 2 Cánh	DOOR
775	GM4-H4-HPK	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:45.869	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H4-HPK	3360000.00	Cửa Đi 4 Cánh	DOOR
777	GM4-H4K-HPK	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:56.403	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H4K-HPK	3360000.00	Cửa Đi 4 Cánh	DOOR
778	GM4-H5-H9	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:19:00.349	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H5-H9	3360000.00	Cửa Đi 4 Cánh	DOOR
779	GM4-H5-HPK	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:19:04.446	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H5-HPK	3360000.00	Cửa Đi 4 Cánh	DOOR
780	GM4-H7-H9	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:19:08.261	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H7-H9	3360000.00	Cửa Đi 4 Cánh	DOOR
781	GM4-H7-HPK	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:19:13.146	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H7-HPK	3360000.00	Cửa Đi 4 Cánh	DOOR
782	GM4-H8-H9	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:19:20.42	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H8-H9	3360000.00	Cửa Đi 4 Cánh	DOOR
783	GM4-H8-HPK	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:19:26.088	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H8-HPK	3360000.00	Cửa Đi 4 Cánh	DOOR
774	GM4-L-H3-H9-3PN	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:19:30.464	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-L-H3-H9-3PN	3360000.00	Cửa Đi 4 Cánh	DOOR
785	GM2-HPK	Cửa Đi Cánh Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 01:00:47.931	2250000.00	\N	\N	m2	Cửa Đi Cánh Kính	GM2-HPK	3423000.00	Cửa Đi Cánh Kính	DOOR
787	GM2-Đ-HPK-VK-2TK	Cửa Đi Vách Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 01:01:23.104	2250000.00	\N	\N	m2	Cửa Đi Vách Kính	GM2-Đ-HPK-VK-2TK	3423000.00	Cửa Đi Vách Kính	DOOR
786	GM4-HPK-HPK	Cửa Đi Cánh Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 01:04:09.633	2250000.00	\N	\N	m2	Cửa Đi Cánh Kính	GM4-HPK-HPK	3423000.00	Cửa Đi Cánh Kính	DOOR
772	LX4-L-H3-HPK-3TK	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:10:35.903	2360000.00	\N	\N	m2	Cửa Đi 4 Cánh	LX4-L-H3-HPK-3TK	3528000.00	Cửa Đi 4 Cánh	DOOR
792	CS3-H10	Cửa Sổ	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:11:51.699	2950000.00	\N	\N	m2	Cửa Sổ	CS3-H10	4305000.00	Cửa Sổ	DOOR
793	CS3-HPK	Cửa Sổ	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:11:56.766	3050000.00	\N	\N	m2	Cửa Sổ	CS3-HPK	4462500.00	Cửa Sổ	DOOR
770	GM4-H2-HPK	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:35.405	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H2-HPK	3360000.00	Cửa Đi 4 Cánh	DOOR
776	GM4-H4K-H9	Cửa Đi 4 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:18:52.919	2160000.00	\N	\N	m2	Cửa Đi 4 Cánh	GM4-H4K-H9	3360000.00	Cửa Đi 4 Cánh	DOOR
744	GM1-H1	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:24.676	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H1	2887500.00	Cửa Đi 1 Cánh	DOOR
745	GM1-H2	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:29.438	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H2	2887500.00	Cửa Đi 1 Cánh	DOOR
747	GM1-H4	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:36.859	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H4	2887500.00	Cửa Đi 1 Cánh	DOOR
748	GM1-H5-1NC	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:39.876	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H5-1NC	2887500.00	Cửa Đi 1 Cánh	DOOR
750	GM1-H7	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:07:47.723	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-H7	2887500.00	Cửa Đi 1 Cánh	DOOR
754	GM1-HTD	Cửa Đi 1 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:01.516	1960000.00	\N	\N	m2	Cửa Đi 1 Cánh	GM1-HTD	2887500.00	Cửa Đi 1 Cánh	DOOR
755	GM2-H1	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:17.164	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H1	3250000.00	Cửa Đi 2 Cánh	DOOR
758	GM2-H3-HP	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:25.541	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H3-HP	3250000.00	Cửa Đi 2 Cánh	DOOR
760	GM2-H4-HPK	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:29.723	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H4-HPK	3250000.00	Cửa Đi 2 Cánh	DOOR
762	GM2-H5-H9	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:36.126	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H5-H9	3250000.00	Cửa Đi 2 Cánh	DOOR
763	GM2-H6	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:39.765	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-H6	3250000.00	Cửa Đi 2 Cánh	DOOR
767	GM2-HTD	Cửa Đi 2 Cánh	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:08:51.756	2060000.00	\N	\N	m2	Cửa Đi 2 Cánh	GM2-HTD	3250000.00	Cửa Đi 2 Cánh	DOOR
784	GM1-HPK	Cửa Đi Cánh Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:52:57.41	2250000.00	\N	\N	m2	Cửa Đi Cánh Kính	GM1-HPK	3423000.00	Cửa Đi Cánh Kính	DOOR
825	Kính tròn bán nguyệt	Gia Công Ô Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:25:53.177	400000.00	\N	\N	Tấm	Gia Công Ô Kính	Kính tròn bán nguyệt	472500.00	Kính tròn bán nguyệt	PROCESSING
826	Kính cường lực 170x1720	Gia Công Ô Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:47:47.097	250000.00	\N	\N	Tấm	Gia Công Ô Kính	Kính cường lực 170x1720	367500.00	Kính cường lực 170x1720 lắp trên cánh phụ	PROCESSING
827	Kính cường lực 250x1720	Gia Công Ô Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-22 13:47:55.247	250000.00	\N	\N	Tấm	Gia Công Ô Kính	Kính cường lực 250x1720	472500.00	Kính cường lực 250x1720 lắp trên cánh phụ	PROCESSING
828	Kính cường lực xanh đen trên cánh  phụ	Gia Công Ô Kính	t	THU_CONG	\N	\N	2026-09-22 10:02:46.51	2026-09-25 00:48:13.674	400000.00	\N	\N	Tấm	Gia Công Ô Kính	Kính cường lực xanh đen trên cánh  phụ	500000.00	Kính cường lực xanh đen trên cánh  phụ	PROCESSING
\.


--
-- Data for Name: master_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_options (id, group_code, code, name, sort_order, active, source, last_source_file, last_imported_at, created_at, updated_at) FROM stdin;
2	PANEL_OPTION	2TK	2TK	20	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.637	2026-09-22 06:57:08.716
3	PANEL_OPTION	3TK	3TK	30	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.64	2026-09-22 06:57:08.718
4	PANEL_OPTION	4TK	4TK	40	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.642	2026-09-22 06:57:08.72
5	PANEL_OPTION	1NC	1NC	50	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.645	2026-09-22 06:57:08.721
6	PANEL_OPTION	2NC	2NC	60	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.647	2026-09-22 06:57:08.723
7	PANEL_OPTION	3NC	3NC	70	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.649	2026-09-22 06:57:08.724
8	PANEL_OPTION	4NC	4NC	80	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.652	2026-09-22 06:57:08.725
9	PANEL_OPTION	1PN	1PN	90	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.655	2026-09-22 06:57:08.727
10	PANEL_OPTION	2PN	2PN	100	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.657	2026-09-22 06:57:08.729
11	PANEL_OPTION	3PN	3PN	110	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.659	2026-09-22 06:57:08.731
12	PANEL_OPTION	4PN	4PN	120	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.662	2026-09-22 06:57:08.732
13	OPENING_DIRECTION	TP	TP	10	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.664	2026-09-22 06:57:08.734
14	OPENING_DIRECTION	TT	TT	20	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.666	2026-09-22 06:57:08.736
15	OPENING_DIRECTION	NP	NP	30	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.669	2026-09-22 06:57:08.738
16	OPENING_DIRECTION	NT	NT	40	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.672	2026-09-22 06:57:08.739
17	TRIM_DIRECTION	Thuận	Thuận	10	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.674	2026-09-22 06:57:08.741
19	TRIM_DIRECTION	Vuông	Vuông	30	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.679	2026-09-22 06:57:08.744
20	PAINT_COLOR	GM-01	GM-01	10	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.681	2026-09-22 06:57:08.745
21	PAINT_COLOR	GM-02	GM-02	20	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.683	2026-09-22 06:57:08.747
22	PAINT_COLOR	GM-03	GM-03	30	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.686	2026-09-22 06:57:08.748
23	PAINT_COLOR	GM-04	GM-04	40	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.688	2026-09-22 06:57:08.75
24	PAINT_COLOR	GM-05	GM-05	50	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.693	2026-09-22 06:57:08.751
25	PAINT_COLOR	GM-06	GM-06	60	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.695	2026-09-22 06:57:08.753
26	PAINT_COLOR	GM-07	GM-07	70	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.697	2026-09-22 06:57:08.755
18	TRIM_DIRECTION	Nghịch	Nghịch	20	t	THU_CONG	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.677	2026-09-22 13:32:29.203
1	PANEL_OPTION	1TK	1TK	10	t	THU_CONG	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.63	2026-09-22 13:33:32.121
27	PAINT_COLOR	GM-08	GM-08	80	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.699	2026-09-22 06:57:08.757
28	PAINT_COLOR	GM-09	GM-09	90	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.702	2026-09-22 06:57:08.759
29	PAINT_COLOR	GM-10	GM-10	100	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.705	2026-09-22 06:57:08.761
30	PAINT_COLOR	GM-11	GM-11	110	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.706	2026-09-22 06:57:08.763
31	PAINT_COLOR	GM-12	GM-12	120	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.708	2026-09-22 06:57:08.764
32	PAINT_COLOR	GM-14	GM-14	130	t	EXCEL_DON_GIA	đơn giá , đơn vị tính, màu.xlsx	2026-09-22 06:57:07.909	2026-09-22 06:13:07.71	2026-09-22 06:57:08.766
65	DEALER_CODE	DL01	Đại Lý 01	0	t	THU_CONG	\N	\N	2026-09-23 13:13:07.591	2026-09-23 13:13:07.591
\.


--
-- Data for Name: order_imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_imports (id, order_id, file_name, file_hash, action, sheet_name, imported_items, imported_at) FROM stdin;
1	\N	Đơn hàng.xlsx	d56495fb4b930c1e8a80c65f3a3df5f61a950d0a160d8142b406ad8d65f75eef	CREATED	 Đơn đặt hàng mẫu	5	2026-09-22 04:34:46.071
2	\N	Đơn hàng.xlsx	d56495fb4b930c1e8a80c65f3a3df5f61a950d0a160d8142b406ad8d65f75eef	REBUILT_DETAILS	 Đơn đặt hàng mẫu	5	2026-09-22 05:47:02.102
3	\N	Copy of 24121441-VVP025 DH709.xlsx	59e8fad22127a7a5517e4ce4f31f0435bbced29b98210c0b08c98a0b1fa858bc	CREATED	 Đơn đặt hàng mẫu	5	2026-09-22 07:35:39.378
4	\N	Copy of 24121441-VVP025 DH709.xlsx	59e8fad22127a7a5517e4ce4f31f0435bbced29b98210c0b08c98a0b1fa858bc	CREATED	 Đơn đặt hàng mẫu	5	2026-09-22 07:36:56.53
\.


--
-- Data for Name: production_calendar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_calendar (id, date, is_working_day, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: production_component_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_component_orders (id, set_id, kind, qty_expected, note, created_at, updated_at) FROM stdin;
1	17	CANH	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
2	17	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
3	17	PHAO	7	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
4	18	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
5	18	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
6	18	PHAO	5	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
7	19	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
8	19	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
9	19	PHAO	5	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
10	20	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
11	20	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
12	20	PHAO	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
13	21	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
14	21	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
15	21	PHAO	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
16	22	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
17	22	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
18	22	PHAO	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
19	23	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
20	23	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
21	23	PHAO	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
22	24	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
23	24	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
24	24	PHAO	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
25	25	CANH	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
26	25	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
27	25	PHAO	7	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
28	26	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
29	26	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
30	26	PHAO	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
31	27	CANH	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
32	27	KHUNG	1	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
33	27	PHAO	4	\N	2026-09-26 07:59:31.699	2026-09-26 07:59:31.699
\.


--
-- Data for Name: production_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_logs (id, entity, entity_id, action, field, old_value, new_value, by_name, created_at) FROM stdin;
1	TASK	49	DOI_TRANG_THAI	status	CHUA_LAM	XONG	\N	2026-09-26 08:04:29.559
2	TASK	50	DOI_TRANG_THAI	status	CHUA_LAM	XONG	\N	2026-09-26 08:04:37.881
\.


--
-- Data for Name: production_machine_downtimes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_machine_downtimes (id, work_center_code, machine, from_at, to_at, reason_code, note, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: production_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_plans (id, code, from_date, to_date, status, created_by, approved_by, approved_at, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: production_programs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_programs (id, model, file_name, version, machine, made_by, made_at, duration_minutes, reusable, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: production_reasons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_reasons (id, code, name, "group", sort_order, active, created_at, updated_at) FROM stdin;
1	CHO_PHOI	Chờ phôi / chờ nhôm	TAM_DUNG	10	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
2	CHO_CHUONG_TRINH	Chờ chương trình máy cắt (Bồi Lares)	TAM_DUNG	20	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
3	CHO_LO_SON	Chờ lô sơn (chưa đủ 20 cánh cùng màu)	TAM_DUNG	30	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
4	CHO_KINH_NGOAI	Chờ kính đặt ngoài	TAM_DUNG	40	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
5	CHO_HAN_NGOAI	Chờ hàn thuê ngoài	TAM_DUNG	50	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
6	KHACH_DOI	Khách đổi kích thước / màu / số lượng	TAM_DUNG	60	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
7	THIEU_NGUOI	Thiếu người	TAM_DUNG	70	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
8	MAY_HONG	Máy hỏng / bảo trì	MAY_DUNG	80	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
9	KHONG_DU_CHO	Hết chỗ để hàng chờ	TAM_DUNG	90	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
10	TRE_CHO_PHOI	Trễ do chờ phôi	TRE_HAN	110	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
11	TRE_QUA_TAI	Trễ do quá tải tổ	TRE_HAN	120	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
12	TRE_NANG_SL	Trễ do nhận quá nhiều đơn	TRE_HAN	130	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
13	TRE_KHACH_DOI	Trễ do khách đổi giữa lúc sản xuất	TRE_HAN	140	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
14	LOI_MOP_MEO	Lỗi móp méo	LOI	210	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
15	LOI_HAN_SAI_VT	Lỗi hàn sai vị trí	LOI	220	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
16	LOI_SON	Lỗi sơn (chảy / bụi / lệch màu)	LOI	230	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
17	LOI_VAN	Lỗi vân (bong / lệch / xước)	LOI	240	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
18	LOI_EP_CANH	Lỗi ép cánh (bọt khí / lệch / bong)	LOI	250	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
19	PHE_PHAI_LAM_LAI	Phế — phải làm lại	LOI	260	t	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
\.


--
-- Data for Name: production_sets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_sets (id, order_id, order_item_id, order_code, set_no, order_type, customer_name, product_name, model, opening_direction, paint_color, veneer_code, height_mm, width_mm, leaves_per_set, trim_bars_per_set, quantity, pricing_quantity, canh_equivalent, due_date, plan_id, priority, status, percent_done, planned_start, planned_end, actual_completed_at, actual_delivered_at, program_ready, material_ready, pack_count, note, created_at, updated_at) FROM stdin;
17	23	94	26091802ĐL03DH01	12062	SAN_XUAT	Anh Vinh	Cửa Đi 4 Cánh	GMLUX4-L-H3-H9-3TK	NP	GM-09	\N	3195	2730	\N	\N	1	8.72235	1	2026-10-08	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
18	23	95	26091802ĐL03DH01	12063	SAN_XUAT	Anh Vinh	Cửa Sổ	CSLUX4-Đ-H10-HPK-3TK	NP	GM-09	\N	2300	2230	\N	\N	1	5.129	1	2026-10-08	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
20	23	97	26091802ĐL03DH01	12065	SAN_XUAT	Anh Vinh	Cửa Đi 1 Cánh	GM1-H5-1TK	NT	GM-09	\N	3180	990	\N	\N	1	3.1482	1	2026-10-08	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
21	23	98	26091802ĐL03DH01	12066	SAN_XUAT	Anh Vinh	Cửa Đi 1 Cánh	GM1-H5-1TK	TT	GM-09	\N	2735	900	\N	\N	1	2.4615	1	2026-10-08	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
22	23	99	26091802ĐL03DH01	12067	SAN_XUAT	Anh Vinh	Cửa Đi 1 Cánh	GM1-H5-1TK	TP	GM-09	\N	2735	900	\N	\N	1	2.4615	1	2026-10-08	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
23	23	100	26091802ĐL03DH01	12068	SAN_XUAT	Anh Vinh	Cửa Đi 1 Cánh	GM1-H5-1TK	TP	GM-09	\N	2735	900	\N	\N	1	2.4615	1	2026-10-08	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
24	13	115	26092108BN11DH02	12104	SAN_XUAT	A Luyện	Cửa Đi Vách Kính	GM2-Đ-HPK-VK-2TK	NP	GM-01	\N	2745	2635	\N	\N	1	7.233075	1	2026-10-07	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
25	16	145	26092203BG58DH03	12122	SAN_XUAT	A Hưng Phương	Cửa Đi 4 Cánh	GM4-L-H3-HPK-3TK	NP	GM-05	\N	2968	2773	\N	\N	1	8.230264	1	2026-10-15	\N	5	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
26	31	156	NHAP-20260925-115637	12125	MAU	dfgdfgg	Cửa Đi 1 Cánh	GM1-H1	TT	GM-02	\N	1111	1111	\N	\N	1	1.234321	1	2026-09-25	\N	8	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
27	32	158	NHAP-20260926-023921	12126	MAU	fsdfsdfds	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	1	2026-09-25	\N	8	CHO_XEP_LICH	0	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 07:59:31.444
19	23	96	26091802ĐL03DH01	12064	SAN_XUAT	Anh Vinh	Cửa Sổ	CSLUX2-Đ-H10-2TK	NP	GM-09	\N	2290	1350	\N	\N	1	3.0915	1	2026-10-08	\N	5	DANG_SX	10	\N	\N	\N	\N	f	f	\N	\N	2026-09-26 07:59:31.444	2026-09-26 08:04:37.651
\.


--
-- Data for Name: production_stages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_stages (id, code, name, kind, scope_mode, scope_parts, work_center_code, seq, lead_time_hours, setup_minutes, capacity_per_day, capacity_unit, batch_key, batch_min_qty, changeover_max_per_day, is_qc_point, rework_to_stage, skip_condition, requires_stage, active, note, created_at, updated_at) FROM stdin;
1	THIET_KE	Thiết kế (bản vẽ CAD)	CHUAN_BI	MODEL	\N	KY_THUAT	10	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	\N	t	Tùy model, nhiều phi tiêu chuẩn (TK2). Leader thiết kế duyệt (TK6). Đặt kính ngoài ngay sau bước này (LK6).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
3	CHO_SAU_BOI_LARES	Chờ sau Bồi Lares mới cắt được	CHO	BO	\N	\N	25	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	BOI_LARES	t	K16. Thực tế xưởng gối công đoạn 1 ngày (C6).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
4	CAT	Cắt (khung / cánh / phào)	GIA_CONG	PARTS	KHUNG,CANH,PHAO	TO_MAY	30	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	BOI_LARES	t	2 máy CNC Lares Fiber × 2 người (C1). Ba phần làm song song (C2). KHÔNG kiểm tra sau cắt (C7).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
5	CHAN	Chấn (khung / cánh / phào)	GIA_CONG	PARTS	KHUNG,CANH,PHAO	TO_MAY	40	24	5	30	CANH	MODEL	\N	2	f	\N	\N	CAT	t	Máy 1: khung+phào; máy 2: cánh+phào (CH2). 30 cánh/ca (CH7). Đổi khuôn 5 phút, ngày chỉ đổi 2 lần (CH4). Có QC, lỗi phải làm lại (CH6).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
6	HAN	Hàn + mài ba via (khung / cánh / phào)	GIA_CONG	PARTS	KHUNG,CANH,PHAO	TO_HAN	50	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	CHAN	t	8 máy MIG, 8 người, 10 phút/cánh (HAN1/HAN3). Ba phần làm ĐỘC LẬP, không cần đủ 3 phần (HAN5). Thợ hàn mài mối hàn luôn (HAN6).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
7	EP_CANH	Ép cánh (sau khi hàn cánh)	GIA_CONG	PARTS	CANH	TO_HAN	60	24	\N	95	CANH	MODEL	\N	\N	f	\N	\N	HAN	t	SAU khi hàn cánh (EP4). 1 máy: 45 phút/lượt, 9–12 cánh/lượt; 8h ép được 90–100 cánh (EP2/EP7). Chờ keo khô 45 phút. Ép lỗi → phế, làm lại (EP6).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
8	TEST_CO_KHI	Test cơ khí (QC — lắp ghép kiểm tra trước sơn)	QC	BO	\N	TO_HAN	70	48	\N	\N	CANH	\N	\N	\N	t	HAN	\N	HAN	t	Lắp ghép khung+cánh+phào kiểm tra trước sơn (TC1). Từng bộ, 20 phút/bộ, 10 bộ/người/ngày (TC2/TC6). Lỗi thường móp méo / hàn sai vị trí (TC4) → quay lại HÀN hoặc báo phế (TC5). Ghi lịch sử + chụp ảnh (TC3).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
9	CHO_TRUOC_SON	Chờ sơn (sau test cơ khí)	CHO	BO	\N	\N	75	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	TEST_CO_KHI	t	TH2: chờ tối đa 24 giờ, có chỗ để.	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
10	SON	Sơn (cả bộ 1 lượt — GATE: đủ 3 phần đã test)	GIA_CONG	BO	\N	TO_SON	80	48	120	44	CANH	MAU_SON	20	2	f	\N	\N	TEST_CO_KHI	t	A1/CH5: bộ phải đủ khung+cánh+phào đã test mới sơn. Cả bộ sơn 1 lượt (SON4). 20–25 cánh/mẻ × 2 mẻ/ngày (SON2/SON3). Đổi màu 2 giờ (SON6), gom lô màu ≥ 20 cánh (SON7), ít hàng thì chờ ghép lô (SON8). Sơn hàng ngày (SON9).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
11	CHO_KHO_SAU_SON	Chờ khô / nguội sau sơn	CHO	BO	\N	\N	85	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	SON	t	K14 CHƯA TRẢ LỜI — tạm để 24 giờ (mặc định, sửa được). SON11: sấy xong nguội mới dán vân được.	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
13	CHO_SAU_VAN	Chờ sau vân trước khi lắp kính / đóng gói	CHO	BO	\N	\N	95	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	VAN	t	K15: 24 giờ. VAN8: sau vân đem đi sấy in chuyển nhiệt.	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
15	DONG_GOI	Vệ sinh + đóng gói (mốc HOÀN THÀNH SẢN XUẤT)	GIA_CONG	BO	\N	TO_DONG_GOI	110	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	LAP_KINH	t	Xịt giấy dán film + lau chùi (KHO1). Đóng gói theo KIỆN, ~5 kiện/bộ (KHO3), 4 phút/kiện (KHO2). KHO5: đóng gói xong = HOÀN THÀNH SẢN XUẤT.	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
16	KHO_GIAO	Kho / giao hàng (đã giao khách)	GIA_CONG	BO	\N	KHO	120	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	DONG_GOI	t	GH1: ghi ngày giao thực tế. GH2: hạn giao = ngày giao tới khách. Gọi xe ghép (GH3). Không lắp đặt tại công trình (GH6). Thu tiền khi giao (GH10).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
12	VAN	Vân (dán film + sấy in chuyển nhiệt)	GIA_CONG	PARTS	KHUNG,CANH,PHAO	TO_VAN	90	48	\N	\N	CANH	\N	\N	\N	f	SON	PAINT_COLOR:11,14	SON	t	Nhà máy chốt 26/09/2026: TÁCH RIÊNG vân cho cánh, khung, phào; khi CẢ 3 phần báo xong vân trên cùng bộ mới chuyển Vệ sinh + Đóng gói. Màu sơn 11 và 14 KHÔNG cần vân (tự bỏ qua). Dán film tay, buồng sấy riêng (VAN1/VAN5). PHẢI dán đủ hoàn chỉnh trước khi sấy (VAN2). KHÔNG cần gom lô (VAN6). Vân lỗi → tẩy sơn lại (VAN10).	2026-09-26 06:52:50.885	2026-09-26 07:53:12.931
2	BOI_LARES	Bồi Lares — nạp chương trình máy cắt (CAM)	CHUAN_BI	MODEL	\N	KY_THUAT	20	24	\N	\N	CANH	MODEL	\N	\N	f	\N	\N	THIET_KE	t	Hậu thiết kế (V121). Theo model, tái dùng được: model đã có chương trình ⇒ ~0. CHẶN Cắt (BL4).	2026-09-26 06:52:50.885	2026-09-26 07:53:12.931
14	LAP_KINH	Lắp kính + phụ kiện	GIA_CONG	BO	\N	TO_DONG_GOI	100	24	\N	\N	CANH	\N	\N	\N	f	\N	\N	VAN	t	Do TỔ ĐÓNG GÓI làm (LK1) — không thuộc tổ vân. Gồm gioăng, silicon, nêm, nẹp, khoá, bản lề, tay nắm… (LK2/LK3). 20 phút/bộ (LK4). Kính đặt ngoài (LK6); thiếu kính thì bộ khác vẫn đẩy trước được (LK7). GATE: chỉ chạy khi CẢ 3 phần (cánh/khung/phào) đã xong VÂN.	2026-09-26 06:52:50.885	2026-09-26 07:53:12.931
\.


--
-- Data for Name: production_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_tasks (id, set_id, order_item_id, stage_code, stage_kind, scope, seq, work_center_code, status, qty_expected, qty_done, planned_start, planned_end, actual_start, actual_end, assignee, is_rework, rework_from_stage, reason_code, note, updated_by, created_at, updated_at) FROM stdin;
1	17	94	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
2	17	94	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
3	17	94	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
4	17	94	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
5	17	94	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
6	17	94	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
7	17	94	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
8	17	94	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
9	17	94	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
10	17	94	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
11	17	94	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
12	17	94	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
13	17	94	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
14	17	94	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
15	17	94	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
16	17	94	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
17	17	94	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
18	17	94	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
19	17	94	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
20	17	94	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
21	17	94	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
22	17	94	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
23	17	94	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
24	17	94	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
25	18	95	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
26	18	95	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
27	18	95	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
28	18	95	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
29	18	95	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
30	18	95	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
31	18	95	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
32	18	95	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
33	18	95	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
34	18	95	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
35	18	95	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
36	18	95	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
37	18	95	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
38	18	95	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
39	18	95	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
40	18	95	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
41	18	95	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
42	18	95	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
43	18	95	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
44	18	95	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
45	18	95	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
46	18	95	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
47	18	95	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
48	18	95	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
51	19	96	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
52	19	96	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
53	19	96	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
54	19	96	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
55	19	96	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
56	19	96	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
57	19	96	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
58	19	96	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
59	19	96	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
60	19	96	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
61	19	96	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
62	19	96	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
63	19	96	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
64	19	96	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
65	19	96	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
50	19	96	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	XONG	1	\N	\N	\N	2026-09-26 08:04:36.732	2026-09-26 08:04:36.732	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 08:04:37.091
66	19	96	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
67	19	96	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
68	19	96	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	5	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
69	19	96	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
70	19	96	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
71	19	96	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
72	19	96	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
73	20	97	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
74	20	97	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
75	20	97	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
76	20	97	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
77	20	97	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
78	20	97	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
79	20	97	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
80	20	97	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
81	20	97	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
82	20	97	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
83	20	97	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
84	20	97	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
85	20	97	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
86	20	97	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
87	20	97	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
88	20	97	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
89	20	97	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
90	20	97	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
91	20	97	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
92	20	97	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
93	20	97	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
94	20	97	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
95	20	97	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
96	20	97	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
97	21	98	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
98	21	98	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
99	21	98	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
100	21	98	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
101	21	98	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
102	21	98	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
103	21	98	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
104	21	98	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
105	21	98	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
106	21	98	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
107	21	98	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
108	21	98	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
109	21	98	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
110	21	98	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
111	21	98	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
112	21	98	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
113	21	98	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
114	21	98	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
115	21	98	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
116	21	98	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
117	21	98	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
118	21	98	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
119	21	98	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
120	21	98	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
121	22	99	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
122	22	99	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
123	22	99	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
124	22	99	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
125	22	99	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
126	22	99	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
127	22	99	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
128	22	99	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
129	22	99	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
130	22	99	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
131	22	99	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
132	22	99	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
133	22	99	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
134	22	99	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
135	22	99	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
136	22	99	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
137	22	99	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
138	22	99	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
139	22	99	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
140	22	99	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
141	22	99	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
142	22	99	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
143	22	99	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
144	22	99	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
145	23	100	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
146	23	100	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
147	23	100	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
148	23	100	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
149	23	100	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
150	23	100	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
151	23	100	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
152	23	100	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
153	23	100	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
154	23	100	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
155	23	100	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
156	23	100	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
157	23	100	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
158	23	100	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
159	23	100	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
160	23	100	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
161	23	100	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
162	23	100	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
163	23	100	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
164	23	100	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
165	23	100	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
166	23	100	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
167	23	100	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
168	23	100	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
169	24	115	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
170	24	115	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
171	24	115	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
172	24	115	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
173	24	115	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
174	24	115	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
175	24	115	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
176	24	115	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
177	24	115	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
178	24	115	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
179	24	115	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
180	24	115	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
181	24	115	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
182	24	115	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
183	24	115	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
184	24	115	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
185	24	115	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
186	24	115	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
187	24	115	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
188	24	115	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
189	24	115	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
190	24	115	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
191	24	115	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
192	24	115	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
193	25	145	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
194	25	145	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
195	25	145	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
196	25	145	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
197	25	145	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
198	25	145	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
199	25	145	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
200	25	145	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
201	25	145	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
202	25	145	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
203	25	145	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
204	25	145	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
205	25	145	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
206	25	145	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
207	25	145	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
208	25	145	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
209	25	145	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
210	25	145	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
211	25	145	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
212	25	145	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	7	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
213	25	145	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
214	25	145	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
215	25	145	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
216	25	145	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
217	26	156	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
218	26	156	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
219	26	156	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
220	26	156	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
221	26	156	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
222	26	156	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
223	26	156	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
224	26	156	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
225	26	156	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
226	26	156	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
227	26	156	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
228	26	156	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
229	26	156	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
230	26	156	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
231	26	156	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
232	26	156	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
233	26	156	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
234	26	156	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
235	26	156	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
236	26	156	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
237	26	156	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
238	26	156	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
239	26	156	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
240	26	156	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
241	27	158	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
242	27	158	BOI_LARES	CHUAN_BI	BO	20	KY_THUAT	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
243	27	158	CHO_SAU_BOI_LARES	CHO	BO	25	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
244	27	158	CAT	GIA_CONG	KHUNG	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
245	27	158	CAT	GIA_CONG	CANH	30	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
246	27	158	CAT	GIA_CONG	PHAO	30	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
247	27	158	CHAN	GIA_CONG	KHUNG	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
248	27	158	CHAN	GIA_CONG	CANH	40	TO_MAY	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
249	27	158	CHAN	GIA_CONG	PHAO	40	TO_MAY	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
250	27	158	HAN	GIA_CONG	KHUNG	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
251	27	158	HAN	GIA_CONG	CANH	50	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
252	27	158	HAN	GIA_CONG	PHAO	50	TO_HAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
253	27	158	EP_CANH	GIA_CONG	CANH	60	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
254	27	158	TEST_CO_KHI	QC	BO	70	TO_HAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
255	27	158	CHO_TRUOC_SON	CHO	BO	75	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
256	27	158	SON	GIA_CONG	BO	80	TO_SON	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
257	27	158	CHO_KHO_SAU_SON	CHO	BO	85	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
258	27	158	VAN	GIA_CONG	KHUNG	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
259	27	158	VAN	GIA_CONG	CANH	90	TO_VAN	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
260	27	158	VAN	GIA_CONG	PHAO	90	TO_VAN	CHUA_LAM	4	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
261	27	158	CHO_SAU_VAN	CHO	BO	95	\N	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
262	27	158	LAP_KINH	GIA_CONG	BO	100	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
263	27	158	DONG_GOI	GIA_CONG	BO	110	TO_DONG_GOI	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
264	27	158	KHO_GIAO	GIA_CONG	BO	120	KHO	CHUA_LAM	1	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 07:59:32.103
49	19	96	THIET_KE	CHUAN_BI	BO	10	KY_THUAT	XONG	1	\N	\N	\N	2026-09-26 08:04:28.393	2026-09-26 08:04:28.393	\N	f	\N	\N	\N	\N	2026-09-26 07:59:32.103	2026-09-26 08:04:28.752
\.


--
-- Data for Name: production_work_centers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_work_centers (id, code, name, kind, people_count, shifts_per_day, hours_per_shift, capacity_per_day, capacity_unit, active, sort_order, note, created_at, updated_at) FROM stdin;
1	TO_MAY	Tổ máy (Cắt + Chấn)	TO	8	2	8	60	CANH	t	10	2 máy CNC Lares Fiber × 2 người. Chấn 30 cánh/ca (CH7); 60 cánh/2 ca (TM3). Đổi khuôn 5 phút, tối đa 2 lần/ngày (CH4).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
2	TO_HAN	Tổ hàn (Hàn + Ép cánh + Test cơ khí)	TO	12	\N	8	45	CANH	t	20	8 máy MIG, 8 người; hàn 10 phút/cánh (HAN3). 1 máy ép: 45 phút/lượt, 9–12 cánh/lượt (EP2). Test 20 phút/bộ, 10 bộ/người/ngày (TC2/TC6). 45 cánh/ngày đã test đạt (TH3).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
3	TO_SON	Tổ sơn (sơn tĩnh điện, 1 lò)	TO	\N	\N	8	44	CANH	t	30	NÚT THẮT: 1 mẻ 20–25 cánh (kèm khung), 2 mẻ/ngày = 40–50 cánh (SON2/SON3). Đổi màu 2 giờ (SON6); gom lô màu tối thiểu 20 cánh (SON7).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
4	TO_VAN	Tổ vân (dán film + buồng sấy)	TO	13	\N	8	\N	CANH	t	40	Dán tay, 13 người (VAN5). CHƯA CÓ SỐ năng lực (VAN12 chưa trả lời) → để trống, app không cảnh báo quá tải tổ này.	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
5	TO_DONG_GOI	Tổ đóng gói (lắp kính + phụ kiện + vệ sinh)	TO	8	\N	8	50	CANH	t	50	8 người = 2 xịt giấy + 1 đi keo + 1 bắt phụ kiện + 4 đóng gói (LK10). Lắp kính+PK 20 phút/bộ (LK4). Đóng gói 4 phút/kiện, ~5 kiện/bộ (KHO2/KHO3).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
6	KHO	Kho / giao hàng	TO	\N	\N	8	\N	CANH	t	60	Gọi xe ghép (GH3). Giao đủ cả bộ, không giao từng phần (B7/GH5). Hàng để quá 2 tháng tính tồn kho (GH9).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
7	KY_THUAT	Kỹ thuật (Thiết kế + Bồi Lares/CAM)	VAN_PHONG	\N	\N	8	60	CANH	t	70	Kỹ sư CAD làm tại nhà máy (TK3). 1 người 1 ca 8h bồi được 60 cánh (BL3). Bồi Lares CHẶN Cắt (BL4).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
8	NGOAI	Thuê ngoài (cắt kính, hàn khung)	NGUON_LUC_NGOAI	\N	\N	\N	\N	CANH	t	80	Kính đặt ngoài ngay sau thiết kế (LK6). Có khi thuê hàn khung, gửi/nhận ≤ 3 ngày (J12).	2026-09-26 06:52:50.885	2026-09-26 06:52:50.885
\.


--
-- Data for Name: sales_order_item_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order_item_details (id, order_item_id, row_order, detail_type, set_no, product_name, product_code, model, opening_direction, trim_direction, paint_color, height_mm, width_mm, frame_mm, clear_height_mm, clear_width_mm, panel_info, trim_bars_per_set, trim_type, lock_model, window_bars, leaves_per_set, quantity, unit, pricing_quantity, unit_price, amount, note, image_path, model_check, price_check, source_row, created_at, updated_at, image_width, image_height) FROM stdin;
220	47	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2000	1620	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	7.24	70000.00	506800.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.799	2026-09-22 14:55:09.799	\N	\N
221	47	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	3	90000.00	270000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.799	2026-09-22 14:55:09.799	\N	\N
222	48	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2000	1620	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	7.24	70000.00	506800.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.808	2026-09-22 14:55:09.808	\N	\N
223	48	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	3	90000.00	270000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.808	2026-09-22 14:55:09.808	\N	\N
224	49	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	1890	1180	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.14	70000.00	429800.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.815	2026-09-22 14:55:09.815	\N	\N
225	49	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	2	90000.00	180000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.815	2026-09-22 14:55:09.815	\N	\N
226	50	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	1870	1111	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	5.962	70000.00	417340.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.823	2026-09-22 14:55:09.823	\N	\N
227	50	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	2	90000.00	180000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.823	2026-09-22 14:55:09.823	\N	\N
228	51	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2010	1380	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.78	70000.00	474600.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.831	2026-09-22 14:55:09.831	\N	\N
229	51	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	2	90000.00	180000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.831	2026-09-22 14:55:09.831	\N	\N
230	52	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2000	1380	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.76	70000.00	473200.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.84	2026-09-22 14:55:09.84	\N	\N
231	52	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	2	90000.00	180000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.84	2026-09-22 14:55:09.84	\N	\N
232	53	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2530	920	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	5.98	70000.00	418600.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.85	2026-09-22 14:55:09.85	\N	\N
233	53	2	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa GM 202	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.85	2026-09-22 14:55:09.85	\N	\N
234	54	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2520	920	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	5.96	70000.00	417200.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.858	2026-09-22 14:55:09.858	\N	\N
235	54	2	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa GM 202	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.858	2026-09-22 14:55:09.858	\N	\N
236	55	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2510	920	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	5.94	70000.00	415800.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.866	2026-09-22 14:55:09.866	\N	\N
237	55	2	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa GM 202	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.866	2026-09-22 14:55:09.866	\N	\N
238	56	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2520	920	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	5.96	70000.00	417200.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.872	2026-09-22 14:55:09.872	\N	\N
239	56	2	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa GM 202	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.872	2026-09-22 14:55:09.872	\N	\N
240	57	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2480	1550	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.51	70000.00	455700.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.879	2026-09-22 14:55:09.879	\N	\N
241	57	2	HANG_KEM	\N	Khóa GM 330	Khóa GM 330	Khóa GM 330	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa GM 330	\N	\N	\N	Bộ	1	770000.00	770000.00	\N	\N	\N	\N	\N	2026-09-22 14:55:09.879	2026-09-22 14:55:09.879	\N	\N
408	115	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2745	2635	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	8.125	70000.00	568750.00	\N	\N	\N	\N	\N	2026-09-25 10:38:30.789	2026-09-25 10:38:30.789	\N	\N
409	115	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	2	90000.00	180000.00	\N	\N	\N	\N	\N	2026-09-25 10:38:30.789	2026-09-25 10:38:30.789	\N	\N
410	115	3	HANG_KEM	\N	Khóa tay trúc GM805	Khóa tay trúc GM805	Khóa tay trúc GM805	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa tay trúc GM805	\N	\N	\N	BỘ	1	1100000.00	1100000.00	\N	\N	\N	\N	\N	2026-09-25 10:38:30.789	2026-09-25 10:38:30.789	\N	\N
299	77	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2850	2900	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	8.6	70000.00	602000.00	\N	\N	\N	\N	\N	2026-09-23 09:51:46.1	2026-09-23 09:51:46.1	\N	\N
300	77	2	HANG_KEM	\N	Ô thoáng nan chớp	Ô thoáng nan chớp	Ô thoáng nan chớp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bộ	3	350000.00	1050000.00	\N	\N	\N	\N	\N	2026-09-23 09:51:46.1	2026-09-23 09:51:46.1	\N	\N
301	77	3	HANG_KEM	\N	Khóa tay trúc GM805	Khóa tay trúc GM805	Khóa tay trúc GM805	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa tay trúc GM805	\N	\N	\N	bộ	1	1100000.00	1100000.00	\N	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790157099400-ec46ee94-1f86-47cd-8e74-4508c17147f2.png	\N	\N	\N	2026-09-23 09:51:46.1	2026-09-23 09:51:46.1	\N	\N
302	78	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2550	970	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.07	70000.00	424900.00	\N	\N	\N	\N	\N	2026-09-23 09:51:46.56	2026-09-23 09:51:46.56	\N	\N
303	78	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-23 09:51:46.56	2026-09-23 09:51:46.56	\N	\N
304	78	3	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa GM 202	\N	\N	\N	bộ	1	480000.00	480000.00	\N	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790157085805-12e59ce5-9727-415f-b9e1-41e06f47ecbf.png	\N	\N	\N	2026-09-23 09:51:46.56	2026-09-23 09:51:46.56	\N	\N
305	80	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2620	955	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.195	70000.00	433650.00	\N	\N	\N	\N	\N	2026-09-23 13:09:32.755	2026-09-23 13:09:32.755	\N	\N
306	80	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-23 13:09:32.755	2026-09-23 13:09:32.755	\N	\N
307	80	3	HANG_KEM	\N	KHÓA	Khoét khóa HH 5810	Khoét khóa HH 5810	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khoét khóa HH 5810	\N	\N	\N	bộ	1	0.00	0.00	\N	\N	\N	\N	\N	2026-09-23 13:09:32.755	2026-09-23 13:09:32.755	\N	\N
308	81	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2610	950	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.17	70000.00	431900.00	\N	\N	\N	\N	\N	2026-09-23 13:09:33.211	2026-09-23 13:09:33.211	\N	\N
309	81	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-23 13:09:33.211	2026-09-23 13:09:33.211	\N	\N
310	81	3	HANG_KEM	\N	KHÓA	Khoét khóa HH 5810	Khoét khóa HH 5810	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khoét khóa HH 5810	\N	\N	\N	bộ	1	0.00	0.00	\N	\N	\N	\N	\N	2026-09-23 13:09:33.211	2026-09-23 13:09:33.211	\N	\N
311	82	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2610	950	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.17	70000.00	431900.00	\N	\N	\N	\N	\N	2026-09-23 13:09:33.67	2026-09-23 13:09:33.67	\N	\N
312	82	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-23 13:09:33.67	2026-09-23 13:09:33.67	\N	\N
313	82	3	HANG_KEM	\N	KHÓA	Khoét khóa HH 5810	Khoét khóa HH 5810	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khoét khóa HH 5810	\N	\N	\N	bộ	1	0.00	0.00	\N	\N	\N	\N	\N	2026-09-23 13:09:33.67	2026-09-23 13:09:33.67	\N	\N
465	145	1	HANG_KEM	\N	Phào mặt trong	PR	PR	\N	\N	\N	2968	2773	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	8.709	70000.00	609630.00	\N	\N	\N	\N	\N	2026-09-25 11:16:39.439	2026-09-25 11:16:39.439	\N	\N
466	145	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	3	\N	\N	\N	\N	\N	\N	\N	2026-09-25 11:16:39.439	2026-09-25 11:16:39.439	\N	\N
467	145	3	HANG_KEM	\N	Khóa GM 330	Khóa GM 330	Khóa GM 330	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khóa GM 330	\N	\N	\N	Bộ	1	770000.00	770000.00	\N	\N	\N	\N	\N	2026-09-25 11:16:39.439	2026-09-25 11:16:39.439	\N	\N
351	94	1	HANG_KEM	\N	Phao Rời	PR	PR	\N	\N	\N	3195	2730	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	9.12	\N	0.00	\N	\N	\N	\N	\N	2026-09-24 14:29:39.738	2026-09-24 14:29:39.738	\N	\N
352	94	2	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự đứng 260	Phào biệt thự đứng 260	\N	\N	\N	3195	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.39	600000.00	3834000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:39.738	2026-09-24 14:29:39.738	\N	\N
353	94	3	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự ngang 260	Phào biệt thự ngang 260	\N	\N	\N	\N	2730	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	2.73	600000.00	1638000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:39.738	2026-09-24 14:29:39.738	\N	\N
354	94	4	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự đỉnh200	Phào biệt thự đỉnh200	\N	\N	\N	\N	2730	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	2.73	580000.00	1583400.00	\N	\N	\N	\N	\N	2026-09-24 14:29:39.738	2026-09-24 14:29:39.738	\N	\N
355	94	5	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	3	90000.00	270000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:39.738	2026-09-24 14:29:39.738	\N	\N
356	94	6	HANG_KEM	\N	KHÓA	Khóa tay trúc GM805	Khóa tay trúc GM805	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bộ	1	1100000.00	1100000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:39.738	2026-09-24 14:29:39.738	\N	\N
357	95	1	HANG_KEM	\N	Phao Rời	PR	PR	\N	\N	\N	2300	2230	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.83	\N	\N	\N	\N	\N	\N	\N	2026-09-24 14:29:40.213	2026-09-24 14:29:40.213	\N	\N
358	95	2	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự đứng 260	Phào biệt thự đứng 260	\N	\N	\N	2300	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	4.6	600000.00	2760000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.213	2026-09-24 14:29:40.213	\N	\N
359	95	3	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự ngang 260	Phào biệt thự ngang 260	\N	\N	\N	\N	2230	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	2.23	600000.00	1338000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.213	2026-09-24 14:29:40.213	\N	\N
360	95	4	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự đỉnh200	Phào biệt thự đỉnh200	\N	\N	\N	\N	2230	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	2.23	580000.00	1293400.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.213	2026-09-24 14:29:40.213	\N	\N
361	95	5	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	3	90000.00	270000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.213	2026-09-24 14:29:40.213	\N	\N
362	96	1	HANG_KEM	\N	Phao Rời	PR	PR	\N	\N	\N	2290	1350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	5.93	\N	\N	\N	\N	\N	\N	\N	2026-09-24 14:29:40.686	2026-09-24 14:29:40.686	\N	\N
363	96	2	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự đứng 260	Phào biệt thự đứng 260	\N	\N	\N	2290	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	4.58	600000.00	2748000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.686	2026-09-24 14:29:40.686	\N	\N
364	96	3	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự ngang 260	Phào biệt thự ngang 260	\N	\N	\N	\N	1350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	1.35	600000.00	810000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.686	2026-09-24 14:29:40.686	\N	\N
365	96	4	HANG_KEM	\N	Phao Biệt Thự	Phào biệt thự đỉnh200	Phào biệt thự đỉnh200	\N	\N	\N	\N	1350	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	1.35	580000.00	783000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.686	2026-09-24 14:29:40.686	\N	\N
366	96	5	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	2	90000.00	180000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:40.686	2026-09-24 14:29:40.686	\N	\N
367	97	1	HANG_KEM	\N	Phao Rời	PR	PR	\N	\N	\N	3180	990	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	7.35	70000.00	514500.00	\N	\N	\N	\N	\N	2026-09-24 14:29:41.155	2026-09-24 14:29:41.155	\N	\N
368	97	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:41.155	2026-09-24 14:29:41.155	\N	\N
369	97	3	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:41.155	2026-09-24 14:29:41.155	\N	\N
370	98	1	HANG_KEM	\N	Phao Rời	PR	PR	\N	\N	\N	2735	900	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.37	70000.00	445900.00	\N	\N	\N	\N	\N	2026-09-24 14:29:41.622	2026-09-24 14:29:41.622	\N	\N
371	98	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:41.622	2026-09-24 14:29:41.622	\N	\N
372	98	3	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:41.622	2026-09-24 14:29:41.622	\N	\N
373	99	1	HANG_KEM	\N	Phao Rời	PR	PR	\N	\N	\N	2735	900	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.37	70000.00	445900.00	\N	\N	\N	\N	\N	2026-09-24 14:29:42.094	2026-09-24 14:29:42.094	\N	\N
374	99	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:42.094	2026-09-24 14:29:42.094	\N	\N
375	99	3	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:42.094	2026-09-24 14:29:42.094	\N	\N
376	100	1	HANG_KEM	\N	Phao Rời	PR	PR	\N	\N	\N	2735	900	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	md	6.37	70000.00	445900.00	\N	\N	\N	\N	\N	2026-09-24 14:29:42.559	2026-09-24 14:29:42.559	\N	\N
377	100	2	HANG_KEM	\N	Ô Thoáng	kính ô thoáng	kính ô thoáng	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ô	1	90000.00	90000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:42.559	2026-09-24 14:29:42.559	\N	\N
378	100	3	HANG_KEM	\N	KHÓA	Khóa GM 202	Khóa GM 202	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bộ	1	480000.00	480000.00	\N	\N	\N	\N	\N	2026-09-24 14:29:42.559	2026-09-24 14:29:42.559	\N	\N
478	156	1	HANG_KEM	\N	Kính cường lực 170x1720 lắp trên cánh phụ	Kính cường lực 170x1720	Kính cường lực 170x1720	\N	\N	\N	1111	1111	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Tấm	\N	250000.00	\N	\N	\N	\N	\N	\N	2026-09-26 02:42:19.184	2026-09-26 02:42:19.184	\N	\N
480	158	1	HANG_KEM	\N	Kính cường lực 170x1720 lắp trên cánh phụ	Kính cường lực 170x1720	Kính cường lực 170x1720	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Tấm	1	250000.00	250000.00	\N	\N	\N	\N	\N	2026-09-26 02:48:53.693	2026-09-26 02:48:53.693	\N	\N
\.


--
-- Data for Name: sales_order_item_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order_item_images (id, order_item_id, sort_order, image_path, image_width, image_height, created_at, updated_at) FROM stdin;
1	77	1	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790157053200-2a886dbf-e5be-4cf7-8e1b-4c5121c21a31.png	\N	\N	2026-09-26 02:20:04.373	2026-09-26 02:20:04.373
2	78	1	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790157068561-7ca8f2bc-1c23-4354-8d58-dab3378c31b5.png	\N	\N	2026-09-26 02:20:04.373	2026-09-26 02:20:04.373
3	80	1	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790126082996-45ffcbfe-16f2-4199-a493-7c031e7ab474.png	\N	\N	2026-09-26 02:20:04.373	2026-09-26 02:20:04.373
5	145	1	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790334982558-9f962afb-200e-464f-9fce-bfcd2fb8c4b6.png	\N	\N	2026-09-26 02:20:04.373	2026-09-26 02:20:04.373
6	115	1	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790332704757-374ec9f3-2b85-47e4-a0de-c33742bd57a7.png	\N	\N	2026-09-26 02:20:04.373	2026-09-26 02:20:04.373
12	156	1	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790390470116-08e97a85-d97d-436d-aeaf-80a4d39d350c.png	65	86	2026-09-26 02:42:19.415	2026-09-26 02:42:19.415
13	156	2	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790390490978-0a57d412-d0ae-4ba8-b3da-9284e6f8273a.png	65	56	2026-09-26 02:42:19.415	2026-09-26 02:42:19.415
\.


--
-- Data for Name: sales_order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order_items (id, order_id, line_no, set_no, product_name, product_code, model, opening_direction, trim_direction, paint_color, height_mm, width_mm, frame_mm, clear_height_mm, clear_width_mm, panel_info, trim_bars_per_set, trim_type, lock_model, window_bars, leaves_per_set, quantity, unit, pricing_quantity, unit_price, amount, note, source_row, raw_block, created_at, updated_at, image_path, model_check, price_check, image_width, image_height) FROM stdin;
47	14	1	12108	Cửa Sổ	CS3-Đ-H10-3TK	CS3-Đ-H10-3TK	NP	Thuận	GM-01	2000	1620	210	\N	\N	3TK	\N	\N	\N	\N	\N	1	m2	3.24	3160000.00	10238400.00	Bản lề, chốt âm inox. OT kính dán 6.38 màu trắng trong. Chấn song tròn đứng phi 3 , 2 lập là. OT bộ cửa sổ số 1 = OT bộ cửa sổ số 2 và = OT bộ cửa chính mã 10955, 10956	\N	\N	2026-09-22 14:55:09.795	2026-09-22 14:55:09.795	\N	\N	\N	\N	\N
48	14	2	12109	Cửa Sổ	CS3-Đ-H10-3TK	CS3-Đ-H10-3TK	NP	Thuận	GM-01	2000	1620	210	\N	\N	3TK	\N	\N	\N	\N	\N	1	m2	3.24	3160000.00	10238400.00	Bản lề, chốt âm inox. OT kính dán 6.38 màu trắng trong. Chấn song tròn đứng phi 34 , 2 lập là. OT bộ cửa sổ số 2 = OT bộ cửa sổ số 1 = OT bộ cửa chính mã 10955, 10955	\N	\N	2026-09-22 14:55:09.805	2026-09-22 14:55:09.805	\N	\N	\N	\N	\N
49	14	3	12110	Cửa Sổ	CS2-Đ-H10-2TK	CS2-Đ-H10-2TK	NP	Thuận	GM-01	1890	1180	210	\N	\N	2TK	\N	\N	\N	\N	\N	1	m2	2.2302	3160000.00	7047432.00	Bản lề, chốt âm inox. OT kính dán 6.38 màu trắng trong. Chấn song vuông tròn phi 34 , 2 lập là	\N	\N	2026-09-22 14:55:09.811	2026-09-22 14:55:09.811	\N	\N	\N	\N	\N
50	14	4	12111	Cửa Sổ	CS2-Đ-H10-2TK	CS2-Đ-H10-2TK	NP	Thuận	GM-01	1870	1111	210	\N	\N	2TK	\N	\N	\N	\N	\N	1	m2	2.07757	2760000.00	5734093.20	Bản lề, chốt âm inox. OT kính dán 6.38 màu trắng trong. Không làm chấn song	\N	\N	2026-09-22 14:55:09.819	2026-09-22 14:55:09.819	\N	\N	\N	\N	\N
51	14	5	12112	Cửa Sổ	CS2-Đ-H10-2TK	CS2-Đ-H10-2TK	NP	Thuận	GM-01	2010	1380	210	\N	\N	2TK	\N	\N	\N	\N	\N	1	m2	2.7738	3160000.00	8765208.00	Bản lề, chốt âm inox. OT kính dán 6.38 màu trắng trong. Chấn song vuông tròn phi 34 , 2 lập là	\N	\N	2026-09-22 14:55:09.827	2026-09-22 14:55:09.827	\N	\N	\N	\N	\N
52	14	6	12113	Cửa Sổ	CS2-Đ-H10-2TK	CS2-Đ-H10-2TK	NP	Thuận	GM-01	2000	1380	210	\N	\N	2TK	\N	\N	\N	\N	\N	1	m2	2.76	3160000.00	8721600.00	Bản lề, chốt âm inox. OT kính dán 6.38 màu trắng trong. Chấn song vuông tròn đứng phi 34 , 2 lập là	\N	\N	2026-09-22 14:55:09.835	2026-09-22 14:55:09.835	\N	\N	\N	\N	\N
53	14	7	12114	Cửa Đi 1 Cánh	GM1-H3	GM1-H3	TT	Thuận	GM-01	2530	920	150	\N	\N	\N	\N	\N	\N	\N	\N	1	m2	2.3276	1970000.00	4585372.00	Bản lề inox	\N	\N	2026-09-22 14:55:09.844	2026-09-22 14:55:09.844	\N	\N	\N	\N	\N
54	14	8	12115	Cửa Đi 1 Cánh	GM1-H3	GM1-H3	TP	Thuận	GM-01	2520	920	150	\N	\N	\N	\N	\N	\N	\N	\N	1	m2	2.3184	1970000.00	4567248.00	Bản lề inox	\N	\N	2026-09-22 14:55:09.854	2026-09-22 14:55:09.854	\N	\N	\N	\N	\N
55	14	9	12116	Cửa Đi 1 Cánh	GM1-H3	GM1-H3	TT	Thuận	GM-01	2510	920	150	\N	\N	\N	\N	\N	\N	\N	\N	1	m2	2.3092	1970000.00	4549124.00	Bản lề inox	\N	\N	2026-09-22 14:55:09.861	2026-09-22 14:55:09.861	\N	\N	\N	\N	\N
56	14	10	12117	Cửa Đi 1 Cánh	GM1-H3	GM1-H3	TT	Thuận	GM-01	2520	920	150	\N	\N	\N	\N	\N	\N	\N	\N	1	m2	2.3184	1970000.00	4567248.00	Bản lề inox	\N	\N	2026-09-22 14:55:09.868	2026-09-22 14:55:09.868	\N	\N	\N	\N	\N
57	14	11	12118	Cửa Đi Cánh Kính	GM2-Đ-HPK	GM2-Đ-HPK	NP	Thuận	GM-01	2480	1550	210	\N	\N	\N	\N	\N	\N	\N	\N	1	m2	3.844	2360000.00	9071840.00	Bản lề, chốt âm inox. Kính trên cánh sử dụng kính cường lực 10mm, có mài	\N	\N	2026-09-22 14:55:09.875	2026-09-22 14:55:09.875	\N	\N	\N	\N	\N
77	11	1	12093	Cửa Đi 4 Cánh	GM4-L-H3-HPK-3NC	GM4-L-H3-HPK-3NC	TP	Thuận	GM-06	2850	2900	250	2370	\N	3NC	\N	\N	\N	\N	\N	1	m2	8.265	2270000.00	18761550.00	Bản lề, chốt âm iox. Kính trên cánh màu trắng trong	\N	\N	2026-09-23 09:51:45.861	2026-09-23 09:51:45.861	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790157053200-2a886dbf-e5be-4cf7-8e1b-4c5121c21a31.png	\N	\N	\N	\N
78	11	2	12094	Cửa Đi 1 Cánh	GM1-H1-1TK	GM1-H1-1TK	TP	Thuận	GM-06	2550	970	250	2170	\N	1TK	\N	\N	\N	\N	\N	1	m2	2.4735	2070000.00	5120145.00	Bản lề inox	\N	\N	2026-09-23 09:51:46.331	2026-09-23 09:51:46.331	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790157068561-7ca8f2bc-1c23-4354-8d58-dab3378c31b5.png	\N	\N	\N	\N
80	15	1	12119	Cửa Đi 1 Cánh	GM1-H1-1TK	GM1-H1-1TK	TP	Thuận	GM-06	2620	955	125	\N	\N	1TK	\N	\N	\N	\N	\N	1	m2	2.5021	1960000.00	4904116.00	Bản lề chốt âm inox .Kính trên OT 6,38 Mầu trắng trong	\N	\N	2026-09-23 13:09:32.512	2026-09-23 13:09:32.512	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790126082996-45ffcbfe-16f2-4199-a493-7c031e7ab474.png	\N	\N	\N	\N
81	15	2	12120	Cửa Đi 1 Cánh	GM1-H1-1TK	GM1-H1-1TK	TP	Thuận	GM-06	2610	950	240	\N	\N	1TK	\N	\N	\N	\N	\N	1	m2	2.4795	2070000.00	5132565.00	Bản lề chốt âm inox .Kính trên OT 6,38 Mầu trắng trong	\N	\N	2026-09-23 13:09:32.985	2026-09-23 13:09:32.985	\N	\N	\N	\N	\N
82	15	3	12121	Cửa Đi 1 Cánh	GM1-H1-1TK	GM1-H1-1TK	TT	Thuận	GM-06	2610	950	235	\N	\N	1TK	\N	\N	\N	\N	\N	1	m2	2.4795	2070000.00	5132565.00	Bản lề chốt âm inox .Kính trên OT 6,38 Mầu trắng trong	\N	\N	2026-09-23 13:09:33.435	2026-09-23 13:09:33.435	\N	\N	\N	\N	\N
145	16	1	12122	Cửa Đi 4 Cánh	GM4-L-H3-HPK-3TK	GM4-L-H3-HPK-3TK	NP	Thuận	GM-05	2968	2773	240	\N	\N	3TK	\N	\N	\N	\N	\N	1	m2	8.230264	2270000.00	18682699.28	Bản lề, chốt âm inox. Kính trên cánh màu trắng trong ( kính OT ĐL tự cấp).	\N	\N	2026-09-25 11:16:39.202	2026-09-25 11:16:39.202	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790334982558-9f962afb-200e-464f-9fce-bfcd2fb8c4b6.png	\N	\N	\N	\N
94	23	1	12062	Cửa Đi 4 Cánh	GMLUX4-L-H3-H9-3TK	GMLUX4-L-H3-H9-3TK	NP	Vuông	GM-09	3195	2730	240	\N	\N	3TK	\N	\N	\N	\N	\N	1	m2	8.72235	2270000.00	19799734.50	Bản lề, chốt âm inox. OT kính dán 6.38 màu trắng trong. ĐÓNG GÓI CHỐNG XỐC	\N	\N	2026-09-24 14:29:39.487	2026-09-24 14:29:39.487	\N	\N	\N	\N	\N
95	23	2	12063	Cửa Sổ	CSLUX4-Đ-H10-HPK-3TK	CSLUX4-Đ-H10-HPK-3TK	NP	Vuông	GM-09	2300	2230	160	\N	\N	3TK	\N	\N	\N	\N	\N	1	m2	5.129	2970000.00	15233130.00	Bản lề, chốt âm inox. Chấn song vuông ngang chéo con rô, 2 lập là. OT + Kính cánh phụ kính dán 6.38 màu trăng trong. ĐÓNG GÓI CHỐNG XỐC	\N	\N	2026-09-24 14:29:39.977	2026-09-24 14:29:39.977	\N	\N	\N	\N	\N
96	23	3	12064	Cửa Sổ	CSLUX2-Đ-H10-2TK	CSLUX2-Đ-H10-2TK	NP	Vuông	GM-09	2290	1350	240	\N	\N	2TK	\N	\N	\N	\N	\N	1	m2	3.0915	3060000.00	9459990.00	Bản lề, chốt âm inox. Chấn song vuông ngang chéo con rô, 2 lập là. OT kính dán 6.38 màu trắng trong. ĐÓNG GÓI CHỐNG XỐC	\N	\N	2026-09-24 14:29:40.446	2026-09-24 14:29:40.446	\N	\N	\N	\N	\N
97	23	4	12065	Cửa Đi 1 Cánh	GM1-H5-1TK	GM1-H5-1TK	NT	Thuận	GM-09	3180	990	160	\N	\N	1TK	\N	\N	\N	\N	\N	1	m2	3.1482	1970000.00	6201954.00	Bản lề inox. OT kính dán 6.38 màu trắng trong. ĐÓNG GÓI CHỐNG XỐC	\N	\N	2026-09-24 14:29:40.92	2026-09-24 14:29:40.92	\N	\N	\N	\N	\N
98	23	5	12066	Cửa Đi 1 Cánh	GM1-H5-1TK	GM1-H5-1TK	TT	Thuận	GM-09	2735	900	170	\N	\N	1TK	\N	\N	\N	\N	\N	1	m2	2.4615	1980000.00	4873770.00	Bản lề inox. OT kính dán 6.38 màu trắng trong. ĐÓNG GÓI CHỐNG XỐC	\N	\N	2026-09-24 14:29:41.388	2026-09-24 14:29:41.388	\N	\N	\N	\N	\N
99	23	6	12067	Cửa Đi 1 Cánh	GM1-H5-1TK	GM1-H5-1TK	TP	Thuận	GM-09	2735	900	170	\N	\N	1TK	\N	\N	\N	\N	\N	1	m2	2.4615	1980000.00	4873770.00	Bản lề inox. OT kính dán 6.38 màu trắng trong. ĐÓNG GÓI CHỐNG XỐC	\N	\N	2026-09-24 14:29:41.856	2026-09-24 14:29:41.856	\N	\N	\N	\N	\N
100	23	7	12068	Cửa Đi 1 Cánh	GM1-H5-1TK	GM1-H5-1TK	TP	Thuận	GM-09	2735	900	170	\N	\N	1TK	\N	\N	\N	\N	\N	1	m2	2.4615	1980000.00	4873770.00	Bản lề inox. OT kính dán 6.38 màu trắng trong. ĐÓNG GÓI CHỐNG XỐC	\N	\N	2026-09-24 14:29:42.326	2026-09-24 14:29:42.326	\N	\N	\N	\N	\N
156	31	1	12125	Cửa Đi 1 Cánh	GM1-H1	GM1-H1	TT	Nghịch	GM-02	1111	1111	111	1111	1111	2TK	\N	\N	\N	\N	\N	1	m2	1.234321	1960000.00	2419269.16	\N	\N	\N	2026-09-26 02:42:18.947	2026-09-26 02:42:18.947	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790390470116-08e97a85-d97d-436d-aeaf-80a4d39d350c.png	\N	\N	65	86
158	32	1	12126	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	2026-09-26 02:48:53.453	2026-09-26 02:48:53.453	\N	\N	\N	\N	\N
115	13	1	12104	Cửa Đi Vách Kính	GM2-Đ-HPK-VK-2TK	GM2-Đ-HPK-VK-2TK	NP	Vuông	GM-01	2745	2635	250	2350	1760	2TK	\N	\N	\N	\N	\N	1	m2	7.233075	2470000.00	17865695.25	Khuôn Vuông, Phào rời 2 mặt. Kính trên cánh+vách kính dán 8.38 xanh đen. Kính OT 6.38 xanh đen	\N	\N	2026-09-25 10:38:30.551	2026-09-25 10:38:30.551	https://fijyvznuevbdmucrwoqo.supabase.co/storage/v1/object/public/order-images/orders/1790332704757-374ec9f3-2b85-47e4-a0de-c33742bd57a7.png	\N	\N	\N	\N
\.


--
-- Data for Name: sales_order_requirements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order_requirements (id, order_id, code, question_text, answer, note, sort_order, created_at, updated_at) FROM stdin;
331	31	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-26 02:42:19.65	2026-09-26 02:42:19.65
332	31	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-26 02:42:19.65	2026-09-26 02:42:19.65
333	31	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-26 02:42:19.65	2026-09-26 02:42:19.65
334	31	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-26 02:42:19.65	2026-09-26 02:42:19.65
335	31	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-26 02:42:19.65	2026-09-26 02:42:19.65
336	31	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-26 02:42:19.65	2026-09-26 02:42:19.65
79	14	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-22 14:55:09.883	2026-09-22 14:55:09.883
80	14	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-22 14:55:09.883	2026-09-22 14:55:09.883
81	14	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-22 14:55:09.883	2026-09-22 14:55:09.883
82	14	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-22 14:55:09.883	2026-09-22 14:55:09.883
83	14	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-22 14:55:09.883	2026-09-22 14:55:09.883
84	14	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-22 14:55:09.883	2026-09-22 14:55:09.883
259	13	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-25 10:38:31.026	2026-09-25 10:38:31.026
260	13	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-25 10:38:31.026	2026-09-25 10:38:31.026
261	13	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-25 10:38:31.026	2026-09-25 10:38:31.026
262	13	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-25 10:38:31.026	2026-09-25 10:38:31.026
263	13	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-25 10:38:31.026	2026-09-25 10:38:31.026
264	13	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-25 10:38:31.026	2026-09-25 10:38:31.026
343	32	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-26 02:48:53.93	2026-09-26 02:48:53.93
344	32	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-26 02:48:53.93	2026-09-26 02:48:53.93
345	32	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-26 02:48:53.93	2026-09-26 02:48:53.93
346	32	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-26 02:48:53.93	2026-09-26 02:48:53.93
347	32	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-26 02:48:53.93	2026-09-26 02:48:53.93
348	32	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-26 02:48:53.93	2026-09-26 02:48:53.93
265	16	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-25 11:16:39.674	2026-09-25 11:16:39.674
266	16	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-25 11:16:39.674	2026-09-25 11:16:39.674
267	16	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-25 11:16:39.674	2026-09-25 11:16:39.674
268	16	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-25 11:16:39.674	2026-09-25 11:16:39.674
269	16	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-25 11:16:39.674	2026-09-25 11:16:39.674
270	16	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-25 11:16:39.674	2026-09-25 11:16:39.674
133	11	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-23 09:51:46.795	2026-09-23 09:51:46.795
134	11	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-23 09:51:46.795	2026-09-23 09:51:46.795
135	11	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-23 09:51:46.795	2026-09-23 09:51:46.795
136	11	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-23 09:51:46.795	2026-09-23 09:51:46.795
137	11	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-23 09:51:46.795	2026-09-23 09:51:46.795
138	11	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-23 09:51:46.795	2026-09-23 09:51:46.795
145	15	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-23 13:09:33.895	2026-09-23 13:09:33.895
146	15	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-23 13:09:33.895	2026-09-23 13:09:33.895
147	15	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-23 13:09:33.895	2026-09-23 13:09:33.895
148	15	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-23 13:09:33.895	2026-09-23 13:09:33.895
149	15	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-23 13:09:33.895	2026-09-23 13:09:33.895
150	15	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-23 13:09:33.895	2026-09-23 13:09:33.895
181	23	NEN_GIAT_CAP	Nền có giật cấp hay không?	\N	\N	1	2026-09-24 14:29:42.792	2026-09-24 14:29:42.792
182	23	KICH_THUOC_DA_TRU	Kích thước đã trừ chưa?	\N	\N	2	2026-09-24 14:29:42.792	2026-09-24 14:29:42.792
183	23	PHAO_XI_MANG	Mép tường có đắp phào xi măng hay không?	\N	\N	3	2026-09-24 14:29:42.792	2026-09-24 14:29:42.792
184	23	PHAO_LUX_LEN_TRAN	Lắp phào LUX: hỏi mép tường lên trần?	\N	\N	4	2026-09-24 14:29:42.792	2026-09-24 14:29:42.792
185	23	TUONG_T_HOAC_I	Có thuộc tường chữ T hoặc I không?	\N	\N	5	2026-09-24 14:29:42.792	2026-09-24 14:29:42.792
186	23	CUA_4_CANH_XAC_NHAN_KT	Cửa 4 cánh xác nhận chiều rộng và cao	\N	\N	6	2026-09-24 14:29:42.792	2026-09-24 14:29:42.792
\.


--
-- Data for Name: sales_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_orders (id, order_code, customer_code, customer_name, sales_employee_code, order_date, required_delivery_date, receiver_address, delivery_km, region, group_no, excel_update_date, form_code, form_effective_date, source_file_name, source_file_hash, last_imported_at, created_at, updated_at, delivery_payment, deposit_amount, discount_amount, discount_percent, receiver_name, receiver_phone, shipping_fee, status, subtotal, total_after_discount, warehouse_receipt_deduction, shipping_calculated_at, shipping_mountain_district, order_type) FROM stdin;
14	26092201LĐ01DH04	LĐ01	Anh Lân	\N	2026-09-22	2026-10-07	Lâm Đồng	\N	\N	\N	\N	QP-01	2023-05-05	\N	\N	\N	2026-09-22 14:55:09.771	2026-09-22 14:55:09.771	61969005.20	25000000.00	0.00	0.0000	\N	\N	0.00	NHAP	86969005.20	86969005.20	0.00	\N	f	MAU
11	26092102BG43DH03	\N	A Tuấn	\N	2026-09-21	2026-10-08	Bắc Giang	\N	\N	\N	\N	QP-01	2023-05-05	\N	\N	\N	2026-09-22 14:50:47.702	2026-09-23 09:51:45.168	16418307.40	9000000.00	2210287.60	8.0000	\N	\N	0.00	NHAP	27628595.00	25418307.40	0.00	\N	f	MAU
15	26092202HD04DH24	HD04	A Kiên	123	2026-09-22	2026-09-11	Hải Dương	\N	\N	\N	\N	QP-01	2023-05-05	\N	\N	\N	2026-09-22 14:55:29.812	2026-09-23 13:09:31.822	14728292.48	0.00	2008403.52	12.0000	\N	\N	0.00	NHAP	16736696.00	14728292.48	0.00	\N	f	MAU
23	26091802ĐL03DH01	ĐL03	Anh Vinh	LĨNH	2026-09-18	2026-10-08	Đak Lak	\N	\N	\N	2026-09-24	\N	\N	\N	\N	\N	2026-09-24 12:34:41.776	2026-09-24 14:29:38.761	56250506.65	23000000.00	8805611.85	10.0000	\N	0123456789	0.00	DA_XAC_NHAN	88056118.50	79250506.65	0.00	\N	f	SAN_XUAT
13	26092108BN11DH02	BN11	A Luyện	Lĩnh	2026-09-21	2026-10-07	Bắc Ninh	\N	\N	\N	2026-09-25	QP-01	2023-05-05	\N	\N	\N	2026-09-22 14:54:42.834	2026-09-25 10:38:29.846	13714445.25	6000000.00	0.00	0.0000	\N	0123456789	0.00	DA_XAC_NHAN	19714445.25	19714445.25	0.00	\N	f	SAN_XUAT
16	26092203BG58DH03	DL01	A Hưng Phương	sadasd	2026-09-22	2026-10-15	Sơn Động- Bắc Giang	\N	\N	\N	2026-09-18	QP-01	2023-05-05	\N	\N	\N	2026-09-22 14:55:56.86	2026-09-25 11:16:38.961	14062329.28	6000000.00	0.00	0.0000	\N	213424234234	0.00	DA_XAC_NHAN	20062329.28	20062329.28	0.00	\N	f	SAN_XUAT
31	NHAP-20260925-115637	DL01	dfgdfgg	gdfgg	2026-09-25	2026-09-25	1111	\N	\N	\N	2026-09-25	QP-01	2023-05-05	\N	\N	\N	2026-09-25 12:00:23.771	2026-09-26 02:42:18.709	2128956.86	0.00	290312.30	12.0000	dfgfdg	123132132	0.00	DA_XAC_NHAN	2419269.16	2128956.86	0.00	\N	f	MAU
32	NHAP-20260926-023921	DL01	fsdfsdfds	sdfdsfds	2026-09-26	2026-09-25	sdfsdfdsf	12	dsfdsf	\N	2026-09-26	QP-01	2023-05-05	\N	\N	\N	2026-09-26 02:45:49.954	2026-09-26 02:48:53.212	220000.00	0.00	30000.00	12.0000	fsdfds	fdsfdsf	0.00	DA_XAC_NHAN	250000.00	220000.00	0.00	\N	f	MAU
\.


--
-- Data for Name: shipping_calculations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_calculations (id, order_id, region, delivery_km, mountain_district, band_label, support_km, raw_total, rounded_total, lines, source, created_at) FROM stdin;
\.


--
-- Data for Name: shipping_model_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_model_mappings (id, source_model, shipping_model_code, note, active, created_at, updated_at) FROM stdin;
1	Cửa Đi 1 Cánh	SV1	\N	t	2026-09-22 23:32:47.09	2026-09-22 23:46:12.916
4	Cửa Đi 2 Cánh	SV2	\N	t	2026-09-22 23:46:05.29	2026-09-22 23:46:13.146
7	Cửa Đi 4 Cánh	SV4	\N	t	2026-09-22 23:46:13.376	2026-09-22 23:46:13.376
\.


--
-- Data for Name: shipping_rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_rates (id, door_group, model_name, model_code, quantity_tier, north_le_100, north_101_200, north_over_200, central, active, source, created_at, updated_at) FROM stdin;
102	CỬA ĐI	1 cánh - SV1	SV1	2	150000.00	200000.00	250000.00	350000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
103	CỬA ĐI	2 cánh - SV2	SV2	1	300000.00	350000.00	400000.00	600000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
104	CỬA ĐI	2 cánh - SV2	SV2	2	250000.00	300000.00	350000.00	500000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
105	CỬA ĐI	4 cánh - SV4	SV4	1	500000.00	600000.00	800000.00	1000000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
106	CỬA ĐI	4 cánh - SV4	SV4	2	400000.00	500000.00	700000.00	800000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
107	CỬA SỔ	1 cánh - SVCS1	SVCS1	1	200000.00	250000.00	300000.00	400000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
108	CỬA SỔ	1 cánh - SVCS1	SVCS1	2	150000.00	200000.00	250000.00	350000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
109	CỬA SỔ	2 cánh - SVCS2	SVCS2	1	250000.00	300000.00	400000.00	500000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
110	CỬA SỔ	2 cánh - SVCS2	SVCS2	2	200000.00	250000.00	300000.00	400000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
111	CỬA SỔ	3 cánh - SVCS3	SVCS3	1	400000.00	500000.00	600000.00	700000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
112	CỬA SỔ	3 cánh - SVCS3	SVCS3	2	300000.00	400000.00	500000.00	600000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
113	CỬA SỔ	4 cánh - SVCS4	SVCS4	1	400000.00	500000.00	600000.00	700000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
114	CỬA SỔ	4 cánh - SVCS4	SVCS4	2	300000.00	400000.00	500000.00	600000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
101	CỬA ĐI	1 cánh - SV1	SV1	1	200000.00	300000.00	300000.00	400000.00	t	MASTER_UI	2026-09-22 23:43:19.469	2026-09-22 23:43:19.469
\.


--
-- Data for Name: survey_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.survey_answers (id, code, answer, choice, updated_by, created_at, updated_at) FROM stdin;
64	B4	mẫu lệnh sản xuất	\N	\N	2026-09-25 23:30:57.398	2026-09-25 23:31:02.85
1	O3	KHÔNG	\N	\N	2026-09-25 23:15:09.866	2026-09-25 23:15:17.08
160	TM3	60 cánh cho 2 ca	\N	\N	2026-09-26 04:02:30.282	2026-09-26 04:02:37.547
162	TM4	tình trạng này chưa xảy ra	\N	\N	2026-09-26 04:02:58.959	2026-09-26 04:02:58.959
163	TM5	chờ phôi	\N	\N	2026-09-26 04:07:58.878	2026-09-26 04:07:58.878
10	A2	không tính chủ nhật và ngày lễ .	\N	\N	2026-09-25 23:21:00.725	2026-09-25 23:21:07.514
66	B5	bộ số do bộ phận kinh doanh đánh. sau khi đơn hàng được chốt và đẩy đơn sản xuất	\N	\N	2026-09-25 23:31:21.169	2026-09-25 23:32:04.422
14	A1	phần này áp dụng sau khi test xong cơ khí	\N	\N	2026-09-25 23:21:31.997	2026-09-25 23:21:42.572
70	B6	hạn giao là ngày cần phải giao đến khách hàng	\N	\N	2026-09-25 23:32:07.989	2026-09-25 23:32:26.636
72	B7	phải giao đầy đủ cả bộ	\N	\N	2026-09-25 23:32:52.39	2026-09-25 23:32:59.374
122	C6	có. thông thường chúng tôi gối công đoạn 1 ngày(	\N	\N	2026-09-25 23:45:30.63	2026-09-25 23:46:00.233
97	TK6	bản vẽ sản xuất, leader bộ phận thiết kế duyệt	\N	\N	2026-09-25 23:40:30.804	2026-09-26 05:43:52.101
17	A3	ép cánh 40 phút. lắp kính+ phụ kiện là 1 công việc trong khâu đóng gói	\N	\N	2026-09-25 23:22:07.52	2026-09-25 23:23:00.181
128	C7	không	\N	\N	2026-09-25 23:46:16.314	2026-09-25 23:46:16.314
74	B8	có, hiện có tương đối nhiều bộ đang sản xuất dang dở	\N	\N	2026-09-25 23:33:37.703	2026-09-26 05:43:15.136
129	C8	một ngày	\N	\N	2026-09-25 23:57:40.451	2026-09-25 23:57:40.451
77	TK1	1 bộ cửa cần bản vẽ cad	\N	\N	2026-09-25 23:36:29.112	2026-09-25 23:36:54.231
6	M11	\N	Có	\N	2026-09-25 23:15:53.361	2026-09-26 00:19:05.421
5	M12	\N	Có	\N	2026-09-25 23:15:47.615	2026-09-26 00:19:05.421
164	TM6	văn phòng	\N	\N	2026-09-26 04:08:10.158	2026-09-26 04:08:11.41
81	TK2	phụ thuộc mà model, có nhiều phi tiêu chuẩn không(	\N	\N	2026-09-25 23:37:20.096	2026-09-25 23:38:24.429
30	A5	chương trình bôi ls. là sau thiết kế xong sẽ cần chuyển sang phần mềm chuyên dụng của máy cắt để đánh dấu các điểm( điểm cắt đứt, điểm chỉ cần khắc , )ghép các chi tiết nhỏ vào tầm phôi nguyên liệu to sao cho tối ưu tránh hao phí vật tư	\N	\N	2026-09-25 23:25:22.749	2026-09-25 23:27:23.985
133	CH1	máy chấn cnc, các chương trình chấn đã được lập trình sẵn	\N	\N	2026-09-26 03:57:45.681	2026-09-26 03:58:12.56
89	TK3	phần mềm cad, kỹ sư cơ khí làm việc tại nhà máy	\N	\N	2026-09-25 23:38:38.371	2026-09-25 23:39:01.379
43	A6	hiện tại tôi đang lên kế hoạch. hàng ngày đều lên, làm bằng excel	\N	\N	2026-09-25 23:27:44.463	2026-09-25 23:28:17.393
210	TC3	ghi lịch sử, chụp ảnh lại	\N	\N	2026-09-26 04:16:47.173	2026-09-26 04:16:49.849
92	TK4	tùy độ khó	\N	\N	2026-09-25 23:39:19.473	2026-09-25 23:39:53.335
96	TK5	đầy đủ	\N	\N	2026-09-25 23:40:09.967	2026-09-25 23:40:09.967
48	A7	ưu tiên giao theo hạn đơn. đơn nào tiến độ cần giao gần nhất sẽ ưu tiên làm trước	\N	\N	2026-09-25 23:28:33.476	2026-09-25 23:29:17.743
55	B1	đúng rồi, làm theo số bộ	\N	\N	2026-09-25 23:29:39.861	2026-09-25 23:29:39.861
137	CH2	chấn khung+ phào 1 máy, chấn cánh và phào 1 máy ( phào có thể chấn bằng cả 2 máy đêu được	\N	\N	2026-09-26 03:58:24.557	2026-09-26 03:58:57.669
56	B2	tất cả	\N	\N	2026-09-25 23:29:54.377	2026-09-25 23:29:58.571
140	CH3	chưa đo chính xác	\N	\N	2026-09-26 03:59:16.556	2026-09-26 03:59:16.556
59	B3	khách đã xác nhận và khi đầy đủ thông tin kích thước, hướng mở, màu sắc...	\N	\N	2026-09-25 23:30:08.888	2026-09-25 23:30:44.729
102	TK7	có	\N	\N	2026-09-25 23:40:58.786	2026-09-25 23:40:58.786
103	BL2	nhà máy	\N	\N	2026-09-25 23:41:16.194	2026-09-25 23:41:16.194
104	BL3	một người ca lao động 8h có thể bôi được 60 cánh	\N	\N	2026-09-25 23:41:48.942	2026-09-25 23:42:00.718
106	BL4	khiong cahyj được	\N	\N	2026-09-25 23:42:12.785	2026-09-25 23:42:12.785
166	HAN1	mig, có 8 máy , 8 người	\N	\N	2026-09-26 04:08:15.323	2026-09-26 04:08:27.08
141	CH4	mất 5 phút, ngày chỉ đổi 2 lần	\N	\N	2026-09-26 03:59:20.984	2026-09-26 03:59:35.045
144	CH5	đúng rồi	\N	\N	2026-09-26 04:00:10.338	2026-09-26 04:00:21.314
169	HAN2	3 người làm 3 việc.	\N	\N	2026-09-26 04:08:47.457	2026-09-26 04:08:51.846
107	C1	cắt bằng máy cnc lares fiber. mỗi máy có 2 người, hiện tại nhà máy có 2 máy	\N	\N	2026-09-25 23:42:40.661	2026-09-25 23:43:27.381
116	C2	đúng rồi	\N	\N	2026-09-25 23:43:47.092	2026-09-25 23:44:14.508
118	C3	chúng tôi sẽ căn cứ tính theo doanh thu	\N	\N	2026-09-25 23:44:35.408	2026-09-25 23:44:35.408
119	C4	không mất thời gian	\N	\N	2026-09-25 23:44:51.586	2026-09-25 23:44:51.586
120	C5	nguyên liệu luôn lưu kho. app cần cảnh báo thiếu nguyên liệu	\N	\N	2026-09-25 23:45:15.784	2026-09-25 23:45:25.031
147	CH6	qc, phải làm lại	\N	\N	2026-09-26 04:00:30.492	2026-09-26 04:00:45.043
171	HAN3	hàn 1 cánh mất 10 phút ( 1 người hàn	\N	\N	2026-09-26 04:09:12.739	2026-09-26 04:09:21.825
173	HAN4	không cần	\N	\N	2026-09-26 04:09:35.717	2026-09-26 04:09:35.717
153	TM1	tổ máy đủ cho 1 ca làm việc cần 8 người	\N	\N	2026-09-26 04:01:37.537	2026-09-26 04:01:48.155
156	TM2	ngày làm 2 ca	\N	\N	2026-09-26 04:01:57.517	2026-09-26 04:01:57.517
174	HAN5	không cần( làm độc lập)	\N	\N	2026-09-26 04:09:48.07	2026-09-26 04:09:53.617
150	CH7	1 ngày chấn được khoảng 30 cánh đầy đủ ( cho ca 8h)	\N	\N	2026-09-26 04:01:02.853	2026-09-26 04:02:22.759
176	HAN6	hàn xong thợ hàn mài luôn	\N	\N	2026-09-26 04:10:07.853	2026-09-26 04:10:14.315
198	EP7	công xuất 8 tiếng có thể ép được 90-100 cánh	\N	\N	2026-09-26 04:14:32.315	2026-09-26 04:14:42.999
178	HAN7	cắt làm lại, thùy vào độ khó của sản phẩm	\N	\N	2026-09-26 04:10:40.607	2026-09-26 04:11:08.35
201	TC1	test là công đoạn QC, sau khi hàn tất cả các chi tiết như khung , cánh, phào. chúng ta tiến lawnhf lắp ghép lại kiểm tra xem có lỗi gì không trước khi đem đi sơn	\N	\N	2026-09-26 04:14:54.44	2026-09-26 04:16:00.893
181	EP1	1 cánh cửa sẽ có 2 mặt, sau khi hàn tăng cứng từng mặt sẽ cho vào ép lại với nhau để thành 1 cánh cửa	\N	\N	2026-09-26 04:11:16.054	2026-09-26 04:12:30.306
186	EP2	có 1 máy ep. mỗi lượt ép mất 45p. 1 lần ép có thể ép từ 9-12 cánh cửa	\N	\N	2026-09-26 04:12:35.107	2026-09-26 04:13:08.626
193	EP3	mất 45p chờ keo khô	\N	\N	2026-09-26 04:13:22.04	2026-09-26 04:13:28.403
195	EP4	sau khi hàn cánh	\N	\N	2026-09-26 04:13:44.963	2026-09-26 04:13:44.963
196	EP5	lấy từ kho , luôn có tồn kho	\N	\N	2026-09-26 04:14:00.777	2026-09-26 04:14:00.777
197	EP6	ép lỗi sẽ phế và làm lại	\N	\N	2026-09-26 04:14:17.377	2026-09-26 04:14:17.377
207	TC2	test tưng bộ, 1 bộ mất khoảng 20 phút	\N	\N	2026-09-26 04:16:16.583	2026-09-26 04:16:32.555
215	TC5	quay lại công đoạn hàn hoặc báo phế	\N	\N	2026-09-26 04:17:38.954	2026-09-26 04:18:02.369
212	TC4	thường là các lỗi móp méo. hoặc hàn sai vị trí	\N	\N	2026-09-26 04:16:58.19	2026-09-26 04:17:20.595
224	TH3	một ngày ra khoảng 45 cánh	\N	\N	2026-09-26 04:19:50.498	2026-09-26 04:19:53.358
219	TC6	một người gày có thể test được 10 bộ	\N	\N	2026-09-26 04:18:21.289	2026-09-26 04:18:29.289
222	TH1	tất cả có 12 người	\N	\N	2026-09-26 04:19:06.122	2026-09-26 04:19:06.122
223	TH2	chờ tối đa 24 tiếng, có chỗ để	\N	\N	2026-09-26 04:19:36.852	2026-09-26 04:19:36.852
226	TH4	không . 1 tuần bảo trì 1 lần	\N	\N	2026-09-26 04:20:07.598	2026-09-26 04:20:07.598
227	TH5	có, phải chờ	\N	\N	2026-09-26 04:20:16.648	2026-09-26 04:20:16.648
4	M10	\N	Thiếu thông tin	\N	2026-09-25 23:15:43.207	2026-09-26 05:16:34.085
228	SON1	sơn tĩnh điện có 1 lò lung	\N	\N	2026-09-26 04:20:31.945	2026-09-26 04:20:38.634
345	KH7	tối đa được 80 cánh/ ngày	\N	\N	2026-09-26 04:44:34.528	2026-09-26 04:44:37.797
307	KHO3	theo kiện. trung bình 1 bộ khoảng 5 kiện	\N	\N	2026-09-26 04:38:13.664	2026-09-26 04:38:32.92
230	SON2	mỗi mẻ được 20-25 cánh( bao gồm kèm cả khung)	\N	\N	2026-09-26 04:20:46.682	2026-09-26 04:21:09.649
235	SON3	một ngày sơn 2 mẻ , sáng chiều	\N	\N	2026-09-26 04:21:24.625	2026-09-26 04:21:24.625
236	SON4	cả bộ sơn cùng 1 lượt	\N	\N	2026-09-26 04:21:35.941	2026-09-26 04:21:39.816
238	SON5	màu do khách chọn	\N	\N	2026-09-26 04:21:54.208	2026-09-26 04:21:54.208
239	SON6	dổi màu mất 2h	\N	\N	2026-09-26 04:22:02.205	2026-09-26 04:22:02.205
240	SON7	có, 1 lo tối thiểu 20 cánh	\N	\N	2026-09-26 04:22:17.6	2026-09-26 04:22:17.6
241	SON8	chờ ghép lo	\N	\N	2026-09-26 04:22:34.041	2026-09-26 04:22:34.041
242	SON9	hàng ngày	\N	\N	2026-09-26 04:22:45.431	2026-09-26 04:22:45.431
243	SON10	chờ làm sạch	\N	\N	2026-09-26 04:22:57.604	2026-09-26 04:22:58.108
245	SON11	sau khi sấy xong, nguội có thể dán vân được	\N	\N	2026-09-26 04:23:16.533	2026-09-26 04:23:16.533
246	SON12	tổ trưởng	\N	\N	2026-09-26 04:23:23.317	2026-09-26 04:23:23.317
247	SON13	tẩy đi sơn lại, tỷ lệ này dưới 1%	\N	\N	2026-09-26 04:23:42.189	2026-09-26 04:23:42.189
311	KHO4	có tem	\N	\N	2026-09-26 04:38:38.641	2026-09-26 04:38:38.641
248	SON14	tùy từng sản lượng của cả nhà máy.	\N	\N	2026-09-26 04:23:55.241	2026-09-26 04:24:09.751
251	SON15	có bảo dưỡng, 2 tháng 1 lần	\N	\N	2026-09-26 04:24:25.047	2026-09-26 04:24:29.404
253	SON16	không	\N	\N	2026-09-26 04:24:35.573	2026-09-26 04:24:35.573
254	SON17	để không quá 2 ngày, có giới hạn chỗ để	\N	\N	2026-09-26 04:24:51.387	2026-09-26 04:25:00.915
256	SON18	không, luôn có lưu kho	\N	\N	2026-09-26 04:25:15.789	2026-09-26 04:25:15.789
312	KHO5	đúng rồi	\N	\N	2026-09-26 04:38:46.797	2026-09-26 04:38:46.797
257	SON19	có phải sơn lại. mất 2-3 tiếng	\N	\N	2026-09-26 04:25:35.61	2026-09-26 04:25:45.276
313	KHO6	8 người , 1 ngày đóng được khoảng 50 cánh	\N	\N	2026-09-26 04:39:02.41	2026-09-26 04:39:02.41
260	VAN1	dán fim vân , có buồng sấy riêng	\N	\N	2026-09-26 04:25:54.207	2026-09-26 04:26:11.784
263	VAN2	cả, mỗi số bộ là 1 màu.cần dán đủ hoàn chỉnh trước khi đem sấy	\N	\N	2026-09-26 04:26:27.162	2026-09-26 04:27:03.217
265	VAN3	khách chọn, trong ap cần có trường màu sắc	\N	\N	2026-09-26 04:27:10.22	2026-09-26 04:27:29.617
267	VAN4	tùy từng độ khó của cánh cửa, có bảng đo thời gian	\N	\N	2026-09-26 04:30:32.134	2026-09-26 04:30:53.41
269	VAN5	dán tay, có 13 người	\N	\N	2026-09-26 04:31:09.882	2026-09-26 04:31:09.882
270	VAN6	không cần	\N	\N	2026-09-26 04:31:16.799	2026-09-26 04:31:16.799
271	VAN7	lau sạch	\N	\N	2026-09-26 04:31:23.714	2026-09-26 04:31:23.714
272	VAN8	sau vân sẽ đem đi sấy in chuyển nhiệt	\N	\N	2026-09-26 04:31:42.958	2026-09-26 04:31:42.958
273	VAN9	qc đóng gói	\N	\N	2026-09-26 04:31:52.068	2026-09-26 04:31:54.372
275	VAN10	tẩy sơn lại	\N	\N	2026-09-26 04:32:02.747	2026-09-26 04:32:02.747
276	VAN11	có giới hạn chỗ để	\N	\N	2026-09-26 04:32:09.324	2026-09-26 04:32:44.056
278	LK1	tổ đóng gói	\N	\N	2026-09-26 04:33:01.596	2026-09-26 04:33:01.596
279	LK2	cả	\N	\N	2026-09-26 04:33:06.902	2026-09-26 04:33:06.902
280	LK3	cả	\N	\N	2026-09-26 04:33:19.682	2026-09-26 04:33:19.682
314	KHO7	kho thành phẩm, có giới hạn	\N	\N	2026-09-26 04:39:11.66	2026-09-26 04:39:16.602
281	LK4	có bộ có kính bộ không, 1 bộ mất tầm 20p	\N	\N	2026-09-26 04:33:37.233	2026-09-26 04:33:52.521
285	LK5	đúng rồi, có màu 11, và 14 không cần vân	\N	\N	2026-09-26 04:34:12.445	2026-09-26 04:34:18.538
287	LK6	đặt ngoài, sau khi thiết kế tiến hành đặt kính luôn	\N	\N	2026-09-26 04:34:24.425	2026-09-26 04:34:44.252
289	LK7	có	\N	\N	2026-09-26 04:34:52.307	2026-09-26 04:34:52.307
290	LK8	qc công đoạn	\N	\N	2026-09-26 04:35:05.116	2026-09-26 04:35:05.116
291	LK9	không cần, đã lắp thử ở khâu test	\N	\N	2026-09-26 04:35:20.201	2026-09-26 04:35:20.201
316	KHO8	có thể niếu đơn hàng để quá nâu	\N	\N	2026-09-26 04:39:23.253	2026-09-26 04:39:37.15
318	GH1	ghi trên đơn, trước khi sản xuất phải thống nhất kế hoạch	\N	\N	2026-09-26 04:39:45.799	2026-09-26 04:39:58.993
292	LK10	có 8 người làm 1 ngày được 50 cánh ( 2 người xịt giấy, 1 người đi keo,1 người bắt phụ kiện, 4 người đóng gói	\N	\N	2026-09-26 04:35:30.158	2026-09-26 04:36:08.792
298	LK11	chưua	\N	\N	2026-09-26 04:36:22.793	2026-09-26 04:36:22.793
320	GH2	là ngày giao tới khách	\N	\N	2026-09-26 04:40:14.641	2026-09-26 04:40:14.641
299	LK12	ít, vì khi đơn hàng chốt sản xuất phải cần đầy đủ thông tin và đã đào tạo công nhân rồi	\N	\N	2026-09-26 04:36:45.189	2026-09-26 04:37:18.02
321	GH3	gọi xe ghép	\N	\N	2026-09-26 04:40:22.545	2026-09-26 04:40:22.545
322	GH4	tùy từng thời điểm	\N	\N	2026-09-26 04:40:35.138	2026-09-26 04:40:35.138
302	KHO1	xịt giấy dán fim, lau chùi	\N	\N	2026-09-26 04:37:28.067	2026-09-26 04:37:38.532
306	KHO2	một kiện mất trung bình 4 phút	\N	\N	2026-09-26 04:38:05.892	2026-09-26 04:38:05.892
323	GH5	không	\N	\N	2026-09-26 04:40:38.916	2026-09-26 04:40:38.916
324	GH6	không	\N	\N	2026-09-26 04:40:44.482	2026-09-26 04:40:44.482
325	GH7	có	\N	\N	2026-09-26 04:40:46.646	2026-09-26 04:40:46.646
326	GH8	tùy từng khu vưc	\N	\N	2026-09-26 04:41:06.805	2026-09-26 04:41:11.069
347	KH8	có mùa cao điểm, từ tháng 1-3 âm lịch mùa thấm điểm , từ tháng 6-9 mùa trung điểm , từ tháng 10-tháng 12 âm lịch là cao điểm , giữa thấp điểm và cao điểm có thế chênh 100%	\N	\N	2026-09-26 04:44:46.478	2026-09-26 04:46:15.747
328	GH9	qua 2 tháng sẽ bị tính tồn kho	\N	\N	2026-09-26 04:41:17.556	2026-09-26 04:41:27.202
331	GH10	có, thanh toán- giao hàng	\N	\N	2026-09-26 04:41:31.844	2026-09-26 04:41:40.973
334	GH11	không có số cố định	\N	\N	2026-09-26 04:41:48.217	2026-09-26 04:41:55.854
336	GH12	do sản xuất chưa xong	\N	\N	2026-09-26 04:42:12.32	2026-09-26 04:42:12.32
337	KH1	tôi la người lên kế hoạch hàng ngày	\N	\N	2026-09-26 04:42:30.706	2026-09-26 04:42:30.706
338	KH2	kế hoạch đang làm bằng giấy	\N	\N	2026-09-26 04:42:45.181	2026-09-26 04:42:45.181
339	KH3	chia theo ngày	\N	\N	2026-09-26 04:43:03.527	2026-09-26 04:43:03.527
340	KH4	ngày giao hàng	\N	\N	2026-09-26 04:43:10.452	2026-09-26 04:43:13.458
342	KH5	khi đã đầy đủ thông tin để triển khai bản vẽ	\N	\N	2026-09-26 04:43:30.591	2026-09-26 04:43:48.806
344	KH6	quá 70 cánh ngày sẽ là quá nhiều với xưởng	\N	\N	2026-09-26 04:44:22.052	2026-09-26 04:44:22.052
362	KH11	1 người trung bình khoảng 1.45m2	\N	\N	2026-09-26 04:47:00.339	2026-09-26 04:47:03.49
359	KH9	ngày thường làm 8 tiếng	\N	\N	2026-09-26 04:46:24.503	2026-09-26 04:46:30.026
361	KH10	tỷ lệ trễ khoảng 75%	\N	\N	2026-09-26 04:46:44.316	2026-09-26 04:46:44.316
364	KH12	khoảng 3%	\N	\N	2026-09-26 04:47:15.84	2026-09-26 04:47:15.84
365	KH13	có khi phải chờ do nhân viên mua quên không mua phôi , chờ khoảng 5-7 ngày	\N	\N	2026-09-26 04:47:42.394	2026-09-26 04:47:46.644
367	KH14	quản lý hoặc kế hoạch	\N	\N	2026-09-26 04:47:53.95	2026-09-26 04:48:01.514
369	KH15	sau khi 3 ngày sẽ không được đổi kích thước	\N	\N	2026-09-26 04:48:15.733	2026-09-26 04:48:22.458
371	KH16	sẽ hoàn thiện và lưu kho	\N	\N	2026-09-26 04:48:41.112	2026-09-26 04:48:41.112
372	KH17	có	\N	\N	2026-09-26 04:48:51.007	2026-09-26 04:48:51.007
373	KH18	không	\N	\N	2026-09-26 04:48:57.33	2026-09-26 04:48:57.33
374	KH19	không	\N	\N	2026-09-26 04:49:01.087	2026-09-26 04:49:01.087
375	KH20	kế  hoạch nhập thủ công trên excel	\N	\N	2026-09-26 04:49:24.747	2026-09-26 04:49:30.993
377	KH21	máy tính ở xưởng	\N	\N	2026-09-26 04:49:44.35	2026-09-26 04:49:44.35
378	KH22	mức công đoạn của từng bộ	\N	\N	2026-09-26 05:06:07.452	2026-09-26 05:06:16.1
381	KH23	văn phong	\N	\N	2026-09-26 05:06:22.096	2026-09-26 05:06:22.096
382	KH24	việc hôm nay của tổ	\N	\N	2026-09-26 05:06:44.397	2026-09-26 05:06:44.397
383	KH25	có, in khổ giấy a4	\N	\N	2026-09-26 05:06:49.064	2026-09-26 05:06:56.724
385	KH26	có việc từng ngày	\N	\N	2026-09-26 05:07:08.628	2026-09-26 05:07:08.628
386	KH27	không, tổ trưởng sẽ phân việc	\N	\N	2026-09-26 05:07:24.003	2026-09-26 05:07:24.003
387	KH28	có	\N	\N	2026-09-26 05:07:27.771	2026-09-26 05:07:27.771
388	KH29	quá tải, bộ sắp chậm tiến độ	\N	\N	2026-09-26 05:07:41.856	2026-09-26 05:07:51.947
390	KH30	thuê cắt kính bên ngoài	\N	\N	2026-09-26 05:08:18.817	2026-09-26 05:08:18.817
391	J1	kế hoạch, cần lưu lại lịch sử	\N	\N	2026-09-26 05:08:35.07	2026-09-26 05:08:38.849
393	J2	hiện tại chưa có xác nhận,	\N	\N	2026-09-26 05:09:05.835	2026-09-26 05:09:05.835
394	J3	kế hoạch tuần chốt giữa kinh doanh và sản xuất, giám đốc nhà máy chốt	\N	\N	2026-09-26 05:09:21.362	2026-09-26 05:09:44.789
396	J4	có	\N	\N	2026-09-26 05:09:53.307	2026-09-26 05:09:53.307
397	J5	có	\N	\N	2026-09-26 05:09:59.491	2026-09-26 05:09:59.491
398	J6	không	\N	\N	2026-09-26 05:10:06.629	2026-09-26 05:10:06.629
399	J7	có	\N	\N	2026-09-26 05:10:12.164	2026-09-26 05:10:12.164
400	J8	báo đỏ để xử lý	\N	\N	2026-09-26 05:10:30.136	2026-09-26 05:10:30.136
401	J9	không cần, báo đỏ là đươc	\N	\N	2026-09-26 05:10:48.935	2026-09-26 05:10:48.935
402	J10	cả 2	\N	\N	2026-09-26 05:10:54.172	2026-09-26 05:10:54.172
403	J11	có	\N	\N	2026-09-26 05:11:03.963	2026-09-26 05:11:06.223
405	J12	có khi thuê ngoài hàn khung, thời gian gửi nhận không quá 3 ngày	\N	\N	2026-09-26 05:11:21.511	2026-09-26 05:11:38.256
423	K11	24h	\N	\N	2026-09-26 05:13:32.064	2026-09-26 05:26:21.78
424	K12	24h	\N	\N	2026-09-26 05:13:32.064	2026-09-26 05:26:21.78
407	K1	24h ( tính từ ngày bắt đầu triển khai	\N	\N	2026-09-26 05:11:56.867	2026-09-26 05:12:12.785
411	K2	24h	\N	\N	2026-09-26 05:12:21.603	2026-09-26 05:12:21.603
425	K13	24h	\N	\N	2026-09-26 05:13:32.064	2026-09-26 05:26:21.78
412	K3	24h	\N	\N	2026-09-26 05:12:41.674	2026-09-26 05:12:48.263
428	L1	\N	Cần	\N	2026-09-26 05:13:53.898	2026-09-26 05:13:53.898
429	L2	\N	Cần	\N	2026-09-26 05:13:58.747	2026-09-26 05:13:58.747
430	L3	\N	Cần	\N	2026-09-26 05:14:05.528	2026-09-26 05:14:05.528
431	L4	\N	Cần	\N	2026-09-26 05:14:11.632	2026-09-26 05:14:11.632
432	L5	\N	Cần	\N	2026-09-26 05:14:23.553	2026-09-26 05:14:23.553
433	L6	\N	Cần	\N	2026-09-26 05:14:26.732	2026-09-26 05:14:26.732
434	L7	\N	Cần	\N	2026-09-26 05:14:32.168	2026-09-26 05:14:32.168
435	L8	\N	Cần	\N	2026-09-26 05:14:38.548	2026-09-26 05:14:38.548
436	L9	\N	Không cần	\N	2026-09-26 05:14:48.042	2026-09-26 05:14:48.042
437	L10	\N	Cần	\N	2026-09-26 05:14:53.163	2026-09-26 05:14:53.163
438	L11	quan trọng	Cần	\N	2026-09-26 05:14:57.773	2026-09-26 05:15:02.997
440	L12	\N	Cần	\N	2026-09-26 05:15:11.561	2026-09-26 05:15:11.561
441	L13	\N	Cần	\N	2026-09-26 05:15:18.826	2026-09-26 05:15:18.826
442	L14	\N	Cần	\N	2026-09-26 05:15:25.511	2026-09-26 05:15:25.511
443	L15	\N	Cần	\N	2026-09-26 05:15:32.24	2026-09-26 05:15:32.24
444	L16	\N	Cần	\N	2026-09-26 05:15:38.14	2026-09-26 05:15:38.14
445	L17	\N	Cần	\N	2026-09-26 05:15:45.512	2026-09-26 05:15:45.512
446	M1	\N	Có	\N	2026-09-26 05:16:06.546	2026-09-26 05:16:06.546
447	M2	\N	Có	\N	2026-09-26 05:16:08.592	2026-09-26 05:16:08.592
448	M3	\N	Có	\N	2026-09-26 05:16:11.857	2026-09-26 05:16:11.857
449	M4	\N	Có	\N	2026-09-26 05:16:15.147	2026-09-26 05:16:15.147
450	M5	\N	Có	\N	2026-09-26 05:16:16.58	2026-09-26 05:16:16.58
451	M6	\N	Có	\N	2026-09-26 05:16:19.722	2026-09-26 05:16:19.722
452	M7	\N	Có	\N	2026-09-26 05:16:21.527	2026-09-26 05:16:21.527
453	M8	\N	Có	\N	2026-09-26 05:16:24.017	2026-09-26 05:16:24.017
454	M9	\N	Có	\N	2026-09-26 05:16:34.085	2026-09-26 05:16:34.085
456	O1	lượng hàng chưa thật sự đủ. thiếu người	\N	\N	2026-09-26 05:17:04.539	2026-09-26 05:17:04.539
426	K15	24h	\N	\N	2026-09-26 05:13:44.438	2026-09-26 05:26:23.756
427	K16	24h	\N	\N	2026-09-26 05:13:44.438	2026-09-26 05:26:25.05
27	A4	cái này sẽ tùy thuộc vào kế hoạch doanh số để lên kế hoạch tuyển dụng	\N	\N	2026-09-25 23:24:48.66	2026-09-26 05:41:35.713
457	O2	lên kế hoạch công đoạn, đo lường , cảnh báo, tính % lỗi, tỷ lệ , nguy cơ chễ hạn đơn hàng, quản trị đo lường chất lượng ...	\N	\N	2026-09-26 05:17:30.788	2026-09-26 05:18:45.729
415	K4	24h	\N	\N	2026-09-26 05:12:50.727	2026-09-26 05:26:12.689
416	K5	24h	\N	\N	2026-09-26 05:12:52.794	2026-09-26 05:26:21.78
417	K6	24h	\N	\N	2026-09-26 05:12:55.544	2026-09-26 05:26:21.78
418	K7	24h	\N	\N	2026-09-26 05:12:58.395	2026-09-26 05:26:21.78
419	K8	48h	\N	\N	2026-09-26 05:13:02.565	2026-09-26 05:26:21.78
420	K9	48h	\N	\N	2026-09-26 05:13:08.118	2026-09-26 05:26:21.78
422	K10	48h	\N	\N	2026-09-26 05:13:26.105	2026-09-26 05:26:21.78
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, key, value, created_at, updated_at) FROM stdin;
2	ORDER_SET_NUMBER_COUNTER	12131	2026-09-24 23:55:32.376	2026-09-26 07:34:27.559
1	ORDER_CALCULATION_CONFIG_V1	{"version":2,"decimalPlaces":2,"setNumberStart":1,"framePrice":{"enabled":true,"roundToMm":10,"standardMaxMm":140,"doubleMinMm":180,"doubleMaxMm":250,"stepMm":10,"normalStepSurcharge":10000,"doubleSurcharge":110000,"overDoubleStepSurcharge":10000},"rules":[{"id":"551636fe-600b-4370-8b01-a4bb2fdd0ad9","scope":"MAIN","groupName":"","itemCode":"","parentGroupName":"","parentItemCode":"","pricingRule":"DOOR_AREA","heightSuggestion":"KEEP","widthSuggestion":"KEEP","active":true,"note":""},{"id":"33abbe78-11c5-4b59-9dd8-3420ec8f01d2","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Khuôn biệt thự trụ đứng 200","parentGroupName":"","parentItemCode":"","pricingRule":"DOUBLE_HEIGHT_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"CLEAR","active":true,"note":""},{"id":"f661a3fa-da63-43a2-ac78-08f6965f0297","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Khuôn biệt thự trụ đứng 260","parentGroupName":"","parentItemCode":"","pricingRule":"DOUBLE_HEIGHT_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"CLEAR","active":true,"note":""},{"id":"3a39f672-fd98-4236-af45-1c6ea01a8ab8","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Khuôn biệt thự trụ đứng 300","parentGroupName":"","parentItemCode":"","pricingRule":"DOUBLE_HEIGHT_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"CLEAR","active":true,"note":""},{"id":"f736b7c5-aacd-4c64-b455-1da7cc96fde3","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Khuôn biệt thự trụ ngang 200","parentGroupName":"","parentItemCode":"","pricingRule":"WIDTH_LINEAR","heightSuggestion":"CLEAR","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"7c373062-0170-490f-9eec-a9b9cb53e85e","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Khuôn biệt thự trụ ngang 300","parentGroupName":"","parentItemCode":"","pricingRule":"WIDTH_LINEAR","heightSuggestion":"CLEAR","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"9b307407-b60c-47d5-aadd-d9d16bed1cf3","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Phào biệt thự ngang 260","parentGroupName":"","parentItemCode":"","pricingRule":"WIDTH_LINEAR","heightSuggestion":"CLEAR","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"ea2c853c-4467-44de-b13e-8e9697b7ca4e","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Phào biệt thự đứng 200","parentGroupName":"","parentItemCode":"","pricingRule":"DOUBLE_HEIGHT_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"CLEAR","active":true,"note":""},{"id":"db9de617-f90c-4e9c-9c73-08273c5b4c17","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Phào biệt thự đỉnh 200","parentGroupName":"","parentItemCode":"","pricingRule":"WIDTH_LINEAR","heightSuggestion":"CLEAR","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"eef6ef00-85d0-446d-bb74-a8741500bed8","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Phào biệt thự đỉnh150","parentGroupName":"","parentItemCode":"","pricingRule":"WIDTH_LINEAR","heightSuggestion":"CLEAR","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"f01b1f58-2c02-4f33-bcd9-fa7973e61194","scope":"GROUP","groupName":"Khóa","itemCode":"","parentGroupName":"","parentItemCode":"","pricingRule":"PARENT_QUANTITY","heightSuggestion":"KEEP","widthSuggestion":"KEEP","active":true,"note":""},{"id":"2117aee3-1e9b-42f9-9baa-73f83a36282a","scope":"GROUP","groupName":"Ô Thoáng","itemCode":"","parentGroupName":"","parentItemCode":"","pricingRule":"PANEL_COUNT","heightSuggestion":"KEEP","widthSuggestion":"KEEP","active":true,"note":""},{"id":"9f9194c7-3ed0-4d7e-9ce3-5acef36cc0c0","scope":"ITEM","groupName":"Phao Rời","itemCode":"PR","parentGroupName":"Cửa Đi 1 Cánh","parentItemCode":"","pricingRule":"TRIM_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"9a3e3361-04fb-4d08-b3df-d7d447073ae2","scope":"ITEM","groupName":"Phào Biệt Thự","itemCode":"Phào biệt thự 120","parentGroupName":"","parentItemCode":"","pricingRule":"TRIM_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"79e24f54-0164-4155-957d-03bbad5de2a2","scope":"ITEM","groupName":"Phao Rời","itemCode":"PR","parentGroupName":"Cửa Đi 2 Cánh","parentItemCode":"","pricingRule":"TRIM_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"888f35a4-eed4-4007-87e2-a4a9dd0865a0","scope":"ITEM","groupName":"Phao Rời","itemCode":"PR","parentGroupName":"Cửa Đi 4 Cánh","parentItemCode":"","pricingRule":"TRIM_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"53304ede-e8f3-4e73-a762-0ae02d3b8d73","scope":"ITEM","groupName":"Phao Rời","itemCode":"PR","parentGroupName":"Cửa Đi Cánh Kính","parentItemCode":"","pricingRule":"TRIM_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"a6d76aa7-d7eb-4eb6-8ac4-fca3ef97f9fe","scope":"ITEM","groupName":"Phao Rời","itemCode":"PR","parentGroupName":"Cửa Đi Vách Kính","parentItemCode":"","pricingRule":"TRIM_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"PARENT_WIDTH","active":true,"note":""},{"id":"f8a9e20b-51ee-4f12-b668-3e7b405c98f2","scope":"ITEM","groupName":"Phao Rời","itemCode":"PR","parentGroupName":"Cửa Sổ","parentItemCode":"","pricingRule":"PERIMETER_LINEAR","heightSuggestion":"PARENT_HEIGHT","widthSuggestion":"PARENT_WIDTH","active":true,"note":""}]}	2026-09-24 11:47:00.336	2026-09-25 03:09:46.987
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-09-22 12:43:01
20211116045059	2026-09-22 12:43:01
20211116050929	2026-09-22 12:43:01
20211116051442	2026-09-22 12:43:01
20211116212300	2026-09-22 12:43:01
20211116213355	2026-09-22 12:43:01
20211116213934	2026-09-22 12:43:01
20211116214523	2026-09-22 12:43:01
20211122062447	2026-09-22 12:43:01
20211124070109	2026-09-22 12:43:01
20211202204204	2026-09-22 12:43:01
20211202204605	2026-09-22 12:43:01
20211210212804	2026-09-22 12:43:01
20211228014915	2026-09-22 12:43:01
20220107221237	2026-09-22 12:43:01
20220228202821	2026-09-22 12:43:01
20220312004840	2026-09-22 12:43:01
20220603231003	2026-09-22 12:43:01
20220603232444	2026-09-22 12:43:01
20220615214548	2026-09-22 12:43:01
20220712093339	2026-09-22 12:43:01
20220908172859	2026-09-22 12:43:01
20220916233421	2026-09-22 12:43:01
20230119133233	2026-09-22 12:43:01
20230128025114	2026-09-22 12:43:01
20230128025212	2026-09-22 12:43:01
20230227211149	2026-09-22 12:43:01
20230228184745	2026-09-22 12:43:01
20230308225145	2026-09-22 12:43:01
20230328144023	2026-09-22 12:43:01
20231018144023	2026-09-22 12:43:01
20231204144023	2026-09-22 12:43:01
20231204144024	2026-09-22 12:43:01
20231204144025	2026-09-22 12:43:01
20240108234812	2026-09-22 12:43:01
20240109165339	2026-09-22 12:43:01
20240227174441	2026-09-22 12:43:01
20240311171622	2026-09-22 12:43:01
20240321100241	2026-09-22 12:43:01
20240401105812	2026-09-22 12:43:01
20240418121054	2026-09-22 12:43:01
20240523004032	2026-09-22 12:43:01
20240618124746	2026-09-22 12:43:01
20240801235015	2026-09-22 12:43:01
20240805133720	2026-09-22 12:43:01
20240827160934	2026-09-22 12:43:01
20240919163303	2026-09-22 12:43:01
20240919163305	2026-09-22 12:43:01
20241019105805	2026-09-22 12:43:01
20241030150047	2026-09-22 12:43:01
20241108114728	2026-09-22 12:43:01
20241121104152	2026-09-22 12:43:01
20241130184212	2026-09-22 12:43:01
20241220035512	2026-09-22 12:43:01
20241220123912	2026-09-22 12:43:01
20241224161212	2026-09-22 12:43:01
20250107150512	2026-09-22 12:43:01
20250110162412	2026-09-22 12:43:01
20250123174212	2026-09-22 12:43:01
20250128220012	2026-09-22 12:43:01
20250506224012	2026-09-22 12:43:01
20250523164012	2026-09-22 12:43:01
20250714121412	2026-09-22 12:43:01
20250905041441	2026-09-22 12:43:01
20251103001201	2026-09-22 12:43:01
20251120212548	2026-09-22 12:43:01
20251120215549	2026-09-22 12:43:01
20260218120000	2026-09-22 12:43:01
20260326120000	2026-09-22 12:43:01
20260514120000	2026-09-22 12:43:01
20260527120000	2026-09-22 12:43:01
20260528120000	2026-09-22 12:43:01
20260603120000	2026-09-22 12:43:01
20260605120000	2026-09-22 12:43:01
20260606110000	2026-09-22 12:43:01
20260616120000	2026-09-22 12:43:01
20260624120000	2026-09-22 12:43:01
20260626120000	2026-09-22 12:43:01
20260706120000	2026-09-22 12:43:01
20260707120000	2026-09-22 12:43:01
20260709120000	2026-09-22 12:43:01
20260714120000	2026-09-22 12:43:01
20260827120000	2026-09-22 12:43:01
20260914120000	2026-09-22 12:43:01
20260916120000	2026-09-22 12:43:01
20260922120000	2026-09-25 11:52:34
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type, versioning_status, lifecycle_configuration, lifecycle_configuration_generation) FROM stdin;
order-images	order-images	\N	2026-09-23 01:14:24.013095+00	2026-09-23 01:14:24.013095+00	t	f	\N	{image/jpeg,image/png,image/webp}	\N	STANDARD	DISABLED	\N	\N
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-09-22 12:43:00.97887
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-09-22 12:43:01.005166
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-09-22 12:43:01.01739
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-09-22 12:43:01.088991
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-09-22 12:43:01.118698
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-09-22 12:43:01.127721
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-09-22 12:43:01.135363
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-09-22 12:43:01.143644
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-09-22 12:43:01.152555
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-09-22 12:43:01.161543
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-09-22 12:43:01.16897
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-09-22 12:43:01.175821
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-09-22 12:43:01.183038
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-09-22 12:43:01.192332
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-09-22 12:43:01.199502
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-09-22 12:43:01.249254
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-09-22 12:43:01.25672
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-09-22 12:43:01.263665
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-09-22 12:43:01.270363
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-09-22 12:43:01.276626
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-09-22 12:43:01.282417
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-09-22 12:43:01.289497
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-09-22 12:43:01.319586
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-09-22 12:43:01.351903
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-09-22 12:43:01.35946
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-09-22 12:43:01.366505
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-09-22 12:43:01.373533
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-09-22 12:43:01.379297
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-09-22 12:43:01.384624
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-09-22 12:43:01.38973
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-09-22 12:43:01.394974
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-09-22 12:43:01.403803
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-09-22 12:43:01.413053
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-09-22 12:43:01.424487
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-09-22 12:43:01.430178
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-09-22 12:43:01.43794
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-09-22 12:43:01.443942
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-09-22 12:43:01.450784
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-09-22 12:43:01.457474
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-09-22 12:43:01.468953
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-09-22 12:43:01.475391
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-09-22 12:43:01.48113
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-09-22 12:43:01.487119
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-09-22 12:43:01.492973
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-09-22 12:43:01.498506
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-09-22 12:43:01.505172
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-09-22 12:43:01.520882
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-09-22 12:43:01.52737
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-09-22 12:43:01.534633
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-09-22 12:43:01.558091
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-09-22 12:43:01.566375
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-09-22 12:43:06.127604
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-09-22 12:43:06.13026
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-09-22 12:43:06.143777
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-09-22 12:43:06.147473
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-09-22 12:43:06.149744
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-09-22 12:43:06.169176
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-09-22 12:43:06.181339
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-09-22 12:43:06.187167
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-09-22 12:43:06.193889
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-09-22 12:43:06.199995
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-09-22 12:43:06.207443
62	object-versioning-core	0b855f00ff3be0bfca91efee02a9858912491a9a	2026-09-22 12:43:06.213025
63	fix-search-name-relative-to-prefix	c7485e417624f795ce8bb2da21927f48e088904d	2026-09-22 12:43:06.23223
64	fix-search-by-timestamp-sqli	0af424ecd388a39bb1645184b222185a12149675	2026-09-22 12:43:06.243389
65	objects-key-version-index	da319c4b89ba800ce795d1b699f3a70675138058	2026-09-22 12:43:06.262487
66	objects-current-version-index	191466c93aa2c46a00e36505577c5fcab8d7cb4b	2026-09-22 12:43:06.274323
67	objects-null-version-index	15bfe8c35b66642b6c78ba60060fa8793bd2207a	2026-09-22 12:43:06.283433
68	bucket-lifecycle-configuration	3c08f6f889922f399519722a932b51007c11bebc	2026-09-22 12:43:06.286019
69	validate-bucket-lifecycle-constraints	4febacaaaa0e61e2b783bef081fe03a287e65eb3	2026-09-22 12:43:06.297559
70	list-objects-with-versions	5c17c3777616cd8d7b18b82835525fa3205af57b	2026-09-22 12:43:06.305813
71	objects-delete-marker-index	6d14858e66c66f8d6accf8a2630aefd1527fddba	2026-09-22 12:43:06.867622
72	drop-bucketid-objname-index	302beb09e1b469d7d4db19566f2389d280b64aa3	2026-09-22 12:43:06.88386
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, archived_at, is_delete_marker, is_versioned) FROM stdin;
d1d0858d-5d7e-4b9b-8bed-c97750ef52d2	order-images	orders/1790126082996-45ffcbfe-16f2-4199-a493-7c031e7ab474.png	\N	2026-09-23 01:14:44.256696+00	2026-09-23 01:14:44.256696+00	2026-09-23 01:14:44.256696+00	{"eTag": "\\"4e0d25d1d95172ab50fa534a75679e29\\"", "size": 26657, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-23T01:14:45.000Z", "contentLength": 26657, "httpStatusCode": 200}	a07fc77a-68e5-4160-9358-b7af80b37673	\N	{}	\N	f	f
6254985b-bb07-412a-a6d5-004baa2d1a6d	order-images	orders/1790157053200-2a886dbf-e5be-4cf7-8e1b-4c5121c21a31.png	\N	2026-09-23 09:50:54.208778+00	2026-09-23 09:50:54.208778+00	2026-09-23 09:50:54.208778+00	{"eTag": "\\"8101d3dd471e424af7a0db6665a63a14\\"", "size": 79566, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-23T09:50:55.000Z", "contentLength": 79566, "httpStatusCode": 200}	fef34b40-c8e4-4e7c-9eea-6fd6ef36d87d	\N	{}	\N	f	f
d341e9ce-8a03-4b5b-8434-7147bd2d8e9a	order-images	orders/1790157068561-7ca8f2bc-1c23-4354-8d58-dab3378c31b5.png	\N	2026-09-23 09:51:09.500063+00	2026-09-23 09:51:09.500063+00	2026-09-23 09:51:09.500063+00	{"eTag": "\\"ab29caaf354b82dbd031ec3087c1eeda\\"", "size": 163677, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-23T09:51:10.000Z", "contentLength": 163677, "httpStatusCode": 200}	0d57e410-6d79-42c3-b1d8-666633306e80	\N	{}	\N	f	f
6ab64bb7-c4b0-4482-ab7a-d046f143ffa1	order-images	orders/1790157085805-12e59ce5-9727-415f-b9e1-41e06f47ecbf.png	\N	2026-09-23 09:51:27.160147+00	2026-09-23 09:51:27.160147+00	2026-09-23 09:51:27.160147+00	{"eTag": "\\"6cfb459513856095ba301e16b3b8222a\\"", "size": 52976, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-23T09:51:28.000Z", "contentLength": 52976, "httpStatusCode": 200}	db5834a7-3aa5-46cb-b30e-26a2a003a8ce	\N	{}	\N	f	f
3991b9c4-080e-4b43-836a-59317db12578	order-images	orders/1790157099400-ec46ee94-1f86-47cd-8e74-4508c17147f2.png	\N	2026-09-23 09:51:40.18162+00	2026-09-23 09:51:40.18162+00	2026-09-23 09:51:40.18162+00	{"eTag": "\\"421b53a4f35d4e09135539faa7d95fc6\\"", "size": 60298, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-23T09:51:41.000Z", "contentLength": 60298, "httpStatusCode": 200}	bb1fdfe1-dc6f-4e26-bcc9-cf4dd7f3f896	\N	{}	\N	f	f
d2c491bf-78d3-4215-b0e1-3c7a7331ef42	order-images	orders/1790332532270-1653a617-a93b-4b02-a9f9-a7b72a5c9d2c.png	\N	2026-09-25 10:35:33.304004+00	2026-09-25 10:35:33.304004+00	2026-09-25 10:35:33.304004+00	{"eTag": "\\"54d3150c397ba29d0a972f3f24c23b26\\"", "size": 67135, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-25T10:35:34.000Z", "contentLength": 67135, "httpStatusCode": 200}	a4737e7f-f176-4be2-9826-ebe625509b99	\N	{}	\N	f	f
08495a46-08c7-4d22-9077-f6899765c4d9	order-images	orders/1790332595126-567f85b2-c59f-4edc-832d-f09f18de80d2.png	\N	2026-09-25 10:36:35.899048+00	2026-09-25 10:36:35.899048+00	2026-09-25 10:36:35.899048+00	{"eTag": "\\"54d3150c397ba29d0a972f3f24c23b26\\"", "size": 67135, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-25T10:36:36.000Z", "contentLength": 67135, "httpStatusCode": 200}	a17c4a67-b9d8-43fd-bd1d-c5c2de9d183e	\N	{}	\N	f	f
11efbd38-6a04-4afe-8996-22e6ee7e3e1d	order-images	orders/1790332704757-374ec9f3-2b85-47e4-a0de-c33742bd57a7.png	\N	2026-09-25 10:38:25.685224+00	2026-09-25 10:38:25.685224+00	2026-09-25 10:38:25.685224+00	{"eTag": "\\"53b7a64f5b24b6fe801a0518d37067f1\\"", "size": 118198, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-25T10:38:26.000Z", "contentLength": 118198, "httpStatusCode": 200}	2942179e-0bdc-46c9-af81-3936ddcebcf7	\N	{}	\N	f	f
65a66129-7fbd-47f2-8d09-3d1ab8b16e9b	order-images	orders/1790334127528-8b9ab644-f35e-4596-8ce2-5a8617637617.png	\N	2026-09-25 11:02:09.011811+00	2026-09-25 11:02:09.011811+00	2026-09-25 11:02:09.011811+00	{"eTag": "\\"1274fa3bd34b25c833c3cc530aa8e43a\\"", "size": 84324, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-25T11:02:10.000Z", "contentLength": 84324, "httpStatusCode": 200}	4ef9af89-01de-45d2-8680-7559d9637e91	\N	{}	\N	f	f
b2b00e96-22f8-45ee-8b90-94a6d1f38a04	order-images	orders/1790334339415-9755e364-5416-4c33-b0cc-ab07628a47c2.png	\N	2026-09-25 11:05:40.80045+00	2026-09-25 11:05:40.80045+00	2026-09-25 11:05:40.80045+00	{"eTag": "\\"1274fa3bd34b25c833c3cc530aa8e43a\\"", "size": 84324, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-25T11:05:41.000Z", "contentLength": 84324, "httpStatusCode": 200}	71085bb6-1b3b-4625-aac3-9fc688eb108e	\N	{}	\N	f	f
abc2ce20-e24d-4e0c-8d50-ee280cb38fac	order-images	orders/1790334971500-34eb6dcc-84c2-4fd0-a969-6bb54d94f378.png	\N	2026-09-25 11:16:12.799766+00	2026-09-25 11:16:12.799766+00	2026-09-25 11:16:12.799766+00	{"eTag": "\\"bda1071aab344c14a6dd6919efdede0a\\"", "size": 102789, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-25T11:16:13.000Z", "contentLength": 102789, "httpStatusCode": 200}	17ae265c-ea04-42b8-a26f-f4210f1eb549	\N	{}	\N	f	f
c31b8d3c-4c20-4534-b99a-e30bb550a4d1	order-images	orders/1790334982558-9f962afb-200e-464f-9fce-bfcd2fb8c4b6.png	\N	2026-09-25 11:16:23.29363+00	2026-09-25 11:16:23.29363+00	2026-09-25 11:16:23.29363+00	{"eTag": "\\"bda1071aab344c14a6dd6919efdede0a\\"", "size": 102789, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-25T11:16:24.000Z", "contentLength": 102789, "httpStatusCode": 200}	0b39dcd2-c26d-4860-a268-f4f963502db1	\N	{}	\N	f	f
c34c0059-0a81-446d-afeb-5cd0aaad17a8	order-images	orders/1790386426583-f8a8cab6-631f-4ebf-848f-052d985471a6.png	\N	2026-09-26 01:33:48.676474+00	2026-09-26 01:33:48.676474+00	2026-09-26 01:33:48.676474+00	{"eTag": "\\"9fbb33f6c8952b2301c0ace9f7d9b213\\"", "size": 442851, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T01:33:49.000Z", "contentLength": 442851, "httpStatusCode": 200}	6ad35a60-6f62-4b63-a732-ae112ffc5b36	\N	{}	\N	f	f
5dae0597-e79d-4986-9179-1e6dc30727e7	order-images	orders/1790386482841-0bc045bc-f464-48b7-9197-366126d834e9.png	\N	2026-09-26 01:34:44.123397+00	2026-09-26 01:34:44.123397+00	2026-09-26 01:34:44.123397+00	{"eTag": "\\"9fbb33f6c8952b2301c0ace9f7d9b213\\"", "size": 442851, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T01:34:45.000Z", "contentLength": 442851, "httpStatusCode": 200}	56226a9e-7b59-4551-9a9a-b81659f61c09	\N	{}	\N	f	f
a7cc690e-e6d3-430e-9116-6731f6068e44	order-images	orders/1790388109821-84b6f12f-1669-4bea-81ff-a5f72fb3fcc4.png	\N	2026-09-26 02:01:50.879504+00	2026-09-26 02:01:50.879504+00	2026-09-26 02:01:50.879504+00	{"eTag": "\\"e1fb0f3fe3d2c741a678080ea01e5a5f\\"", "size": 73392, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:01:51.000Z", "contentLength": 73392, "httpStatusCode": 200}	11e6185c-06bd-41fe-81ba-0fe73abeea45	\N	{}	\N	f	f
3a1dd539-2427-4a7a-99a0-2090269c8c6d	order-images	orders/1790388111092-e2313aff-f049-4cab-a597-b236eddf6b0a.png	\N	2026-09-26 02:01:51.827355+00	2026-09-26 02:01:51.827355+00	2026-09-26 02:01:51.827355+00	{"eTag": "\\"e1fb0f3fe3d2c741a678080ea01e5a5f\\"", "size": 73392, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:01:52.000Z", "contentLength": 73392, "httpStatusCode": 200}	89d13561-4093-4a49-8c62-e39ab762fc37	\N	{}	\N	f	f
6b215cf8-5d03-4a78-857f-0b84b4b4c6f3	order-images	orders/1790388120872-df20d6cd-33ba-49a7-8366-31964775eadf.png	\N	2026-09-26 02:02:02.135404+00	2026-09-26 02:02:02.135404+00	2026-09-26 02:02:02.135404+00	{"eTag": "\\"e1fb0f3fe3d2c741a678080ea01e5a5f\\"", "size": 73392, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:02:03.000Z", "contentLength": 73392, "httpStatusCode": 200}	e3ac9e74-7ee9-49f0-9a73-a36f0d9e20ee	\N	{}	\N	f	f
a52a2973-9ae2-4c30-af6d-b850e055b4e0	order-images	orders/1790388121314-e985f4fa-a5dd-428d-8872-77df6ea6cc26.png	\N	2026-09-26 02:02:02.82185+00	2026-09-26 02:02:02.82185+00	2026-09-26 02:02:02.82185+00	{"eTag": "\\"e1fb0f3fe3d2c741a678080ea01e5a5f\\"", "size": 73392, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:02:03.000Z", "contentLength": 73392, "httpStatusCode": 200}	f6ba55df-9079-44ea-bcfe-975f0795649d	\N	{}	\N	f	f
1ca7cf46-6084-4824-9a4c-c6bca53247ac	order-images	orders/1790388157387-7be996e5-51ae-4c8f-964e-bbc874d3baff.png	\N	2026-09-26 02:02:38.198812+00	2026-09-26 02:02:38.198812+00	2026-09-26 02:02:38.198812+00	{"eTag": "\\"e1fb0f3fe3d2c741a678080ea01e5a5f\\"", "size": 73392, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:02:39.000Z", "contentLength": 73392, "httpStatusCode": 200}	6297b267-326b-4d14-a3b6-535d9f1f6c91	\N	{}	\N	f	f
df57e363-a6b2-4878-bbce-c9a4cd20dd32	order-images	orders/1790388157592-cf4f8d97-4423-44d1-b2a1-40feea726b8e.png	\N	2026-09-26 02:02:38.902548+00	2026-09-26 02:02:38.902548+00	2026-09-26 02:02:38.902548+00	{"eTag": "\\"e1fb0f3fe3d2c741a678080ea01e5a5f\\"", "size": 73392, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:02:39.000Z", "contentLength": 73392, "httpStatusCode": 200}	7f05ccc4-e069-412f-bc91-be3fc1e459f6	\N	{}	\N	f	f
5b33d9dc-1cfa-4132-b231-3950ba17ac81	order-images	orders/1790389434700-edf1c93c-01f8-4ce4-9398-9c8097dfd76f.png	\N	2026-09-26 02:23:55.676916+00	2026-09-26 02:23:55.676916+00	2026-09-26 02:23:55.676916+00	{"eTag": "\\"5fd4aaaee7d52bfd91da9ffcbae32fff\\"", "size": 22305, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:23:56.000Z", "contentLength": 22305, "httpStatusCode": 200}	bb03dd16-152c-4e79-884d-83fd32583b6b	\N	{}	\N	f	f
f3c71995-529c-4671-809e-0b268b756c97	order-images	orders/1790389435080-c231eb0a-f166-4a50-b801-589557138691.png	\N	2026-09-26 02:23:55.678473+00	2026-09-26 02:23:55.678473+00	2026-09-26 02:23:55.678473+00	{"eTag": "\\"5fd4aaaee7d52bfd91da9ffcbae32fff\\"", "size": 22305, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:23:56.000Z", "contentLength": 22305, "httpStatusCode": 200}	fd21013d-6ec6-4f3f-90e0-527c365beb13	\N	{}	\N	f	f
30c59bc9-d7f4-4d81-b2fd-0e09a8b4d3c8	order-images	orders/1790389494138-83a5dadd-166f-4a13-9e5f-fbe43737114b.png	\N	2026-09-26 02:24:54.709218+00	2026-09-26 02:24:54.709218+00	2026-09-26 02:24:54.709218+00	{"eTag": "\\"5fd4aaaee7d52bfd91da9ffcbae32fff\\"", "size": 22305, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:24:55.000Z", "contentLength": 22305, "httpStatusCode": 200}	d8cf26e5-589e-4b98-a1c9-ff57df29dd29	\N	{}	\N	f	f
e47e2f9f-f042-48da-b6a8-b96902c0fa20	order-images	orders/1790389494605-96f7e77f-2e60-4c8e-bb3f-c4d68ab3fabd.png	\N	2026-09-26 02:24:55.622475+00	2026-09-26 02:24:55.622475+00	2026-09-26 02:24:55.622475+00	{"eTag": "\\"5fd4aaaee7d52bfd91da9ffcbae32fff\\"", "size": 22305, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:24:56.000Z", "contentLength": 22305, "httpStatusCode": 200}	2820e0ae-7c81-4773-880f-644fc922ed49	\N	{}	\N	f	f
68cb7568-f399-439c-8554-d883e2162447	order-images	orders/1790389549717-59484982-d12a-4563-b052-734ab3080f78.png	\N	2026-09-26 02:25:50.907723+00	2026-09-26 02:25:50.907723+00	2026-09-26 02:25:50.907723+00	{"eTag": "\\"35f3c870694f36345432c83ea81963db\\"", "size": 211638, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:25:51.000Z", "contentLength": 211638, "httpStatusCode": 200}	65cf3471-fe3b-4348-bb5a-e5f7abf79b6b	\N	{}	\N	f	f
bcd7a589-cae0-4c9b-b48f-3a388bccc095	order-images	orders/1790390470116-08e97a85-d97d-436d-aeaf-80a4d39d350c.png	\N	2026-09-26 02:41:10.910027+00	2026-09-26 02:41:10.910027+00	2026-09-26 02:41:10.910027+00	{"eTag": "\\"72bc30de80edb6bf4f34ed515a75c81d\\"", "size": 57761, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:41:11.000Z", "contentLength": 57761, "httpStatusCode": 200}	0ef853e9-9b6e-47b4-b3aa-bb5d2b3cf04e	\N	{}	\N	f	f
cc59ad07-ad79-4dde-9fab-2340edd6cc98	order-images	orders/1790390490978-0a57d412-d0ae-4ba8-b3da-9284e6f8273a.png	\N	2026-09-26 02:41:31.602498+00	2026-09-26 02:41:31.602498+00	2026-09-26 02:41:31.602498+00	{"eTag": "\\"ab3e7ae9a6fe04e9c2fdd56def698d97\\"", "size": 21221, "mimetype": "image/png", "cacheControl": "3600", "lastModified": "2026-09-26T02:41:32.000Z", "contentLength": 21221, "httpStatusCode": 200}	f586f5cd-ff18-4151-8db3-074f57d37b2f	\N	{}	\N	f	f
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: item_attribute_imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_attribute_imports_id_seq', 2, true);


--
-- Name: item_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_categories_id_seq', 3, true);


--
-- Name: item_master_imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_master_imports_id_seq', 3, true);


--
-- Name: item_masters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_masters_id_seq', 851, true);


--
-- Name: master_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.master_options_id_seq', 65, true);


--
-- Name: order_imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_imports_id_seq', 4, true);


--
-- Name: production_calendar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_calendar_id_seq', 1, false);


--
-- Name: production_component_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_component_orders_id_seq', 33, true);


--
-- Name: production_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_logs_id_seq', 2, true);


--
-- Name: production_machine_downtimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_machine_downtimes_id_seq', 1, false);


--
-- Name: production_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_plans_id_seq', 1, false);


--
-- Name: production_programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_programs_id_seq', 1, false);


--
-- Name: production_reasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_reasons_id_seq', 19, true);


--
-- Name: production_sets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_sets_id_seq', 27, true);


--
-- Name: production_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_stages_id_seq', 16, true);


--
-- Name: production_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_tasks_id_seq', 264, true);


--
-- Name: production_work_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_work_centers_id_seq', 8, true);


--
-- Name: sales_order_item_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_order_item_details_id_seq', 483, true);


--
-- Name: sales_order_item_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_order_item_images_id_seq', 13, true);


--
-- Name: sales_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_order_items_id_seq', 164, true);


--
-- Name: sales_order_requirements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_order_requirements_id_seq', 348, true);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_orders_id_seq', 37, true);


--
-- Name: shipping_calculations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_calculations_id_seq', 1, false);


--
-- Name: shipping_model_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_model_mappings_id_seq', 7, true);


--
-- Name: shipping_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_rates_id_seq', 114, true);


--
-- Name: survey_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.survey_answers_id_seq', 485, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 22, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_mfa_factor_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_mfa_factor_id_key UNIQUE (mfa_factor_id);


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_pkey PRIMARY KEY (id);


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_user_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_user_id_key UNIQUE (user_id);


--
-- Name: mfa_recovery_codes mfa_recovery_codes_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: scim_tokens scim_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.scim_tokens
    ADD CONSTRAINT scim_tokens_pkey PRIMARY KEY (id);


--
-- Name: scim_users scim_users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.scim_users
    ADD CONSTRAINT scim_users_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: item_attribute_imports item_attribute_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_attribute_imports
    ADD CONSTRAINT item_attribute_imports_pkey PRIMARY KEY (id);


--
-- Name: item_categories item_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_categories
    ADD CONSTRAINT item_categories_pkey PRIMARY KEY (id);


--
-- Name: item_master_imports item_master_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_master_imports
    ADD CONSTRAINT item_master_imports_pkey PRIMARY KEY (id);


--
-- Name: item_masters item_masters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_masters
    ADD CONSTRAINT item_masters_pkey PRIMARY KEY (id);


--
-- Name: master_options master_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_options
    ADD CONSTRAINT master_options_pkey PRIMARY KEY (id);


--
-- Name: order_imports order_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_imports
    ADD CONSTRAINT order_imports_pkey PRIMARY KEY (id);


--
-- Name: production_calendar production_calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_calendar
    ADD CONSTRAINT production_calendar_pkey PRIMARY KEY (id);


--
-- Name: production_component_orders production_component_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_component_orders
    ADD CONSTRAINT production_component_orders_pkey PRIMARY KEY (id);


--
-- Name: production_logs production_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_logs
    ADD CONSTRAINT production_logs_pkey PRIMARY KEY (id);


--
-- Name: production_machine_downtimes production_machine_downtimes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_machine_downtimes
    ADD CONSTRAINT production_machine_downtimes_pkey PRIMARY KEY (id);


--
-- Name: production_plans production_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_plans
    ADD CONSTRAINT production_plans_pkey PRIMARY KEY (id);


--
-- Name: production_programs production_programs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_programs
    ADD CONSTRAINT production_programs_pkey PRIMARY KEY (id);


--
-- Name: production_reasons production_reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_reasons
    ADD CONSTRAINT production_reasons_pkey PRIMARY KEY (id);


--
-- Name: production_sets production_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_sets
    ADD CONSTRAINT production_sets_pkey PRIMARY KEY (id);


--
-- Name: production_stages production_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_stages
    ADD CONSTRAINT production_stages_pkey PRIMARY KEY (id);


--
-- Name: production_tasks production_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_tasks
    ADD CONSTRAINT production_tasks_pkey PRIMARY KEY (id);


--
-- Name: production_work_centers production_work_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_work_centers
    ADD CONSTRAINT production_work_centers_pkey PRIMARY KEY (id);


--
-- Name: sales_order_item_details sales_order_item_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_item_details
    ADD CONSTRAINT sales_order_item_details_pkey PRIMARY KEY (id);


--
-- Name: sales_order_item_images sales_order_item_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_item_images
    ADD CONSTRAINT sales_order_item_images_pkey PRIMARY KEY (id);


--
-- Name: sales_order_items sales_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_pkey PRIMARY KEY (id);


--
-- Name: sales_order_requirements sales_order_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_requirements
    ADD CONSTRAINT sales_order_requirements_pkey PRIMARY KEY (id);


--
-- Name: sales_orders sales_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_pkey PRIMARY KEY (id);


--
-- Name: shipping_calculations shipping_calculations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_calculations
    ADD CONSTRAINT shipping_calculations_pkey PRIMARY KEY (id);


--
-- Name: shipping_model_mappings shipping_model_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_model_mappings
    ADD CONSTRAINT shipping_model_mappings_pkey PRIMARY KEY (id);


--
-- Name: shipping_rates shipping_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_rates
    ADD CONSTRAINT shipping_rates_pkey PRIMARY KEY (id);


--
-- Name: survey_answers survey_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.survey_answers
    ADD CONSTRAINT survey_answers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: mfa_recovery_codes_set_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_recovery_codes_set_id_idx ON auth.mfa_recovery_codes USING btree (mfa_recovery_code_set_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: scim_tokens_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_tokens_expires_at_idx ON auth.scim_tokens USING btree (expires_at);


--
-- Name: scim_tokens_revoked_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_tokens_revoked_at_idx ON auth.scim_tokens USING btree (revoked_at);


--
-- Name: scim_tokens_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_tokens_sso_provider_id_idx ON auth.scim_tokens USING btree (sso_provider_id);


--
-- Name: scim_tokens_token_hash_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX scim_tokens_token_hash_key ON auth.scim_tokens USING btree (token_hash);


--
-- Name: scim_users_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_users_created_at_idx ON auth.scim_users USING btree (sso_provider_id, created_at, id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_users_deleted_at_idx ON auth.scim_users USING btree (deleted_at);


--
-- Name: scim_users_external_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX scim_users_external_id_key ON auth.scim_users USING btree (sso_provider_id, external_id) WHERE ((external_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: scim_users_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_users_id_idx ON auth.scim_users USING btree (sso_provider_id, id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_users_sso_provider_id_idx ON auth.scim_users USING btree (sso_provider_id);


--
-- Name: scim_users_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_users_updated_at_idx ON auth.scim_users USING btree (sso_provider_id, updated_at, id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_users_user_id_idx ON auth.scim_users USING btree (user_id);


--
-- Name: scim_users_user_name_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX scim_users_user_name_idx ON auth.scim_users USING btree (sso_provider_id, user_name COLLATE "C", id) WHERE (deleted_at IS NULL);


--
-- Name: scim_users_user_name_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX scim_users_user_name_key ON auth.scim_users USING btree (sso_provider_id, user_name) WHERE (deleted_at IS NULL);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: item_attribute_imports_file_hash_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_attribute_imports_file_hash_idx ON public.item_attribute_imports USING btree (file_hash);


--
-- Name: item_attribute_imports_imported_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_attribute_imports_imported_at_idx ON public.item_attribute_imports USING btree (imported_at);


--
-- Name: item_categories_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_categories_active_idx ON public.item_categories USING btree (active);


--
-- Name: item_categories_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX item_categories_code_key ON public.item_categories USING btree (code);


--
-- Name: item_categories_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_categories_sort_order_idx ON public.item_categories USING btree (sort_order);


--
-- Name: item_master_imports_file_hash_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_master_imports_file_hash_idx ON public.item_master_imports USING btree (file_hash);


--
-- Name: item_master_imports_imported_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_master_imports_imported_at_idx ON public.item_master_imports USING btree (imported_at);


--
-- Name: item_masters_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_masters_active_idx ON public.item_masters USING btree (active);


--
-- Name: item_masters_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_masters_category_idx ON public.item_masters USING btree (category);


--
-- Name: item_masters_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX item_masters_code_key ON public.item_masters USING btree (code);


--
-- Name: item_masters_price_imported_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_masters_price_imported_at_idx ON public.item_masters USING btree (price_imported_at);


--
-- Name: item_masters_sales_model_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_masters_sales_model_idx ON public.item_masters USING btree (sales_model);


--
-- Name: item_masters_sales_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_masters_sales_name_idx ON public.item_masters USING btree (sales_name);


--
-- Name: item_masters_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_masters_updated_at_idx ON public.item_masters USING btree (updated_at);


--
-- Name: master_options_group_code_active_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX master_options_group_code_active_sort_order_idx ON public.master_options USING btree (group_code, active, sort_order);


--
-- Name: master_options_group_code_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX master_options_group_code_code_key ON public.master_options USING btree (group_code, code);


--
-- Name: order_imports_file_hash_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_imports_file_hash_idx ON public.order_imports USING btree (file_hash);


--
-- Name: order_imports_order_id_imported_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_imports_order_id_imported_at_idx ON public.order_imports USING btree (order_id, imported_at);


--
-- Name: production_calendar_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_calendar_date_key ON public.production_calendar USING btree (date);


--
-- Name: production_component_orders_set_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_component_orders_set_id_idx ON public.production_component_orders USING btree (set_id);


--
-- Name: production_component_orders_set_id_kind_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_component_orders_set_id_kind_key ON public.production_component_orders USING btree (set_id, kind);


--
-- Name: production_logs_entity_entity_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_logs_entity_entity_id_created_at_idx ON public.production_logs USING btree (entity, entity_id, created_at);


--
-- Name: production_machine_downtimes_work_center_code_from_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_machine_downtimes_work_center_code_from_at_idx ON public.production_machine_downtimes USING btree (work_center_code, from_at);


--
-- Name: production_plans_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_plans_code_key ON public.production_plans USING btree (code);


--
-- Name: production_plans_from_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_plans_from_date_idx ON public.production_plans USING btree (from_date);


--
-- Name: production_programs_model_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_programs_model_idx ON public.production_programs USING btree (model);


--
-- Name: production_programs_model_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_programs_model_version_key ON public.production_programs USING btree (model, version);


--
-- Name: production_reasons_active_group_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_reasons_active_group_sort_order_idx ON public.production_reasons USING btree (active, "group", sort_order);


--
-- Name: production_reasons_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_reasons_code_key ON public.production_reasons USING btree (code);


--
-- Name: production_sets_order_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_sets_order_id_idx ON public.production_sets USING btree (order_id);


--
-- Name: production_sets_order_item_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_sets_order_item_id_key ON public.production_sets USING btree (order_item_id);


--
-- Name: production_sets_plan_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_sets_plan_id_idx ON public.production_sets USING btree (plan_id);


--
-- Name: production_sets_set_no_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_sets_set_no_idx ON public.production_sets USING btree (set_no);


--
-- Name: production_sets_status_due_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_sets_status_due_date_idx ON public.production_sets USING btree (status, due_date);


--
-- Name: production_stages_active_seq_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_stages_active_seq_idx ON public.production_stages USING btree (active, seq);


--
-- Name: production_stages_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_stages_code_key ON public.production_stages USING btree (code);


--
-- Name: production_stages_work_center_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_stages_work_center_code_idx ON public.production_stages USING btree (work_center_code);


--
-- Name: production_tasks_planned_start_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_tasks_planned_start_idx ON public.production_tasks USING btree (planned_start);


--
-- Name: production_tasks_set_id_stage_code_scope_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_tasks_set_id_stage_code_scope_key ON public.production_tasks USING btree (set_id, stage_code, scope);


--
-- Name: production_tasks_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_tasks_status_idx ON public.production_tasks USING btree (status);


--
-- Name: production_tasks_work_center_code_planned_start_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_tasks_work_center_code_planned_start_idx ON public.production_tasks USING btree (work_center_code, planned_start);


--
-- Name: production_work_centers_active_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX production_work_centers_active_sort_order_idx ON public.production_work_centers USING btree (active, sort_order);


--
-- Name: production_work_centers_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX production_work_centers_code_key ON public.production_work_centers USING btree (code);


--
-- Name: sales_order_item_details_order_item_id_row_order_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sales_order_item_details_order_item_id_row_order_key ON public.sales_order_item_details USING btree (order_item_id, row_order);


--
-- Name: sales_order_item_details_product_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_order_item_details_product_code_idx ON public.sales_order_item_details USING btree (product_code);


--
-- Name: sales_order_item_images_order_item_id_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_order_item_images_order_item_id_sort_order_idx ON public.sales_order_item_images USING btree (order_item_id, sort_order);


--
-- Name: sales_order_item_images_order_item_id_sort_order_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sales_order_item_images_order_item_id_sort_order_key ON public.sales_order_item_images USING btree (order_item_id, sort_order);


--
-- Name: sales_order_items_model_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_order_items_model_idx ON public.sales_order_items USING btree (model);


--
-- Name: sales_order_items_order_id_line_no_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sales_order_items_order_id_line_no_key ON public.sales_order_items USING btree (order_id, line_no);


--
-- Name: sales_order_items_product_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_order_items_product_code_idx ON public.sales_order_items USING btree (product_code);


--
-- Name: sales_order_items_set_no_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_order_items_set_no_idx ON public.sales_order_items USING btree (set_no);


--
-- Name: sales_order_requirements_order_id_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sales_order_requirements_order_id_code_key ON public.sales_order_requirements USING btree (order_id, code);


--
-- Name: sales_order_requirements_order_id_sort_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_order_requirements_order_id_sort_order_idx ON public.sales_order_requirements USING btree (order_id, sort_order);


--
-- Name: sales_orders_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_created_at_idx ON public.sales_orders USING btree (created_at);


--
-- Name: sales_orders_customer_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_customer_code_idx ON public.sales_orders USING btree (customer_code);


--
-- Name: sales_orders_last_imported_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_last_imported_at_idx ON public.sales_orders USING btree (last_imported_at);


--
-- Name: sales_orders_order_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sales_orders_order_code_key ON public.sales_orders USING btree (order_code);


--
-- Name: sales_orders_order_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_order_date_idx ON public.sales_orders USING btree (order_date);


--
-- Name: sales_orders_order_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_order_type_idx ON public.sales_orders USING btree (order_type);


--
-- Name: sales_orders_region_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_region_idx ON public.sales_orders USING btree (region);


--
-- Name: sales_orders_required_delivery_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_required_delivery_date_idx ON public.sales_orders USING btree (required_delivery_date);


--
-- Name: sales_orders_sales_employee_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_sales_employee_code_idx ON public.sales_orders USING btree (sales_employee_code);


--
-- Name: sales_orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sales_orders_status_idx ON public.sales_orders USING btree (status);


--
-- Name: shipping_calculations_order_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_calculations_order_id_created_at_idx ON public.shipping_calculations USING btree (order_id, created_at);


--
-- Name: shipping_model_mappings_active_shipping_model_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_model_mappings_active_shipping_model_code_idx ON public.shipping_model_mappings USING btree (active, shipping_model_code);


--
-- Name: shipping_model_mappings_source_model_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX shipping_model_mappings_source_model_key ON public.shipping_model_mappings USING btree (source_model);


--
-- Name: shipping_rates_active_model_code_quantity_tier_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shipping_rates_active_model_code_quantity_tier_idx ON public.shipping_rates USING btree (active, model_code, quantity_tier);


--
-- Name: shipping_rates_model_code_quantity_tier_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX shipping_rates_model_code_quantity_tier_key ON public.shipping_rates USING btree (model_code, quantity_tier);


--
-- Name: survey_answers_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX survey_answers_code_key ON public.survey_answers USING btree (code);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: idx_objects_current_version; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_objects_current_version ON storage.objects USING btree (bucket_id, name COLLATE "C") WHERE (archived_at IS NULL);


--
-- Name: idx_objects_delete_markers; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_delete_markers ON storage.objects USING btree (bucket_id, name COLLATE "C") WHERE is_delete_marker;


--
-- Name: idx_objects_null_version; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_objects_null_version ON storage.objects USING btree (bucket_id, name COLLATE "C") WHERE (NOT is_versioned);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects_bucket_id_name_version_key; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX objects_bucket_id_name_version_key ON storage.objects USING btree (bucket_id, name COLLATE "C", version) NULLS NOT DISTINCT;


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_bucket_control_insert; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_bucket_control_insert BEFORE INSERT ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.protect_bucket_control_columns('service_role');


--
-- Name: buckets protect_bucket_control_update; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_bucket_control_update BEFORE UPDATE OF lifecycle_configuration, lifecycle_configuration_generation ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.protect_bucket_control_columns();


--
-- Name: buckets protect_bucket_control_update_role; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_bucket_control_update_role AFTER UPDATE OF lifecycle_configuration, lifecycle_configuration_generation ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_lifecycle_service_role('service_role');


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_mfa_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_mfa_factor_id_fkey FOREIGN KEY (mfa_factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_code_sets mfa_recovery_code_sets_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_recovery_code_sets
    ADD CONSTRAINT mfa_recovery_code_sets_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_recovery_codes mfa_recovery_codes_mfa_recovery_code_set_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_recovery_codes
    ADD CONSTRAINT mfa_recovery_codes_mfa_recovery_code_set_id_fkey FOREIGN KEY (mfa_recovery_code_set_id) REFERENCES auth.mfa_recovery_code_sets(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: scim_tokens scim_tokens_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.scim_tokens
    ADD CONSTRAINT scim_tokens_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: scim_users scim_users_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.scim_users
    ADD CONSTRAINT scim_users_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: scim_users scim_users_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.scim_users
    ADD CONSTRAINT scim_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: order_imports order_imports_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_imports
    ADD CONSTRAINT order_imports_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.sales_orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: production_component_orders production_component_orders_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_component_orders
    ADD CONSTRAINT production_component_orders_set_id_fkey FOREIGN KEY (set_id) REFERENCES public.production_sets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: production_sets production_sets_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_sets
    ADD CONSTRAINT production_sets_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.production_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: production_tasks production_tasks_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_tasks
    ADD CONSTRAINT production_tasks_set_id_fkey FOREIGN KEY (set_id) REFERENCES public.production_sets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_order_item_details sales_order_item_details_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_item_details
    ADD CONSTRAINT sales_order_item_details_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.sales_order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_order_item_images sales_order_item_images_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_item_images
    ADD CONSTRAINT sales_order_item_images_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.sales_order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_order_items sales_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.sales_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_order_requirements sales_order_requirements_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_requirements
    ADD CONSTRAINT sales_order_requirements_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.sales_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_calculations shipping_calculations_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_calculations
    ADD CONSTRAINT shipping_calculations_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.sales_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: item_categories; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.item_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: production_calendar; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_calendar ENABLE ROW LEVEL SECURITY;

--
-- Name: production_component_orders; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_component_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: production_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: production_machine_downtimes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_machine_downtimes ENABLE ROW LEVEL SECURITY;

--
-- Name: production_plans; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: production_programs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_programs ENABLE ROW LEVEL SECURITY;

--
-- Name: production_reasons; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_reasons ENABLE ROW LEVEL SECURITY;

--
-- Name: production_sets; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_sets ENABLE ROW LEVEL SECURITY;

--
-- Name: production_stages; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_stages ENABLE ROW LEVEL SECURITY;

--
-- Name: production_tasks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: production_work_centers; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.production_work_centers ENABLE ROW LEVEL SECURITY;

--
-- Name: sales_order_item_images; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sales_order_item_images ENABLE ROW LEVEL SECURITY;

--
-- Name: shipping_model_mappings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.shipping_model_mappings ENABLE ROW LEVEL SECURITY;

--
-- Name: survey_answers; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.survey_answers ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;
GRANT USAGE ON SCHEMA realtime TO authenticated;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION pg_reload_conf(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pg_catalog.pg_reload_conf() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO service_role;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION send_binary(payload bytea, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION wal2json_escape_identifier(name text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO postgres;
GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO dashboard_user;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE custom_oauth_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.custom_oauth_providers TO postgres;
GRANT ALL ON TABLE auth.custom_oauth_providers TO dashboard_user;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE mfa_recovery_code_sets; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_recovery_code_sets TO postgres;
GRANT ALL ON TABLE auth.mfa_recovery_code_sets TO dashboard_user;


--
-- Name: TABLE mfa_recovery_codes; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.mfa_recovery_codes TO postgres;
GRANT ALL ON TABLE auth.mfa_recovery_codes TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_client_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_client_states TO postgres;
GRANT ALL ON TABLE auth.oauth_client_states TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE scim_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.scim_tokens TO postgres;
GRANT ALL ON TABLE auth.scim_tokens TO dashboard_user;


--
-- Name: TABLE scim_users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.scim_users TO postgres;
GRANT ALL ON TABLE auth.scim_users TO dashboard_user;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE webauthn_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_challenges TO postgres;
GRANT ALL ON TABLE auth.webauthn_challenges TO dashboard_user;


--
-- Name: TABLE webauthn_credentials; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_credentials TO postgres;
GRANT ALL ON TABLE auth.webauthn_credentials TO dashboard_user;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE _prisma_migrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public._prisma_migrations TO anon;
GRANT ALL ON TABLE public._prisma_migrations TO authenticated;
GRANT ALL ON TABLE public._prisma_migrations TO service_role;


--
-- Name: TABLE item_attribute_imports; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.item_attribute_imports TO anon;
GRANT ALL ON TABLE public.item_attribute_imports TO authenticated;
GRANT ALL ON TABLE public.item_attribute_imports TO service_role;


--
-- Name: SEQUENCE item_attribute_imports_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.item_attribute_imports_id_seq TO anon;
GRANT ALL ON SEQUENCE public.item_attribute_imports_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.item_attribute_imports_id_seq TO service_role;


--
-- Name: TABLE item_categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.item_categories TO anon;
GRANT ALL ON TABLE public.item_categories TO authenticated;
GRANT ALL ON TABLE public.item_categories TO service_role;


--
-- Name: SEQUENCE item_categories_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.item_categories_id_seq TO anon;
GRANT ALL ON SEQUENCE public.item_categories_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.item_categories_id_seq TO service_role;


--
-- Name: TABLE item_master_imports; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.item_master_imports TO anon;
GRANT ALL ON TABLE public.item_master_imports TO authenticated;
GRANT ALL ON TABLE public.item_master_imports TO service_role;


--
-- Name: SEQUENCE item_master_imports_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.item_master_imports_id_seq TO anon;
GRANT ALL ON SEQUENCE public.item_master_imports_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.item_master_imports_id_seq TO service_role;


--
-- Name: TABLE item_masters; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.item_masters TO anon;
GRANT ALL ON TABLE public.item_masters TO authenticated;
GRANT ALL ON TABLE public.item_masters TO service_role;


--
-- Name: SEQUENCE item_masters_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.item_masters_id_seq TO anon;
GRANT ALL ON SEQUENCE public.item_masters_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.item_masters_id_seq TO service_role;


--
-- Name: TABLE master_options; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.master_options TO anon;
GRANT ALL ON TABLE public.master_options TO authenticated;
GRANT ALL ON TABLE public.master_options TO service_role;


--
-- Name: SEQUENCE master_options_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.master_options_id_seq TO anon;
GRANT ALL ON SEQUENCE public.master_options_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.master_options_id_seq TO service_role;


--
-- Name: TABLE order_imports; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.order_imports TO anon;
GRANT ALL ON TABLE public.order_imports TO authenticated;
GRANT ALL ON TABLE public.order_imports TO service_role;


--
-- Name: SEQUENCE order_imports_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.order_imports_id_seq TO anon;
GRANT ALL ON SEQUENCE public.order_imports_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.order_imports_id_seq TO service_role;


--
-- Name: TABLE production_calendar; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_calendar TO anon;
GRANT ALL ON TABLE public.production_calendar TO authenticated;
GRANT ALL ON TABLE public.production_calendar TO service_role;


--
-- Name: SEQUENCE production_calendar_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_calendar_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_calendar_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_calendar_id_seq TO service_role;


--
-- Name: TABLE production_component_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_component_orders TO anon;
GRANT ALL ON TABLE public.production_component_orders TO authenticated;
GRANT ALL ON TABLE public.production_component_orders TO service_role;


--
-- Name: SEQUENCE production_component_orders_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_component_orders_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_component_orders_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_component_orders_id_seq TO service_role;


--
-- Name: TABLE production_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_logs TO anon;
GRANT ALL ON TABLE public.production_logs TO authenticated;
GRANT ALL ON TABLE public.production_logs TO service_role;


--
-- Name: SEQUENCE production_logs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_logs_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_logs_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_logs_id_seq TO service_role;


--
-- Name: TABLE production_machine_downtimes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_machine_downtimes TO anon;
GRANT ALL ON TABLE public.production_machine_downtimes TO authenticated;
GRANT ALL ON TABLE public.production_machine_downtimes TO service_role;


--
-- Name: SEQUENCE production_machine_downtimes_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_machine_downtimes_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_machine_downtimes_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_machine_downtimes_id_seq TO service_role;


--
-- Name: TABLE production_plans; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_plans TO anon;
GRANT ALL ON TABLE public.production_plans TO authenticated;
GRANT ALL ON TABLE public.production_plans TO service_role;


--
-- Name: SEQUENCE production_plans_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_plans_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_plans_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_plans_id_seq TO service_role;


--
-- Name: TABLE production_programs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_programs TO anon;
GRANT ALL ON TABLE public.production_programs TO authenticated;
GRANT ALL ON TABLE public.production_programs TO service_role;


--
-- Name: SEQUENCE production_programs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_programs_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_programs_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_programs_id_seq TO service_role;


--
-- Name: TABLE production_reasons; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_reasons TO anon;
GRANT ALL ON TABLE public.production_reasons TO authenticated;
GRANT ALL ON TABLE public.production_reasons TO service_role;


--
-- Name: SEQUENCE production_reasons_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_reasons_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_reasons_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_reasons_id_seq TO service_role;


--
-- Name: TABLE production_sets; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_sets TO anon;
GRANT ALL ON TABLE public.production_sets TO authenticated;
GRANT ALL ON TABLE public.production_sets TO service_role;


--
-- Name: SEQUENCE production_sets_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_sets_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_sets_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_sets_id_seq TO service_role;


--
-- Name: TABLE production_stages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_stages TO anon;
GRANT ALL ON TABLE public.production_stages TO authenticated;
GRANT ALL ON TABLE public.production_stages TO service_role;


--
-- Name: SEQUENCE production_stages_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_stages_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_stages_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_stages_id_seq TO service_role;


--
-- Name: TABLE production_tasks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_tasks TO anon;
GRANT ALL ON TABLE public.production_tasks TO authenticated;
GRANT ALL ON TABLE public.production_tasks TO service_role;


--
-- Name: SEQUENCE production_tasks_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_tasks_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_tasks_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_tasks_id_seq TO service_role;


--
-- Name: TABLE production_work_centers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.production_work_centers TO anon;
GRANT ALL ON TABLE public.production_work_centers TO authenticated;
GRANT ALL ON TABLE public.production_work_centers TO service_role;


--
-- Name: SEQUENCE production_work_centers_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.production_work_centers_id_seq TO anon;
GRANT ALL ON SEQUENCE public.production_work_centers_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.production_work_centers_id_seq TO service_role;


--
-- Name: TABLE sales_order_item_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sales_order_item_details TO anon;
GRANT ALL ON TABLE public.sales_order_item_details TO authenticated;
GRANT ALL ON TABLE public.sales_order_item_details TO service_role;


--
-- Name: SEQUENCE sales_order_item_details_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.sales_order_item_details_id_seq TO anon;
GRANT ALL ON SEQUENCE public.sales_order_item_details_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.sales_order_item_details_id_seq TO service_role;


--
-- Name: TABLE sales_order_item_images; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sales_order_item_images TO anon;
GRANT ALL ON TABLE public.sales_order_item_images TO authenticated;
GRANT ALL ON TABLE public.sales_order_item_images TO service_role;


--
-- Name: SEQUENCE sales_order_item_images_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.sales_order_item_images_id_seq TO anon;
GRANT ALL ON SEQUENCE public.sales_order_item_images_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.sales_order_item_images_id_seq TO service_role;


--
-- Name: TABLE sales_order_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sales_order_items TO anon;
GRANT ALL ON TABLE public.sales_order_items TO authenticated;
GRANT ALL ON TABLE public.sales_order_items TO service_role;


--
-- Name: SEQUENCE sales_order_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.sales_order_items_id_seq TO anon;
GRANT ALL ON SEQUENCE public.sales_order_items_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.sales_order_items_id_seq TO service_role;


--
-- Name: TABLE sales_order_requirements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sales_order_requirements TO anon;
GRANT ALL ON TABLE public.sales_order_requirements TO authenticated;
GRANT ALL ON TABLE public.sales_order_requirements TO service_role;


--
-- Name: SEQUENCE sales_order_requirements_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.sales_order_requirements_id_seq TO anon;
GRANT ALL ON SEQUENCE public.sales_order_requirements_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.sales_order_requirements_id_seq TO service_role;


--
-- Name: TABLE sales_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sales_orders TO anon;
GRANT ALL ON TABLE public.sales_orders TO authenticated;
GRANT ALL ON TABLE public.sales_orders TO service_role;


--
-- Name: SEQUENCE sales_orders_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.sales_orders_id_seq TO anon;
GRANT ALL ON SEQUENCE public.sales_orders_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.sales_orders_id_seq TO service_role;


--
-- Name: TABLE shipping_calculations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.shipping_calculations TO anon;
GRANT ALL ON TABLE public.shipping_calculations TO authenticated;
GRANT ALL ON TABLE public.shipping_calculations TO service_role;


--
-- Name: SEQUENCE shipping_calculations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.shipping_calculations_id_seq TO anon;
GRANT ALL ON SEQUENCE public.shipping_calculations_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.shipping_calculations_id_seq TO service_role;


--
-- Name: TABLE shipping_model_mappings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.shipping_model_mappings TO anon;
GRANT ALL ON TABLE public.shipping_model_mappings TO authenticated;
GRANT ALL ON TABLE public.shipping_model_mappings TO service_role;


--
-- Name: SEQUENCE shipping_model_mappings_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.shipping_model_mappings_id_seq TO anon;
GRANT ALL ON SEQUENCE public.shipping_model_mappings_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.shipping_model_mappings_id_seq TO service_role;


--
-- Name: TABLE shipping_rates; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.shipping_rates TO anon;
GRANT ALL ON TABLE public.shipping_rates TO authenticated;
GRANT ALL ON TABLE public.shipping_rates TO service_role;


--
-- Name: SEQUENCE shipping_rates_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.shipping_rates_id_seq TO anon;
GRANT ALL ON SEQUENCE public.shipping_rates_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.shipping_rates_id_seq TO service_role;


--
-- Name: TABLE survey_answers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.survey_answers TO anon;
GRANT ALL ON TABLE public.survey_answers TO authenticated;
GRANT ALL ON TABLE public.survey_answers TO service_role;


--
-- Name: SEQUENCE survey_answers_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.survey_answers_id_seq TO anon;
GRANT ALL ON SEQUENCE public.survey_answers_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.survey_answers_id_seq TO service_role;


--
-- Name: TABLE system_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_settings TO anon;
GRANT ALL ON TABLE public.system_settings TO authenticated;
GRANT ALL ON TABLE public.system_settings TO service_role;


--
-- Name: SEQUENCE system_settings_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.system_settings_id_seq TO anon;
GRANT ALL ON SEQUENCE public.system_settings_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.system_settings_id_seq TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE realtime.messages TO postgres;
GRANT SELECT,INSERT ON TABLE realtime.messages TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.buckets FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.buckets TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE buckets_vectors; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.buckets_vectors TO service_role;
GRANT SELECT ON TABLE storage.buckets_vectors TO authenticated;
GRANT SELECT ON TABLE storage.buckets_vectors TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.objects FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.objects TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE vector_indexes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.vector_indexes TO service_role;
GRANT SELECT ON TABLE storage.vector_indexes TO authenticated;
GRANT SELECT ON TABLE storage.vector_indexes TO anon;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT SELECT,INSERT ON TABLES TO postgres WITH GRANT OPTION;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

\unrestrict t1v96gDlqMEaS4OWnIeqwqQRPzUatWTmnhqmRjbdd7r6G3kbyIJMOqcV3BRPZNh

