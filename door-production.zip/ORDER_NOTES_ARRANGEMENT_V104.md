# V104 — Ghi chú kỹ thuật trong tab Quản lý đơn hàng xếp như bản xuất file

## Yêu cầu

> “xem cách sắp xếp ghi chú kỹ thuật ở xuất file, tương tự vậy áp dụng cho tab quản lý đơn hàng”

## Cách bản xuất file đang xếp (mình đã kiểm tra lại đúng code)

Trong **Excel V2 / PDF** (`src/lib/order-export-v2.ts`, `python/reportlab_order_v2.py`):

- **Không có cột ghi chú.** Ghi chú kỹ thuật của **mọi dòng** (bộ cửa + phụ kiện) được in thành **hàng riêng trải hết bề ngang bảng**: Excel merge `A→S`, PDF 1 span toàn bảng.
- **Chữ đỏ**, in nghiêng, nhãn in đậm: `GHI CHÚ KỸ THUẬT (Bộ số 12119): <nội dung>`; bộ chưa có bộ số thì nhãn là `GHI CHÚ KỸ THUẬT:` (V69).
- **Vị trí: ở CUỐI mỗi bộ cửa**, sau dòng phụ kiện cuối cùng của bộ đó (V68) — không chen giữa các dòng hàng hóa.
- Nền hàng ghi chú là nền nhạt, và **bề rộng cột còn lại được chia lại** cho các cột khác (V66).

Ví dụ kiểm tra thật trên file Excel V2 của chính đơn thử:

```
dòng 18 [A18:S18] GHI CHÚ KỸ THUẬT (Bộ số 12119): Bản lề chốt âm inox / Kính trên OT 6.38 Màu trắng trong
dòng 19 [A19:S19] GHI CHÚ KỸ THUẬT (Bộ số 12119): Phào mặt trong bản 6cm
dòng 20 [A20:S20] GHI CHÚ KỸ THUẬT (Bộ số 12119): Khoét âm, không tính tiền
```

## Trước đây tab Quản lý đơn hàng xếp khác

Trong cột bên phải của `/orders`, bảng hàng hóa có **cột “Ghi chú” rộng 90px** — ghi chú dài như “Bản lề chốt âm inox / Kính trên OT 6.38 Màu trắng trong” bị bó trong ô nhỏ, phải đọc trong hộp hẹp (đúng như ảnh bạn gửi).

## Nay đã áp đúng như bản xuất

- **Bỏ cột “Ghi chú”** → bảng từ **13 cột còn 12 cột**, bề rộng chia lại cho các cột còn lại (Mã hàng 20→24%, Màu sơn 8%, Đơn giá 9→10%…).
- Ghi chú in thành **hàng riêng trải hết bề ngang bảng** (`colSpan=12`), **chữ đỏ in nghiêng**, nhãn in đậm **`GHI CHÚ KỸ THUẬT (Bộ số 12119):`** (đơn chưa vào sản xuất thì nhãn không kèm bộ số, giống bản xuất).
- **Nằm ở cuối mỗi bộ cửa**, sau dòng phụ kiện cuối cùng; ghi chú của **cả dòng cửa lẫn dòng phụ kiện** đều được in, theo đúng thứ tự trong bản xuất.
- Ghi chú nhiều dòng giữ nguyên xuống dòng (`whitespace-pre-line`).
- Nền hàng ghi chú dùng màu hồng rất nhạt (`bg-rose-50/60`) thay cho nền xám như bản in — để trên màn hình nổi bật hơn; muốn giống hệt bản in (nền xám) thì nói, đổi 1 dòng.

## Kiểm chứng (chạy thật)

**a) 17/17 kiểm tra trên markup thật của bảng:**

```
OK   bảng còn 12 cột (bỏ cột Ghi chú)              OK   nhãn in đậm kèm Bộ số, đúng như bản xuất
OK   không còn tiêu đề "Ghi chú"                   OK   nhãn đúng ở cả ghi chú phụ kiện
OK   không còn ô ghi chú trong dòng hàng           OK   nội dung ghi chú nguyên vẹn (không bị cắt)
OK   có 3 hàng ghi chú (1 của cửa + 2 phụ kiện)    OK   ghi chú nằm CUỐI bộ cửa (ITEM×4 → NOTE×3 → ITEM×3)
OK   hàng ghi chú trải hết bề ngang (colSpan=12)   OK   bộ không có ghi chú thì không thêm hàng nào
OK   chữ đỏ + in nghiêng                           OK   đơn không có ghi chú → không có hàng ghi chú
OK   đơn hàng mẫu → nhãn KHÔNG kèm Bộ số           OK   đơn chưa có hàng hóa → ô rỗng đúng 12 cột
OK   vẫn hiện đủ ghi chú ở đơn hàng mẫu            OK   ghi chú nhiều dòng giữ nguyên xuống dòng
```

**b) Đối chiếu với chính bản xuất** (dựng file Excel V2 thật cho cùng đơn rồi đọc lại): bản xuất cũng có **3 hàng ghi chú**, cùng nhãn `GHI CHÚ KỸ THUẬT (Bộ số 12119):`, cùng **merge `A→S`** (tab dùng `colSpan=12`), cùng nằm cuối bộ cửa → **khớp với bản xuất**.

**c) Đo trong trình duyệt:** bảng vẫn khớp đúng bề rộng vùng chứa (898px = 898px), **không phát sinh cuộn ngang**; hàng ghi chú rộng 898px, **không cắt chữ**.

**d) Ảnh `order-notes-arrangement-v104.png`** — TRƯỚC/SAU (bản TRƯỚC copy nguyên văn từ gói V100 để so cho công bằng).

**đ) `npm run build` → PASS**, `npx tsc --noEmit` → 0 lỗi, `npx eslint` → 0 errors / 0 warnings (bằng bản V100).

## Lưu ý

- Chỉ áp dụng cho **cột phải của màn Quản lý đơn hàng**. Hai chỗ khác vẫn để nguyên, nói nếu muốn làm cho giống:
  1. **Trang “Xem đầy đủ 23 cột”** (`/orders/[id]`) — vẫn có cột Ghi chú vì đó là bản xem đủ cột.
  2. **Trang in trên web** (`/orders/[id]/print`, mở từ nút “In / Lưu PDF”) — vẫn có cột ghi chú; *file* PDF/Excel tải về thì đã xếp theo kiểu hàng riêng từ trước.
- Không cần migration DB, không đổi dữ liệu — chỉ đổi cách hiển thị.

## File thay đổi

- `src/components/order-list/order-detail-pane.tsx` — bỏ cột Ghi chú (13→12 cột, chia lại bề rộng), thêm hàng `GHI CHÚ KỸ THUẬT` ở cuối mỗi bộ cửa.
