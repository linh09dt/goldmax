# ORDER KH/LƯỢNG AUTO V43

Cập nhật từ V42, chỉ thay các logic đã chốt:

1. KH/Lượng tự động làm tròn đến tối đa 2 chữ số thập phân.
   - Nhóm cửa: `(Cao × Rộng) / 1.000.000`.
   - Phào/Phao: `(Cao × 2 + Rộng) / 1.000`.
   - Với Phào/Phao, ô Cao hoặc Rộng có thể để trống và được tính như 0 để phù hợp loại phụ kiện chỉ dùng một chiều.
   - Ô thoáng: `1TK=1`, `2TK=2`, `3TK=3`.
   - Khóa: theo `SL bộ` của cửa cha.
   - Nhóm khác vẫn nhập tay.

2. Khi chọn phụ kiện từ Danh mục hàng hóa, đề xuất kích thước từ Bộ cửa cha:
   - Phào rời: `Cao = Cao cửa`, `Rộng = Rộng cửa`.
   - Phào biệt thự đứng: `Cao = Cao cửa`, `Rộng` để trống.
   - Phào biệt thự ngang: `Rộng = Rộng cửa`, `Cao` để trống.
   - Phào biệt thự đỉnh: `Rộng = Rộng cửa`, `Cao` để trống.

3. Đề xuất kích thước chỉ áp dụng lúc chọn Model phụ kiện; sau đó người dùng vẫn có thể sửa Cao/Rộng bằng tay.

Ví dụ cửa 2000 × 1620:
- Cửa: KH/Lượng = `3.24`.
- Phào rời: Cao 2000, Rộng 1620 => `(2000×2+1620)/1000 = 5.62`.
- Phào biệt thự đứng: Cao 2000 => `(2000×2)/1000 = 4`.
- Phào biệt thự ngang/đỉnh: Rộng 1620 => `1620/1000 = 1.62`.

Không thay DB, API, cấu trúc đơn hàng, Master Data hay các logic khác.
