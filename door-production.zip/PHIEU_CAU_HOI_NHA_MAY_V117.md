# V117 — Phiếu câu hỏi gửi nhà máy (để thiết kế module Lên kế hoạch sản xuất)

**Mục đích:** gom tất cả câu cần nhà máy xác nhận thành **một phiếu duy nhất**, trả lời một lần là đủ để thiết kế dữ liệu app.
Gộp từ: V112 (loại đơn/trạng thái) · V114 (dashboard, dữ liệu còn thiếu) · V115 (chuẩn bị kế hoạch) · V116 (bảng công đoạn).

**Cách dùng:** in phiếu này (bản PDF kèm theo) đưa quản đốc/tổ trưởng, hoặc gửi từng nhóm qua Zalo. Câu nào chưa trả lời được thì ghi "chưa rõ" —
mình đã ghi sẵn **giá trị mặc định** ở mục cuối để không bị chặn tiến độ.

**Phân loại:** 🔴 **P1 = bắt buộc** (không có là không lập trình được) · 🟡 P2 = cần cho đợt sau.

---

## ⚡ 12 câu chặn — hỏi trước, còn lại hỏi sau

| # | Câu hỏi | Trả lời |
|---|---|---|
| B5 | Thời gian trong bảng công đoạn là **giờ hay ngày làm việc**? Xưởng có làm **thứ 7 / chủ nhật** không? | |
| B6 | **Ép cánh mất bao lâu?** (bảng đang trống) | |
| B8 | Có công đoạn **lắp kính + phụ kiện** không? Nằm ở bước nào, mất bao lâu? | |
| B9 | "**Bồi Lares**" là bồi *film vân gỗ* hay bồi *tấm lõi*? Trước hay sau khi sơn? | |
| C13 | Mỗi tổ **bao nhiêu người**, mỗi tuần làm được **bao nhiêu bộ**? | |
| C14 | **Sơn theo lô bao nhiêu bộ?** Một lò sơn được mấy màu cùng lúc? | |
| D19 | Xếp lịch ưu tiên theo **hạn giao** hay **đơn đến trước**? Có chen lệnh gấp không? | |
| D20 | **Gom lô** theo màu sơn / mã vân / model nhôm: tối thiểu bao nhiêu bộ mỗi lô? | |
| D21 | Được **đẩy từng bộ** khi đủ, hay phải **đủ cả đơn** mới chuyển công đoạn? | |
| D22 | **Đơn làm lại**: quay lại công đoạn nào? Có chen trước đơn thường không? | |
| A1 | Đơn vị lên kế hoạch là **1 bộ cửa** — đúng chứ? Có trường hợp nửa bộ / lẻ bộ không? | |
| G31 | Đơn nào vào kế hoạch: chỉ *Sản xuất + Đã xác nhận*, hay cả *Đơn làm lại* / *Đơn hàng mẫu*? | |

---

## A. Sản phẩm & cách định lượng

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| A1 | Đơn vị lên kế hoạch là **bộ cửa**? Có trường hợp nửa bộ / lẻ bộ không? | Khóa chính của bảng kế hoạch | 🔴 | |
| A2 | Một **bộ cửa** gồm những phần nào: khung · cánh · phào · kính · phụ kiện · ô thoáng? Luôn đủ hay tuỳ loại? | Biết theo dõi 3 luồng khung/cánh/phào | 🟡 | |
| A3 | Xưởng đang làm những **loại cửa** nào (cửa đi, cửa sổ, vách kính, tủ, lan can…)? | Mỗi loại một lead time riêng | 🟡 | |
| A4 | Để định mức giờ công, chia nhóm theo **model nhôm**, **số cánh**, hay **kích thước**? | Tính tải & lead time theo nhóm | 🟡 | |

## B. Công đoạn & thời gian (theo bảng V116)

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| B5 | Đơn vị thời gian: **giờ / ngày làm việc / ngày lịch**? Có làm T7, CN không? Ngày lễ tính sao? | Sai đơn vị = sai toàn bộ kế hoạch | 🔴 | |
| B6 | **Ép cánh mất bao lâu?** Tổng 12 trong bảng đã gồm nó chưa? | Tổng hiện đang không khớp | 🔴 | |
| B7 | **Chờ khô**: sau sơn bao lâu mới vân được? Sau vân bao lâu mới đóng gói? | Đây là chỗ kế hoạch hay trượt nhất | 🟡 | |
| B8 | Có công đoạn **lắp kính + phụ kiện** (khoá, bản lề, tay nắm)? Nằm ở bước nào, bao lâu? | Đơn có kính 8.38/khoá nhưng bảng chưa có bước này | 🔴 | |
| B9 | "Bồi Lares" là **film vân gỗ** hay **tấm lõi**? Trước hay sau sơn? Có phải là bước "Vân" không? | Tránh thiết kế trùng 2 công đoạn | 🔴 | |
| B10 | Công đoạn nào làm **song song** cho khung/cánh/phào, công đoạn nào **phải chờ ghép thành bộ**? | Xếp tải theo từng luồng | 🟡 | |
| B11 | Thời gian nào **cố định** (thiết kế, chờ khô sơn) và thời gian nào **tỷ lệ theo số bộ**? | Oánh giá khả thi khi số bộ tăng | 🟡 | |
| B12 | **Kiểm tra chất lượng** ở bước nào (sau chấn, sau hàn, trước sơn, sau vân, trước giao)? Ai kiểm, ghi ở đâu? | Bổ sung điểm QC; tính tỷ lệ làm lại | 🟡 | |

## C. Năng lực & lịch làm việc

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| C13 | Mỗi tổ (Máy / Hàn / Sơn / Vân / Kho) **bao nhiêu người**, mỗi tuần làm được **bao nhiêu bộ**? | Cảnh báo quá tải — thiếu số này thì kế hoạch vô nghĩa | 🔴 | |
| C14 | Có mấy máy cắt / chấn / lò sơn? **Sơn mỗi lô bao nhiêu bộ**, một lò được mấy màu cùng lúc? | Quyết định thuật toán gom lô | 🔴 | |
| C15 | Giờ làm mỗi ngày, **mấy ca**? Cao điểm có tăng ca không? | Quy đổi ngày → giờ | 🟡 | |
| C16 | Tổ nào đang **chờ nhiều nhất / hay nghẽn nhất**? | Ưu tiên tối ưu đúng chỗ | 🟡 | |
| C17 | Có **gia công ngoài** (kính, sơn, phào, phụ kiện) không? Thời gian nhận lại? | Thêm lead time ngoài vào kế hoạch | 🟡 | |
| C18 | Có giới hạn **diện tích xưởng / chỗ phơi sơn / chỗ để hàng chờ** không? | Giới hạn số bộ đang làm song song | 🟡 | |

## D. Quy tắc xếp lịch (phần quyết định thuật toán)

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| D19 | Ưu tiên theo **hạn giao** hay **đơn đến trước**? Đơn gấp có chen được không? | Thứ tự xếp trong tuần | 🔴 | |
| D20 | **Gom lô**: sơn tối thiểu bao nhiêu bộ/lô màu? Vân gom theo mã? Nhôm gom theo model? | Giảm thời gian đổi màu | 🔴 | |
| D21 | Được **đẩy từng bộ** khi đủ, hay **đủ cả đơn** mới chuyển công đoạn? (bảng ghi "cần đầy đủ đơn") | Quyết định chờ ở tổ máy | 🔴 | |
| D22 | **Đơn làm lại**: quay lại công đoạn nào, có ưu tiên chen trước? | Nhánh xử lý mà bảng chưa có | 🔴 | |
| D23 | Xưởng có **sản xuất trước / làm tồn** không, hay chỉ làm theo đơn? | Nếu có thì kế hoạch phải có cả phần dự báo | 🟡 | |
| D24 | **Giao từng phần** (giao trước vài bộ) có được không? | Chia nhỏ kế hoạch giao hàng | 🟡 | |

## E. Tiến độ & in ấn

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| E25 | Xưởng muốn **cập nhật tiến độ** ở đâu: máy tính ở xưởng, điện thoại, hay ghi giấy rồi nhập? | Quyết định giao diện nhập | 🔴 | |
| E26 | Theo dõi ở mức **bộ** hay mức **từng công đoạn**? | Chi tiết quá thì không ai nhập | 🔴 | |
| E27 | Có cần **in phiếu lệnh sản xuất** cho tổ không? In nội dung gì, khổ giấy nào? | Mẫu in (dùng lại reportlab) | 🟡 | |
| E28 | Có muốn ghi lại **lỗi/hỏng và làm lại** để tính tỷ lệ lỗi của tổ không? | Chỉ số chất lượng | 🟡 | |

## F. Vật tư & định mức

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| F29 | Có muốn quản lý **tồn vật tư** (nhôm, kính, phụ kiện, sơn) không? | Nếu có là module kho riêng, lớn hơn nhiều | 🟡 | |
| F30 | Có **định mức vật tư theo bộ** (kg nhôm/bộ, m² kính/bộ) không? | Ước tính & cảnh báo thiếu vật tư | 🟡 | |

## G. Đơn hàng & nghiệp vụ (câu còn treo từ V112/V114)

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| G31 | Đơn nào vào kế hoạch: chỉ *Sản xuất + Đã xác nhận*, hay cả *Đơn làm lại* / *Đơn hàng mẫu*? | Bộ lọc đầu vào | 🔴 | |
| G32 | **Bộ số** do sale đánh hay do xưởng? Nếu trùng số thì xử lý sao? | Bộ số là định danh khi xếp lịch | 🟡 | |
| G33 | **Đơn làm lại** có tính vào **doanh thu** không? | Công thức doanh thu đang loại nó ra | 🟡 | |
| G34 | "**Quá hạn**" tính cả đơn nháp, hay chỉ đơn đã xác nhận? | Cảnh báo trên dashboard | 🟡 | |
| G35 | Đơn **Đã hủy** có cần giữ lại để xem không? | Báo cáo & dọn dữ liệu | 🟡 | |
| G36 | **Hạn giao** là ngày xưởng xong hay ngày giao tới khách? | Mốc mà kế hoạch phải nhắm | 🟡 | |
| G37 | **Ngày giao thực tế** ai ghi, ghi ở đâu? | Cần để tính giao đúng hạn (OTD) | 🟡 | |
| G38 | Có cần quản lý **thu tiền nhiều lần** (phiếu thu) không? | Công nợ & dòng tiền thật | 🟡 | |
| G39 | Có muốn nhập **giá vốn theo mã hàng** để tính lãi gộp không? | Hiện chỉ có giá bán, chưa có giá vốn | 🟡 | |
| G40 | Khách có được xem **báo giá/đơn** của mình không, hay nội bộ xem? | Phân quyền | 🟡 | |

## H. Người dùng & phân quyền

| # | Câu hỏi | Vì sao cần | Mức | Trả lời |
|---|---|---|---|---|
| H41 | Có bao nhiêu người sẽ dùng app, chia mấy nhóm (quản trị / sale / xưởng / kế toán)? | Hiện **chưa có đăng nhập** — ai có link cũng sửa được | 🔴 | |
| H42 | Có cần **chặn xem giá** với một số nhóm (ví dụ tổ trưởng chỉ thấy số bộ, không thấy giá)? | Yêu cầu bảo mật dữ liệu | 🟡 | |

---

## Mặc định nếu nhà máy chưa trả lời (để không bị chặn)

| Câu | Mặc định sẽ dùng | Ghi chú |
|---|---|---|
| B5 | **Ngày làm việc**, T2–T6 (nghỉ CN) | Có thể sửa trong app |
| B6 | Ép cánh = **1** | Sửa được |
| B7 | Chờ khô = **1 ngày** sau sơn | Sửa được |
| B8 | **Có** công đoạn "Lắp kính + phụ kiện", đặt **sau Vân**, = **1** | Thêm nút bật/tắt |
| B9 | Coi **Bồi Lares** là bước riêng trước Sơn (không trùng với Vân) | Chờ xác nhận để sửa |
| C13/C14 | Để **trống năng lực**, app vẫn cho lập kế hoạch nhưng **không cảnh báo quá tải** | Nhập sau khi có số |
| D19 | Ưu tiên **hạn giao gần nhất trước** (EDD) | Có thể đổi tay |
| D20 | **Không giới hạn lô**, chỉ gợi ý gom theo màu | Bật khi có số |
| D21 | Cho phép **đẩy từng bộ** | Mặc định mềm |
| D22 | Đơn làm lại: **ưu tiên cao nhất**, bắt đầu ở công đoạn bị lỗi (chọn tay) | |
| G31 | Vào kế hoạch: **Sản xuất + Đã xác nhận**; đơn làm lại **bật/tắt bằng cấu hình** | |
| G33/G34 | Đơn làm lại **không** tính doanh thu; quá hạn **chỉ đơn đã xác nhận** | Đúng như đang chạy |
| H41 | **1 vai trò quản trị** dùng chung trước, làm đăng nhập phân quyền ngay sau | Tránh mở app cho nhiều người khi chưa có đăng nhập |

---

## Xin kèm theo (nếu có)

- Bảng công đoạn bản cứng (bản gốc trên giấy).
- **Mẫu phiếu lệnh sản xuất / phiếu tiến độ** xưởng đang dùng (nếu đang dùng giấy).
- Danh sách **máy móc + số người từng tổ**.
- Danh sách **loại cửa + model nhôm** xưởng đang làm nhiều nhất.
- Mẫu **phiếu giao hàng** và cách ghi ngày giao thực tế.
