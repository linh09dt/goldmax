# V146 — BỎ tab **Kế hoạch tuần** và bảng **Tải theo tổ và ngày**

> Chốt 26/09/2026: tab "Kế hoạch tuần" không dùng được → bỏ; bảng "Tải theo tổ và ngày" trong tab
> Kế hoạch sản xuất không dùng → bỏ. **Không cần chạy SQL** — chỉ thay code.

---

## 1. Đã bỏ những gì

### a) Tab "Kế hoạch tuần" (menu Sản xuất)
| Bỏ | Ghi chú |
|---|---|
| Mục menu **Kế hoạch tuần** (`src/components/erp-nav.tsx`) | kèm icon `IconCalendar` không còn dùng |
| Nút **Kế hoạch tuần** trên bảng kế hoạch sản xuất | |
| Trang `src/app/ke-hoach-san-xuat/ke-hoach/` | **xoá cả thư mục** |
| Bảng client `src/components/production/production-plan-board.tsx` | chỉ trang trên dùng |
| API `src/app/api/production/plans/` | **xoá cả thư mục** (GET/POST chốt – mở lại kế hoạch) |
| Hàm trong `src/lib/production/service.ts`: `loadPlans`, `createPlan`, `approvePlan`, `reopenPlan`, `deletePlan`, type `PlanSummary` | chỉ API trên gọi |

**Giữ nguyên dữ liệu:** bảng `production_plans` + model `ProductionPlan` + cột `production_sets.plan_id`
vẫn còn trong DB (không xoá gì). Nếu sau này muốn làm lại "kế hoạch tuần", dữ liệu cũ vẫn đó.

### b) Bảng "Tải theo tổ và ngày" (tab Kế hoạch sản xuất)
Bỏ cả thẻ đó trong `src/app/ke-hoach-san-xuat/page.tsx`, gồm: bảng lưới **Tổ × Ngày**, các dòng con **↳ công đoạn**,
dòng **Toàn xưởng**, hàng chip **Lọc tổ**, và nút chuyển khoảng ngày (← 7 ngày trước / Hôm nay / 7 ngày sau →).

Màn Kế hoạch sản xuất nay còn đúng **4 khối**:
1. 8 ô số liệu (Bộ trong kế hoạch · Chờ xếp lịch · Đang sản xuất · Hoàn thành/đã giao · Tổng cánh · Tiến độ TB · Chưa nhập vào kế hoạch · Tạm dừng)
2. **Cảnh báo** (giữ nguyên — xem mục 2)
3. **Bộ chờ xếp lịch** (bấm số bộ → trang bộ cửa)
4. **Đang sản xuất** · **Đã hoàn thành sản xuất**

---

## 2. Những gì KHÔNG đổi (để bạn khỏi bất ngờ)

- **Cảnh báo vẫn chạy**: `QUA_TAI` (quá tải tổ theo ngày) và `QUA_TAI_CONG_DOAN` (quá tải theo công đoạn),
  `SAP_TRE`, `CHAM_CONG_DOAN`, `KHONG_KIP`, thiếu thông tin… Nay **không có bảng** để tra chi tiết, nhưng
  cảnh báo quá tải vẫn dùng năng lực khai ở **Cấu hình → Tổ** và **Cấu hình → Công đoạn (Năng lực/ngày)**.
  Khoảng tính cảnh báo quá tải: **7 ngày kể từ hôm nay** (ghi rõ ở dòng chú thích cuối trang).
- **Bảng kế hoạch nay hiện TẤT CẢ bộ** (trước đây lọc theo khoảng ngày `?from=&days=`; nay bỏ tham số đó).
  Không còn "Lọc tổ" nữa (nó nằm trong bảng đã bỏ).
- Công đoạn → **Số ngày** (V145), mốc sản xuất (V144), lệnh sản xuất (V142), bỏ qua vân màu 11/14 (V143): **không đổi**.

---

## 3. Cách áp dụng (chỉ code, không SQL)

Vì zip không xoá được file, **xoá tay 3 đường dẫn** (xem `V146_XOA_FILE.txt`):

```
src/app/ke-hoach-san-xuat/ke-hoach/          (xoá cả thư mục)
src/app/api/production/plans/                (xoá cả thư mục)
src/components/production/production-plan-board.tsx
```
Windows (CMD):
```cmd
rmdir /s /q src\app\ke-hoach-san-xuat\ke-hoach
rmdir /s /q src\app\api\production\plans
del src\components\production\production-plan-board.tsx
rmdir /s /q .next
```
Sau đó: `npx tsc --noEmit && npm run build`.
⚠️ **Nhớ xoá `.next`** — Next giữ type cũ của 2 trang vừa xoá, không xoá sẽ báo
`Cannot find module '../../src/app/ke-hoach-san-xuat/ke-hoach/page.js'`.

---

## 4. Kiểm chứng

- `tsc --noEmit` 0 lỗi · `eslint` (vùng sản xuất + menu) 0 lỗi · `npm run build` OK.
- Không còn tham chiếu nào tới `ke-hoach-san-xuat/ke-hoach`, `production-plan-board`, `/api/production/plans`,
  `loadPlans/createPlan/approvePlan/reopenPlan/deletePlan` trong `src/`.
- Trang Kế hoạch sản xuất: 296 dòng (trước ~460), còn 4 khối như mục 1b.

**Muốn lấy lại:** bản cũ nằm trong các gói trước (`door-production-v145-so-ngay.zip` và trước đó) — trang kế hoạch
tuần chỉ là 1 trang + 1 bảng client + 1 API, khôi phục dễ.
