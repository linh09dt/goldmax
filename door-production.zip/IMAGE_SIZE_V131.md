# V131 — Tự chỉnh kích thước ảnh SP, xuất file theo đúng kích thước đó

## Yêu cầu

> *"sau khi dán ảnh vào cột hình ảnh sp, tôi có thể điều chỉnh kích thước bằng tay theo ý muốn của tôi mà không phải fit theo code như hiện tại, khi xuất files sẽ theo kích thước của tôi mong muốn"*

Trước V131, ảnh SP luôn bị **tự động fit theo ô** (V110b: rộng hết cột, giữ tỉ lệ, nới dòng đầu) — người dùng không can thiệp được.

## Đã làm

### 1. Lưu kích thước theo từng dòng ảnh
- Thêm 2 cột `image_width`, `image_height` (INTEGER, đơn vị **pixel**) vào **`sales_order_items`** và **`sales_order_item_details`**.
- `NULL` = chế độ **tự động** (giữ nguyên hành vi cũ). Giá trị hợp lệ: **24–800 px** (ngoài khoảng bị bỏ qua để không phá bố cục file xuất).

### 2. Ô Ảnh SP trong form tạo/sửa đơn
Khi dòng đã có ảnh, ô ảnh hiện thêm bộ điều khiển:
- **Kéo tay nắm** ở góc dưới-phải ảnh để đổi kích thước.
- **Gõ số px** vào 2 ô `Rộng` / `Cao` — **giữ đúng tỉ lệ ảnh** (gõ Rộng tự suy ra Cao và ngược lại).
- Nút nhanh **Nhỏ (120) · Vừa (200) · Lớn (320)** và **Tự động** (trả về chế độ vừa ô; nút sáng xanh khi đang ở chế độ tự động).
- Dòng chú thích xác nhận: *"Xuất file theo 200 x 120 px"*.

### 3. Xuất file dùng ĐÚNG kích thước đã đặt
| Nơi xuất | Trước | Sau (khi có kích thước tay) |
|---|---|---|
| **Excel V2** (`Xuất Excel`) | ảnh tự fit ~74 px | nhúng ảnh đúng W×H px + **nới cột ẢNH SP** cho đủ chứa + nới chiều cao dòng đầu |
| **Excel V1** (bản cũ, đang ẩn) | ảnh tự fit ~109 px | như trên (cột T) |
| **PDF V2** (`Xuất PDF`) | ảnh rộng hết cột (~57 px) | ảnh đúng W×H px (px → mm), **nới cột ẢNH SP** (trần 34% bề rộng bảng), các cột khác co theo tỉ lệ |
| **Bản in** (`/orders/[id]/print`) | CSS cố định 86×58 px | đúng W×H px (ghi đè cả max-width/max-height) |

Chưa đặt kích thước → mọi nơi giữ nguyên hành vi tự động như cũ.
Danh sách đơn & trang chi tiết vẫn dùng thumbnail nhỏ như trước (chỉ là ảnh xem nhanh, không phải file xuất).

## Cách dùng

1. Bấm vào ô **Hình ảnh SP** → **Ctrl+V** dán ảnh (hoặc *Tải ảnh*).
2. Kéo nút góc dưới-phải, hoặc gõ số vào ô **Rộng / Cao**, hoặc bấm **Nhỏ / Vừa / Lớn**.
3. Bấm **Lưu nháp** / **Lưu đơn hàng** — kích thước được lưu theo dòng hàng.
4. **Xuất Excel / Xuất PDF / In** → ảnh ra đúng kích thước đã đặt.
5. Muốn quay lại tự động: bấm **Tự động** (hoặc xoá trắng ô Rộng/Cao) rồi lưu lại.

## Kiểm chứng (chạy thật, không đoán)

Dựng lại đúng môi trường: PostgreSQL 18 cục bộ + nạp dữ liệu thật, chạy app Next.js, dùng ảnh test **600×360 px**.

**a) Lưu trữ (DB):**
```
POST /api/orders với imageWidth=320, imageHeight=192  →  sales_order_items.image_width=320, image_height=192
sửa qua UI (gõ Rộng=200) → lưu → DB = 200 × 120   (Cao tự suy ra đúng tỉ lệ 600:360)
```

**b) Excel V2** — mở file xuất ra, soi `xl/drawings/drawing1.xml` + `xl/worksheets/sheet1.xml`:
```
Đặt tay 320×192:  ext = 3048000 × 1828800 EMU  →  ĐÚNG 320 × 192 px
                 cột S (HÌNH ẢNH SP) = 47 ký tự ≈ 320 px   (mặc định 11)
                 dòng 14 cao 150 pt (đủ chứa ảnh 192 px)
Tự động (không đặt): ext = 74 × 44 px · cột S giữ 11   → giống hệt V110b
```

**c) PDF V2** — dựng PDF thật rồi render 72 dpi và **đo khung ảnh** trên trang:
```
Đặt tay 320×192:  241 × 145 pt  ≈  321 × 193 px   ✔ đúng kích thước
Tự động:           43 ×  26 pt  ≈   57 ×  35 px   ✔ như cũ
cột ẢNH SP: 46,4 pt (mặc định) → 246 pt khi ảnh 320 px; ảnh không bị cắt
```

**d) Bản in** — soi HTML thật:
```
Đặt 200×120: <img src="…" style="width:200px;height:120px;max-width:none;max-height:none"/>
Không đặt:   <img src="…"/>   (rơi về CSS tự động như trước)
```

**e) Giao diện** — đo bằng trình duyệt thật: ô nhập hiện đúng `Rộng 200 / Cao 120`, chú thích *"Xuất file theo 200 x 120 px"*; đổi Rộng→200 thì Cao tự thành 120; bấm *Lưu nháp* lưu thành công.

**f) Mã:** `npx tsc --noEmit` → **0 lỗi**; `npx eslint` không phát sinh lỗi mới (các lỗi `no-explicit-any`/`react-hooks` còn lại là lỗi cũ có từ trước); `npx next build` → **PASS**.

## File thay đổi

**Mới:**
- `prisma/migrations/20260926180000_image_size/migration.sql` — thêm 4 cột (idempotent).

**Sửa:**
- `prisma/schema.prisma` — `imageWidth`, `imageHeight` cho `SalesOrderItem` + `SalesOrderItemDetail`.
- `src/lib/order-persistence.ts` — nhận & giới hạn kích thước (24–800 px) khi lưu.
- `src/lib/order-form.ts` — `imageWidth?`, `imageHeight?` trong dữ liệu dòng.
- `src/app/orders/[id]/edit/page.tsx` — nạp kích thước đã lưu vào form.
- `src/components/order-form.tsx` — ô Ảnh SP: kéo/gõ kích thước, khóa tỉ lệ, nút nhanh, nút Tự động.
- `src/lib/order-output.ts` — `groupManualImageSize()` + xác định dòng cung cấp ảnh.
- `src/lib/excel-image-cell.ts` — nhánh dùng kích thước thủ công + `imageColumnWidthFor()` (nới cột).
- `src/lib/order-export-v2.ts`, `src/lib/order-export.ts` — dùng kích thước đã đặt + nới cột ảnh.
- `src/app/orders/[id]/print/page.tsx` — in ảnh đúng kích thước.
- `python/reportlab_order_v2.py` — cột ảnh nới theo kích thước đặt, ảnh vẽ đúng box, giữ tỉ lệ.
- `api/order_pdf_v2.py` — lấy thêm `image_width`, `image_height` trong query.

## Lưu ý

- Đơn vị là **pixel** (quy đổi: PDF 1 px = 25,4/96 mm ≈ 0,2646 mm).
- Kích thước bị giới hạn **24–800 px**; Excel nới cột ẢNH SP tối đa ~420 px, PDF tối đa 34% bề rộng bảng để file không vỡ bố cục.
- Hệ thống **giữ tỉ lệ ảnh** khi chỉnh (không làm méo ảnh).
- Không cần chạy lại Excel/PDF cũ: đơn cũ không có kích thước vẫn xuất như trước.
