# ORDER DOOR CARD UI V41.35

## Mục tiêu
Thay bảng nhập liệu 21 cột của **Chi tiết đơn hàng theo từng bộ cửa** bằng giao diện card dễ nhập, không còn cuộn ngang.

## Logic giao diện mới
- Mỗi **Bộ cửa** là một card lớn, header navy hiển thị Bộ số, sản phẩm/model và tổng tiền của cả bộ.
- Nội dung chính chia 3 khu vực:
  1. **Sản phẩm**: Bộ số, Nhóm cửa, Model, tên sản phẩm tự điền.
  2. **Kích thước & cấu hình**: Cao/Rộng/Khuôn/Ô thoáng/Hướng mở/Phào/Màu sơn.
  3. **Số lượng & giá**: SL, ĐVT, KH/Lượng, Đơn giá, Thành tiền.
- **Thông số thêm** dùng progressive disclosure cho KT thông thủy, phào/khóa, ghi chú, ảnh và các thông số nâng cao.
- **Phụ kiện / Chi tiết** hiển thị dạng mini-card, không dùng bảng ngang.
- 3 dòng đầu tự mở; các dòng sau thu gọn dạng accordion. Dòng mới chưa chọn hàng sẽ tự mở.
- Phào đứng ưu tiên Cao; phào ngang ưu tiên Rộng; loại khác hiển thị Cao/Rộng/Khuôn bình thường.
- Giữ nguyên toàn bộ dữ liệu, API, DB, công thức giá, upload/paste ảnh và export.

## File sửa
- `src/components/order-form.tsx`
- `src/app/guide/page.tsx`
