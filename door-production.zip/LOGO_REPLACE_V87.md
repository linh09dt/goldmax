# V87 — Thay logo GOLDMAX mới (GOLDMAX.jpg 2000×2000) trên mọi đường xuất file

## Yêu cầu

> “đây là logo GOLDMAX.jpg (2000×2000) mới của mình, giúp mình thay và cân đối trên xuất file cho mình”

## Bối cảnh (vì sao phải sửa nhiều chỗ)

Logo cũ nằm ở **3 bản lưu riêng biệt** và được render ở **5 điểm**; thay mỗi `public/goldmax-logo.png`
là không đủ:

| Bản logo | Trước | Sau |
|---|---|---|
| `public/goldmax-logo.png` | 473×202, nội dung 268×76 (3,53:1) | 1024×395, nội dung 1000×371 (2,70:1), nền trong suốt |
| `public/goldmax-logo-cropped.png` | 269×76 | 1000×371 (crop sát nội dung), nền trong suốt |
| base64 nhúng `python/reportlab_order_v2.py` | 269×76 (9,4 KB base64) | 460×171, PNG8 (16 KB → 21 KB base64) |

## Cách làm

### 1. Tạo asset từ `GOLDMAX.jpg`

- Ảnh gốc 2000×2000 **nền trắng, không có kênh alpha**. Nền rất sạch (median 255, chỉ ~190/4.000.000
  pixel lệch < 7 mức) nên tách nền bằng color-to-alpha an toàn, không bị viền/halo JPEG.
- Dò vùng nội dung thật của logo: `(384, 773)` → `(1616, 1230)` = **1232×457 px (tỉ lệ 2,70:1)**.
  (Logo gồm mark vàng + chữ GOLD/MAX + dòng tagline “TRAO GỬI NIỀM TIN, AN TÂM TRỌN ĐỜI”.)
- Chuyển sang RGBA: `alpha = (255 − min(R,G,B)) × 1,35`, pixel có `255 − min ≤ 6` → trong suốt hoàn
  toàn, rồi un-premultiply để giữ đúng màu gốc. Hệ số 1,35 giữ các mảng vàng gold đủ đậm khi đặt
  trên nền xanh nhạt của header Excel/trang in mà viền chữ vẫn mượt.
- Xuất 3 bản: `goldmax-logo-cropped.png` (1000×371), `goldmax-logo.png` (1024×395, thêm 12 px lề
  trong suốt), và bản nhúng PNG8 460×171.
- Kiểm chứng màu: ghép bản trong suốt lên nền trắng rồi so với ảnh gốc → lệch tối đa 6/255,
  trung bình 0,14 (chỉ do làm tròn khi un-premultiply).

### 2. PDF V2 + PDF preview — `python/reportlab_order_v2.py`

- Cập nhật hằng `_EMBEDDED_LOGO_PNG_B64` (dòng ~94) sang logo mới. Đây là bản PDF dùng khi
  Python Function **không thấy `public/`** (Vercel không bundle `public/` theo `vercel.json`).
- Thêm 3 hằng số ở đầu khối logo: `LOGO_W_MM = 30`, `LOGO_H_MM = 12`, `LOGO_MAX_PX = 360`.
- Trong `_logo_flowable()`: sau khi crop alpha, **hạ ảnh về tối đa 360 px** trước khi nhúng
  (file public rộng 1000 px). 360 px cho 30 mm ≈ 305 dpi — đủ nét in, mà PDF không phình theo ảnh gốc.
- Không đổi `kind="proportional"` nên logo mới tự về ~30×11 mm, **không bị kéo giãn**.
- `python/reportlab_order_preview.py` import lại `_logo_flowable` nên tự động dùng logo mới.

### 3. Excel V1 + V2 — không còn kéo giãn logo

Trước đây khung ảnh ghi cứng `92×40` (V1, tỉ lệ 2,30) và `136×52` (V2, tỉ lệ 2,62) — logo cũ 3,53:1
bị bóp dọc. Logo mới 2,70:1 nên cần tính chiều cao theo tỉ lệ thật:

- Thêm `src/lib/png-size.ts`: đọc kích thước pixel từ chunk `IHDR` của PNG (không cần thư viện ảnh)
  + hàm `logoBox(filePath, width)` trả `{ width, height }` đúng tỉ lệ, có fallback tỉ lệ 2,7 nếu
  không đọc được file (không chặn xuất file).
- `src/lib/order-export.ts` (Excel V1): bề rộng logo `LOGO_WIDTH_PX = 92` → cao 35 px.
- `src/lib/order-export-v2.ts` (Excel V2): bề rộng logo `LOGO_WIDTH_PX = 170` → cao 63 px
  (trước 136×52; logo mới có thêm tagline nên nới bề rộng cho chữ đọc được, vùng merge A1:C6 rộng
  ~304×160 px nên vẫn thoải mái).

### 4. Trang in — `src/app/globals.css`

- `.order-print-brand img`: `105px` → `130px` (xem trên màn hình), `74px` → `95px` (khi in),
  vẫn `height: auto` nên giữ đúng tỉ lệ. Cột logo của header là 170 px (in: 120 px) nên không tràn.

### 5. Dọn dẹp

- Xoá `python/__pycache__/` khỏi gói (xem mục Lưu ý).

## Kiểm chứng

- **PDF V2 (có `public/`)**: build thật bằng `build_order_pdf(sample_order.json)` → ảnh trong PDF
  là **360×134, tỉ lệ 2,687** (khớp ảnh nguồn), có `/SMask` nên nền vẫn trong suốt. Render trang 1
  bằng `pdftoppm` và soi header: logo mới hiện đúng, không có ô trắng/ô đen.
- **PDF V2 (nhánh dự phòng, đã tạm ẩn `public/*.png`)**: vẫn ra logo mới từ base64 — ảnh PNG8 +
  alpha giải mã đúng, `/SMask` = 1, không lỗi.
- **PDF preview**: build thật → OK, dùng chung logo với PDF V2.
- **Excel V1**: build thật bằng `buildOrderExcel()` → `xl/media/image1.png` = 1024×395; drawing
  `cx="876300" cy="333375"` = **92×35 px** (tỉ lệ 2,629 so với 2,592 của ảnh — lệch 1,4% do làm
  tròn pixel).
- **Excel V2**: `xl/media/image1.png` = 1000×371; drawing `cx="1619250" cy="600075"` =
  **170×63 px**, tỉ lệ 2,698 so với 2,695 → khớp gần như tuyệt đối.
- **Mở thật 2 file Excel bằng LibreOffice** → chuyển PDF → soi header: logo mới nằm đúng góc trái,
  hiển thị trên nền xanh nhạt (#C6E0B4) không có ô trắng, chữ công ty/bảng giá không bị lệch.
- `npx tsc --noEmit` → 0 lỗi.

## Lưu ý (đọc trước khi đổi logo lần sau)

- **Phải thay đủ 3 bản**: `public/goldmax-logo.png`, `public/goldmax-logo-cropped.png` và hằng
  `_EMBEDDED_LOGO_PNG_B64` trong `python/reportlab_order_v2.py`. Thiếu bản base64 thì PDF trên
  Vercel vẫn ra logo cũ (đã kiểm chứng nhánh này là nhánh được dùng khi thiếu `public/`).
- Lệnh tạo base64 từ bản cropped:
  `python -c "import base64;print(base64.b64encode(open('public/goldmax-logo-cropped.png','rb').read()).decode())"`
- **Luôn xoá `python/__pycache__/` sau khi sửa `reportlab_order_v2.py`**: trong lúc làm bản này,
  một lần sửa file `.py` trong cùng một giây với lần chạy trước đã khiến Python dùng lại `.pyc` cũ
  (build ra logo cũ). `__pycache__` hiện không nằm trong `.gitignore`.
- Logo mới có **tỉ lệ 2,70:1**; nếu sau này thay logo tỉ lệ khác thì chỉ cần thay 3 file ảnh, chiều
  cao trong Excel tự tính lại — không phải sửa code, trừ khi muốn đổi bề rộng.
- **Chưa đổi `src/app/favicon.ico`** (icon tab trình duyệt vẫn là logo cũ) vì favicon không nằm
  trong file xuất. Muốn đồng bộ thì gửi mình ảnh, hoặc nói mình tự cắt từ logo mới.
- Ảnh logo giờ nặng hơn (240 KB/ảnh so với 7 KB trước đây, do có gradient + tagline). PDF tăng từ
  ~78 KB lên ~141 KB (đã hạ về 360 px để hạn chế). Muốn nhẹ hơn nữa thì giảm `LOGO_MAX_PX`.

## File thay đổi

- `public/goldmax-logo.png` — logo mới, nền trong suốt, 1024×395.
- `public/goldmax-logo-cropped.png` — logo mới crop sát, 1000×371.
- `python/reportlab_order_v2.py` — base64 logo mới, hằng số `LOGO_W_MM/LOGO_H_MM/LOGO_MAX_PX`, hạ ảnh về 360 px.
- `src/lib/png-size.ts` — **mới**: đọc kích thước PNG + tính khung logo theo tỉ lệ thật.
- `src/lib/order-export.ts` — logo Excel V1 theo tỉ lệ thật (92 px).
- `src/lib/order-export-v2.ts` — logo Excel V2 theo tỉ lệ thật (170 px).
- `src/app/globals.css` — bề rộng logo trang in 130 px (màn hình) / 95 px (in).
- Xoá `python/__pycache__/`.
