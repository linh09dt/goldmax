# PDF V2 V41.13

- Giữ nguyên layout/logic PDF V2 V41.12.
- Response PDF từ Python Function đổi sang một lần `wfile.write(pdf_bytes)` thay vì stream nhiều chunk.
- Không gửi response lỗi thứ hai sau khi binary headers đã bắt đầu.
- Thêm `diag=build` để xác nhận DB + ReportLab + phân trang hoàn tất trước response.
- UI không còn đổ nguyên HTML 500 của Next/Vercel vào hộp lỗi.
