# ORDER NOTE TITLE STYLE V60

## Mục tiêu
Trong file xuất (Excel + PDF):
- Dòng **“Ghi chú:”**: **bôi đậm + gạch chân + nghiêng + chữ đỏ**.
- Dòng **“Khách hàng xác nhận các thông tin sau:”**: **in đậm**.

## File sửa
1. `python/reportlab_order_v2.py`
   - `_fontpkg_roboto_files()` trả thêm font **bold-italic** (`fontpkg.path("Roboto", weight=700, style="italic")`).
   - `register_fonts()` đăng ký thêm **`GM-BoldItalic`**; nếu môi trường không có file bold-italic thì lùi về `GM-Bold` (vẫn đậm, không lỗi). Có thể override bằng env `REPORTLAB_FONT_BOLDITALIC_PATH`. Ở máy local dùng `DejaVuSans-BoldOblique.ttf`.
   - Style `footnote_title`: font `bold_italic`, màu đỏ `#DC2626`.
   - `_footnote_block()`: dòng tiêu đề dùng `Paragraph("<u>Ghi chú:</u>", …)` để có **gạch chân**.
2. `python/reportlab_order_preview.py` — `pstyle()` nhận thêm tham số `font`; style `footnote_title` = bold-italic + đỏ; dùng `rich("<u>Ghi chú:</u>")`.
3. `src/lib/order-export-v2.ts` — mỗi dòng ghi chú có `font` riêng: “Ghi chú:” = `bold + italic + underline + #DC2626`; “Khách hàng xác nhận…” = `bold`; các dòng còn lại giữ nguyên (8pt, xám).

## Không thay đổi
- Nội dung ghi chú, khung + nền `#F8FAFC`, vị trí (dưới box tiền, trải hết chiều ngang).
- Công thức tiền, box tiền, quy tắc ẩn dòng chiết khấu khi 0%, không xuất bảng checklist.

## Kiểm chứng thực tế
- **PDF V2**: render `_bottom_section` → ảnh cho thấy “Ghi chú:” **đậm, nghiêng, gạch chân, màu đỏ**; “Khách hàng xác nhận các thông tin sau:” **đậm** (`pdf_note_title_red.png`).
- **Excel V2**: đọc lại thuộc tính ô → `row 24 "Ghi chú:" bold=true italic=true underline=true color=FFDC2626`; `row 25 "Khách hàng xác nhận…" bold=true`. Convert sang PDF bằng LibreOffice để xem bản in thật: đúng như yêu cầu (`excel_note_title_red.png`).
- `python -m py_compile`: OK · `npx tsc --noEmit`: pass.
