# V86 — Menu trái: bỏ chú thích dưới từng mục

## Yêu cầu

> “trên thanh menu, bỏ chú thích phía dưới tab *Tự động tổng hợp từ đơn hàng*, *Hàng hóa, thuộc tính, tính toán*”

## Cách làm

File sửa duy nhất: `src/components/erp-nav.tsx` (menu trái của toàn app).

- Xoá chú thích **“Tự động tổng hợp từ đơn hàng”** dưới mục **Thông tin khách hàng**.
- Xoá chú thích **“Hàng hóa · Thuộc tính · Tính toán”** dưới mục **Cấu hình**.
- Xoá luôn field `hint?: string` khỏi type `NavItem` và khối render chú thích — vì sau khi bỏ 2 chú thích thì không còn mục nào dùng nữa.
- Đổi cách xếp mục menu từ `flex items-start` (canh trên, để chừa chỗ cho chú thích) sang **`flex items-center`** canh giữa icon với tên mục, tên mục `truncate` khi quá dài.

## Kiểm chứng

- `npx tsc --noEmit` → 0 lỗi. `npm run build` → OK. `npx eslint src/components/erp-nav.tsx` → 0 lỗi.
- Đo thật trong trình duyệt (1280×720):
  - Menu trái còn đúng **7 mục, mỗi mục 1 dòng**: Tổng quan · Quản lý đơn hàng · Thông tin khách hàng · Theo dõi doanh thu · Cấu hình · Tính cước vận chuyển · Hướng dẫn sử dụng.
  - Chiều cao mỗi mục đều nhau **40px** (trước đây mục có chú thích cao hơn).
  - Quét toàn bộ nội dung trang: **không còn** chuỗi “Tự động tổng hợp từ đơn hàng” và “Hàng hóa · Thuộc tính · Tính toán”.

## Lưu ý

- Hai chuỗi này chỉ tồn tại trong `erp-nav.tsx`; không xuất hiện ở trang nào khác nên bỏ là hết.
- Các dòng ghi chú **khác** trong khu Cấu hình vẫn giữ nguyên (không nằm trong yêu cầu): ghi chú dưới thanh chọn A1/A2/B1 (“Khai báo một lần, dùng lại cho mọi đơn hàng · Áp cho các đơn hàng tạo/sửa sau khi lưu.”), dòng tổng hợp số lượng dưới mỗi mục A1/A2 trong thanh chọn, và chú thích cuối sidebar (“Dữ liệu nền và quy tắc tính toán nằm chung trong mục “Cấu hình”.”). Muốn bỏ luôn thì nói mình.

## File thay đổi

- `src/components/erp-nav.tsx` — bỏ `hint` của 2 mục menu, canh giữa icon và tên mục.
