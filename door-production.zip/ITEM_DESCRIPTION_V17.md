# ERP V17 — Tên sản phẩm diễn giải

## Mục tiêu

Bổ sung trường **Tên sản phẩm diễn giải** vào Master Data hàng hóa và liên kết với màn hình Tạo/Sửa đơn hàng.

## Master Data hàng hóa

Cấu trúc hiển thị:

- TENHANG
- Tên sản phẩm diễn giải
- MODEL
- ĐVT
- Giá đại lý
- Giá bán lẻ
- Trạng thái

`Tên sản phẩm diễn giải` là trường tùy chọn, có thể nhập và sửa trực tiếp trên tab Danh mục hàng hóa.

Tìm kiếm Danh mục hàng hóa hỗ trợ cả TENHANG, Tên sản phẩm diễn giải, MODEL và ĐVT.

File **Xuất Master Data** cũng có thêm cột `TÊN SẢN PHẨM DIỄN GIẢI`.

## Liên kết với Đơn hàng

Khi chọn một MODEL/TENHANG từ Master Data trong Tạo/Sửa đơn hàng:

1. Mã sản phẩm lấy từ MODEL.
2. Tên sản phẩm ưu tiên lấy `Tên sản phẩm diễn giải`.
3. Nếu chưa cấu hình tên diễn giải, fallback về TENHANG.
4. ĐVT, Giá đại lý/Giá bán lẻ tiếp tục lấy theo logic V15.
5. Giá trị Tên sản phẩm được lưu snapshot vào đơn hàng để đơn cũ không tự đổi khi Master Data thay đổi.

Xuất Excel/PDF đơn hàng vẫn giữ logic TENHANG/MODEL đã chốt trước đó; trường diễn giải dùng cho dữ liệu Tên sản phẩm trong nghiệp vụ đơn hàng.

## Database

Thêm cột:

```sql
item_masters.product_description TEXT NULL
```

## Cập nhật

Chép patch lên V16 hiện tại rồi chạy:

```cmd
npm run db:migrate
npm run db:generate
rmdir /s /q .next
npm run dev -- --webpack
```
