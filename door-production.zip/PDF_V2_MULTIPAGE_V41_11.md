# PDF V2 multipage V41.11

- `noImages=1` vẫn lỗi 500 => loại ảnh sản phẩm khỏi nguyên nhân chính.
- Đổi bảng dữ liệu từ `Table` sang `LongTable`.
- Bỏ `NOSPLIT` theo từng bộ cửa để ReportLab được phép phân trang tự nhiên.
- Bật `splitInRow=1` cho dòng có ghi chú quá cao.
- Bỏ `KeepTogether` bao phần checklist/tổng tiền.
- API không còn dựng PDF trong `BytesIO`; ghi trực tiếp `/tmp` và stream theo chunk.
- Không SELECT `raw_block` cho toàn bộ đơn hàng ở PDF V2.
- Thêm `?diag=1` để kiểm tra DB/count mà không render PDF.
- Thêm log theo stage `start`, `db_loaded`, `pdf_built`, `response_done`, `error`.
- Chặn trước PDF > 4.3 MB để trả lỗi rõ ràng trước giới hạn 4.5 MB của Vercel.
- `vercel.json`: maxDuration 300 giây cho `api/order_pdf_v2.py`.
