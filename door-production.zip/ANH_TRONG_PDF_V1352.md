# V135.2 — Sửa lỗi PDF xuất ra KHÔNG có hình (Excel thì có)

## Bạn báo

> *"ĐANG ĐỂ HÌNH Ở XUẤT EXCEL RỒI, ĐỂ HÌNH XUẤT PDF CHO TÔI"*

Đúng: file **Excel có ảnh**, nhưng **PDF thiếu ảnh** (hoặc trắng cột Hình ảnh SP).

## Nguyên nhân (đã tái hiện được)

1. **Hàm PDF chỉ chờ 1,5 giây cho mỗi ảnh** — `_download_image_bytes(..., timeout=1.5)` trong `python/reportlab_order_v2.py`.
   Ảnh cửa thật trên Supabase Storage thường 1–3 MB nên tải quá 1,5 giây ⇒ **ảnh bị bỏ**, ô hình để trống.
   Excel không có giới hạn này (Node `fetch` chờ tới khi xong) ⇒ **Excel vẫn có ảnh**, đúng như bạn thấy.
2. **Ảnh lưu đường dẫn tương đối (`/uploads/orders/...`) bị bỏ qua hoàn toàn**: hàm tải chỉ nhận URL `http(s)://…`, nên đơn tạo khi chưa bật Supabase Storage thì PDF không bao giờ có ảnh.
3. (Kèm theo) ảnh được thu nhỏ cố định **240 px** trong khi người dùng đặt cỡ ảnh tới 800 px ⇒ ảnh in ra bị mờ.

**Bằng chứng tái hiện:** dựng một server trả ảnh **chậm 3 giây** rồi gọi `_download_image_bytes`:
trước khi sửa → *"KHÔNG có ảnh (bị bỏ)"* sau 1,51 giây; sau khi sửa → *"CÓ ảnh"* (2083 KB) sau 3,01 giây.

## Đã sửa

| Việc | Trước | Sau |
|---|---|---|
| Thời gian chờ tải ảnh | 1,5 giây | **6 giây**, **thử lại 1 lần** |
| Giới hạn dung lượng ảnh | 6 MB | 15 MB |
| URL tương đối `/uploads/...` | bỏ qua | **ghép với host của chính app** rồi tải; dự phòng `SITE_URL` / `NEXT_PUBLIC_SITE_URL` / `VERCEL_URL` |
| Số ảnh tải song song | 6 | 8 |
| Cỡ ảnh nhúng PDF | cố định 240 px | theo **cỡ ảnh bạn đặt** (tối đa 900 px), tự giảm khi đơn nhiều ảnh (≤6 ảnh → 900 px · ≤12 → 600 · ≤20 → 420 · >20 → 300) để PDF không vượt giới hạn 4,5 MB của Vercel |
| Nhật ký | không có | log `08B_IMAGES: requested / loaded / failed / targetPx` để chẩn đoán |
| Giao diện | im lặng khi thiếu ảnh | đọc header `X-GoldMax-Images-Loaded` / `-Requested`, **cảnh báo ngay trong hộp thoại xuất** nếu thiếu ảnh |

## Kiểm chứng (chạy thật)

| Kịch bản | Kết quả |
|---|---|
| Ảnh trả chậm **3 giây** (3 ảnh) | tải **3/3**, PDF nhúng **3 ảnh**, 3,3 giây |
| Ảnh lưu **đường dẫn tương đối** `/uploads/...` + host của app | tải 3/3, PDF nhúng 3 ảnh |
| Ảnh thật 1–2 MB, cỡ đặt tay 800 px | thumbnail **800 px**, PDF 242 KB |
| **25 ảnh khác nhau** | tự giảm còn **300 px**, tải 25/25, PDF **167 KB** (không chạm giới hạn Vercel) |
| Chạy **đúng handler production** (`api/order_pdf_v2.py` qua HTTP, Host = app) | HTTP 200 · `X-GoldMax-Images-Requested: 3` · `X-GoldMax-Images-Loaded: 3` · PDF 3 trang, có ảnh |
| Chế độ `noImages=1` | không nhúng ảnh, không gửi header ảnh (đúng) |
| Không hồi quy: dựng PDF cho **6 đơn** (15, 17, 100, 166, 167, 199) | tất cả OK, không lỗi; đơn 199 có 3/3 ảnh |

Ảnh nhúng trong PDF được kiểm tra bằng `pdfimages -list` (đếm ảnh thật trong file, không chỉ tin log).

`tsc` 0 lỗi · `eslint` file sửa 0 lỗi · `next build` PASS · Python syntax OK.

## File thay đổi

- `python/reportlab_order_v2.py` — `_download_image_bytes` (timeout/retry/giới hạn), `_absolute_image_url` (mới),
  `_collect_image_targets` (mới), `_image_budget_px` (mới), `_image_target_px` (mới),
  `_optimize_product_image` (cỡ theo tham số), `_prefetch_product_images` (base_url + thống kê),
  `build_order_pdf` / `build_order_pdf_bytes` (nhận `base_url`, `stats`).
- `api/order_pdf_v2.py` — `_request_base_url()` từ header của request; truyền base_url + thống kê;
  log `08B_IMAGES`; gửi header `X-GoldMax-Images-Requested/Loaded`.
- `src/components/order-export-buttons.tsx` — đọc 2 header trên và cảnh báo trong hộp thoại xuất khi thiếu ảnh.

## Deploy

Chỉ cần đẩy code (không có migration). Nếu PDF vẫn thiếu ảnh, mở đường chẩn đoán để xem log:

```
/api/order_pdf_v2?orderId=<id>&diag=trace     → xem trace (JSON)
/api/order_pdf_v2?orderId=<id>                → xem header X-GoldMax-Images-Loaded
```

## Ghi chú

- Ảnh trong PDF được nén về JPEG nên file PDF vẫn nhẹ (150–250 KB cho đơn thường) — nhưng nay **đủ và sắc nét** theo cỡ bạn đặt.
- Nếu ảnh gốc quá nặng hoặc mạng chậm, PDF vẫn xuất được: ảnh nào tải không kịp sẽ để trống và giao diện **báo rõ thiếu bao nhiêu ảnh** để bạn xuất lại.
