# PDF V2 Debug V41.16 — Binary Response Test

Chỉ bổ sung debug, không thay logic PDF V2/Excel V2.

## Test
`/api/order_pdf_v2_debug?orderId=14&test=response&noImages=1`

Endpoint sẽ: load DB -> build toàn bộ PDF -> xác nhận `%PDF-` -> trả chính file PDF binary với `Content-Length`.

- Nếu tải/mở PDF: binary response của debug endpoint OK; so sánh endpoint chính.
- Nếu HTML 500: lỗi nằm ở binary response/runtime proxy.
