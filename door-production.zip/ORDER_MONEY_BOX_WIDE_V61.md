# ORDER MONEY BOX WIDE V61

## Mục tiêu
Theo bản vẽ hộp tiền:
1. **Bố trí lại kích thước**: hộp tiền **trải hết chiều ngang trang**, mỗi dòng **nhãn bên trái – số tiền bên phải**, **không còn vạch dọc** giữa nhãn và tiền (chỉ kẻ vạch ngang giữa các dòng).
2. **Nhãn IN HOA**: `TỔNG GIÁ TRỊ ĐƠN HÀNG:` · `CHIẾT KHẤU THƯƠNG MẠI (12%):` · `TỔNG TIỀN SAU CHIẾT KHẤU:` · `ĐÃ ĐẶT CỌC:` · `TRỪ TIỀN NHẬN HÀNG TẠI KHO:` (nếu có) · `CÒN LẠI CẦN THANH TOÁN:`.

Đối chiếu bản vẽ (đo pixel): box cũ `x 31 → 1385` (= hết chiều ngang trang), các dòng `y 435/466/496/526/556/587`, không có vạch dọc nào trong hộp; nhãn ở `x 31–245`, số tiền kết thúc ở `x 1385`; dòng `(Bằng chữ: …)` nằm **dưới** hộp và căn phải.

## File sửa
1. `python/reportlab_order_v2.py` — `_bottom_section`: bảng tổng kết đổi sang `colWidths=[CONTENT_W*0.6, CONTENT_W*0.4]`, `hAlign="LEFT"`; thay `INNERGRID` bằng `LINEBELOW` (bỏ vạch dọc); nhãn viết HOA. Bảng ngoài còn 2 hàng 1 cột: hộp tiền (full width) + hộp ghi chú (full width), cách 1 dòng.
2. `python/reportlab_order_preview.py` — tương tự.
3. `src/lib/order-export-v2.ts` — `writeSummary`: nhãn HOA; vùng nhãn merge **A→P**, vùng số tiền **Q→S** (hết chiều ngang sheet); bỏ viền phải của ô `P` và viền trái của ô `Q` để không có vạch dọc; dòng “Bằng chữ” merge `A→S`.

## Giữ nguyên
- Màu dòng chiết khấu (nền vàng nhạt + chữ đỏ) và dòng “TỔNG TIỀN SAU CHIẾT KHẤU” (nền xanh rất nhạt), dòng tổng (nền navy, chữ trắng).
- Quy tắc ẩn dòng “Tổng tiền sau chiết khấu” khi chiết khấu 0% (V51); không xuất bảng checklist (V52); hộp ghi chú full width + style chữ (V57/V60).
- Công thức tiền, DB/Prisma, API; không cần migration.

## Kiểm chứng thực tế
- **PDF V2 + preview**: render rồi trích text → đủ 5 nhãn **IN HOA**, có dòng “Bằng chữ”. Đo ảnh render: dòng navy `x 54 → 2165` (hết chiều ngang), **không có cột vạch dọc** nào trong hộp tiền; hộp ghi chú vẫn full width bên dưới (`pdf_money_box_v61.png`).
- **Excel V2**: đọc lại file → `row 16..20` nhãn IN HOA ở cột A (merge `A:P`), số tiền ở cột Q (merge `Q:S`), `P.right = none` và `Q.left = none` (không vạch dọc), `A.left`/`S.right` có viền (khung ngoài), dòng “Bằng chữ” merge `A21:S22`. Convert sang PDF bằng LibreOffice để xem bản in thật (`excel_money_box_v61.png`) — đúng bố cục bản vẽ.
- `npx tsc --noEmit`: pass · `python -m py_compile`: OK.
