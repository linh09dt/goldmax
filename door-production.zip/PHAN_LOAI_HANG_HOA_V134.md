# V134 — Tab CẤU HÌNH: phân loại hàng hóa thành CẤP CỬA / PHỤ KIỆN / CHI PHÍ GIA CÔNG

> ⚠️ **Đã được thay thế một phần bởi V135** (`PHAN_LOAI_TU_CAU_HINH_V135.md`): danh sách phân loại
> **không còn hard-code** — nay là bảng `item_categories`, tự thêm / đổi tên / xoá / đổi cách dùng ở
> **Cấu hình → A3 Phân loại hàng hóa**. Tài liệu này giữ lại để tham chiếu lịch sử.

## Yêu cầu

> *"TAB CẤU HÌNH MÌNH MUỐN PHÂN CẤP CHI RA CẤP CỬA VÀ PHỤ KIỆN, CHI PHÍ GIA CÔNG"*

## Hiện trạng trước khi sửa (đã khảo sát code + dữ liệu thật)

- Tab Cấu hình (`/settings`) có 3 tab con: **A1 Danh mục hàng hóa** (bảng `item_masters`), **A2 Danh mục cấu hình** (`master_options`), **B1 Cấu hình tính toán** (`system_settings`).
- Danh mục hàng hóa **không có cột phân loại**. App chỉ chia 2 khối bằng cách **đoán theo tên TENHANG**: bắt đầu bằng "Cửa" ⇒ CỬA, còn lại ⇒ PHỤ KIỆN (`isDoorTenhang` trong `item-master.tsx`, `isDoorCatalogItem` trong `order-form.tsx`).
- ⇒ Không có chỗ nào khai báo "chi phí gia công"; nhóm **"Gia Công Ô Kính" (5 MODEL)** đang bị gộp chung vào PHỤ KIỆN.
- Dữ liệu thật trong DB test: **92 MODEL / 15 TENHANG** — 7 nhóm cửa (52 MODEL), 7 nhóm phụ kiện (35 MODEL), 1 nhóm gia công (5 MODEL).

## Đã làm

### 1. Dữ liệu — cột phân loại thật
- `prisma/schema.prisma`: `ItemMaster.category String @default("ACCESSORY")` + index `item_masters_category_idx`.
- Migration `prisma/migrations/20260926210000_item_category/migration.sql`:
  - thêm cột `category` (`DOOR` | `ACCESSORY` | `PROCESSING`),
  - **tự phân loại dữ liệu đang có**: TENHANG bắt đầu bằng "Cửa"/"Cua" ⇒ `DOOR`; chứa "gia công" / "chi phí" / "phụ phí" / "khoét" ⇒ `PROCESSING`; còn lại ⇒ `ACCESSORY`,
  - **không đổi hành vi cũ**: đúng 52/35/5 như cách app vẫn chia trước đây, chỉ khác là nay sửa được.

### 2. Một nguồn logic dùng chung — `src/lib/item-category.ts`
- `ITEM_CATEGORY_SECTIONS` (nhãn + màu + mô tả của 3 khối), `itemCategoryLabel()`, `normalizeItemCategory()`,
- `classifyItemByName()` — heuristic (chỉ dùng khi nạp Excel / dòng chưa có phân loại),
- `resolveItemCategory(category, name)` — **ưu tiên cột `category`**, chưa có thì mới đoán theo tên ⇒ tab Cấu hình và form tạo đơn không bao giờ lệch nhau.

### 3. Tab Cấu hình — 3 khối + sửa phân loại ngay
- Danh sách hàng hóa chia **3 khối theo cột Phân loại**: `CẤP CỬA` (52) · `PHỤ KIỆN` (35) · `CHI PHÍ GIA CÔNG` (5), mỗi khối có badge đếm MODEL/TENHANG và mô tả cách dùng.
- Thêm **cột "Phân loại"**: mỗi dòng có ô chọn `Cấp cửa / Phụ kiện / Chi phí gia công` — **đổi là lưu ngay** (không phải vào chế độ Sửa), dòng tự nhảy sang khối mới, badge tự cập nhật.
- Form "Thêm hàng hóa thủ công" có ô **Phân loại** (mặc định tự đoán theo TENHANG, chọn tay được).
- Hint của bảng nói rõ 3 khối theo cột Phân loại.

### 4. Form tạo đơn dùng phân loại thật
- `isDoorCatalogItem()` nay đọc cột phân loại ⇒ ô **"Nhóm cửa"** chỉ liệt kê nhóm cửa (7 nhóm), không lẫn phụ kiện.
- Ô **"Nhóm hàng"** của dòng chi tiết: phụ kiện như cũ, còn nhóm chi phí gia công nằm trong **optgroup riêng `CHI PHÍ GIA CÔNG`** (ví dụ "Gia Công Ô Kính") để chọn nhanh.
- Đổi phân loại ở tab Cấu hình là form tạo đơn thay đổi ngay (không cần build lại danh sách).

### 4b. Tạo lại Master Data giữ phân loại (V134.1)
"Tạo lại Master Data từ Excel" xoá toàn bộ danh mục rồi nạp lại từ file nguồn (file chỉ có TENHANG + MODEL),
nên trước V134.1 nó **xoá mất phân loại đã đặt**. Nay route snapshot `MODEL → phân loại` trước khi xoá và dùng lại
cho mã cũ; mã mới thì phân loại theo TENHANG. Kiểm chứng: đặt `PR` = CẤP CỬA → tạo lại → `PR` vẫn CẤP CỬA,
mã mới "Cửa Test Mới" → CẤP CỬA, "Phào Test Mới" → PHỤ KIỆN. Chi tiết đầy đủ ở `ANH_HUONG_PHAN_LOAI_V134.md`.

### 5. API / Excel
- `GET /api/items`: trả thêm `category`, hỗ trợ lọc `?category=DOOR|ACCESSORY|PROCESSING`.
- `POST /api/items`: nhận `category` (không gửi thì tự đoán theo TENHANG).
- `PUT /api/items/[id]`: nhận `category`; **không gửi thì giữ nguyên** (sửa tên/giá không làm mất phân loại đã đặt).
- `GET /api/items/export`: thêm cột **PHÂN LOẠI** (Cấp cửa / Phụ kiện / Chi phí gia công).
- `POST /api/items/master/rebuild` và `POST /api/items/import`: hàng mới được phân loại theo TENHANG (file Master chỉ có TENHANG + MODEL), sau đó sửa lại được trong tab Cấu hình.

## Kiểm chứng (chạy thật)

| Kiểm tra | Kết quả |
|---|---|
| Migration trên DB test | `DOOR 52` · `ACCESSORY 35` · `PROCESSING 5` (đúng bằng cách chia cũ) |
| Tab Cấu hình | 92 dòng, 3 khối: `CẤP CỬA 52 MODEL / 7 TENHANG`, `PHỤ KIỆN 35 / 6`, `CHI PHÍ GIA CÔNG 5 / 1` |
| Ô chọn phân loại | `DOOR: Cấp cửa`, `ACCESSORY: Phụ kiện`, `PROCESSING: Chi phí gia công` |
| Đổi phân loại mã `PR` (Phao Rời) → Chi phí gia công | dòng chuyển khối: `35→34` và `5→6`; TENHANG `6→5` và `1→2`; lưu vào DB; đổi lại về Phụ kiện ⇒ `52/35/5` |
| Đổi qua API (`PUT`) 1 mã "Gia Công Ô Kính" → Phụ kiện | số hàng `?category=PROCESSING` từ **5 → 4**, khôi phục về **5** ⇒ phân loại là dữ liệu thật, không phải suy diễn |
| Form tạo đơn — ô "Nhóm cửa" | đúng 7 nhóm cửa, **không** có phụ kiện/gia công |
| Form tạo đơn — ô "Nhóm hàng" dòng chi tiết | `KHÓA, Khuôn Kép, Ô Thoáng, Phào Biệt Thự, Phao Rời, Song Tròn` + **`[CHI PHÍ GIA CÔNG] Gia Công Ô Kính`** |
| Excel danh mục | có tiêu đề `PHÂN LOẠI` + 3 nhãn `Cấp cửa / Phụ kiện / Chi phí gia công` |
| Bề rộng bảng ở 1600/1440/1280 px | **không** phát sinh cuộn ngang (0 px tràn) |
| `tsc` / `eslint` / `next build` | 0 lỗi TS · không thêm lỗi lint · build **PASS** |

## Deploy

1. **Chạy migration trước** (dán SQL `prisma/migrations/20260926210000_item_category/migration.sql` vào Supabase, hoặc `npx prisma migrate deploy`).
   Migration tự phân loại 92 mã đang có nên sau khi chạy, app hiển thị y như cũ (chỉ khác là sửa được).
2. Rồi mới đẩy code.

## File thay đổi

**Mới:** `src/lib/item-category.ts`, `prisma/migrations/20260926210000_item_category/migration.sql`

**Sửa:** `prisma/schema.prisma`, `src/components/item-master.tsx`, `src/components/order-form.tsx`, `src/app/guide/page.tsx`,
`src/app/api/items/route.ts`, `src/app/api/items/[id]/route.ts`, `src/app/api/items/export/route.ts`,
`src/app/api/items/import/route.ts`, `src/app/api/items/master/rebuild/route.ts`

## Ghi chú

- Nhãn khối dùng đúng chữ bạn viết: **CẤP CỬA**. Muốn đổi thành "Cửa" / "Cấp cửa 1–2–3" hay tách tiếp thành nhiều cấp nhỏ hơn thì nói mình — chỉ cần sửa `ITEM_CATEGORY_SECTIONS` và (nếu thêm giá trị mới) thêm vào `ITEM_CATEGORIES`.
- Phân loại hiện ảnh hưởng tới: khối trong tab Cấu hình, ô "Nhóm cửa"/"Nhóm hàng" khi tạo đơn, cột PHÂN LOẠI khi xuất Excel danh mục. Tiền và báo cáo **không** thay đổi.
