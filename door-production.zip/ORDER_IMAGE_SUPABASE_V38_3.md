# V38.3 - Order image Supabase Storage

- Hình đơn hàng lưu vào Supabase Storage bucket `order-images`.
- Hiển thị thumbnail tại cột Hình ảnh SP.
- Hiển thị thumbnail ngay sau khi upload trong màn hình sửa/tạo đơn.
- Local development vẫn có fallback `public/uploads/orders` nếu chưa cấu hình Storage.
- Production/Vercel yêu cầu `SUPABASE_URL` và `SUPABASE_SERVICE_ROLE_KEY` (hoặc `SUPABASE_SECRET_KEY`).
- Không đổi schema database.
