# ERP V22.1 - Sửa ô Chiết khấu (%) nhập tay

- `Chiết khấu (%)` là input number, không còn hiển thị badge cố định 12%.
- Mặc định đơn mới vẫn là 12%, nhưng có thể sửa 0..100 (hỗ trợ số thập phân).
- Số tiền chiết khấu, tổng sau chiết khấu và thanh toán khi giao hàng tính lại ngay khi thay đổi.
- Khi lưu, `discountPercent` được lưu theo từng đơn.
- Khi sửa đơn cũ, lấy % đã lưu của đơn đó.
- Không đổi schema database.

Patch này được đóng gói với `src/` ở ngay root ZIP để giải nén trực tiếp vào thư mục project.
