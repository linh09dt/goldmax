# ERP V16 — Xóa hàng hóa trong Danh mục hàng hóa

## Chức năng mới

- Thêm nút **Xóa** tại từng dòng của `/items`.
- Khi xóa, hệ thống hiển thị xác nhận gồm **TENHANG + MODEL**.
- Xác nhận xong sẽ xóa vật lý bản ghi khỏi `item_masters`.
- Hàng đã xóa không còn xuất hiện khi tìm/chọn hàng hóa cho đơn hàng mới.
- Đơn hàng đã lưu trước đó không bị thay đổi vì đơn hàng lưu snapshot TENHANG/MODEL/ĐVT/Đơn giá riêng.
- Không thay đổi schema database, không cần migration.

## Cập nhật

Chép patch chồng lên V15 hiện tại, dừng server và chạy:

```cmd
rmdir /s /q .next
npm run dev -- --webpack
```

Nếu đang dùng Turbopack và vẫn thấy `stale`, đóng tab cũ và mở lại localhost hoặc hard refresh bằng `Ctrl + Shift + R`.
