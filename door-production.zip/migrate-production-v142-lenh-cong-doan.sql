-- ============================================================================
-- V142 — LỆNH SẢN XUẤT CHO TỪNG CÔNG ĐOẠN (mã lệnh lưu trong DB)
--   BẢN CHẠY TAY — IDEMPOTENT: chạy lại nhiều lần vẫn an toàn.
--
-- Nội dung giống hệt `prisma/migrations/20260927000000_production_work_orders/migration.sql`
-- nhưng thêm IF NOT EXISTS và kiểm tra tồn tại, để chạy được trên DB đã có dữ liệu.
--
-- MỖI CÂU TỰ CHỨA: KHÔNG bảng tạm, KHÔNG session state ⇒ dán cả file vào SQL Editor,
--   hoặc chạy từng câu một (autocommit / pooler / mỗi câu một connection) đều được.
--
-- 1 bộ = 1 lệnh CHA (BO) + 3 lệnh CON (CANH/KHUNG/PHAO) + 1 lệnh mỗi CÔNG ĐOẠN (CONG_DOAN).
-- Bảng chỉ lưu mã lệnh + danh tính + ngày phát; số lượng/trạng thái/ngày kế hoạch suy ra từ
-- `production_tasks`. Bảng này giữ NGUỒN SỰ THẬT DUY NHẤT cho mã lệnh — không lưu trùng số liệu.
--
-- ⚠️ Chạy TRƯỚC khi deploy code (bài học V112).
-- ⚠️ Nếu pipeline có chạy `prisma migrate deploy`, đánh dấu migration đã áp dụng:
--      npx prisma migrate resolve --applied 20260927000000_production_work_orders
--
-- MÃ LỆNH (khớp `src/lib/production/work-order.ts`):
--   LSX-<mã đơn>-<bộ số>-<seq 02 chữ số><chữ phần>   vd LSX-26082201QN17DH01-1-40C
--   chữ phần: Cánh C · Khung K · Phào P · cả bộ B · lệnh cha/con dùng seq = 00
--   bộ không có mã đơn → LSX-<id bộ>-<seq><chữ phần>
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) BẢNG LỆNH SẢN XUẤT
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "production_work_orders" (
    "id"         SERIAL NOT NULL,
    "code"       VARCHAR(220) NOT NULL,
    "set_id"     INTEGER NOT NULL,
    "task_id"    INTEGER,
    "kind"       VARCHAR(20) NOT NULL,
    "stage_code" VARCHAR(40),
    "scope"      VARCHAR(10),
    "seq"        INTEGER,
    "issued_at"  DATE,
    "issued_by"  VARCHAR(120),
    "note"       TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_work_orders_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "production_work_orders_code_key" ON "production_work_orders"("code");
CREATE UNIQUE INDEX IF NOT EXISTS "production_work_orders_task_id_key" ON "production_work_orders"("task_id");
CREATE INDEX IF NOT EXISTS "production_work_orders_set_id_kind_idx" ON "production_work_orders"("set_id", "kind");
CREATE INDEX IF NOT EXISTS "production_work_orders_kind_idx" ON "production_work_orders"("kind");
CREATE INDEX IF NOT EXISTS "production_work_orders_stage_code_idx" ON "production_work_orders"("stage_code");
CREATE UNIQUE INDEX IF NOT EXISTS "production_work_orders_set_id_kind_key"
    ON "production_work_orders"("set_id", "kind")
    WHERE "kind" <> 'CONG_DOAN';

DO $v142$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'production_work_orders_set_id_fkey') THEN
        ALTER TABLE "production_work_orders"
            ADD CONSTRAINT "production_work_orders_set_id_fkey"
            FOREIGN KEY ("set_id") REFERENCES "production_sets"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'production_work_orders_task_id_fkey') THEN
        ALTER TABLE "production_work_orders"
            ADD CONSTRAINT "production_work_orders_task_id_fkey"
            FOREIGN KEY ("task_id") REFERENCES "production_tasks"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
END $v142$;

-- ----------------------------------------------------------------------------
-- 2) LỆNH CHA cho các bộ đã có
-- ----------------------------------------------------------------------------
INSERT INTO "production_work_orders" ("code", "set_id", "kind", "seq", "created_at", "updated_at")
SELECT left(btrim(regexp_replace(regexp_replace(upper(
           CASE WHEN nullif(btrim(coalesce(s."order_code", '')), '') IS NULL
                THEN 'LSX-' || s."id"::text || '-00B'
                ELSE 'LSX-' || btrim(s."order_code") || '-'
                     || coalesce(nullif(btrim(coalesce(s."set_no", '')), ''), s."id"::text) || '-00B'
           END), '[^A-Z0-9_./-]', '', 'g'), '-{2,}', '-', 'g'), '-'), 220) AS "code",
       s."id", 'BO', NULL, now(), now()
FROM "production_sets" s
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 3) LỆNH CON (CÁNH / KHUNG / PHÀO) cho các bộ đã có
-- ----------------------------------------------------------------------------
INSERT INTO "production_work_orders" ("code", "set_id", "kind", "seq", "created_at", "updated_at")
SELECT left(btrim(regexp_replace(regexp_replace(upper(
           CASE WHEN nullif(btrim(coalesce(s."order_code", '')), '') IS NULL
                THEN 'LSX-' || s."id"::text || '-00' || co."short"
                ELSE 'LSX-' || btrim(s."order_code") || '-'
                     || coalesce(nullif(btrim(coalesce(s."set_no", '')), ''), s."id"::text)
                     || '-00' || co."short"
           END), '[^A-Z0-9_./-]', '', 'g'), '-{2,}', '-', 'g'), '-'), 220) AS "code",
       s."id", co."kind", NULL, now(), now()
FROM (
    SELECT o."set_id", o."kind",
           CASE o."kind" WHEN 'CANH' THEN 'C' WHEN 'KHUNG' THEN 'K' WHEN 'PHAO' THEN 'P' ELSE 'X' END AS "short"
    FROM "production_component_orders" o
) co
JOIN "production_sets" s ON s."id" = co."set_id"
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 4) LỆNH CHO TỪNG CÔNG ĐOẠN của các bộ đã có
--    Xếp hạng theo TỪNG BỘ, tính cả các mã đã có của bộ → hậu tố -2, -3… giống hệt app.
-- ----------------------------------------------------------------------------
INSERT INTO "production_work_orders" ("code", "set_id", "task_id", "kind", "stage_code", "scope", "seq", "created_at", "updated_at")
SELECT r."code", r."set_id", r."task_id", 'CONG_DOAN', r."stage_code", r."scope", r."seq", now(), now()
FROM (
    SELECT u."set_id", u."task_id", u."stage_code", u."scope", u."seq",
           CASE WHEN u."rn" = 1 THEN u."base"
                ELSE left(u."base", 220 - length('-' || u."rn"::text)) || '-' || u."rn"::text
           END AS "code"
    FROM (
        SELECT b."set_id", b."task_id", b."stage_code", b."scope", b."seq", b."base",
               row_number() OVER (
                   PARTITION BY b."set_id", b."base"
                   ORDER BY b."is_reserved", b."seq", b."scope", b."task_id"
               ) AS "rn"
        FROM (
            SELECT w."set_id", NULL::int AS "task_id", w."stage_code", w."scope", w."seq",
                   w."code" AS "base", 0 AS "is_reserved"
            FROM "production_work_orders" w
            UNION ALL
            SELECT t."set_id", t."id" AS "task_id", t."stage_code", t."scope", t."seq",
                   left(btrim(regexp_replace(regexp_replace(upper(
                       CASE WHEN nullif(btrim(coalesce(s."order_code", '')), '') IS NULL
                            THEN 'LSX-' || s."id"::text || '-' || lpad(t."seq"::text, 2, '0') || t."short"
                            ELSE 'LSX-' || btrim(s."order_code") || '-'
                                 || coalesce(nullif(btrim(coalesce(s."set_no", '')), ''), s."id"::text)
                                 || '-' || lpad(t."seq"::text, 2, '0') || t."short"
                       END), '[^A-Z0-9_./-]', '', 'g'), '-{2,}', '-', 'g'), '-'), 220) AS "base",
                   1 AS "is_reserved"
            FROM (
                SELECT k."set_id", k."id", k."stage_code", k."scope", k."seq",
                       CASE upper(btrim(coalesce(k."scope", '')))
                         WHEN 'CANH' THEN 'C' WHEN 'KHUNG' THEN 'K' WHEN 'PHAO' THEN 'P' WHEN 'BO' THEN 'B'
                         ELSE 'X'
                       END AS "short"
                FROM "production_tasks" k
                WHERE NOT EXISTS (SELECT 1 FROM "production_work_orders" w2 WHERE w2."task_id" = k."id")
            ) t
            JOIN "production_sets" s ON s."id" = t."set_id"
        ) b
    ) u
    WHERE u."task_id" IS NOT NULL
) r
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 5) KIỂM TRA — BÁO LỖI TO nếu có bộ thiếu lệnh (không để im lặng)
-- ----------------------------------------------------------------------------
DO $v142_check$ DECLARE thieu integer; BEGIN
    SELECT count(*) INTO thieu
    FROM "production_sets" s
    WHERE (SELECT count(*) FROM "production_work_orders" w WHERE w."set_id" = s."id")
        < 4 + (SELECT count(*) FROM "production_tasks" t WHERE t."set_id" = s."id");
    IF thieu > 0 THEN
        RAISE EXCEPTION 'V142: % bộ THIẾU lệnh sản xuất (cần 4 lệnh cố định + 1 lệnh mỗi công đoạn). Kiem tra Bo so trung trong cung don, hoac mo bo do bam "Sinh lai".', thieu;
    END IF;
END $v142_check$;

-- ----------------------------------------------------------------------------
-- 6) KIỂM TRA NHANH
--    SELECT "kind", count(*) FROM production_work_orders GROUP BY "kind";
--    SELECT (SELECT count(*) FROM production_sets) * 4
--         + (SELECT count(*) FROM production_tasks) AS ky_vong,
--           (SELECT count(*) FROM production_work_orders) AS thuc_te;   -- 2 số phải bằng nhau
--    SELECT "code","kind","stage_code" FROM production_work_orders
--      WHERE "set_id" = (SELECT max("id") FROM production_sets) ORDER BY "id";
--
-- 7) ĐỔI MẪU MÃ LỆNH (chỉ khi đã sửa "Mẫu mã lệnh" trong Cấu hình sản xuất)
--    File này sinh mã theo MẪU MẶC ĐỊNH. Muốn đổi mã cho TOÀN BỘ về sau:
--      a) Bỏ dấu -- ở câu dưới để xoá hết lệnh cũ rồi chạy lại MỤC 2 → 3 → 4 (vẫn ra mã MẶC ĐỊNH);
--      b) Muốn theo mẫu trong Cấu hình thì phải sinh bằng APP (mở bộ → "Sinh lại"),
--         vì SQL không đọc được mẫu token trong system_settings.
--    ⚠️ action=rebuild XOÁ và SINH LẠI công đoạn (mất tiến độ đã ghi) — chỉ dùng khi danh mục đổi.
-- DELETE FROM "production_work_orders";
--
-- 8) SAU KHI NẠP DỮ LIỆU MÔ PHỎNG (sim-500 / sim-1000): chạy lại MỤC 2 → 3 → 4 → 5.
--    (Dữ liệu mô phỏng ghi thẳng production_sets / production_tasks nên không qua luồng sinh lệnh của app.)
-- ----------------------------------------------------------------------------
