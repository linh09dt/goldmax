# ERP V42 – KH/Lượng tự động

## Logic đã chốt
- Dòng **Nhóm cửa**: `KH/Lượng = (Cao × Rộng) / 1.000.000`.
- Dòng **Phào / Phao**: `KH/Lượng = (Cao × 2 + Rộng) / 1.000`.
- Dòng **Ô thoáng**: lấy số lượng từ `Ô thoáng` của Bộ cửa: `3TK → 3`, `2TK → 2`, `1TK → 1`.
- Dòng **Khóa**: `KH/Lượng = SL bộ` của Bộ cửa cha.
- Các nhóm phụ kiện / chi tiết khác: **KH/Lượng nhập tay**.

## Hành vi UI
- KH/Lượng của Bộ cửa luôn là ô tự tính, chỉ đọc.
- KH/Lượng của Phào / Ô thoáng / Khóa tự tính và chỉ đọc.
- Các nhóm khác vẫn cho nhập KH/Lượng thủ công.
- Khi Cao/Rộng, Ô thoáng hoặc SL bộ thay đổi, KH/Lượng liên quan được tính lại ngay.
- Thành tiền của dòng tự tính sẽ dùng lại `KH/Lượng × Đơn giá` sau khi giá trị tự tính thay đổi.

## Phạm vi
- Không đổi database/schema.
- Không đổi API đơn hàng.
- Không đổi logic các nhóm khác.
- Import Excel nghiêm ngặt vẫn giữ snapshot lúc vừa import; công thức mới áp dụng khi người dùng tiếp tục chỉnh sửa trên form.
