-- ============================================================================
-- V139.1 — NĂNG LỰC CHIA THEO CÔNG ĐOẠN
--
-- Trước đây năng lực chỉ khai ở TỔ (`production_work_centers.capacity_per_day`).
-- Cột `production_stages.capacity_per_day` đã có từ V136 nhưng chưa dùng và chưa sửa
-- được trên màn Cấu hình. Từ V139.1:
--   • Khai được NĂNG LỰC/NGÀY riêng cho từng công đoạn (Cắt cánh, Chấn khung, Hàn phào…).
--   • Để TRỐNG = kế thừa năng lực tổ (giữ nguyên hành vi cũ).
--   • Xếp lịch và bảng tải đều dùng: công đoạn khai riêng thì lấy số công đoạn,
--     công đoạn để trống thì lấy số tổ.
--
-- ⚠️ KHÔNG có thay đổi cột/bảng ⇒ KHÔNG cần `prisma migrate`.
--    Nên chạy SAU khi deploy code V139.1 (code cũ bỏ qua cột này — vô hại, nên
--    thực ra chạy trước cũng được; chạy lại vô hại).
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- Chấn: khảo sát nói 30 cánh/ca (CH7), tổ máy chạy 2 ca → 60 cánh/ngày (TM3).
-- Ghi đúng bằng năng lực tổ để KHÔNG làm hụt năng lực so với trước; nếu xưởng chỉ
-- chạy 1 ca thì sửa lại thành 30 ngay trên màn Cấu hình sản xuất.
-- ----------------------------------------------------------------------------
UPDATE "production_stages"
SET "capacity_per_day" = 60,
    "capacity_unit"    = 'CANH',
    "note"             = "note" || ' [V139.1] Năng lực công đoạn: 60 cánh/ngày = 30 cánh/ca × 2 ca (CH7/TM3); chạy 1 ca thì sửa thành 30.',
    "updated_at"       = now()
WHERE "code" IN ('CHAN_CANH', 'CHAN_KHUNG', 'CHAN_PHAO')
  AND ("capacity_per_day" IS DISTINCT FROM 60 OR "capacity_unit" IS DISTINCT FROM 'CANH');

-- Các công đoạn tách phần còn lại (Cắt / Hàn / Vân) để TRỐNG = kế thừa năng lực tổ.
-- Ghi chú lại cách hiểu để người dùng biết chỗ sửa.
UPDATE "production_stages"
SET "note"       = "note" || ' [V139.1] Năng lực để trống = kế thừa năng lực tổ; muốn tách riêng thì nhập Năng lực/ngày ở Cấu hình sản xuất.',
    "updated_at" = now()
WHERE "code" IN (
        'CAT_CANH', 'CAT_KHUNG', 'CAT_PHAO',
        'HAN_CANH', 'HAN_KHUNG', 'HAN_PHAO',
        'VAN_CANH', 'VAN_KHUNG', 'VAN_PHAO'
      )
  AND "note" NOT LIKE '%[V139.1]%';

COMMIT;

-- ----------------------------------------------------------------------------
-- Kiểm tra sau khi chạy (không bắt buộc):
--   SELECT code, name, work_center_code, capacity_per_day, capacity_unit
--     FROM production_stages
--    WHERE seq IN (30,40,50,90) ORDER BY seq, code;
--   -- CHAN_* = 60/CANH; CAT_*/HAN_*/VAN_* = NULL (theo tổ)
-- ----------------------------------------------------------------------------
