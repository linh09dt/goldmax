# V113 — Tab Tổng quan (dashboard báo cáo bán hàng)

## 1. Mục tiêu & nguyên tắc thiết kế

Tab **`/` (Tổng quan)** trước đây chỉ có 2 nút, chưa có số liệu. Bản này dựng lại thành **dashboard báo cáo bán hàng** theo 4 nguyên tắc:

1. **Bám đúng nghiệp vụ V112** — doanh thu chỉ tính **đơn loại "Sản xuất" ở trạng thái "Đã xác nhận"**; đơn hàng mẫu / đơn làm lại / đơn nháp vẫn được theo dõi khối lượng nhưng tách khỏi doanh thu.
2. **Trả lời được câu hỏi điều hành hằng ngày**: hôm nay/tháng này bán được bao nhiêu, còn phải thu bao nhiêu, đơn nào sắp tới hạn hoặc đã quá hạn, đại lý/NVKD nào dẫn đầu.
3. **Tận dụng dữ liệu đang có** — không thêm bảng, không thêm migration, không thêm thư viện biểu đồ (SVG/CSS thuần để app nhẹ và không phình bundle).
4. **Ít lượt truy vấn DB** — DB production ở xa (~40–100 ms/lượt, xem V111) nên cả trang chỉ dùng **3 truy vấn**.

## 2. Đã làm gì (chạy được ngay)

```
┌─ Bộ lọc ────────────────────────────────────────────────────────────────────────┐
│ Hôm nay · Tuần này · Tháng này · Quý này · Năm nay · Tất cả   [Từ] [Đến]        │
│ [Đại lý ▾] [Loại đơn ▾] [Trạng thái ▾]  (Lọc) (Xoá lọc)  (Mở trong Quản lý đơn) │
├─ 6 thẻ KPI ─────────────────────────────────────────────────────────────────────┤
│ Doanh thu │ Đơn đã xác nhận │ Đơn nháp cần xử lý │ Còn phải thu │ Quá hạn │ Sản lượng │
├───────────────────────────────────┬─────────────────────────────────────────────┤
│ Doanh thu theo tháng (12 tháng)   │ Cơ cấu theo LOẠI ĐƠN                        │
│ cột doanh thu + đường số đơn      │ Theo TRẠNG THÁI                             │
├───────────────────────────────────┴─────────────────────────────────────────────┤
│ Top đại lý            │ Top NVKD             │ Top sản phẩm / Model              │
├─────────────────────────────────────────────────────────────────────────────────┤
│ Đơn cần chú ý: quá hạn · đến hạn 7 ngày · nháp để lâu                           │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Công thức từng chỉ số (đã cài trong `src/lib/dashboard.ts`)

| Chỉ số | Cách tính |
|---|---|
| **Doanh thu** | Σ `total_after_discount` của đơn `order_type='SAN_XUAT'` + `status='DA_XAC_NHAN'`; có % so với **kỳ trước liền kề** (cùng độ dài) |
| **Đơn đã xác nhận** | số đơn đã xác nhận (mọi loại) · kèm số **bộ cửa** (số dòng hàng có KH/Lượng) và **tỉ lệ xác nhận** = đã xác nhận / tổng đơn trong kỳ |
| **Đơn nháp cần xử lý** | số đơn chưa xác nhận + giá trị tạm tính (tổng sau CK) — nói rõ "chưa có Bộ số" |
| **Còn phải thu** | Σ `delivery_payment` của đơn Sản xuất đã xác nhận |
| **Đơn quá hạn giao** | đơn **đã xác nhận** có `required_delivery_date` < hôm nay |
| **Sản lượng** | Σ KH/Lượng (`pricing_quantity`) của dòng hàng + dòng chi tiết/phụ kiện (m²) |
| **Giá trị đơn trung bình** | doanh thu / số đơn có doanh thu |
| **Cơ cấu loại đơn / trạng thái** | số đơn + **giá trị đơn** của cả 2 trạng thái (không phải doanh thu) — ghi chú ngay trên thẻ để khỏi hiểu nhầm |
| **Top đại lý / NVKD / sản phẩm** | xếp theo doanh thu đơn Sản xuất đã xác nhận; kèm số dòng hàng + KH/Lượng |
| **Đơn cần chú ý** | ưu tiên đỏ: quá hạn · vàng: đến hạn trong 7 ngày · nháp tạo > 7 ngày chưa xác nhận (tính theo `created_at`) |

### Bộ lọc

Dùng lại `resolveDatePreset` + `parseDealerFilter` của màn Quản lý đơn hàng nên hai nơi lọc giống nhau. Có nút **"Mở trong Quản lý đơn hàng"** mang theo khoảng ngày + đại lý đang xem để tra chi tiết.

## 3. Kỹ thuật

- `src/app/page.tsx` — server component, chỉ **3 truy vấn**: (1) kỳ đang xem **gộp cả kỳ trước** trong một lần lấy rồi tách bằng JS, (2) 12 tháng cho biểu đồ, (3) danh sách đại lý cho bộ lọc.
- `src/lib/dashboard.ts` — toàn bộ tính toán là **hàm thuần** (`buildDashboard`), không truy vấn DB → dễ kiểm thử và tái dùng cho xuất Excel sau này.
- `src/components/dashboard/dashboard-ui.tsx` — chỉ hiển thị: thẻ KPI, biểu đồ SVG, thanh xếp hạng, bảng đơn cần chú ý.
- Không thêm dependency; không đổi schema/DB; không đụng các màn khác.

## 4. Kiểm chứng (chạy thật trên Postgres 14 + dữ liệu thật trong DB test)

```
Trang / trả HTTP 200 · tsc 0 lỗi · eslint 0 lỗi · npm run build PASS
Doanh thu 2,92 tỷ · Đơn đã xác nhận 11 (465 bộ cửa, tỉ lệ xác nhận 73%)
Đơn nháp cần xử lý 4 (1,22 tỷ) · Còn phải thu 2,89 tỷ · Quá hạn 2 · Sản lượng 3.567 m²
Cơ cấu: Đơn hàng mẫu 5 đơn · 1,25 tỷ | Sản xuất 8 đơn · 2,92 tỷ | Đơn làm lại 2 đơn · 72,6 triệu
Đơn cần chú ý: 2 đơn "Quá hạn 5 ngày" + 1 đơn "Nháp 17 ngày chưa xác nhận"
Bộ lọc: ?range=month → kỳ 1/9–30/9/2026 · ?type=LAM_LAI → đúng 2 đơn Đơn làm lại
```

Ảnh: `v113-dashboard.png`.

## 5. Đề xuất giai đoạn 2 (xếp theo mức ưu tiên)

| # | Hạng mục | Vì sao đáng làm | Nguồn dữ liệu |
|---|---|---|---|
| 1 | **Công nợ theo đại lý + tuổi nợ** (0–30 / 31–60 / 61–90 / >90 ngày) | Đại lý là kênh chính; cần biết ai đang nợ bao lâu | `sales_orders` (total_after_discount, deposit, delivery_payment, order_date) — có thể tính ngay, chưa cần bảng mới |
| 2 | **Đơn quá hạn / đến hạn theo tuần** (bảng tải sản xuất 8 tuần tới: số bộ cửa cần giao mỗi tuần) | Điều độ xưởng, tránh dồn cuối tháng | `required_delivery_date` + số dòng hàng |
| 3 | **Báo cáo theo nhóm cửa / model** (dùng `item_master`: tên hàng, nhóm cửa) và theo **vùng miền** | Biết mặt hàng nào bán chạy, miền nào mạnh | `sales_order_items` + `item_master` (đã có bảng danh mục) |
| 4 | **So sánh cùng kỳ năm trước + mục tiêu doanh thu tháng/năm** | Đánh giá tăng trưởng thật, không chỉ nhìn số tuyệt đối | Doanh thu hiện có + 1 bảng/1 setting cho mục tiêu (`system_settings` có sẵn) |
| 5 | **Chất lượng đơn: tỉ lệ hủy, số đơn làm lại, đơn thiếu ảnh SP / thiếu KH-Lượng** | Kiểm soát lỗi nhập liệu và chi phí làm lại | `sales_orders`, `sales_order_items`, `image_path` |
| 6 | **Xuất Excel/PDF báo cáo tổng quan** (dùng lại `buildDashboard`) + **gửi định kỳ** (email/Telegram mỗi sáng/tuần) | Báo cáo cho ban giám đốc không cần mở app | Hàm thuần đã tách sẵn |
| 7 | **Phân quyền theo NVKD** (mỗi NVKD chỉ thấy số của mình) | Nhạy cảm dữ liệu bán hàng | Cần bổ sung đăng nhập/phân quyền |

Ghi chú kỹ thuật cho giai đoạn 2:
- Nếu số đơn lớn dần: chuyển phần tổng hợp sang `groupBy`/SQL tổng hợp hoặc thêm **bảng tổng hợp theo ngày** (`daily_sales_summary`) để dashboard không phải quét toàn bộ đơn.
- Thêm **cache 60 giây** cho dashboard (dữ liệu bán hàng không cần tức thời) và skeleton khi tải.
- Khi làm công nợ: nên có thêm **phiếu thu/chi** thay vì chỉ suy ra từ đơn hàng (hiện chỉ có `deposit_amount`).

## 6. Ba điểm mình cần bạn chốt

1. **Doanh thu có tính "Đơn làm lại" không?** Hiện KHÔNG (chỉ Sản xuất) — nếu đơn làm lại vẫn thu tiền thì nên cộng vào hoặc tách một dòng riêng.
2. **"Quá hạn" tính theo đơn đã xác nhận** (đang làm vậy) hay tính cả đơn nháp?
3. **Ưu tiên giai đoạn 2**: mình đề xuất làm **#1 công nợ theo đại lý** và **#2 tải sản xuất theo tuần** trước — đúng hai việc sếp hay hỏi nhất. Bạn muốn thứ tự khác thì nói.

## 7. File thay đổi

- `src/app/page.tsx` — **viết lại**: dashboard + bộ lọc + 3 truy vấn.
- `src/lib/dashboard.ts` — **mới**: toàn bộ công thức tính chỉ số (hàm thuần).
- `src/components/dashboard/dashboard-ui.tsx` — **mới**: thẻ KPI, biểu đồ SVG, thanh xếp hạng, bảng đơn cần chú ý.
