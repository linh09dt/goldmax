# ERP V20 — Đơn hàng động theo Master Data

## Logic đã chốt

### 1. Dòng đầu tiên của mỗi Bộ cửa

- Không còn mặc định Cửa đi/Cửa sổ bằng mẫu cứng.
- Cột **Loại cửa / Nhóm hàng** lấy từ `TENHANG` trong Danh mục hàng hóa.
- Các TENHANG được xem là loại cửa khi TENHANG bắt đầu bằng `Cửa`.
- Sau khi chọn Loại cửa, hai cột **Tên sản phẩm diễn giải** và **MODEL danh mục** chỉ hiển thị các MODEL thuộc đúng TENHANG đó.
- Có thể chọn bằng Tên sản phẩm diễn giải hoặc MODEL; hai trường được đồng bộ cùng một hàng hóa Master.
- Khi chọn hàng hóa, hệ thống tiếp tục lấy ĐVT và giá theo logic Master Data V15 hiện tại.

Ví dụ:

`Cửa Đi 4 Cánh` → chỉ đề xuất các MODEL thuộc `Cửa Đi 4 Cánh`.

### 2. Hàng hóa kèm theo

- Bỏ toàn bộ các dòng điền cứng cũ: Phào Rời, LUX200, Khóa, Khoét Pano, Khoét kính, Khác...
- Khi tạo Bộ cửa mới, `details = []`.
- Nút **+ Hàng hóa kèm theo** thêm đúng 1 dòng trống mỗi lần.
- Tất cả hàng hóa Master Data **không phải cửa** được xem là hàng hóa kèm theo.
- Dòng hàng kèm chọn theo 2 bước:
  1. Chọn nhóm `TENHANG` (KHÓA, Ô Thoáng, Phao Rời, Phao Biệt Thự, Gia Công Ô Kính...)
  2. Chọn Tên sản phẩm diễn giải / MODEL trong đúng nhóm đó.

### 3. Đơn cũ

- Không xóa hoặc thay đổi snapshot của đơn hàng đã lưu.
- Khi sửa đơn cũ, các dòng chi tiết đã tồn tại vẫn được hiển thị.
- Logic không điền cứng chỉ áp dụng cho Bộ cửa/hàng kèm được tạo mới.

## Database

Không thay đổi schema và không cần migrate.

## Cập nhật

Chép patch chồng lên V19, sau đó:

```cmd
rmdir /s /q .next
npm run dev -- --webpack
```
