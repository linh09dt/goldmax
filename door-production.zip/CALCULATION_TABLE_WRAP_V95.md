# V95 — Bảng rule: full view không kéo ngang, chữ tự xuống dòng

## Yêu cầu

> “mình muốn fullview không kéo ngang, có thể xuống dòng để hiện đầy đủ thông tin”

## Nguyên nhân

Ô chọn trong bảng rule là thẻ `<select>` gốc của trình duyệt. **`<select>` chỉ hiển thị nhãn trên MỘT dòng**, không thể xuống dòng → khi cột hẹp thì buộc phải cắt chữ (“Khuôn biệt thự…”, “PR - Phào mặt t…”) hoặc phải kéo ngang (cách làm ở V94). Muốn “không kéo ngang” **và** “đủ chữ” thì phải thay `<select>` bằng ô chọn tự viết có nhãn xuống dòng.

## Cách làm

### 1. Thêm ô chọn nhãn xuống dòng — `WrapSelect` (trong `src/components/settings/settings-ui.tsx`)

- Dựng bằng `<button>` + danh sách lựa chọn (không dùng `<select>`), nhãn hiển thị với `whitespace-normal break-words` nên **tự xuống 2–3 dòng** khi cột hẹp.
- Danh sách mở ra hiển thị nhãn đầy đủ (cho phép xuống dòng, rộng tối đa 340px, cao tối đa 256px, tự cuộn).
- Tự **mở lên trên** khi ô nằm gần đáy màn hình; đóng khi bấm ra ngoài, khi bấm `Esc`, hoặc sau khi chọn.
- Giữ nguyên hành vi cũ: `title` = nhãn đang chọn (V85) để rê chuột vẫn xem đủ.

### 2. Thay toàn bộ ô chọn trong bảng rule

Áp dụng cho 8 loại ô: **Áp dụng cho · Nhóm hàng · Model / hàng hóa · Bộ cửa chính (nhóm) · Bộ cửa chính (model) · Cách tính KH/Lượng · Đề xuất Cao · Đề xuất Rộng** (hàm `RuleSelect` cũ giờ chỉ bọc `WrapSelect`, nên 3 ô cách tính/đề xuất không phải sửa chỗ gọi). Ô nhập Ghi chú vẫn là textarea (vốn đã xuống dòng), ô chọn số chữ số thập phân ở thẻ “Làm tròn KH/Lượng” vẫn là `<select>` thường vì nằm trong thẻ rộng rãi.

### 3. Bảng quay lại fit khung

Bỏ `min-w-[1660px]` và bề rộng px của V94, đưa cột về **%** (tổng đúng 100%): Áp dụng cho 11 · Nhóm hàng 10 · Model 12 · Bộ cửa chính 12 · Cách tính KH/Lượng 15 · Đề xuất Cao 11 · Đề xuất Rộng 11 · Ghi chú 11 · Dùng 3 · Xóa 4. Bảng **không còn kéo ngang**; thông tin đủ nhờ nhãn xuống dòng.

## Kiểm chứng

**a) Render thật component (React SSR) — 14/14 case đúng:**

| Kiểm tra | Kết quả |
|---|---|
| Không còn `min-w-[1660px]` (không kéo ngang) | ✓ |
| Cột chia % và **tổng = 100%** | ✓ `[11,10,12,12,15,11,11,11,3,4]` |
| Bảng rule **không còn `<select>`** (chỉ còn 1 select ở thẻ Làm tròn) | ✓ |
| Nhãn ô chọn có `whitespace-normal break-words` (xuống dòng) | ✓ |
| 22 ô chọn kiểu mới render ra | ✓ |
| Nội dung quan trọng còn đủ (công thức, Nhập tay / giữ nguyên, 2 khu vực, …) | ✓ |

**b) Test tương tác thật bằng jsdom + React (bấm chuột) — 6/6 case đúng:** ô “Áp dụng cho” ban đầu hiện “Bộ cửa chính” → bấm mở ra 2 lựa chọn → chọn “Theo nhóm hàng” → nhãn đổi đúng, danh sách tự đóng, và ô “Chọn nhóm hàng” xuất hiện (rule chuyển phạm vi đúng như trước).

- `npx tsc --noEmit` → 0 lỗi.
- `npx eslint` 2 file sửa → **1 error / 0 warning, đúng bằng bản gốc**, không phát sinh lỗi mới.

## Lưu ý

- **V95 thay cách làm của V94 (mục 3)**: V94 chọn “bề rộng px + kéo ngang”, V95 chọn “fit khung + nhãn xuống dòng”. Prop `className` của `SettingsTable` vẫn được giữ lại để bảng khác dùng khi cần bề rộng tối thiểu.
- Bảng dài: danh sách chọn nằm trong khung cuộn của bảng nên ở dòng sát đáy khung, danh sách sẽ mở **lên trên**; nếu khung bị cuộn, danh sách có thể cần cuộn theo — nếu bạn thấy vướng khi dùng thật, mình chuyển sang kiểu “portal” nổi hẳn lên trên (không bị khung cắt).
- Hai thao tác như trước vẫn giữ: bấm ra ngoài hoặc `Esc` để đóng danh sách.

## File thay đổi

- `src/components/settings/settings-ui.tsx` — thêm `WrapSelect` (ô chọn nhãn xuống dòng).
- `src/components/calculation-config.tsx` — thay 8 loại ô chọn trong bảng rule, cột quay lại %, bỏ bề rộng tối thiểu.
