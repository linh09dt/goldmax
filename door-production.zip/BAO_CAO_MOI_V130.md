# V130 — Nhóm báo cáo dựng từ dữ liệu hiện có + Drill-down + Tìm kiếm toàn cục

Yêu cầu: *"làm tất cả những gì đã có trong dữ liệu thật rồi, còn lại giá vốn, khách hàng chưa cần"*.
Vì vậy V130 **chỉ dùng dữ liệu đang có sẵn trong database**, không thêm dữ liệu mới (không giá vốn, không bảng khách hàng, không phiếu thu, không ngày giao thực tế).

## 1. Đã làm gì

| # | Hạng mục | Đường dẫn |
|---|---|---|
| 1 | **6 trang báo cáo mới** + trung tâm báo cáo | `/reports`, `/reports/orders`, `/reports/products`, `/reports/sales-performance`, `/reports/receivables`, `/reports/production-load` |
| 2 | **Xuất Excel dùng chung** cho cả 5 báo cáo, giữ đúng bộ lọc đang xem | `/api/reports/<type>/export` |
| 3 | **Drill-down**: KPI và xếp hạng trên Dashboard bấm ra danh sách đã lọc | `src/app/page.tsx`, `src/components/dashboard/dashboard-ui.tsx` |
| 4 | **So cùng kỳ năm trước** (+ % tăng trưởng) trên Dashboard | `src/lib/dashboard.ts`, `src/app/page.tsx` |
| 5 | **Tìm kiếm toàn cục Ctrl+K** (đơn / khách hàng / hàng hóa / mã đại lý) | `src/components/global-search.tsx`, `src/app/api/search/route.ts`, `src/lib/search.ts` |
| 6 | **Bộ lọc mới**: trạng thái (nháp/đã xác nhận), nhân viên Sales, vùng miền | `src/lib/order-list-filters.ts` |
| 7 | **Sửa lỗi**: ô "Xuất Excel danh sách đơn" chưa đọc tham số lọc mới | `src/app/api/orders/export-list/route.ts` |
| 8 | **Menu BÁO CÁO** + index phục vụ báo cáo | `src/components/erp-nav.tsx`, migration V130 |

## 2. Nội dung từng báo cáo

- **Trung tâm báo cáo `/reports`** — điểm vào cho tất cả báo cáo, ghi rõ nguồn dữ liệu từng báo cáo.
- **Báo cáo Đơn hàng `/reports/orders`** — tổng đơn, tỉ lệ xác nhận, đơn nháp, quá hạn, giá trị đơn; biểu đồ đơn theo tháng; cơ cấu loại đơn / trạng thái / **vùng miền**; bảng đơn chi tiết.
- **Báo cáo Sản phẩm `/reports/products`** — top sản phẩm bán chạy, doanh thu theo sản phẩm (nối `sales_order_items` ↔ `item_masters`), số bộ, SL, KH/Lượng, **đơn giá TB / thấp nhất / cao nhất**, danh sách sản phẩm chưa phát sinh doanh thu.
- **Báo cáo Nhân viên Sales `/reports/sales-performance`** — theo `sales_employee_code`: số đơn, đã xác nhận, nháp, số bộ, doanh thu, đã thu, còn phải thu, giá trị đơn TB, tỉ lệ xác nhận, quá hạn.
- **Báo cáo Công nợ `/reports/receivables`** — còn phải thu theo khách/đại lý + **tuổi nợ** (chưa đến hạn · 1–7 · 8–30 · 31–60 · >60 ngày) theo hạn giao, có mức cảnh báo màu.
- **Tải sản xuất theo tuần `/reports/production-load`** — khối lượng bộ cửa phải giao theo tuần (tuần này + 7 tuần tới), danh sách đơn **quá hạn**, phân bổ vùng miền.

Tất cả giữ đúng nghiệp vụ V112: **doanh thu chỉ tính đơn loại `SAN_XUAT` ở trạng thái `DA_XAC_NHAN`**; đơn mẫu / làm lại / nháp vẫn được thống kê khối lượng nhưng không vào doanh thu.

## 3. File thay đổi

**Mới:**
```
prisma/migrations/20260926120000_report_indexes/migration.sql
src/lib/reporting.ts                 (toàn bộ công thức báo cáo — hàm thuần)
src/lib/report-data.ts               (nạp dữ liệu + bộ lọc dùng chung)
src/lib/search.ts                    (tìm kiếm toàn cục)
src/components/reports/report-ui.tsx (KPI, card, filter bar, bar list)
src/components/global-search.tsx     (ô tìm kiếm Ctrl+K)
src/app/reports/page.tsx
src/app/reports/orders/page.tsx
src/app/reports/products/page.tsx
src/app/reports/sales-performance/page.tsx
src/app/reports/receivables/page.tsx
src/app/reports/production-load/page.tsx
src/app/api/reports/[type]/export/route.ts
src/app/api/search/route.ts
```

**Sửa:**
```
prisma/schema.prisma                     (+4 index sales_orders, +1 index sales_order_items)
src/lib/order-list-filters.ts            (+ lọc state / sales / region)
src/lib/dashboard.ts                     (+ doanh thu cùng kỳ năm trước)
src/app/page.tsx                         (drill-down, YoY, mở rộng khoảng truy vấn)
src/components/dashboard/dashboard-ui.tsx(KpiCard có link, RankCard có link)
src/components/erp-nav.tsx               (+ nhóm BÁO CÁO)
src/components/erp-shell.tsx             (gắn ô tìm kiếm toàn cục)
src/app/api/orders/export-list/route.ts  (đọc đủ tham số lọc)
```

## 4. Migration & triển khai

Migration mới **idempotent**, chạy an toàn trên DB đã có dữ liệu:

```sql
CREATE INDEX IF NOT EXISTS "sales_orders_order_date_idx" ...
CREATE INDEX IF NOT EXISTS "sales_orders_created_at_idx" ...
CREATE INDEX IF NOT EXISTS "sales_orders_sales_employee_code_idx" ...
CREATE INDEX IF NOT EXISTS "sales_orders_region_idx" ...
CREATE INDEX IF NOT EXISTS "sales_order_items_model_idx" ...
```

Thứ tự deploy như các bản trước (DB trước, code sau):
```bash
npx prisma migrate deploy     # hoặc dán nội dung migration vào Supabase SQL Editor
```
Không thêm biến môi trường, không đổi API cũ, không đổi dữ liệu hiện có.

## 5. Kiểm chứng (chạy thật, không đoán)

- `npx tsc --noEmit` → **0 lỗi**; `npx eslint` (các file V130) → **0 lỗi/warning**.
- `npx next build` → **PASS**; `next start` chạy production, **tất cả 14 trang cũ + 6 trang mới trả HTTP 200**.
- Cả 5 endpoint `/api/reports/<type>/export` trả file `.xlsx` hợp lệ.
- Kiểm tra bằng dữ liệu thật (6 đơn / 20 bộ cửa / 92 mã hàng nạp từ `door_production.backup`):
  - Báo cáo Sản phẩm ra đúng model `GM1`, `CS3`, "Cửa Sổ"; 24 dòng gắn nhãn "(chưa có trong danh mục)" đúng với các mã chưa khai báo.
  - Báo cáo Sales ra đúng `NV01`, `NV02`, `NV03`.
  - Công nợ: tổng còn phải thu **115,4 triệu**, có đủ nhóm "Chưa đến hạn / 1–7 / 8–30 ngày".
  - Drill-down: link `/orders?...type=san_xuat&state=da_xac_nhan`, `state=nhap`, `/reports/receivables`, `/reports/production-load` xuất hiện đúng.
  - **So cùng kỳ năm trước**: thêm 1 đơn test 2025 → Dashboard hiện `cùng kỳ năm trước +58.4%` (đúng 158,38/100 − 1); với kỳ không có dữ liệu năm trước thì hiện "chưa có kỳ trước" — chứng minh khoảng lọc kỳ trước **không** bị lẫn đơn năm trước.
  - Tìm kiếm `?q=GM1` trả danh sách model GM1; `?q=26092201` trả đơn `26092201LĐ01DH04` + khách "Anh Lân".

## 6. Chưa làm (đã loại theo yêu cầu)

Giá vốn / báo cáo lợi nhuận, bảng khách hàng chuẩn, phiếu thu nhiều lần, ngày giao thực tế, đăng nhập/phân quyền, audit log, realtime, SQL view.
Các mục này cần **dữ liệu hoặc bảng mới**, không nằm trong "những gì đã có trong dữ liệu thật".

## 7. V130.1 — Thanh lọc báo cáo về đúng 1 dòng

Yêu cầu: *"các tab trong báo cáo, phần lọc các trường ô bị xuống 2 dòng, đưa tất cả lên 1 dòng bao gồm các nút lọc, xóa lọc, xuất excel"*.

Đã sửa cho **mọi thanh lọc thuộc nhóm báo cáo**:

| Trang | Thay đổi |
|---|---|
| `/revenue` (ảnh báo lỗi) | Bỏ grid 12 cột (gây xuống 2 dòng) → 1 hàng `flex-nowrap` |
| `/reports/orders` | Dùng chung `ReportFilterBar` 1 hàng |
| `/reports/products` | nt |
| `/reports/sales-performance` | nt |
| `/reports/receivables` | nt |
| `/reports/production-load` | nt |
| `/` (Tổng quan) | Bỏ `flex-wrap` → 1 hàng, Từ/Đến/Đại lý/Loại đơn/Trạng thái + nút |

Cơ chế: **toàn bộ ô lọc nằm trong một vùng cuộn ngang (1 dòng duy nhất), còn nhóm nút Lọc / Xoá lọc / Xuất Excel được ghim cố định bên phải nên luôn hiển thị** (không bị đẩy xuống dòng, không bị khuất khi màn hình hẹp). Nút "Lọc" trên Dashboard dùng thuộc tính `form="dashboard-filter"` để vẫn submit đúng form dù nằm ngoài form.

**Kiểm chứng tự động** (Chrome headless + puppeteer, đo layout thật): ở cả 3 cỡ màn hình 1600 / 1440 / 1280 px, **7/7 thanh lọc đều 1 dòng**, chiều cao thanh lọc 52–79 px (đúng 1 hàng), **3/3 nút luôn hiển thị trong khung nhìn**, và không ô nào bị cắt chữ (`scrollWidth == clientWidth`).

File sửa thêm: `src/components/reports/report-ui.tsx`, `src/app/revenue/page.tsx`, `src/app/page.tsx`.
