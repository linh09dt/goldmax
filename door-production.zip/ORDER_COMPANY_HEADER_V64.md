# ORDER COMPANY HEADER V64

## Yêu cầu
“GPĐKKD Số: … Email: Goldmaxdoor@gmail.com — Cân dòng 1 hàng dọc bằng nhau như hình”.

## Đối chiếu bản vẽ với bản xuất hiện tại (đo pixel, cùng tỉ lệ toàn trang)
| | Ảnh bạn gửi | PDF hiện tại |
|---|---|---|
| Số dòng thông tin | 6 dòng | 6 dòng |
| Lề trái các dòng | cùng 1 mốc `x = 175/1172` (14.9% trang) | cùng 1 mốc `x = 252/1684` (15.0% trang) |
| Khoảng cách giữa các dòng | ~14 px (ở 1172 px) | ~21 px (ở 1684 px) → quy đổi ≈ 20 px, tương đương |
| Mỗi thông tin | 1 hàng (không xuống hàng) | 1 hàng (không xuống hàng) |

→ Về cơ bản bản xuất **đã đúng** như hình: một cột dọc, thẳng lề trái, cách đều, mỗi dòng 1 hàng.

## Vẫn siết thêm 2 điểm cho chắc
1. **Tự co cỡ chữ thông tin công ty** (`_company_line_style`): đo bề rộng dòng dài nhất bằng `pdfmetrics.stringWidth`, nếu vượt bề rộng cột thì thu nhỏ cỡ chữ (sàn 6.4pt) → **không bao giờ có dòng bị xuống hàng** làm lệch nhịp khối, kể cả khi đổi font hoặc thêm nội dung dài.
2. **Giảm khoảng trống sau tên công ty** (Spacer `0.8mm → 0.3mm`) để nhịp giữa tên công ty và 6 dòng sát với nhịp chung của khối.

Kèm refactor nhỏ: tách `COMPANY_LINES` (danh sách 6 dòng) và `COMPANY_COL_RATIO` để dùng chung cho bảng header và hàm auto-fit.

## Lưu ý (lỗi tự phát hiện khi làm)
Lần đầu mình dựng dòng bằng `Paragraph("\n".join(...))` — reportlab **không** tự đổi `\n` thành xuống dòng nên 6 dòng bị gộp thành 1 đoạn văn. Đã sửa bằng `"<br/>".join(...)` (giống hàm `para()` sẵn có) và kiểm tra lại: đúng 6 dòng riêng biệt.

## Kiểm chứng
- `python3 python/reportlab_order_v2.py --input … --output …`: trích text ra đúng 7 dòng (tên công ty + 6 dòng thông tin), mỗi dòng riêng.
- Đo lại bản render: 6 dòng cùng lề trái `x = 252`, khoảng cách đều ~21 px ở thang 2x (trước là 30/21/21/21/23/20) → nhịp đều hơn sau khi giảm khoảng trống sau tên công ty.
- Ảnh so sánh cùng tỉ lệ: `header_compare.png`.
- `python -m py_compile`: OK.
