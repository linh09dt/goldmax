# ORDER VIEW NO CHECKLIST V56

## Mục tiêu
Tab **xem đơn hàng** (`/orders/[id]`) — bỏ box **“Câu hỏi thêm / Xác nhận”** cho khớp với form tạo/sửa đơn (đã bỏ ở V52).

## File sửa
- `src/app/orders/[id]/page.tsx`
  - Xóa card “Câu hỏi thêm / Xác nhận” (6 câu hỏi + trạng thái “Chưa xác nhận” + ghi chú).
  - Card **“Tổng hợp giá trị”** thêm `xl:col-start-2` để giữ nguyên vị trí cột phải và kích thước như trước, không bị kéo dãn.
  - Giữ nguyên `include: { requirements: ... }` trong truy vấn Prisma — dữ liệu vẫn được nạp (nếu sau này muốn hiện lại box thì chỉ cần dựng lại JSX), DB không đổi.

## Không thay đổi
- DB/Prisma, dữ liệu `sales_order_requirements` của các đơn cũ vẫn còn nguyên.
- Form tạo/sửa đơn (đã bỏ ở V52), file xuất Excel/PDF (đã bỏ checklist ở V52), bảng hàng hóa, tổng hợp giá trị, lịch sử nhập Excel.
- Trang in cũ `/orders/[id]/print` (nút PDF cũ đang ẩn) **vẫn còn bảng checklist** — chưa sửa theo phạm vi yêu cầu.

## Kiểm chứng thực tế (có DB thật)
- Dựng **PostgreSQL cục bộ** trong sandbox (pgserver), chạy `npx prisma migrate deploy` (all migrations applied), tạo đơn `TEST-VIEW-001` với **1 bộ cửa + 1 dòng phụ kiện + 6 dòng requirements** (để chắc chắn box bị bỏ chứ không phải do không có dữ liệu).
- Mở thật `/orders/2` trên `next dev`:
  - HTML và UI **không còn** “Câu hỏi thêm” và “Chưa xác nhận” (dù DB có 6 câu hỏi);
  - card “Tổng hợp giá trị” vẫn hiển thị đủ 8 dòng đúng vị trí cột phải (`left 871 → right 1248`, khung nhìn 1280);
  - bảng hàng hóa + dòng “Chi tiết / phụ kiện…” + “Lịch sử nhập Excel” vẫn nguyên.
- Gọi thật API `GET /api/orders/2/export-v2` (HTTP 200) rồi đọc lại file: khối tổng kết + “Bằng chữ” + hộp ghi chú đủ, **không có** `BẢNG CHECKLIST`.
- `npx tsc --noEmit`: pass. `npx eslint src/app/orders/[id]/page.tsx`: đúng 4 vấn đề như bản gốc (3 `no-explicit-any` + 1 cảnh báo `<img>`), không phát sinh mới.
