# V102 — Cột “Loại ĐH” ở màn Theo dõi doanh thu lấy theo trạng thái đơn

## Yêu cầu

> “tab theo dõi doanh thu, cột loại ĐH thì lấy theo trạng thái đơn hàng mẫu hoặc sản xuất, không để mặc định là sản xuất”

## Nguyên nhân

Cột “Loại ĐH” bị **ghi cứng chữ “Sản xuất”** ở 2 chỗ (không đọc trạng thái của đơn):

| Chỗ | Dòng cũ |
|---|---|
| Màn `/revenue` | `<Td className="text-center">Sản xuất</Td>` |
| File Excel `Xuất Excel` của màn doanh thu | `orderType: "Sản xuất",` |

Nên mọi đơn đều hiện “Sản xuất”, kể cả các đơn `NHAP-…` (đơn hàng mẫu) — đúng như ảnh bạn gửi.

## Đã sửa

Cả 2 chỗ nay dùng **hàm nhãn trạng thái dùng chung** `orderStatusLabel()` trong `src/lib/order-form.ts` (chính hàm màn đơn hàng đang dùng), nên tự quy đổi cả mã trạng thái cũ:

| Trạng thái trong dữ liệu | Hiện ở cột “Loại ĐH” |
|---|---|
| `NHAP` (Lưu nháp) | **Đơn hàng mẫu** |
| `CHUYEN_SAN_XUAT` (Lưu đơn hàng) | **Sản xuất** |
| `DA_XAC_NHAN` (mã cũ của đơn đã sản xuất) | **Sản xuất** |
| `CHO_XAC_NHAN` (mã cũ) | **Đơn hàng mẫu** |
| `HUY` (đơn đã hủy) | **Đã hủy** |
| trống / lạ | `—` (hoặc chính mã đó) |

Trên màn hình nhãn được tô màu cho dễ nhìn, **giống màu ở các chỗ khác của app**: xám = Đơn hàng mẫu, xanh lá = Sản xuất, đỏ = Đã hủy.

## Kiểm chứng (chạy thật, không đoán)

Mình dựng Prisma giả (5 đơn, mỗi đơn 1 loại trạng thái: `NHAP`, `CHUYEN_SAN_XUAT`, `DA_XAC_NHAN`, `HUY`, và 1 đơn không có trạng thái) rồi **chạy chính trang doanh thu** và **chính route xuất Excel**:

**a) Trên màn `/revenue` — 6/6 đúng:**

```
OK   đơn NHAP → Đơn hàng mẫu
OK   đơn CHUYEN_SAN_XUAT → Sản xuất
OK   đơn cũ DA_XAC_NHAN → Sản xuất
OK   đơn cũ HUY → Đã hủy
OK   đơn không có trạng thái → —
OK   không còn ô nào ghi cứng 'Sản xuất' cho mọi đơn (5 nhãn, chỉ 2 nhãn là 'Sản xuất')
```

**b) Trong file Excel xuất ra (mở lại file bằng ExcelJS, đọc đúng cột) — 6/6 đúng:**

```
sheet "Doanh thu đơn hàng": 6 dòng; cột "Loại đơn hàng" = cột 6, cột "Số đơn hàng" = cột 5
OK   NHAP-20260925-040111 → Đơn hàng mẫu
OK   26092202HD04DH24     → Sản xuất
OK   OLD-DA-XAC-NHAN-01   → Sản xuất
OK   OLD-HUY-02           → Đã hủy
OK   NO-STATUS-03         → —
```

**c) Ảnh chụp từ code thật:** `revenue-type-column-v102.png` (bảng doanh thu với 5 loại trạng thái, đủ 4 màu nhãn).

**d) `npm run build` → PASS** (“Compiled successfully”), `npx tsc --noEmit` → 0 lỗi, `npx eslint` 2 file → **0 errors / 0 warnings** (bằng bản gốc).

Suýt nữa thì lỗi: kiểu dữ liệu của dòng trong trang chỉ khai báo `id, orderCode, customerCode, customerName, orderDate` nên `row.order.status` **không biên dịch được** — đã khai báo thêm `status` vào kiểu (tsc bắt được, không để lọt).

## Lưu ý

- **Không đổi dữ liệu**: chỉ đổi cách hiển thị/xuất, không sửa DB, không cần migration. Đơn cũ giữ nguyên trạng thái trong bảng.
- Đơn **đã hủy** vẫn hiện riêng “Đã hủy” (đỏ) — không bị gộp nhầm vào “Sản xuất”.
- Mình thấy **một điểm khác chưa sửa** (ngoài phạm vi yêu cầu): trang doanh thu định dạng ngày theo giờ máy chủ, nếu chạy ở múi giờ âm sẽ lệch 1 ngày (màn đơn hàng đã sửa theo UTC ở V100). Bạn muốn mình sửa luôn cho đồng bộ thì nói nhé.
- Muốn thêm **lọc theo Loại ĐH** (Đơn hàng mẫu / Sản xuất) ở thanh lọc trang doanh thu thì cũng nói — hiện thanh lọc chỉ có ngày, đại lý, khách hàng.

## File thay đổi

- `src/app/revenue/page.tsx` — thêm `StatusTag` dùng `orderStatusLabel` + `isProductionStatus`; thay ô ghi cứng; khai báo `status` trong kiểu dòng.
- `src/app/api/revenue/export/route.ts` — cột “Loại đơn hàng” trong Excel dùng `orderStatusLabel(row.order.status)`.
