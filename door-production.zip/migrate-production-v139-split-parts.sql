-- ============================================================================
-- V139 — TÁCH CÔNG ĐOẠN THEO PHẦN: CẮT · CHẤN · HÀN · VÂN × (KHUNG · CÁNH · PHÀO)
--
-- Trước đây mỗi thao tác chỉ có MỘT dòng danh mục ("Cắt (khung / cánh / phào)"),
-- mọi phần dùng chung tổ / thời lượng / setup → không cấu hình riêng được và trên
-- phiếu lệnh không hiện rõ "cắt cánh", "chấn khung"… Bản này tách thành 12 công đoạn,
-- MỖI PHẦN MỘT DÒNG, cấu hình riêng (tổ, giờ, setup, QC, cổng…).
--
--   CAT_CANH · CAT_KHUNG · CAT_PHAO      (bước 30)
--   CHAN_CANH · CHAN_KHUNG · CHAN_PHAO   (bước 40)
--   HAN_CANH · HAN_KHUNG · HAN_PHAO      (bước 50)
--   VAN_CANH · VAN_KHUNG · VAN_PHAO      (bước 90)
--
-- Cơ chế tách: giữ nguyên cột `scope` của `production_tasks` (KHUNG/CANH/PHAO) và đặt
-- `scope_mode = 'PART'` + `scope_parts = <một phần>` cho dòng danh mục. Ba công đoạn cùng
-- bước (`seq`) chạy SONG SONG trong cùng ngày (đã xử lý ở `auto-schedule.ts`).
--
-- KHÔNG có thay đổi cột/bảng ⇒ KHÔNG cần `prisma migrate`.
--   ⚠️ NÊN chạy SAU khi deploy code (code mới hiểu `scope_mode = 'PART'`;
--      code cũ sẽ hiểu nhầm thành 'BO'). Câu lệnh idempotent, chạy lại vô hại.
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- 1) Thêm 12 công đoạn mới — mỗi phần một dòng, sửa riêng ở Cấu hình sản xuất
-- ----------------------------------------------------------------------------
INSERT INTO "production_stages"
  ("code", "name", "kind", "scope_mode", "scope_parts", "work_center_code", "seq",
   "lead_time_days", "setup_minutes", "capacity_per_day", "capacity_unit",
   "batch_key", "batch_min_qty", "changeover_max_per_day", "is_qc_point",
   "rework_to_stage", "skip_condition", "requires_stage", "active", "note", "updated_at")
VALUES
  -- CẮT (bước 30) — 2 máy CNC, ba phần cắt song song
  ('CAT_CANH',  'Cắt cánh',  'GIA_CONG', 'PART', 'CANH',  'TO_MAY', 30, 24, NULL, NULL, 'CANH', NULL, NULL, NULL, false, NULL, NULL, 'BOI_LARES', true,
   'Máy CNC Lares Fiber × 2 người (C1). Ba phần cắt SONG SONG, không cần chờ nhau (C2). KHÔNG kiểm tra sau cắt (C7). Chặn bởi Bồi Lares.', now()),
  ('CAT_KHUNG', 'Cắt khung', 'GIA_CONG', 'PART', 'KHUNG', 'TO_MAY', 30, 24, NULL, NULL, 'CANH', NULL, NULL, NULL, false, NULL, NULL, 'BOI_LARES', true,
   'Máy CNC Lares Fiber × 2 người (C1). Ba phần cắt SONG SONG, không cần chờ nhau (C2). KHÔNG kiểm tra sau cắt (C7). Chặn bởi Bồi Lares.', now()),
  ('CAT_PHAO',  'Cắt phào',  'GIA_CONG', 'PART', 'PHAO',  'TO_MAY', 30, 24, NULL, NULL, 'CANH', NULL, NULL, NULL, false, NULL, NULL, 'BOI_LARES', true,
   'Máy CNC Lares Fiber × 2 người (C1). Ba phần cắt SONG SONG, không cần chờ nhau (C2). KHÔNG kiểm tra sau cắt (C7). Chặn bởi Bồi Lares.', now()),

  -- CHẤN (bước 40) — máy 1: khung + phào; máy 2: cánh
  ('CHAN_CANH',  'Chấn cánh',  'GIA_CONG', 'PART', 'CANH',  'TO_MAY', 40, 24, 5, 30, 'CANH', 'MODEL', NULL, 2, false, NULL, NULL, 'CAT_CANH',  true,
   'Máy 1: khung + phào; máy 2: cánh (CH2). 30 cánh/ca (CH7). Đổi khuôn 5 phút, tối đa 2 lần/ngày (CH4). Có QC, lỗi phải làm lại (CH6).', now()),
  ('CHAN_KHUNG', 'Chấn khung', 'GIA_CONG', 'PART', 'KHUNG', 'TO_MAY', 40, 24, 5, 30, 'CANH', 'MODEL', NULL, 2, false, NULL, NULL, 'CAT_KHUNG', true,
   'Máy 1: khung + phào; máy 2: cánh (CH2). 30 cánh/ca (CH7). Đổi khuôn 5 phút, tối đa 2 lần/ngày (CH4). Có QC, lỗi phải làm lại (CH6).', now()),
  ('CHAN_PHAO',  'Chấn phào',  'GIA_CONG', 'PART', 'PHAO',  'TO_MAY', 40, 24, 5, 30, 'CANH', 'MODEL', NULL, 2, false, NULL, NULL, 'CAT_PHAO',  true,
   'Máy 1: khung + phào; máy 2: cánh (CH2). 30 cánh/ca (CH7). Đổi khuôn 5 phút, tối đa 2 lần/ngày (CH4). Có QC, lỗi phải làm lại (CH6).', now()),

  -- HÀN + mài ba via (bước 50) — 8 máy MIG, ba phần hàn độc lập
  ('HAN_CANH',  'Hàn cánh',  'GIA_CONG', 'PART', 'CANH',  'TO_HAN', 50, 24, NULL, NULL, 'CANH', NULL, NULL, NULL, false, NULL, NULL, 'CHAN_CANH',  true,
   '8 máy MIG, 8 người, 10 phút/cánh (HAN1/HAN3). Ba phần hàn ĐỘC LẬP, không cần đủ 3 phần (HAN5). Thợ hàn mài mối hàn luôn (HAN6).', now()),
  ('HAN_KHUNG', 'Hàn khung', 'GIA_CONG', 'PART', 'KHUNG', 'TO_HAN', 50, 24, NULL, NULL, 'CANH', NULL, NULL, NULL, false, NULL, NULL, 'CHAN_KHUNG', true,
   '8 máy MIG, 8 người, 10 phút/cánh (HAN1/HAN3). Ba phần hàn ĐỘC LẬP, không cần đủ 3 phần (HAN5). Thợ hàn mài mối hàn luôn (HAN6). Có thể thuê ngoài hàn khung (J12) — đổi Tổ ở Cấu hình sản xuất.', now()),
  ('HAN_PHAO',  'Hàn phào',  'GIA_CONG', 'PART', 'PHAO',  'TO_HAN', 50, 24, NULL, NULL, 'CANH', NULL, NULL, NULL, false, NULL, NULL, 'CHAN_PHAO',  true,
   '8 máy MIG, 8 người, 10 phút/cánh (HAN1/HAN3). Ba phần hàn ĐỘC LẬP, không cần đủ 3 phần (HAN5). Thợ hàn mài mối hàn luôn (HAN6).', now()),

  -- VÂN / dán film + sấy (bước 90) — tách riêng từng phần, tất cả các cửa đều qua
  ('VAN_CANH',  'Vân cánh',  'GIA_CONG', 'PART', 'CANH',  'TO_VAN', 90, 48, NULL, NULL, 'CANH', NULL, NULL, NULL, false, 'SON', NULL, 'SON', true,
   'Dán film tay, buồng sấy riêng (VAN1/VAN5). PHẢI dán đủ hoàn chỉnh trước khi sấy (VAN2). KHÔNG cần gom lô (VAN6). Tất cả các cửa đều đi qua công đoạn này. Vân lỗi → tẩy sơn lại (VAN10).', now()),
  ('VAN_KHUNG', 'Vân khung', 'GIA_CONG', 'PART', 'KHUNG', 'TO_VAN', 90, 48, NULL, NULL, 'CANH', NULL, NULL, NULL, false, 'SON', NULL, 'SON', true,
   'Dán film tay, buồng sấy riêng (VAN1/VAN5). PHẢI dán đủ hoàn chỉnh trước khi sấy (VAN2). KHÔNG cần gom lô (VAN6). Tất cả các cửa đều đi qua công đoạn này. Vân lỗi → tẩy sơn lại (VAN10).', now()),
  ('VAN_PHAO',  'Vân phào',  'GIA_CONG', 'PART', 'PHAO',  'TO_VAN', 90, 48, NULL, NULL, 'CANH', NULL, NULL, NULL, false, 'SON', NULL, 'SON', true,
   'Dán film tay, buồng sấy riêng (VAN1/VAN5). PHẢI dán đủ hoàn chỉnh trước khi sấy (VAN2). KHÔNG cần gom lô (VAN6). Tất cả các cửa đều đi qua công đoạn này. Vân lỗi → tẩy sơn lại (VAN10).', now())
ON CONFLICT ("code") DO NOTHING;

-- ----------------------------------------------------------------------------
-- 2) Cập nhật CỔNG của các công đoạn dùng chung (đọc được nhiều mã, cách dấu phẩy)
-- ----------------------------------------------------------------------------

-- Ép cánh chỉ cần HÀN CÁNH xong
UPDATE "production_stages"
SET "requires_stage" = 'HAN_CANH',
    "note"           = 'SAU khi hàn cánh (EP4). 1 máy: 45 phút/lượt, 9–12 cánh/lượt; 8h ép được 90–100 cánh (EP2/EP7). Chờ keo khô 45 phút. Ép lỗi → phế, làm lại (EP6).',
    "updated_at"     = now()
WHERE "code" = 'EP_CANH';

-- Test cơ khí (gộp) chỉ chạy khi CẢ 3 phần đã hàn xong; lỗi thì quay lại đúng phần hàn
UPDATE "production_stages"
SET "requires_stage"  = 'HAN_CANH,HAN_KHUNG,HAN_PHAO',
    "rework_to_stage" = 'HAN_CANH,HAN_KHUNG,HAN_PHAO',
    "note"            = 'Lắp ghép khung+cánh+phào kiểm tra trước sơn (TC1). Chỉ chạy khi CẢ 3 phần (cánh/khung/phào) đã hàn xong. Từng bộ, 20 phút/bộ, 10 bộ/người/ngày (TC2/TC6). Lỗi thường móp méo / hàn sai vị trí (TC4) → quay lại HÀN phần lỗi hoặc báo phế (TC5). Ghi lịch sử + chụp ảnh (TC3).',
    "updated_at"      = now()
WHERE "code" = 'TEST_CO_KHI';

-- Chờ sau vân: đủ CẢ 3 phần vân xong
UPDATE "production_stages"
SET "requires_stage" = 'VAN_CANH,VAN_KHUNG,VAN_PHAO',
    "note"           = 'K15: 24 giờ. Chỉ bắt đầu khi CẢ 3 phần (cánh/khung/phào) đã vân xong. VAN8: sau vân đem đi sấy in chuyển nhiệt.',
    "updated_at"     = now()
WHERE "code" = 'CHO_SAU_VAN';

-- Lắp kính + phụ kiện: đủ CẢ 3 phần vân xong
UPDATE "production_stages"
SET "requires_stage" = 'VAN_CANH,VAN_KHUNG,VAN_PHAO',
    "updated_at"     = now()
WHERE "code" = 'LAP_KINH';

-- ----------------------------------------------------------------------------
-- 3) Chuyển công đoạn CŨ trong production_tasks sang mã MỚI (giữ nguyên trạng thái/ngày/người)
--    CAT + CANH → CAT_CANH … (idempotent: chạy lại không còn dòng nào khớp)
-- ----------------------------------------------------------------------------
UPDATE "production_tasks"
SET "stage_code" = "stage_code" || '_' || "scope",
    "updated_at" = now()
WHERE "stage_code" IN ('CAT', 'CHAN', 'HAN', 'VAN')
  AND "scope" IN ('CANH', 'KHUNG', 'PHAO');

-- ----------------------------------------------------------------------------
-- 3b) Đổi đích "làm lại" cũ trong production_tasks (HAN → 3 phần hàn)
-- ----------------------------------------------------------------------------
UPDATE "production_tasks"
SET "rework_from_stage" = 'HAN_CANH,HAN_KHUNG,HAN_PHAO',
    "updated_at"        = now()
WHERE "rework_from_stage" = 'HAN';

-- ----------------------------------------------------------------------------
-- 4) Xoá 4 công đoạn GỘP cũ (đã thay bằng 12 dòng mới ở mục 1)
-- ----------------------------------------------------------------------------
DELETE FROM "production_stages" WHERE "code" IN ('CAT', 'CHAN', 'HAN', 'VAN');

COMMIT;

-- ----------------------------------------------------------------------------
-- Kiểm tra sau khi chạy (không bắt buộc):
--   SELECT code, name, scope_mode, scope_parts, seq, work_center_code, requires_stage
--     FROM production_stages WHERE seq IN (30,40,50,90) ORDER BY seq, code;
--   -- phải ra đúng 12 dòng, scope_mode = 'PART'
--   SELECT stage_code, scope, count(*) FROM production_tasks
--    WHERE stage_code LIKE 'CAT_%' OR stage_code LIKE 'CHAN_%'
--       OR stage_code LIKE 'HAN_%' OR stage_code LIKE 'VAN_%'
--    GROUP BY 1,2 ORDER BY 1,2;
--   -- không còn stage_code = 'CAT'/'CHAN'/'HAN'/'VAN'
-- ----------------------------------------------------------------------------

-- V145: cột này là SỐ NGÀY (không phải giờ) — đặt số ngày đúng theo SỔ GIẤY xưởng (TỔNG 12 ngày).
-- Chỉ sửa dòng còn mang giá trị GIỜ cũ (≥ 8); dòng đã nhập theo ngày (< 8) thì giữ nguyên ⇒ chạy lại an toàn.
UPDATE "production_stages" AS s
SET "lead_time_days" = v.days, "updated_at" = now()
FROM (VALUES
  ('THIET_KE', 1), ('BOI_LARES', 1), ('CHO_SAU_BOI_LARES', 0),
  ('CAT', 1), ('CAT_CANH', 1), ('CAT_KHUNG', 1), ('CAT_PHAO', 1),
  ('CHAN', 1), ('CHAN_CANH', 1), ('CHAN_KHUNG', 1), ('CHAN_PHAO', 1),
  ('HAN', 2), ('HAN_CANH', 2), ('HAN_KHUNG', 2), ('HAN_PHAO', 2),
  ('EP_CANH', 0), ('TEST_CO_KHI', 1), ('CHO_TRUOC_SON', 0),
  ('SON', 2), ('CHO_KHO_SAU_SON', 0),
  ('VAN', 2), ('VAN_CANH', 2), ('VAN_KHUNG', 2), ('VAN_PHAO', 2),
  ('CHO_SAU_VAN', 0), ('LAP_KINH', 0), ('DONG_GOI', 1), ('KHO_GIAO', 0)
) AS v(code, days)
WHERE s."code" = v.code AND COALESCE(s."lead_time_days", 0) >= 8;
