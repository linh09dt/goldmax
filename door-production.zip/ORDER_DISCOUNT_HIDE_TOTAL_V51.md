# ORDER DISCOUNT HIDE TOTAL V51

## Mục tiêu
Khi xuất **Excel / PDF**: nếu đơn **không có chiết khấu** hoặc **chiết khấu 0%** thì **ẩn luôn dòng “Tổng tiền sau chiết khấu”**. Nếu đơn có chiết khấu (> 0%) thì vẫn hiện dòng đó như cũ.

## Quy tắc áp dụng
`has_discount = discountPercent > 0 AND discountAmount > 0`
- **Có chiết khấu** → hiện 2 dòng: `Chiết khấu thương mại (x%)` và `Tổng tiền sau chiết khấu` (giữ nguyên như trước).
- **Không chiết khấu / 0%** → chỉ còn `Tổng giá trị đơn hàng` → `Đã đặt cọc` → (`Trừ tiền nhận hàng tại kho` nếu > 0) → `CÒN LẠI CẦN THANH TOÁN`.
- Số tiền “CÒN LẠI CẦN THANH TOÁN” không đổi (vẫn tính `afterDiscount - đặt cọc - trừ kho`), chỉ ẩn dòng trung gian.

## File sửa
1. `src/lib/order-export-v2.ts` — nút **Xuất Excel** (API `/api/orders/[id]/export-v2`).
2. `python/reportlab_order_v2.py` — nút **Xuất PDF** (API `/api/order_pdf_v2`), hàm `_bottom_section`.
3. `python/reportlab_order_preview.py` — PDF mẫu mới (API `/api/order_pdf_preview`), cùng logic.
   - Ở cả 2 file Python: `after_index` giờ là `int | None`, chỉ gán khi có chiết khấu; nền xanh nhạt `#EEF2FF` của dòng “Tổng tiền sau chiết khấu” chỉ vẽ khi dòng đó tồn tại (tránh tô nhầm sang dòng “Đã đặt cọc”).

## Không thay đổi
- Công thức tiền, KH/Lượng, cước vận chuyển, đặt cọc, trừ kho, tổng tiền đơn hàng.
- DB/Prisma, API, dữ liệu Excel/PDF khác (bảng hàng hóa, checklist, chữ ký, “Bằng chữ”).
- Màn hình xem đơn (`/orders/[id]` hiển thị “Tổng sau chiết khấu”) và màn Theo dõi doanh thu — không thuộc phạm vi xuất file.
- Excel cũ `src/lib/order-export.ts` (nút đang ẩn) vẫn giữ dòng `CÒN LẠI` như trước.

## Kiểm chứng thực tế
- **Excel V2**: dựng workbook bằng `buildOrderExcelV2` với 1 đơn có giá trị 18.434.507đ, đọc lại file:
  - `discountPercent = 0` → `Tổng giá trị đơn hàng` · `Đã đặt cọc` · `CÒN LẠI CẦN THANH TOÁN` (không có dòng chiết khấu / sau chiết khấu).
  - `discountPercent = 12` → thêm `Chiết khấu thương mại (12%) = -2.212.140,84` và `Tổng tiền sau chiết khấu = 16.222.366,16`.
- **PDF V2 (ReportLab)**: render `_bottom_section` ra PDF rồi trích text:
  - 0% → `Tổng giá trị đơn hàng` · `Đã đặt cọc` · `CÒN LẠI CẦN THANH TOÁN`.
  - 12% → `Chiết khấu thương mại (12%)` · `Tổng tiền sau chiết khấu` · `Đã đặt cọc` · `CÒN LẠI CẦN THANH TOÁN`.
- **PDF preview**: kết quả tương tự ở cả 3 trường hợp (0%, 12%, percent > 0 nhưng tiền = 0 → ẩn).
- `npx tsc --noEmit`: pass. `npx eslint src/lib/order-export-v2.ts`: 7 lỗi `no-explicit-any` có sẵn từ bản gốc, không phát sinh mới. `python -m py_compile`: OK.
