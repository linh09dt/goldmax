# V129 — Hoàn thiện 2 việc đang chờ deploy (đã diễn tập trên môi trường giống production)

Hai việc đang nằm chờ trên production:

| # | Việc | Loại thay đổi | Có cần chạy SQL? |
|---|---|---|---|
| 1 | **Khảo sát nhà máy** (V126 + V127: trang `/khao-sat`, lưu DB, xuất file) | Code + **migration mới** | ✅ **CÓ** — bảng `survey_answers` |
| 2 | **UI thông tin đơn gọn 1 hàng** (V112b/V112c) + **tab Tổng quan** (V113) | Chỉ code (UI + truy vấn) | ❌ KHÔNG — không đổi database |

Không cần thêm biến môi trường nào. Không đổi cấu hình Vercel.

---

## 1. Đã diễn tập những gì (trên Postgres local, dựng y như production)

Mình dựng một database mới rồi tái hiện **đúng trạng thái production hiện nay**: có các migration cũ, có cột `order_type` (do bạn chạy SQL tay ở V112) nhưng **chưa có bảng khảo sát**.

| Bước diễn tập | Kết quả |
|---|---|
| Apply các migration production đang có | Thành công |
| Xoá dấu `V112` khỏi lịch sử migration (mô phỏng “chạy SQL tay, Prisma không biết”) | – |
| Chạy `npx prisma migrate deploy` | ✅ **Thành công** — tạo được bảng `survey_answers`, không lỗi |
| Kiểm tra `npx prisma migrate status` | ✅ “Database schema is up to date!” |
| Nạp 15 đơn + 234 dòng hàng thật vào DB giả lập rồi chạy app | ✅ Tất cả trang trả về **200**, log **không có lỗi**: `/` · `/orders` · `/orders/16` · `/orders/16/edit` · `/orders/16/print` · `/revenue` · `/khao-sat` |

**Phát hiện quan trọng (tin tốt):** migration V112 được viết **an toàn khi chạy lại** — dùng
`ALTER TABLE … ADD COLUMN IF NOT EXISTS` và `CREATE INDEX IF NOT EXISTS`.
Nghĩa là **kể cả khi lịch sử migration chưa có dấu V112, `migrate deploy` vẫn chạy trơn**, không bị lỗi “column already exists”.
Chạy thêm bước `resolve` bên dưới chỉ để lịch sử sạch, không còn là điều kiện bắt buộc.

**Đã xem tận mắt 3 giao diện chờ deploy** (ảnh chụp kèm trong gói): hàng “Thông tin đơn hàng” gọn 1 hàng,
tab Tổng quan đủ 6 thẻ KPI + biểu đồ + cơ cấu loại đơn/trạng thái + Top đại lý/NVKD/sản phẩm + bảng “Đơn cần chú ý”.

---

## 2. Các bước deploy (đúng thứ tự)

### Bước 1 — Tạo bảng khảo sát (chọn 1 trong 2 cách)

**Cách A — chạy từ máy bạn (khuyến nghị, chắc chắn đúng):**
```bash
cd <thư-mục-dự-án>
npx prisma migrate deploy
```

**Cách B — dán vào Supabase → SQL Editor** (file `migrate-survey-v126.sql` kèm trong gói):
```sql
CREATE TABLE "survey_answers" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(20) NOT NULL,
    "answer" TEXT,
    "choice" VARCHAR(40),
    "updated_by" VARCHAR(120),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "survey_answers_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "survey_answers_code_key" ON "survey_answers"("code");
```
Sau khi dán, chạy thêm để Prisma ghi nhận (lịch sử sạch):
```bash
npx prisma migrate resolve --applied 20260925160000_survey_v126
```
> Nếu bạn từng chạy SQL tay cho V112 mà chưa `resolve`, chạy luôn 1 lệnh này cho sạch lịch sử:
> `npx prisma migrate resolve --applied 20260925120000_order_type_v112`

**Kiểm tra bước 1:** vào Supabase → Table Editor phải thấy bảng `survey_answers` (rỗng).

### Bước 2 — Deploy code
Deploy như mọi lần (Vercel). Vercel chỉ chạy `prisma generate` khi build — **không tự chạy migration**, nên bước 1 là bắt buộc.

### Bước 3 — Kiểm tra sau deploy (8 mục, khoảng 3 phút)

| # | Kiểm tra | Kết quả đúng |
|---|---|---|
| 1 | `/khao-sat` mở được | Thấy 230 câu, mỗi câu 1 hàng, ô trả lời bên phải |
| 2 | Gõ thử 1 câu ở `/khao-sat`, chờ ~2 giây | Thẻ “Tình trạng lưu” hiện **Đã lưu lúc hh:mm** |
| 3 | Supabase → `survey_answers` | Có 1 dòng với `answer` đúng nội dung vừa gõ |
| 4 | `/orders` | Có dải lọc **Tất cả · Đơn hàng mẫu · Sản xuất · Đơn làm lại**, không lỗi |
| 5 | Mở 1 đơn bất kỳ | Hàng “Thông tin đơn hàng” **nằm gọn 1 hàng**, không xuống dòng |
| 6 | Trang `/` (Tổng quan) | 6 thẻ KPI + biểu đồ doanh thu + Top đại lý/NVKD/sản phẩm hiện số |
| 7 | Trang `/revenue` | Danh sách chỉ gồm đơn **Sản xuất + Đã xác nhận** |
| 8 | Xuất thử 1 đơn ra Excel/PDF | Ảnh sản phẩm lấp đầy ô (V110b), không méo form |

### Bước 4 — Báo lại cho mình
Sau khi deploy xong, nhắn “deploy xong”. Mình sẽ kiểm tra lại lần cuối và bắt đầu phần tiếp theo (module Lên kế hoạch sản xuất) — hoặc chờ kết quả khảo sát nhà máy, tuỳ bạn.

---

## 3. Nếu có lỗi thì xử lý thế nào

| Hiện tượng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Trang `/khao-sat` báo lỗi 500, log ghi `P2021` (bảng không tồn tại) | Chưa chạy bước 1 | Chạy `npx prisma migrate deploy` hoặc dán SQL ở Bước 1 rồi deploy lại |
| `migrate deploy` báo `P3009` / drift | Lịch sử migration lệch | Chạy `npx prisma migrate resolve --applied 20260925120000_order_type_v112` (và `…survey_v126` nếu đã dán SQL tay) |
| Trang Tổng quan trống số | Kỳ lọc đang là “Năm nay” mà dữ liệu ở năm khác | Bấm **Tất cả** ở dải kỳ |
| Muốn quay lại bản trước | – | Vercel → Deployments → bản trước → **Promote to Production**. Bảng `survey_answers` cứ để nguyên (không ảnh hưởng bản cũ vì bản cũ không truy vấn bảng này) |

---

## 4. Trong gói kèm theo

- **Toàn bộ code đã sửa** (62 file) — gồm cả khảo sát và 2 việc chờ deploy.
- **2 migration**: `20260925120000_order_type_v112` (đã chạy) và `20260925160000_survey_v126` (chưa chạy).
- `migrate-survey-v126.sql` — để dán vào Supabase nếu muốn.
- **Ảnh chụp 3 giao diện** trên môi trường giả lập production (danh sách đơn · chi tiết đơn · Tổng quan) + ảnh trang khảo sát.
- Tài liệu: `KHAO_SAT_TREN_APP_V126.md` (kèm mục V127), `DASHBOARD_TONG_QUAN_V113.md`, `LOAI_DON_TRANG_THAI_V112.md`.
