# V123 — Bộ câu hỏi ĐẦY ĐỦ THEO TỔ & CÔNG ĐOẠN (module Lên kế hoạch sản xuất)

Bản đầy đủ nhất: **153 câu hỏi**, chia theo **tổ → công đoạn**, và trong **mỗi công đoạn câu hỏi đi theo 7 nhóm cố định** để tổ dễ trả lời:

> ① nội dung & phạm vi · ② thời lượng · ③ nguồn lực & máy móc · ④ setup & gom lô · ⑤ chờ & ràng buộc · ⑥ kiểm tra & lỗi · ⑦ ghi nhận trong app

**File giao:** `artifacts/bo-cau-hoi-day-du-theo-to-v123.docx` (điền trong Word) ·
`artifacts/bo-cau-hoi-day-du-theo-to-v123.pdf` (in A4, 14 trang) · script sinh: `scripts/v123/mk_v123.py` (+ `_part1`, `_part2`).

## Ba bản để dùng đúng việc

| Bản | Dùng khi nào |
|---|---|
| **V117** | Trao đổi nhanh 12 phút với quản đốc (bản ngắn) |
| **V122** | Chốt quyết định thiết kế (62 câu, xếp theo quyết định — dùng khi họp kỹ thuật) |
| **V123 (bản này)** | Gửi **từng tổ** tự điền phần của mình — đầy đủ, chi tiết tới từng công đoạn |

## Phân bổ câu hỏi

| Mục | Nội dung | Công đoạn | Câu | Trang |
|---|---|---|---|---|
| **1** | **TỔ MÁY** | Thiết kế (TK 7) · **Bồi Lares – CAM** (BL 9) · Cắt (C 8) · Chấn (CH 7) · chung (TM 6) | **37** | 1–2 |
| **2** | **TỔ HÀN** | Hàn (HAN 7) · Ép cánh (EP 7) · Test cơ khí (TC 6) · chung (TH 5) | **25** | 3 |
| **3** | **TỔ SƠN** | Sơn (SON 19) | **19** | 4 |
| **4** | **TỔ VÂN** | Vân (VAN 12) | **12** | 5 |
| **5** | **LẮP KÍNH + PHỤ KIỆN** | LK 12 (công đoạn chưa có trong bảng công đoạn) | **12** | 6 |
| **6** | **TỔ KHO** | Vệ sinh + Đóng gói (KHO 8) · Kho & Giao hàng & lắp đặt (GH 12) | **20** | 6–7 |
| **7** | **XUYÊN SUỐT** | Cách lên kế hoạch (KH1–6) · Năng lực & thực tế (KH7–13) · Ngoại lệ & thay đổi (KH14–20) · Cập nhật & báo cáo (KH21–28) | **28** | 8 |
| **8** | Bảng điền thời lượng **16 dòng** (đã ghi sẵn số từ bảng gốc, chừa ô trống) | | — | 10 |
| **9** | **17 trường dữ liệu** app cần thêm (tick Cần/Không) | | — | 10 |
| **10** | Kiểm tra chéo **12 trường** app đang có | | — | 11 |
| **11** | **24 mặc định** nếu chưa trả lời được | | — | 11–12 |
| **12** | Xin kèm theo (9 mục) | | — | 12 |

**Tổng: 153 câu hỏi** · 113 câu mức **P1** (bắt buộc để lập trình).

## Điểm mới so với các bản trước

1. **Câu hỏi theo 7 nhóm trong mỗi công đoạn** → tổ chỉ cần học 1 lần cách trả lời, đọc công đoạn nào cũng quen.
2. **Bồi Lares** đặt đúng bản chất: *nạp chương trình cho máy cắt chuyên dụng (hậu thiết kế)*, có câu về chương trình theo model hay theo bộ, thời gian chương trình mới vs. đã có, máy cắt có đứng chờ file không.
3. **Bổ sung 2 công đoạn còn thiếu**: **Mài mối hàn / làm sạch ba via** và **Lắp kính + phụ kiện** (mục 5 dành riêng vì bảng công đoạn đang nhảy từ Vân sang Đóng gói).
4. **Bảng thời lượng** có thêm cột **Loại (G = gia công / C = chuẩn bị)** — công đoạn chuẩn bị không được nhân theo số bộ.
5. Câu **CH5** (quy tắc “cần đầy đủ đơn”) và **LK12** (“khi nhận đơn xưởng phải gọi sale hỏi lại gì”) — hai câu cho ra nhiều thông tin thiết kế nhất.

## Sinh lại tài liệu

```bash
cd /tmp && cat dp/scripts/v123/mk_v123_part1.py dp/scripts/v123/mk_v123_part2.py > mk_v123.py
python3 mk_v123.py
libreoffice --headless --convert-to pdf --outdir artifacts artifacts/bo-cau-hoi-day-du-theo-to-v123.docx
```

> **Lưu ý kỹ thuật (đã gặp lỗi):** khi sinh docx bằng python-docx, thẻ `<b>...</b>` trong chuỗi **phải** được tách thành nhiều run đậm — nếu đưa thẳng vào `run()` thì thẻ bị in ra thành chữ (đã từng xảy ra ở V122, đã sửa bằng hàm `rich()`).
