# V101 — Cân đối thanh lọc màn Quản lý đơn hàng

## Yêu cầu

> “cân đối các ô trên thanh lọc trong tab quản lý đơn hàng”

## Vấn đề của thanh lọc cũ (V100)

Mỗi ô một chiều rộng đặt rời rạc (`240px` tìm nhanh · `132px` từ/đến ngày · `168px` đại lý · `150px` khách hàng) trong một hàng `flex-wrap gap-2`, nên:

- các ô **không thẳng cột** với nhau, mép phải lệch, không có lưới chung;
- màn hẹp thì tự xuống dòng tuỳ độ dài chữ → hàng bị **so le, chỗ thừa chỗ thiếu**;
- ô tìm nhanh hẹp hơn chữ gợi ý nên **bị cắt chữ** (“Mã đơn, khách hàng, SĐT, mã đ…”).

## Đã làm gì

**1. Tách thanh lọc ra component riêng:** `src/components/order-list/order-filter-bar.tsx` (component thuần, không tự truy vấn) — `page.tsx` gọn lại, và thanh lọc kiểm tra/đối chiếu được độc lập.

**2. Xếp theo LƯỚI 12 CỘT** (`grid xl:grid-cols-12`) để mọi ô trùng mép trên cùng một hệ cột, cao bằng nhau (`h-9`):

| Hàng | Ô | Số cột | Bề rộng ở vùng nội dung 940px |
|---|---|---|---|
| 1 | Tìm nhanh | 3 | 226px |
| 1 | Khoảng ngày (5 chip) | 5 | 385px |
| 1 | Từ ngày | 2 | 147px |
| 1 | Đến ngày | 2 | 147px |
| 2 | Đại lý | 3 | 226px |
| 2 | Khách hàng | 3 | 226px |
| 2 | Nút Lọc / Xoá lọc / Xuất Excel | 6 | 464px, **dồn phải** |

Tỉ lệ này **tính từ số đo thật**, không phải ước lượng: đo trong trình duyệt ở màn 1280px cho thấy dải 5 chip cần **329px**, nên “Khoảng ngày” phải được 5 cột (385px) mới không bị xuống dòng; nếu để 4 cột (305px) thì chip “Năm” rơi xuống hàng 2 làm lệch cả hàng.

**3. Chi tiết chỉnh cho cân:**

- các ô cùng loại cho cùng bề rộng: Từ/Đến ngày (2–2), Đại lý/Khách hàng (3–3) → hai mép thẳng nhau;
- bỏ chiều rộng cứng, cho ô tự dãn theo cột (`erp-input w-full` sẵn có) → mép trái/phải luôn trùng lưới;
- chip ngày: `shrink-0` + `whitespace-nowrap` → chữ trong chip không tự bẻ dòng; cả dải chỉ xuống dòng khi thật sự hết chỗ;
- nút thao tác dồn phải, thẳng mép phải thẻ;
- gợi ý ô tìm nhanh rút còn “Mã đơn, khách hàng, SĐT…” để **không bị cắt chữ** trong ô 226px;
- màn hẹp: `< 1280px` xếp 2 cột rồi 1 cột (Tìm nhanh và Khoảng ngày chiếm cả hàng) — vẫn cân, không tràn.

## Kiểm chứng

**a) Đo trực tiếp trong trình duyệt ở màn 1280px (vùng nội dung 940px):**

| Ô | Bề rộng | Chiều cao | Tràn ô? | Chip 1 hàng? |
|---|---|---|---|---|
| Tìm nhanh | 226 | 61 | không | — |
| Khoảng ngày | 385 | 61 | không | **có** (cần 329) |
| Từ ngày | 147 | 61 | không | — |
| Đến ngày | 147 | 61 | không | — |
| Đại lý | 226 | 61 | không | — |
| Khách hàng | 226 | 61 | không | — |
| Nút thao tác | 464 | 36 | không | — |

→ **Mọi ô cao đều 61px** (thẳng hàng), không ô nào tràn, chip không xuống dòng, chữ gợi ý trong ô tìm nhanh **vừa** (đo bằng `canvas.measureText`).

**b) Bản màn hẹp (mô phỏng < 1280px):** Tìm nhanh và Khoảng ngày chiếm cả hàng, Từ/Đến ngày 2 ô cạnh nhau (464px mỗi ô), Đại lý/Khách hàng 2 ô cạnh nhau — **không ô nào tràn**, chip vẫn 1 hàng.

**c) Ảnh chụp từ code thật** — `filter-bar-truoc-sau.png`: dựng markup React thật + **CSS Tailwind biên dịch từ dự án**, mô phỏng đúng bề rộng vùng nội dung của app (1286px ≈ màn 1600 và 940px ≈ màn 1280). Bản “TRƯỚC” là **đoạn form cũ copy nguyên văn** từ gói V100 để so cho công bằng. Ảnh `order-filter-bar-v101.png`: thanh lọc mới đặt trong khung app thật.

**d) `npm run build` → PASS** (“Compiled successfully”), `npx tsc --noEmit` → 0 lỗi, `npx eslint` các file liên quan → 0 errors / 0 warnings.

## Lưu ý

- **Không đổi nghiệp vụ**: vẫn đúng các field `q`, `from`, `to`, `dealer`, `customer`, `status` như V100 → link “Xuất Excel danh sách” và bộ lọc dùng chung không bị ảnh hưởng.
- Ô “Đại lý”/“Khách hàng” chưa chọn thì nay ghi rõ **“Tất cả đại lý” / “Tất cả khách hàng”** (trước chỉ ghi “Tất cả”).
- Chip “Khoảng ngày” đổi từ 4 cột sang 5 cột là **theo số đo**, không phải theo cảm tính — nếu sau này thêm/bớt chip thì cần đo lại.

## File thay đổi

- `src/components/order-list/order-filter-bar.tsx` — **mới**: thanh lọc theo lưới 12 cột.
- `src/app/orders/page.tsx` — dùng component thanh lọc mới (bỏ đoạn form cũ trong trang).
