# V89 — Cấu hình tính toán: cột “Bộ cửa chính” để chọn rule theo loại cửa cha

## Yêu cầu

> “cho mình chọn bộ cửa chính, xong chọn phân loại model hàng hóa phụ kiện chi tiết, vì cách tính cho phào rời của cửa sổ khác với phào rời của cửa đi, nên mình muốn chọn cho đúng”

## Cách làm

Thêm **1 cột mới “Bộ cửa chính”** vào bảng Rule tính KH/Lượng (ngay sau cột Model / hàng hóa):

- **Ô 1 — nhóm hàng của bộ cửa chính**: “Mọi bộ cửa” (mặc định) hoặc một nhóm hàng trong Danh mục hàng hóa (ví dụ `Cửa sổ`, `Cửa đi`, `Vòm`).
- **Ô 2 — model của bộ cửa chính** (chỉ hiện sau khi đã chọn nhóm): “Mọi model trong nhóm” hoặc một model cụ thể (ví dụ `CS-01`).

Cột này chỉ áp dụng cho rule **Theo nhóm hàng** và **Theo Model / hàng hóa**; rule **Bộ cửa chính** (dòng chính) hiển thị “—” vì cửa chính không có cửa cha.

Cách khớp khi tính:
- Để trống = **áp dụng cho mọi bộ cửa** → toàn bộ 11 rule bạn đang có giữ nguyên hành vi.
- Điền nhóm hàng = chỉ áp khi **nhóm hàng của bộ cửa cha** khớp (khớp cả tiền tố: `Cửa sổ` áp cho `Cửa sổ 2 cánh`).
- Điền thêm model = chỉ áp khi bộ cửa cha **đúng model** đó.
- Nhóm hàng của bộ cửa cha được tra từ Danh mục hàng hóa theo model của dòng chính; nếu không tra được thì lấy tên hàng trên đơn.
- Rule **Theo Model** vẫn ưu tiên hơn rule **Theo nhóm hàng** như trước. Ví dụ thực tế:

| Rule | Nhóm hàng (phụ kiện) | Model (phụ kiện) | Bộ cửa chính | Cách tính |
|---|---|---|---|---|
| 1 | Phao Rời | *(tất cả)* | Mọi bộ cửa | (Cao × 2 + Rộng) / 1.000 |
| 2 | Phao Rời | PR-01 | Cửa sổ | (Cao × 2 + Rộng × 2) / 1.000 |

→ Phào rời của **cửa đi / cửa lùa** dùng rule 1; phào rời của **cửa sổ** bị rule 2 ghi đè.

Thay đổi kỹ thuật:
- `CalculationRule` thêm 2 field `parentGroupName`, `parentItemCode` (JSON cấu hình, **không cần migration DB**; cấu hình cũ thiếu 2 field này sẽ tự hiểu là “mọi bộ cửa”).
- `resolveCalculationRule()` nhận thêm `parentGroupName` / `parentItemCode` của cửa cha và lọc rule theo đó.
- Khoá chống trùng rule (`dedupeRules`) tính thêm điều kiện bộ cửa, để **cùng một phụ kiện vẫn giữ được nhiều rule cho các loại cửa khác nhau**.
- `order-form.tsx`: truyền thông tin cửa cha vào cả 2 chỗ tính rule (tính KH/Lượng và đề xuất Cao/Rộng).
- Hướng dẫn sử dụng (mục B1) thêm dòng giải thích cột mới.

## Kiểm chứng

**1. Khớp rule (15/15 case đúng)** — chạy trực tiếp `resolveCalculationRule` với cấu hình thử:

| Case | Kết quả |
|---|---|
| Phào rời + cửa cha nhóm `Cửa sổ` | dùng rule riêng của cửa sổ ✓ |
| Phào rời + cửa cha nhóm `Cửa đi` | dùng rule riêng của cửa đi ✓ |
| Phào rời + cửa cha `Cửa lùa` (không có rule riêng) | rơi về rule chung của nhóm ✓ |
| Cửa cha `Cửa sổ 2 cánh` (khớp tiền tố) | dùng rule của cửa sổ ✓ |
| Rule giới hạn model `CS-01` + cửa cha `CS-02` | không áp ✓ |
| Rule không có điều kiện cửa | áp cho mọi cửa ✓ |
| Rule Bộ cửa chính (MAIN) | không bị ảnh hưởng bởi cột mới ✓ |
| Cấu hình cũ (chưa có 2 field mới) | chạy y như trước, 2 field tự = rỗng ✓ |
| Lưu/đọc cấu hình (normalize) | giữ nguyên điều kiện cửa, không mất rule ✓ |

**2. Test tích hợp qua chính code màn nhập đơn** (`recalculateAutomaticPricingQuantity` của `order-form.tsx`, cửa 2000 × 900):

| Tình huống | KH/Lượng tính ra |
|---|---|
| Phào rời của **cửa đi** (`CD-01`) | `4.9` = (2000×2 + 900)/1.000 |
| Phào rời của **cửa sổ** (`CS-01`) | `5.8` = (2000×2 + 900×2)/1.000 |
| Phào rời của **cửa lùa** (`CL-09`, không có rule riêng) | `4.9` — công thức chung |
| Dòng đã nhập KH/Lượng tay | giữ nguyên, không bị tính lại |

- `npx tsc --noEmit` → 0 lỗi.
- `npx eslint` 4 file sửa → **5 errors / 11 warnings, đúng bằng bản gốc** (đều là lỗi `react-hooks/set-state-in-effect` có từ trước), không phát sinh lỗi mới.

## Lưu ý

- **Không cần migration DB.** Cấu hình 11 rule hiện tại không bị đổi; muốn dùng thì vào Cấu hình → Cấu hình tính toán, đặt cột **Bộ cửa chính** cho rule cần giới hạn rồi bấm **Lưu cấu hình**. Nhớ tạo rule riêng cho từng loại cửa (rule “Theo Model / hàng hóa” cho phào rời cửa sổ, rule còn lại để trống cột Bộ cửa chính = dùng chung).
- Cột mới làm bảng có 10 cột; cột nhóm hàng / model của bộ cửa khá hẹp nên nhãn dài có thể bị cắt — rê chuột vào ô chọn để xem đầy đủ.
- Cách phân biệt cửa sổ / cửa đi hiện dựa trên **nhóm hàng (Tên hàng) hoặc Model trong Danh mục hàng hóa**. Nếu nhà máy đang phân biệt bằng cách khác (ví dụ chỉ ghi trong Diễn giải, hoặc theo tiền tố model như `CS-`/`CD-`), nói mình biết để bổ sung kiểu khớp tương ứng.
- Điều kiện bộ cửa áp cho cả **đề xuất Cao/Rộng**, không chỉ công thức KH/Lượng — tức rule gắn “cửa sổ” cũng chỉ đề xuất kích thước cho phụ kiện của cửa sổ.

## File thay đổi

- `src/lib/calculation-config.ts` — thêm `parentGroupName` / `parentItemCode` vào `CalculationRule`, lọc rule theo cửa cha trong `resolveCalculationRule`, cập nhật `normalizeRule` + `dedupeRules` + cấu hình mặc định/gợi ý.
- `src/components/calculation-config.tsx` — thêm cột “Bộ cửa chính” (2 ô chọn) + chú thích dưới bảng, cân lại bề rộng 10 cột.
- `src/components/order-form.tsx` — `parentDoorTarget()` và truyền cửa cha vào 2 chỗ tính rule.
- `src/app/guide/page.tsx` — thêm dòng “Bộ cửa chính” trong Hướng dẫn sử dụng.
