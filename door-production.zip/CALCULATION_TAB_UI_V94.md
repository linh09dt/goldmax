# V94 — Dọn lại tab Cấu hình tính toán: tách 2 khu vực, bỏ dải ô ví dụ, hiển thị đủ chữ trong bảng rule

## Yêu cầu (3 việc trong cùng tab)

> 1. “Cấu hình tính toán, chia rõ ra 2 khu vực, làm tròn khối lượng và bộ số”
> 2. “xóa cái này trong tab cấu hình tính toán” *(kèm ảnh: dải 5 ô ví dụ NHÓM CỬA · PHÀO/PHAO · Ô THOÁNG · KHÓA · BỘ SỐ ở cuối trang)*
> 3. “hiển thị đầy đủ thông tin, chữ bị mất” *(kèm ảnh: bảng rule bị cắt chữ kiểu “Khuôn biệt thự…”, “PR - Phào mặt t…”)*

## Cách làm

### 1. “Thông số chung” → 2 khu vực rõ ràng

Khối gộp `Thông số chung` (3 cột: làm tròn | số bắt đầu | cơ chế bộ số) được tách thành **2 thẻ riêng, xếp 2 cột** trên màn rộng:

| Khu vực | Nội dung |
|---|---|
| **Làm tròn KH/Lượng** | chọn số chữ số thập phân + ghi chú “chỉ ảnh hưởng cách hiển thị; tiền vẫn tính trên giá trị chính xác” + **bảng ví dụ** (2000 × 900 mm → 1,8; số lẻ 0,9056 → 0,91 khi chọn 2 chữ số, → 1 khi chọn 0) |
| **Bộ số** | ô “Số bắt đầu áp dụng” + khối **Cơ chế cấp số** (Đơn hàng mẫu chưa có Bộ số → bấm Lưu đơn hàng chuyển Sản xuất thì cấp số tự động → số đã cấp giữ nguyên) |

### 2. Bỏ dải 5 ô ví dụ cuối trang

Xoá `<section>` chứa 5 ô `NHÓM CỬA / PHÀO–PHAO / Ô THOÁNG / KHÓA / BỘ SỐ` và xoá luôn component `Example` (không còn dùng ở đâu). Thông tin “4TK → 4; 3TK → 3; 2TK → 2; 1TK → 1” được **chuyển vào Hướng dẫn sử dụng** (mục B1 → dòng “Công thức KH/Lượng”) để không mất kiến thức, vì dòng đó trước đây dựa vào dải ô ví dụ.

### 3. Bảng rule hiển thị đủ chữ

Trước đây (V85) bảng chia cột theo **%** + `table-layout: fixed` để bảng luôn nằm gọn trong khung ⇒ nhãn dài bị cắt. Nay:

- `SettingsTable` (dùng chung tab Cấu hình) nhận thêm prop `className` — không đổi hành vi các bảng khác (mặc định rỗng).
- Bảng rule đặt **bề rộng từng cột theo px** (đủ cho nhãn dài nhất) và `min-w-[1660px]`:
  Áp dụng cho 175 · Nhóm hàng 155 · Model/hàng hóa 205 · Bộ cửa chính 195 · Cách tính KH/Lượng 235 · Đề xuất Cao 180 · Đề xuất Rộng 180 · Ghi chú 215 · Dùng 56 · Xóa 64.
- Màn rộng: hiển thị đủ chữ như trước nhưng không bị cắt. Màn hẹp hơn 1660px: bảng **cuộn ngang** (khung đã có sẵn `overflow-x-auto`) thay vì bóp cột lại.

## Kiểm chứng

Render thật component `CalculationConfigEditor` (React SSR) và kiểm tra nội dung HTML:

| Kiểm tra | Kết quả |
|---|---|
| Có khu vực “Làm tròn KH/Lượng” và khu vực “Bộ số” (Số bắt đầu + Cơ chế cấp số) | ✓ |
| Không còn khối gộp “Thông số chung” | ✓ |
| Không còn dải 5 ô ví dụ (`4TK → 4`, `Tự tăng dần, tạo khi bấm Lưu đơn hàng`) | ✓ |
| Bảng rule có `min-w-[1660px]` và cột dùng px (`w-[235px]`, `w-[205px]`), không còn `w-[15%]` | ✓ |
| Vẫn đủ 10 cột tiêu đề, select công thức KH/Lượng còn nguyên | ✓ |
| Bảng ví dụ làm tròn (0,9056 → 0,91) hiển thị đúng | ✓ |

- `npx tsc --noEmit` → 0 lỗi.
- `npx eslint` 3 file sửa → **1 error / 0 warning, đúng bằng bản gốc** (`react-hooks/set-state-in-effect` có từ trước), không phát sinh lỗi mới.

## Lưu ý

- Việc cho bảng rule cuộn ngang là **đánh đổi có chủ ý** so với V85 (V85 ưu tiên không cuộn ngang nên phải cắt chữ). Nếu bạn muốn quay lại kiểu không cuộn ngang thì phải chấp nhận cắt chữ, hoặc giảm bớt cột.
- Tooltip khi rê chuột vào ô chọn vẫn còn (V85), nên kể cả màn rất hẹp vẫn đọc được đầy đủ nhãn.
- Không đổi dữ liệu/cấu hình nào — chỉ đổi giao diện tab Cấu hình tính toán.

## File thay đổi

- `src/components/calculation-config.tsx` — tách 2 khu vực, bỏ dải ô ví dụ + component `Example`, cột bảng theo px + min-width.
- `src/components/settings/settings-ui.tsx` — `SettingsTable` nhận `className` (bề rộng tối thiểu).
- `src/app/guide/page.tsx` — chuyển thông tin 1TK/2TK/3TK/4TK vào Hướng dẫn (mục B1).
