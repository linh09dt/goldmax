# V140 — THÊM "TỔ THIẾT KẾ" CHO CÔNG ĐOẠN THIẾT KẾ

## Vấn đề
Công đoạn **Thiết kế** (`THIET_KE`) đang nằm chung tổ **`KY_THUAT`** —
"Kỹ thuật (Thiết kế + Bồi Lares/CAM)" — nên trên bảng tải không tách được việc thiết kế
và không thấy được tải riêng của nhóm thiết kế.

## Thay đổi (V140)

| # | Việc | Chi tiết |
|---|---|---|
| 1 | **Thêm tổ mới** `TO_THIET_KE` — "Tổ thiết kế" | `kind = 'TO'`, `sort_order = 5` (đứng trước Tổ máy), `hours_per_shift = 8`, **năng lực/ngày để trống** |
| 2 | Công đoạn **`THIET_KE`** | `work_center_code` → `TO_THIET_KE` |
| 3 | Việc Thiết kế **đã sinh cho bộ cũ** trong `production_tasks` | chuyển `work_center_code` → `TO_THIET_KE` (để bộ cũ hiện đúng tổ, báo cáo theo tổ đúng) |
| 4 | Tổ **`KY_THUAT`** | đổi tên thành "Kỹ thuật (Bồi Lares / CAM)" vì Thiết kế đã tách ra |

**`BOI_LARES` (Bồi Lares / CAM) vẫn ở `KY_THUAT`** — không đổi.

## Vì sao năng lực để trống
Khảo sát nhà máy: thiết kế **tùy model, nhiều phi tiêu chuẩn** (TK2) ⇒ chưa có con số định mức/ngày.
Để trống thì bảng tải hiện *"Năng lực: theo tổ / chưa khai"* (không cảnh báo quá tải sai).
Khi có số, nhập ngay ở **Cấu hình sản xuất → tab Tổ & năng lực** (cột *Năng lực/ngày*).

## Không cần sửa code, không cần `prisma migrate`
Đây là **thay đổi dữ liệu**: app đọc tổ và công đoạn từ DB. Cột/bảng không đổi.
File code kèm theo chỉ là 2 dòng ghi chú/hằng số cho gọn (`WORK_CENTER` trong `catalog.ts` — thực tế
đang không được dùng ở đâu; và comment trong `schema.prisma`).

## File thay đổi

| File | Việc |
|---|---|
| `migrate-production-v140-them-to-thiet-ke.sql` | **mới** — migration dữ liệu (idempotent) |
| `src/lib/production/catalog.ts` | thêm hằng số `WORK_CENTER.TO_THIET_KE` (chỉ để đồng bộ, không bắt buộc) |
| `prisma/schema.prisma` | sửa comment mô tả `kind` (không đổi cấu trúc, không cần migrate) |

## Cách chạy
```bash
psql "$DATABASE_URL" -f migrate-production-v140-them-to-thiet-ke.sql
```
Chạy lại vô hại (idempotent). Không cần deploy code cho việc này.

## Kiểm tra sau khi chạy
```sql
SELECT code, name, kind, sort_order, capacity_per_day
  FROM production_work_centers WHERE code IN ('TO_THIET_KE','KY_THUAT') ORDER BY sort_order;
-- TO_THIET_KE | Tổ thiết kế | TO | 5 | NULL
-- KY_THUAT    | Kỹ thuật (Bồi Lares / CAM) | VAN_PHONG | 70 | 60

SELECT code, name, work_center_code FROM production_stages
 WHERE code IN ('THIET_KE','BOI_LARES') ORDER BY seq;
-- THIET_KE  → TO_THIET_KE
-- BOI_LARES → KY_THUAT
```
Vào app: **Kế hoạch sản xuất** → bảng "Tải theo tổ và ngày" sẽ có dòng **Tổ thiết kế**
(kèm dòng con `↳ Thiết kế (bản vẽ CAD)`); dải lọc tổ cũng có "Tổ thiết kế".

## Muốn hoàn tác
```sql
UPDATE production_stages SET work_center_code='KY_THUAT' WHERE code='THIET_KE';
UPDATE production_tasks  SET work_center_code='KY_THUAT' WHERE stage_code='THIET_KE';
UPDATE production_work_centers SET name='Kỹ thuật (Thiết kế + Bồi Lares/CAM)' WHERE code='KY_THUAT';
DELETE FROM production_work_centers WHERE code='TO_THIET_KE';
```
(hay đơn giản hơn: đổi Tổ của dòng `THIET_KE` về `KY_THUAT` ngay trong Cấu hình sản xuất).
