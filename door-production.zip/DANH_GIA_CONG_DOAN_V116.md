# V116 — Đánh giá "QUY TRÌNH TIẾN ĐỘ SẢN XUẤT, CÔNG ĐOẠN ĐƠN HÀNG"

Tài liệu này là **nhận xét về quy trình bạn gửi** (ảnh bảng công đoạn) và **đối chiếu với module Lên kế hoạch sản xuất**
sắp làm (V115). Mục tiêu: trước khi đưa quy trình vào phần mềm, chỉ ra chỗ nào cần chốt/sửa để dữ liệu kế hoạch không bị sai.

---

## 1. Mình đọc được gì từ bảng (xin xác nhận lại)

| # | Tổ | Công đoạn | Thời gian |
|---|---|---|---|
| 1 | TỔ MÁY | Thiết kế | 1 |
| 2 | TỔ MÁY | Bồi Lares | 1 |
| 3 | TỔ MÁY | Cắt Lares khung · Cắt Lares cánh · Cắt phào (3 việc song song) | 1 |
| 4 | TỔ MÁY | Chấn khung · Chấn cánh · Chấn phào (3 việc song song) — *ghi chú: "Cần đầy đủ đơn để đẩy công đoạn kế tiếp"* | 1 |
| 5 | HÀN | Hàn khung · Hàn cánh · Hàn phào | 2 |
| 6 | HÀN | Ép cánh | *(bảng đang để trống)* |
| 7 | HÀN | Test cơ khí | 1 |
| 8 | SƠN | Sơn | 2 |
| 9 | VÂN | Vân khung · Vân cánh · Vân phào | 2 |
| 10 | KHO | Vệ sinh + Đóng gói | 1 |
| 11 | KHO | Kho *(ô ghi chú được khoanh xanh)* | 0 |
| | | **TỔNG** | **12** |

→ **Đây là tiến độ theo ĐƠN** (tiêu đề ghi "đơn hàng"), mỗi công đoạn làm cho **cả bộ cửa** (khung/cánh/phào là 3 việc con).

---

## 2. Đánh giá: làm được gì tốt

1. **Đã chia đúng tổ theo năng lực thiết bị** (Máy → Hàn → Sơn → Vân → Kho). Đây chính là "work center" mà module kế hoạch cần — bạn đã có sẵn, không phải bịa.
2. **Nhận diện đúng 3 luồng song song** khung / cánh / phào. Đây là điểm khó nhất của xưởng cửa và bảng đã thể hiện được → kế hoạch phải xếp theo 3 luồng này chứ không phải chuỗi thẳng.
3. **Có bước "Test cơ khí"** trước khi sơn — đúng chỗ (sửa cơ khí trước khi sơn rẻ hơn nhiều so với sau sơn/vân).
4. **Có ghi chú điều kiện** ("cần đầy đủ đơn để đẩy công đoạn kế tiếp") — đây là **quy tắc gom lô**, thứ mà phần mềm cần biết để không đẩy việc dang dở.
5. **Có tổng thời gian (12)** — nghĩa là bạn đã có khái niệm **lead time chuẩn**; chỉ cần chuẩn hóa đơn vị và tách theo loại cửa.

---

## 3. Mười hai chỗ cần sửa/bổ sung (xếp theo mức ảnh hưởng)

| # | Vấn đề | Vì sao quan trọng | Đề xuất |
|---|---|---|---|
| 1 | **Chưa rõ đơn vị "THỜI GIAN"** — 12 là 12 giờ, 12 ngày làm việc hay 12 ngày lịch? | Sai đơn vị là sai toàn bộ kế hoạch và hạn giao | Ghi rõ **ngày làm việc** ở chân bảng; phần mềm lưu theo **giờ** rồi quy đổi |
| 2 | **Ép cánh (dòng 6) không có thời gian** | Tổng 12 không khớp; nếu ép cánh 1–2 thì lead time thật là 13–14 | Điền thời gian; kiểm tra lại tổng |
| 3 | **Thiếu công đoạn LẮP KÍNH / PHỤ KIỆN** (kính cánh + vách kính, khóa, bản lề, tay nắm) | Trong đơn hàng bạn có "Kính trên cánh + vách kính 8.38", "Khóa tay trúc", phụ kiện… nhưng bảng không có bước lắp ráp | Thêm **"Lắp kính + phụ kiện"** (thường sau Vân, trước Vệ sinh/Đóng gói) |
| 4 | **Thiếu thời gian chờ khô** (sau sơn trước khi vân, sau vân trước khi đóng gói) | Đây là chỗ kế hoạch hay bị trượt nhất: sơn xong chưa khô thì không vân được | Ghi rõ thời gian chờ/thời gian khô cho Sơn và Vân |
| 5 | **Chỉ có 1 điểm kiểm tra chất lượng (Test cơ khí)** | Lỗi phát hiện muộn = làm lại đắt (bạn đang có loại "Đơn làm lại") | Thêm điểm kiểm: sau chấn (kích thước/góc), sau hàn (mối hàn), **trước sơn** (bề mặt), **sau vân** (bề mặt/màu), **trước giao** (nghiệm thu + chống xước) |
| 6 | **"Kho" để 0 thời gian nhưng lại là ô được khoanh xanh** | Không rõ đây là công đoạn hay chỉ là điểm bàn giao; ảnh hưởng mốc "hoàn thành" | Tách rõ: **Hoàn thành sản xuất** (xong đóng gói) và **Đã giao** (xuất kho) — dùng cho chỉ số giao đúng hạn |
| 7 | **Chưa có nhánh xử lý ĐƠN LÀM LẠI / sửa lỗi** | Đơn làm lại phải chen vào giữa quy trình (quay lại đúng công đoạn lỗi) | Ghi quy tắc: làm lại từ công đoạn nào, có ưu tiên chen trước không |
| 8 | **Chưa có năng lực từng tổ** (mấy người, mỗi ngày/tuần làm được bao nhiêu bộ) | Không có con số này thì không biết kế hoạch có khả thi hay quá tải | Điền năng lực/tuần cho 5 tổ (đây là dữ liệu mình đã hỏi ở V115 câu 3) |
| 9 | **Chưa có quy tắc gom lô theo màu sơn / mã vân** | Sơn và Vân chiếm 4/12 thời gian; đổi màu/vân nhiều lần làm chậm cả xưởng | Chốt: gom sơn theo màu, gom vân theo mã vân, mỗi lô tối thiểu bao nhiêu bộ |
| 10 | **"Thiết kế" nằm trong TỔ MÁY và tính 1 đơn vị thời gian** | Thiết kế thường do văn phòng/kỹ thuật làm, không phải tổ máy; và có thể làm trước nhiều ngày | Tách "Thiết kế" khỏi công đoạn xưởng (hoặc đánh dấu là bước chuẩn bị trước khi lên kế hoạch) |
| 11 | **Bảng đang theo ĐƠN, không theo BỘ CỬA** | Xưởng làm theo bộ (đã có Bộ số); trong 1 đơn, các bộ có thể làm xong lệch nhau | Giữ bảng tiến độ **theo bộ**, cộng dồn lên thành % của đơn |
| 12 | **Cột "TIẾN ĐỘ" để ghi tự do** | Trong phần mềm ghi tự do thì không tổng hợp/lọc được | Chuẩn hóa thành **trạng thái**: Chưa làm → Đang làm → Xong (+ ngày bắt đầu/kết thúc), có ô ghi chú riêng |

**Câu hỏi cần bạn xác nhận:** "**Bồi Lares**" là bồi/dán *vân Lares* (film vân gỗ) hay bồi *tấm Lares* (lõi/xốp)? Vì nếu là film vân gỗ thì **"Bồi Lares" (bước 2) và "Vân" (bước 9) đang mô tả cùng một việc ở hai thời điểm** — cần làm rõ thứ tự thật.

---

## 4. Mô hình dữ liệu nên dùng cho công đoạn này trong ERP

Bảng của bạn chính là **danh mục công đoạn + tổ**. Trong phần mềm nên tách thành 3 tầng:

```
work_centers        TỔ MÁY · HÀN · SƠN · VÂN · KHO   (+ năng lực bộ/tuần)
production_stages   Thiết kế · Bồi Lares · Cắt · Chấn · Hàn · Ép cánh · Test cơ khí · Sơn · Vân · Lắp kính-PK · Vệ sinh+Đóng gói
                     └ mỗi dòng: tổ phụ trách, thứ tự, thời lượng chuẩn (giờ), phạm vi (KHUNG/CÁNH/PHAO/BỘ), điểm QC?
production_task_stages   Trạng thái TỪNG CÔNG ĐOẠN cho TỪNG BỘ CỬA
                     └ ngày bắt đầu/kết thúc thực tế, người phụ trách, ghi chú, làm lại?
```

Ba điểm kỹ thuật quan trọng:

1. **Phạm vi (KHUNG / CÁNH / PHAO / BỘ)** — để biểu diễn 3 luồng song song trong bước Cắt/Chấn/Hàn/Vân. Không có trường này thì không biết "khung đã hàn xong hay chưa".
2. **Thời lượng chuẩn theo loại cửa** (cửa đi vách kính, cửa sổ, cửa 2 cánh… khác nhau) — không thể dùng 1 con số 12 cho mọi loại.
3. **Ngày bắt đầu/kết thúc thực tế từng công đoạn**, không chỉ trạng thái — đây là dữ liệu để sau này tính **năng suất thật theo tổ** và **chỗ nào hay trễ**.

---

## 5. Đọc nhanh từ bảng này: đường găng & nút thắt

- **Chuỗi dài nhất (đường găng)**: Thiết kế(1) → Bồi Lares(1) → Cắt(1) → Chấn(1) → Hàn(2) → Ép cánh(?) → Test(1) → Sơn(2) → Vân(2) → Lắp kính/PK(?) → Vệ sinh+Đóng gói(1) ≈ **12–15** đơn vị thời gian.
- **Nút thắt nằm ở SƠN + VÂN**: 4/12 đơn vị (≈ 33%) thời gian nằm ở 2 tổ này. Nếu muốn rút ngắn lead time thì tăng năng lực/lò sơn hoặc gom lô màu — chứ thêm người ở tổ máy không giúp gì.
- **Ghi chú "cần đầy đủ đơn để đẩy công đoạn kế tiếp"** đang tạo chờ ở Tổ Máy: nếu 1 đơn thiếu 1 bộ thì cả đơn đứng. Nên chốt quy tắc: **chốt đủ danh sách bộ trước ngày X** hoặc **cho phép đẩy từng bộ đủ trước**.
- **Cắt/Chấn/Hàn chia 3 luồng** → kế hoạch phải xếp theo tải của từng luồng, không chỉ tổng số bộ.

---

## 6. Việc cần bổ sung vào bảng (bản tối thiểu để đưa vào phần mềm)

```
Thêm 3 cột:  [Phạm vi] (Khung/Cánh/Phào/Bộ)   [Thời lượng (giờ)]   [Điểm kiểm tra chất lượng? Y/N]
Thêm 2 dòng: Lắp kính + phụ kiện   |   Kiểm tra trước khi giao (nghiệm thu, chống xước)
Sửa 3 chỗ:   điền thời gian Ép cánh · ghi rõ đơn vị thời gian · tách "Kho" thành "Hoàn thành sản xuất" và "Đã giao"
Ghi rõ 2 quy tắc: gom lô sơn/vân (tối thiểu bao nhiêu bộ/lô) · điều kiện đầy đủ đơn trước khi chuyển công đoạn
```

---

## 7. Kết luận ngắn

Quy trình của bạn **đúng hướng và dùng được ngay làm nền cho module kế hoạch** — có tổ, có công đoạn, có thứ tự, có tổng thời gian.
Ba việc đáng làm trước khi lập trình:

1. **Chốt đơn vị thời gian + điền thời gian Ép cánh + năng lực từng tổ** (số thật).
2. **Bổ sung 2 công đoạn còn thiếu** (lắp kính/phụ kiện, kiểm tra trước khi giao) và **các điểm QC**.
3. **Chốt quy tắc gom lô sơn/vân** và **quy tắc đủ đơn mới chuyển công đoạn** — hai quy tắc này quyết định thuật toán xếp lịch.


---

## ĐÍNH CHÍNH (V121) — “Bồi Lares”

Nhà máy đã xác nhận: **Bồi Lares KHÔNG phải film vân và cũng không phải tấm lõi**, mà là **công đoạn HẬU THIẾT KẾ — chuyển đổi file thiết kế sang chương trình cho máy cắt chuyên dụng** (bản chất CAM). Vì vậy:

- Bỏ giả thuyết “Bồi Lares trùng với bước Vân”.
- Khi điền bảng công đoạn, thêm cột **Loại công đoạn: GIA_CONG / CHUAN_BI** — Bồi Lares và Thiết kế thuộc nhóm **CHUAN_BI**.
- Bồi Lares tính **theo file/model** (không nhân theo số bộ), có thể **tái sử dụng** (≈ 0 nếu chương trình đã có) và là **ràng buộc bắt buộc trước khi Cắt**.

Chi tiết + 8 câu hỏi mới: `dp/BOI_LARES_V121.md`.
