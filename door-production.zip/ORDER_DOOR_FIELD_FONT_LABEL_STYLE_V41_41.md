# V41.41 – Thu nhỏ font trong ô nhập và thêm nền cho tên trường

## Mục tiêu
Cải thiện trải nghiệm nhập liệu ở phần **Bộ cửa** và panel chỉnh sửa **Phụ kiện / Chi tiết**:
- Giảm cỡ chữ trong các ô nhập để giao diện gọn hơn.
- Giảm chiều cao input/select để bớt chiếm diện tích.
- Thêm nền nhạt cho các tên trường (label) để dễ quét mắt.

## Thay đổi chính
### 1) Ô nhập gọn hơn
Áp dụng cho các field card chính và phần chỉnh sửa phụ kiện:
- `input/select` từ `h-10` -> `h-9`
- font trong ô từ `13px` -> `12px`
- giảm padding ngang để ô nhìn gọn hơn

### 2) Tên trường có nền
`CardField` được đổi label sang dạng badge nhỏ:
- nền `slate-100`
- border `slate-200`
- chữ `10px`
- bo góc nhẹ
- field nhấn mạnh vẫn có tone cyan nhạt

### 3) Các control chọn model / nhóm / đơn giá đồng bộ lại
Các control dùng trong `CardSelectShell`, `GridInput`, `GridGroupSelect`, `GridCatalogSelect`, `GridNumber`, `GridPriceInput` đã được đồng bộ theo kiểu compact hơn.

## File thay đổi
- `src/components/order-form.tsx`
