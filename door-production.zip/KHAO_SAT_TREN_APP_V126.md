# V126 — Đưa bộ câu hỏi khảo sát lên app (nhà máy điền & lưu trên app)

Nhà máy mở trang **Khảo sát nhà máy** trên app, điền trực tiếp, câu trả lời **lưu vào database**; khi xong bấm **xuất file** gửi lại để lên phương án thiết kế module.

**Trang:** `/khao-sat` (menu **Công cụ → Khảo sát nhà máy**)
**Nội dung khảo sát:** 230 câu — lấy từ bộ câu hỏi V125 (PHẦN A–J + bảng K/L/M + 3 câu góp ý), chia 14 phần theo tổ/công đoạn, mỗi câu có mức **P1** (bắt buộc) / **P2**.

---

## 1. Cách nhà máy dùng

1. Mở app → **Công cụ → Khảo sát nhà máy**.
2. Ghi **Người trả lời (tên + tổ)** ở ô trên cùng — mỗi câu trả lời sẽ được ghi kèm tên này.
3. Chọn phần của mình ở dải nút: **A** (7 câu chặn) · **B** (phạm vi & điều kiện) · **C** (tổ máy: thiết kế, Bồi Lares, cắt, chấn) · **D** (tổ hàn) · **E** (tổ sơn) · **F** (tổ vân) · **G** (lắp kính + phụ kiện) · **H** (tổ kho) · **I, J** (người lên kế hoạch) · **K/L/M** (bảng điền) · **O** (góp ý).
4. Gõ trả lời → **tự động lưu sau ~1 giây** (thẻ “Tình trạng lưu” hiện *Đã lưu lúc hh:mm*). Đóng máy giữa chừng không mất.
5. Bộ lọc hữu ích: **Chỉ câu P1** (câu bắt buộc) · **Chưa trả lời** (để biết còn thiếu gì) · ô **tìm trong câu hỏi**.
6. Xong thì bấm:
   - **Xuất file gửi Zentor (.md)** — file gọn, đúng thứ tự phần/câu, có cả danh sách **câu P1 còn thiếu** → gửi lại cho Zentor đọc và lên phương án.
   - **Xuất Excel** — 3 sheet: *Tổng hợp* (mã · câu hỏi · trả lời · ai trả lời · lúc nào) · *P1 còn thiếu* · *Tiến độ theo phần*.
   - **In / Lưu PDF** — để lưu bản giấy nếu cần.

---

## 2. Cài đặt (BẮT BUỘC làm migration TRƯỚC khi deploy code)

> ⚠️ Đây đúng bài học V112: code mới mà DB chưa có bảng `survey_answers` thì trang khảo sát sẽ lỗi 500.

**Bước 1 — chạy migration** (chọn 1 trong 2 cách):

```bash
# Cách A (khuyến nghị): từ thư mục dự án
npx prisma migrate deploy
```

```sql
-- Cách B: dán vào Supabase → SQL Editor
CREATE TABLE "survey_answers" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(20) NOT NULL,
    "answer" TEXT,
    "choice" VARCHAR(40),
    "updated_by" VARCHAR(120),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "survey_answers_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "survey_answers_code_key" ON "survey_answers"("code");
```

Nếu dùng cách B thì chạy thêm để Prisma không báo lệch lịch sử:
```bash
npx prisma migrate resolve --applied 20260925160000_survey_v126
```

**Bước 2 — deploy code** (Vercel như bình thường).
**Bước 3 — kiểm tra**: mở `/khao-sat`, gõ thử 1 câu, xem thẻ “Đã lưu lúc …” hiện lên.

---

## 3. Câu trả lời lưu ở đâu

Bảng `survey_answers` — mỗi câu 1 dòng: `code` (A1, BL3, K5, L2, M7…), `answer` (trả lời tự do), `choice` (lựa chọn Cần/Không, Có/Không/Thiếu thông tin), `updated_by` (tên + tổ), `updated_at`.

- Mỗi lần lưu: **1 lượt ghi duy nhất** cho cả bảng bằng `INSERT … ON CONFLICT DO UPDATE` (bài học V111: DB remote mỗi lượt ~50–100 ms nên không ghi từng dòng).
- Chỉ lưu câu **có thay đổi** (diff), tự lưu sau 1,2 giây ngừng gõ, và lưu lần cuối khi rời trang.
- Trả lời **rỗng** thì không ghi đè giá trị cũ.

---

## 4. File đã thêm/sửa

| File | Việc |
|---|---|
| `prisma/schema.prisma` | Thêm model `SurveyAnswer` |
| `prisma/migrations/20260925160000_survey_v126/migration.sql` | Tạo bảng `survey_answers` |
| `src/lib/survey-questions.ts` | Danh mục **230 câu** (sinh tự động từ bộ V125) — sửa câu hỏi ở đây |
| `src/app/api/survey/route.ts` | `GET` tải câu trả lời · `POST` lưu (1 lượt ghi/bảng) |
| `src/app/api/survey/export/route.ts` | `GET ?format=xlsx` hoặc `?format=md` |
| `src/app/khao-sat/page.tsx` | Trang khảo sát |
| `src/components/survey-form.tsx` | Form điền + tự lưu + tiến độ + lọc P1/chưa trả lời + nút xuất |
| `src/components/erp-nav.tsx` | Menu “Khảo sát nhà máy” |

## 5. Chưa có / làm sau (đã biết)

- **Chưa có đăng nhập**: ai có link cũng mở và sửa được (hiện 1 tài khoản dùng chung). Ai sửa câu nào thì vẫn biết nhờ cột `updated_by` — nhưng không chống được người khác sửa hộ.
- Máy tính bảng/điện thoại dùng được (bố cục 1 cột), nhưng nhập nhiều câu nên dùng máy tính cho nhanh.
- Sửa câu hỏi: sửa `src/lib/survey-questions.ts` (hoặc sửa script `dp/scripts/v125` rồi sinh lại) — câu trả lời cũ vẫn giữ theo `code`.
- Sau khi có câu trả lời: Zentor đối chiếu với bảng **MẶC ĐỊNH** (V125 phần N) và **11 quyết định nội bộ** (V124) để chốt thiết kế trước khi viết migration cho module kế hoạch.

---

## V127 — Sửa bố cục theo yêu cầu: liệt kê tất cả câu hỏi, mỗi câu 1 dòng

- **Liệt kê toàn bộ 230 câu** trên một trang (bỏ kiểu bấm chọn từng phần như trước); đầu trang có dải nút nhảy nhanh tới từng phần kèm tiến độ (`C · 1/37`) và chip lọc **Tất cả / Chỉ câu P1 / Chưa trả lời** + ô tìm kiếm.
- **Mỗi câu 1 dòng**: bên trái là `mã câu · mức P1/P2 · nội dung câu hỏi` (cắt gọn, di chuột xem đầy đủ nội dung + lý do hỏi + ai trả lời lúc nào), **bên phải là ô trả lời** (ô nhập 1 dòng; câu dạng lựa chọn thì hiện nút chọn + ô ghi chú cùng dòng).
- Câu đã trả lời có **dấu ✓** xanh; tự động lưu vẫn giữ nguyên (ngừng gõ ~1 giây là lưu).
- Thêm **nhắc nhở**: nếu chưa ghi tên người trả lời thì hiện cảnh báo vàng — để mỗi câu luôn biết ai điền.
- Đúng bố cục này: chiều cao trang giảm mạnh, nhà máy nhìn một màn là thấy hết việc phải trả lời.

Ảnh: `artifacts/v127-khao-sat-1dong.png` (toàn trang) · `v127-xem-dau-trang.png` (phần đầu).
