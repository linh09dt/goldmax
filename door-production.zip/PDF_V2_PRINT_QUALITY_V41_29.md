# V41.29 - PDF V2 print quality + near-edge width

Chỉ thay đổi trình xuất PDF V2 ReportLab.

- Lề trái/phải: 4 mm -> 2 mm để tận dụng gần hết chiều ngang A4 landscape.
- Chữ body chuyển sang màu gần đen (#111111) để in rõ hơn.
- Chữ phụ/secondary chuyển từ xám nhạt sang xám đậm (#374151).
- Dòng chi tiết/phụ kiện bỏ italic xám nhạt, dùng GM-Regular màu đậm để in rõ.
- Dòng sản phẩm chính và số liệu quan trọng vẫn dùng GM-Bold thật.
- Meta header: nhãn regular đậm màu hơn, giá trị dùng GM-Bold gần đen.
- Viền bảng/meta/checklist/summary tăng độ đậm nhẹ để bản in sắc nét hơn.
- Footer tăng độ đậm đường phân cách.

Không thay đổi dữ liệu, giá, logic tính toán, pagination, hình ảnh, API hoặc binary response.
