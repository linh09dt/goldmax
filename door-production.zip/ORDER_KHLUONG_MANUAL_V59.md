# ORDER KH/LƯỢNG MANUAL V59

## Mục tiêu
Trong tab tạo đơn hàng: **KH/Lượng cho phép sửa bằng tay ở tất cả sản phẩm hàng hóa** (cả dòng Bộ cửa lẫn dòng Phụ kiện / Chi tiết). Trước đây dòng nào có rule trong Cấu hình tính toán thì ô KH/Lượng bị khoá (nền xanh nhạt, `readOnly`).

## Cách làm
1. **Bỏ khoá giao diện**: 2 ô KH/Lượng thôi truyền `readOnly` / `autoCalculated` → ô nhập bình thường (nền trắng) ở mọi dòng.
2. **Giá trị nhập tay được giữ**: thêm cờ `pricingManual?: string` (chỉ dùng ở giao diện, **không lưu DB**) vào `OrderLineForm`:
   - `updateMain` / `updateDetail`: khi người dùng sửa đúng ô `pricingQuantity` → đánh dấu `pricingManual = "1"` cho dòng đó.
   - `recalculateAutomaticPricingQuantity`: bỏ qua dòng đã đánh dấu → công thức tự động **không ghi đè** giá trị nhập tay (khi đổi Cao/Rộng/Khuôn, sửa ghi chú…).
   - `applyMainCatalog` / `applyDetailCatalog`: **đổi Model thì xoá đánh dấu** để KH/Lượng tự tính lại theo cấu hình cho sản phẩm mới.
3. Dọn phần nay không dùng: bỏ 2 biến `mainAutomaticPricing` / `automaticPricing` cùng 2 khối `resolveCalculationRule` chỉ để tính cờ khoá, bỏ prop `calculationConfig` không còn dùng ở `DoorSetCard` và `DetailMasterRow`.

## Không thay đổi
- Công thức tính KH/Lượng tự động (DOOR_AREA, TRIM_LINEAR, PANEL_COUNT, PARENT_QUANTITY) và Cấu hình tính toán.
- Thành tiền / tổng tiền đơn hàng, DB/Prisma (không cần migration), API, Excel/PDF.
- Trường `pricingManual` là cờ giao diện, API lưu đơn chỉ map các trường có tên trong `normalizeLine` nên không lọt vào DB.

## Kiểm chứng thực tế (Postgres + dev server + trình duyệt)
Seed 1 cửa `GM1-H2` (Nhóm “Cửa Đi 1 Cánh”, ĐVT m2) và 1 mã phào `PR-01` (Nhóm “Phào mặt trong”):
- **Dòng Bộ cửa**: chọn Model → nhập Cao 2750, Rộng 2650 → KH/Lượng tự điền `7.2875` (đúng công thức DOOR_AREA). Ô nhập `readOnly = false`, nền trắng (trước là nền xanh khoá).
  - Nhập tay `5.5` → đổi Cao sang 2800 → KH/Lượng **vẫn 5.5**; sửa ô Ghi chú → **vẫn 5.5**.
  - Chọn lại Model → cờ nhập tay được xoá → KH/Lượng tự tính lại `7.42` (= 2800 × 2650 / 1.000.000).
- **Dòng Phụ kiện**: Nhóm “Phào mặt trong” + Model `PR-01` → nhập Cao 2750, Rộng 2650 → KH/Lượng `8.15` (đúng TRIM_LINEAR). Nhập tay `9.9` rồi đổi Rộng sang 2700 → **vẫn 9.9**.
- Ảnh: `khl_editable_manual.png`.
- `npx tsc --noEmit`: pass. `npx eslint`: `order-form.tsx` đúng mức nền cũ (4 error + 11 warning), không phát sinh mới.

## Lưu ý còn lại
Cờ `pricingManual` chỉ sống trong phiên đang nhập, **không lưu DB**. Vì vậy khi **mở lại một đơn đã lưu để sửa**, KH/Lượng vẫn được tính lại theo Cấu hình tính toán như hành vi cũ (V42/V43). Nếu muốn giá trị nhập tay giữ nguyên cả sau khi mở lại đơn thì cần bổ sung (giữ giá trị đã lưu thay vì tính lại khi load).
