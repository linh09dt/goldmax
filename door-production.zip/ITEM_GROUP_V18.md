# ERP V18 — Nhóm Danh mục hàng hóa theo TENHANG

## Mục tiêu

Tab **Danh mục hàng hóa** mặc định nhóm các MODEL có cùng `TENHANG` vào một nhóm chung để tránh lặp tên hàng nhiều dòng.

Ví dụ:

- Cửa Đi 1 Cánh — 11 MODEL
  - GM1-H1
  - GM1-H2
  - GM1-H3
  - ...
- Cửa Đi 2 Cánh — ... MODEL
- Cửa Đi 4 Cánh — ... MODEL

## Chức năng

- Mặc định bật **Nhóm theo TENHANG**.
- Nhóm không phân biệt khoảng trắng thừa và chữ hoa/thường.
- Mỗi nhóm hiển thị số MODEL.
- Có nút `+ / −` để mở/thu gọn từng nhóm.
- Có `Mở tất cả` và `Thu gọn`.
- Có thể chuyển về danh sách phẳng bằng nút `Đang nhóm theo TENHANG`.
- Khi tìm kiếm, các nhóm có kết quả tự mở để thấy MODEL phù hợp.
- Sửa/Xóa, ĐVT, Giá đại lý, Giá bán lẻ, Tên sản phẩm diễn giải và Trạng thái giữ nguyên.
- Không thay đổi database và không ảnh hưởng liên kết Đơn hàng.

## Cài đặt

Chép patch chồng lên V17 hiện tại, sau đó:

```cmd
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần migrate database.
