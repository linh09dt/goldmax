# ERP V26.1 — Tinh gọn Theo dõi doanh thu

Theo đánh dấu trên ảnh của người dùng:

- Giữ các dòng tổng hợp theo từng đơn hàng.
- Bỏ dòng Tổng màu vàng nằm trong bảng.
- Bỏ toàn bộ bảng chi tiết sản phẩm dưới từng đơn.
- Bỏ cột Ghi chú khỏi bảng doanh thu.
- Giữ các KPI tổng ở đầu trang và các cột tài chính của từng đơn.
- Không thay đổi công thức doanh thu, chiết khấu, đặt cọc hay còn lại.
- Không thay đổi database.
