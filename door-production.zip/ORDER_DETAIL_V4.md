# Đơn hàng ERP V4 — Hiển thị dòng chi tiết theo từng bộ cửa

## Mục tiêu

Sửa màn hình chi tiết đơn hàng để các dòng phụ kiện / phụ phí nằm ngay dưới đúng bộ cửa tương ứng và chỉ hiện các dòng thực sự có dữ liệu.

## Logic mới

- Dòng sản phẩm chính vẫn hiển thị ở đầu mỗi bộ cửa.
- Ngay phía dưới có nhóm **Chi tiết / phụ kiện / phụ phí của bộ cửa**.
- Chỉ hiện dòng có dữ liệu thực tế.
- Các dòng mẫu rỗng chỉ có `0`, `-`, `—`, `#N/A` hoặc dòng `Khác` chưa nhập sẽ không hiện.
- Các dòng như Phào Rời, Phào LUX, Khóa, khoét Pano, khoét kính, phụ phí... sẽ hiện khi có mã, kích thước, số lượng, đơn vị, đơn giá, ghi chú hoặc dữ liệu liên quan.

## Tương thích đơn đã import trước đây

Bản này không yêu cầu migration database.

Đơn được import bằng V1/V2 mà bảng `sales_order_item_details` chưa có dữ liệu vẫn hiển thị được vì hệ thống tự đọc lại `rawBlock` đã lưu từ lần import cũ.

Nếu import lại đúng file Excel cũ:

- Nếu detail đã đầy đủ: bỏ qua file trùng.
- Nếu detail đang thiếu hoặc số dòng không đúng: tự rebuild detail và ghi lịch sử `REBUILT_DETAILS`.

## File thay đổi

- `src/lib/order-detail.ts` — mới
- `src/lib/order-excel.ts`
- `src/app/orders/[id]/page.tsx`
- `src/app/orders/[id]/edit/page.tsx`
- `src/app/api/orders/import/route.ts`
- `src/components/order-import.tsx`

## Cài đặt

Giải nén patch chồng lên source hiện tại rồi chạy:

```cmd
npm run dev
```

Không cần chạy `prisma migrate` vì không đổi schema.

## Khuyến nghị sau khi cập nhật

Mở lại đơn hàng cũ. Detail sẽ hiển thị ngay từ `rawBlock`.

Để ghi các detail này thành dữ liệu chuẩn vào `sales_order_item_details`, có thể:

1. Import lại đúng file Excel cũ; hệ thống sẽ tự phát hiện thiếu detail và rebuild, hoặc
2. Mở **Chỉnh sửa đơn** rồi **Lưu thay đổi**.
