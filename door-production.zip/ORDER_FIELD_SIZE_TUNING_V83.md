# CHỈNH KÍCH THƯỚC Ô NHẬP — VÒNG 2 (V83)

## 8 ô người dùng đổi (các ô khác giữ nguyên, tổng % không đổi)

| Khối | Ô | % mới | Trước | px @1920 |
| --- | --- | --- | --- | --- |
| A | Trạng thái | **12.4** | 13.4 | 196 |
| A | Mã Đại Lý | **5.6** | 4.6 | 89 |
| B | Bộ số | **5.4** | 7.4 | 85 |
| B | TT Cao | **4.3** | 4.9 | 68 |
| B | TT Rộng | **4.3** | 4.9 | 68 |
| B | SL bộ | **3.3** | 2.1 | 52 |
| B | ĐVT | **3.0** | 3.6 | 47 |
| B | Đơn giá | **7.5** | 4.9 | 115 |

## Bảng kích thước hiện tại @1920

**A. Thông tin đơn hàng (13 ô)**
Mã đơn 127 · Trạng thái **196** · Ngày cập nhật 108 · NVKD 114 · Mã Đại Lý **89** · Tên khách hàng 144 · Ngày đặt hàng 108 · Ngày cần giao 114 · Người nhận 108 · Số điện thoại 101 · Địa chỉ nhận hàng 180 · Vùng miền 74 · Số Km 49

**B. Bộ cửa (17 ô)**
Bộ số **85** · Nhóm cửa 142 · Model 236 · Ô thoáng 61 · Hướng mở 61 · Phào 77 · Màu sơn 77 · Cao 68 · Rộng 68 · Khuôn 68 · TT Cao **68** · TT Rộng **68** · SL bộ **52** · ĐVT **47** · KH/L 77 · Đơn giá **115** · Thành tiền 88

**C. Phụ kiện / chi tiết (10 ô)** — giữ như V82
Nhóm hàng 129 · Model 541 · Cao/Rộng/Khuôn 65 · ĐVT 55 · KH/Lượng 122 · Đơn giá 108 · Thành tiền 126 · Ghi chú 156

## Mức sàn (chỉ tác dụng ở màn hẹp, KHÔNG ảnh hưởng 1920)

`Model ≥168px · Mã Đại Lý ≥52px · Ô thoáng ≥56px · Hướng mở ≥46px · TT Rộng ≥46px · ĐVT ≥34px · SL bộ ≥30px`
— thêm sàn cho TT Rộng và ĐVT vì ở màn 1366 trở xuống nhãn 2 ô này bị “…” khi chỉ dùng %.

## Kiểm chứng

| Khổ màn | Nhãn bị “…” |
| --- | --- |
| **1920 (mốc)** | **0** |
| 1536 | 0 |
| 1366 | 0 |
| 1280 | 3 (Khuôn, TT Cao, Thành tiền) |

`npx tsc --noEmit` 0 lỗi · `next build` thành công · không tràn ngang.

## File thay đổi
- `src/components/order-form.tsx`
