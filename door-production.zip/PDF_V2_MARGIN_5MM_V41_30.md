# PDF V2 Margin 5mm – V41.30

## Yêu cầu
- Tăng lề trái/phải của PDF V2 từ **2 mm** lên **5 mm mỗi bên**.
- Giữ nguyên các cải tiến trước đó về:
  - font in đậm/normal rõ hơn,
  - bố cục full-width,
  - chất lượng in đẹp hơn.

## Thay đổi thực hiện
### File sửa
- `python/reportlab_order_v2.py`

### Nội dung sửa
- Đổi:
  - `LEFT = RIGHT = 2 * mm`
- Thành:
  - `LEFT = RIGHT = 5 * mm`

### Giữ nguyên
- `TOP = BOTTOM = 10 * mm`
- Toàn bộ logic layout, style và render còn lại.

## Kết quả
- PDF V2 khi in sẽ có lề trái/phải **5 mm mỗi bên**.
- Nội dung vẫn tận dụng gần tối đa chiều ngang trang A4 landscape nhưng chừa lề hợp lý hơn để in thực tế.
