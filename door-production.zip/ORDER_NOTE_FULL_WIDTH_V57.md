# ORDER NOTE FULL WIDTH V57

## Mục tiêu
Theo bản vẽ tay: **hộp ghi chú trải hết chiều ngang trang**, nằm **dưới box tiền** (box tiền vẫn co lại ở phần bên phải). Trước đó hộp ghi chú chỉ rộng 60% nằm lệch trái.

## Đối chiếu bản vẽ
Đo trực tiếp các đường kẻ trong ảnh sketch:
- Box tiền: `x 726 → 1094` (phần bên phải), cao `y 18 → 140`, 5 dòng (có dòng chiết khấu).
- Hộp ghi chú: `x 9 → 1094` — **bằng đúng chiều ngang trang**, nằm dưới (`y 179 → 295`).
→ Kết luận: cần cho hộp ghi chú rộng full chiều ngang, giữ vị trí dưới box tiền.

## File sửa
1. `python/reportlab_order_v2.py` — `_footnote_block()`: `colWidths=[CONTENT_W]` (trước là `CONTENT_W * 0.60`).
2. `python/reportlab_order_preview.py` — tương tự.
3. `src/lib/order-export-v2.ts` — `writeSummary`: vùng ghi chú đổi từ **A→K** sang **A→S** (hết chiều ngang vùng in), chiều cao dòng vẫn ước lượng theo độ dài (ngưỡng 200 ký tự/dòng vì A→S rộng ~202 đơn vị ≈ 270 ký tự ở 8pt).

## Không thay đổi
- Kiểu hộp (nền nhạt `#F8FAFC`, viền `#C9D5E3`, chữ 8pt/7.2pt xám, “Ghi chú:” + “Khách hàng xác nhận các thông tin sau:” in đậm), nội dung ghi chú.
- Vị trí box tiền (bên phải), công thức tiền, quy tắc ẩn dòng “Tổng tiền sau chiết khấu” khi 0% (V51), không xuất bảng checklist (V52).

## Kiểm chứng thực tế
- **PDF V2** (render 2.6x, trang rộng 2189px): hộp ghi chú `x 54 → 2165` = **hết chiều ngang**, `y 405 → 604` = nằm dưới; box tiền navy `x 1450 → 2165`, `y 280 → 324` → mép phải hộp ghi chú trùng mép phải box tiền, đúng như bản vẽ.
- **Excel V2**: đọc lại file → cả 6 dòng ghi chú merge `A:S`, `fill = FFF8FAFC`, có border, chiều cao 13; convert sang PDF bằng LibreOffice ở chế độ headless rồi trích text → đủ nguyên câu (kể cả đoạn dài kết thúc “…khi đã chốt cọc sx.”), không bị cắt; có dòng chiết khấu 12% và “Tổng tiền sau chiết khấu”, không có `BẢNG CHECKLIST`.
- `npx tsc --noEmit`: pass. `python -m py_compile`: OK.
