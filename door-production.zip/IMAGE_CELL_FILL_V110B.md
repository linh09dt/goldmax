# V110b — Ảnh SP lấp đầy ô khi xuất file (Excel V1/V2 + PDF)

## Hiện tượng

> “Lấy ảnh chuẩn từ tool bỏ vào nhưng xuất ra vẫn nhỏ lắm, chưa full view ô được.”

Ảnh trong cột **Hình ảnh SP** chỉ chiếm ~70% bề rộng ô vì code **vẽ ảnh với kích thước cứng**, không tính theo ô:

| Nơi | Trước | Ô chứa | Ảnh chiếm |
|---|---|---|---|
| Excel V1 | 82 × 48 px | cột T ≈ 117 px | 70% |
| Excel V2 | 58 × 36 px | cột S ≈ 82 px | 71% |
| PDF | 11,00 mm | cột 16,35 mm | 67% |

Tệ hơn: kích thước cứng còn **bóp méo ảnh không đúng tỉ lệ khung** (ảnh 2:1 bị ép thành 1,71; ảnh dọc bị ép ngang), và dòng đầu mỗi bộ cửa bị **ép cao 43pt (V1) / 34pt (V2)** bất kể ảnh lớn nhỏ — nên ảnh nhỏ nằm lọt thỏm trong dòng cao.

## Cách sửa

**Excel (V1 + V2)** — module mới `src/lib/excel-image-cell.ts`, dùng cho cả hai bản xuất:

1. **Ảnh rộng hết bề rộng cột** (trừ lề 4 px mỗi bên): V1 → 109 px, V2 → 74 px.
2. **Nới dòng đầu của bộ** vừa đủ để ảnh đúng tỉ lệ nằm gọn (trần 90 px), thay cho việc ép cứng 43pt/34pt. Khối nhiều dòng (bộ cửa + phụ kiện) thường đã đủ cao nên **không đổi chiều cao dòng**.
3. **Giữ đúng tỉ lệ thật** của ảnh (`contain`, canh giữa cả ngang lẫn dọc). Tỉ lệ đọc trực tiếp từ buffer ảnh — thêm `readJpegSize` vào `src/lib/png-size.ts` (module này trước chỉ đọc được PNG). Ảnh không đọc được kích thước (vd. WEBP) thì dùng 5:3.
4. **Neo bằng EMU tuyệt đối** (`nativeCol/nativeColOff/nativeRow/nativeRowOff`) thay vì dạng phân số `{col, row}`: ExcelJS quy đổi dạng phân số bằng đơn vị riêng — 1 cột = `width × 10000` EMU (chỉ ~16,8 px cho cột rộng 16 ký tự, trong khi cột thật ~117 px) và 1 pt = 10000 EMU (thay vì 12700) — nên mọi khoảng lệch bị **nén ~7 lần theo cột và ~1,27 lần theo dòng**. Dùng EMU tuyệt đối cho ra đúng vị trí trong Excel và mọi trình đọc OOXML khác.

**PDF** — `python/reportlab_order_v2.py`: bề rộng ảnh lấy đúng bề rộng cột `HÌNH ẢNH SP` trừ padding (11 mm → **14,94 mm**), `kind="proportional"` giữ nguyên tỉ lệ. Thumbnail vẫn tối đa 240 px → in ở 14,94 mm vẫn ~408 dpi nên không mất nét.

## Kiểm chứng (chạy thật, không đoán)

**a) Hình học trong file Excel** — mở file xuất ra, soi trực tiếp `xl/drawings/drawing1.xml`:

```
Excel V1 (cột T = 117 px):
  bộ 1 (3 dòng, khối 104 px): ảnh 109 × 65 px | lề trái 4,0 px | lệch trên 19,5 px (đúng tâm khối)
  bộ 2 (1 dòng, dòng được nới 28pt → 46,88pt = 62,5 px): ảnh 109 × 55 px | lề trái 4,0 px | lệch trên 3,8 px
Excel V2 (cột S = 82 px):
  bộ 1: ảnh 74 × 44 px | lề trái 4,0 px | lệch trên 30,7 px
  bộ 2: ảnh 74 × 37 px | lề trái 4,0 px | lệch trên 4,0 px
bộ cửa không có ảnh: không nhúng ảnh, giữ hyperlink “Xem ảnh” (đúng)
```

**b) Render thật bằng LibreOffice → PDF, đo lại khung đặt ảnh trong PDF:**

| | Trước | Sau |
|---|---|---|
| Ảnh 5:3 | 33,0 × 20,5 pt (tỉ lệ 1,611 — **méo**) | **42,2 × 25,1 pt** (tỉ lệ 1,683 = đúng 5:3) |
| Ảnh 2:1 | 33,0 × 20,5 pt (tỉ lệ 1,611 — **méo, bị ép**) | **42,2 × 21,1 pt** (tỉ lệ 2,001 = đúng 2:1) |

→ ảnh rộng hơn **+28%** (diện tích +64%) và **hết méo**. Ảnh: `anh-sp-truoc-sau.png`.

**c) PDF (reportlab) — dựng PDF thật từ `build_order_pdf`:**

```
cột HÌNH ẢNH SP = 16,35 mm | ảnh mới = 14,94 mm (91% bề rộng cột) | trước = 11,00 mm (65%)
số trang PDF: 1 → 1 (không phát sinh trang mới)
```

**d) Mã:** `npx tsc --noEmit` → 0 lỗi · `npx eslint` các file mới/sửa → không phát sinh lỗi mới (`order-export.ts` + `order-export-v2.ts` vẫn đúng 14 lỗi `no-explicit-any` như baseline) · `npm run build` → **Compiled successfully**, `/cong-cu-anh` vẫn prerender tĩnh.

## File thay đổi

- `src/lib/excel-image-cell.ts` — **mới**: tính kích thước/neo ảnh cho ô Excel (lấp đầy ô, giữ tỉ lệ, nới dòng khi cần, neo EMU tuyệt đối).
- `src/lib/png-size.ts` — thêm `readJpegSize` + `readImageSize` (đọc kích thước PNG **và** JPEG để biết tỉ lệ thật).
- `src/lib/order-export.ts` — dùng module trên; bỏ ext cứng 82×48 và dòng ép 43pt.
- `src/lib/order-export-v2.ts` — dùng module trên; bỏ ext cứng 58×36 và dòng ép 34pt.
- `python/reportlab_order_v2.py` — `_product_image_max_width_mm()` thay cho hằng số 11 mm.

## Lưu ý

- Dòng đầu của bộ cửa **chỉ bị nới khi cần** cho ảnh vừa ô: bộ có phụ kiện (khối cao) giữ nguyên 28pt/29pt như cũ; bộ chỉ 1 dòng hàng thì dòng đó cao ~47pt (V2) / ~55pt (V1) để ảnh lấp đầy ô.
- Ảnh chuẩn hóa 5:3 là tối ưu (khớp cả 2 khung Excel lẫn PDF). Ảnh tỉ lệ khác vẫn **không bị méo** nữa, chỉ để trống thêm một chút trong ô.
- Không đổi schema DB, không đổi API upload, không đụng logic giá/KH-Lượng.
