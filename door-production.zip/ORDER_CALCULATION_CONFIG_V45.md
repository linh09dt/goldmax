# ORDER CALCULATION CONFIG V45

## Mục tiêu

Mở rộng **Cấu hình tính toán** để tự động tính **Đơn giá Bộ cửa theo Khuôn**, đồng thời giữ nguyên các rule KH/Lượng và đề xuất input của V44.

## Nguồn giá gốc

- Chỉ lấy **Giá đại lý** của Model cửa từ Master Data.
- Không dùng Giá bán lẻ để fallback.
- Khi đổi Model cửa, hệ thống lấy lại Giá đại lý rồi cộng phụ thu Khuôn.
- Khi đổi Khuôn, hệ thống tính lại Đơn giá.
- Người dùng vẫn có thể sửa tay Đơn giá; hệ thống chỉ tính lại tự động khi đổi Model/Khuôn hoặc khi tạo đơn mới có đủ dữ liệu.
- Không tự ghi đè hàng loạt giá snapshot của đơn cũ khi chỉ mở màn chỉnh sửa.

## Làm tròn Khuôn

Mặc định làm tròn về bội số **10 mm gần nhất** trước khi tính phụ thu:

`Khuôn tính giá = ROUND(Khuôn nhập / 10) × 10`

Ví dụ:

- 143 -> 140
- 145 -> 150
- 176 -> 180
- 245 -> 250
- 254 -> 250
- 255 -> 260

Nấc làm tròn có thể thay đổi trong Cấu hình tính toán.

## Công thức phụ thu mặc định

Sau khi làm tròn Khuôn:

1. `Khuôn <= 140 mm` -> phụ thu `0 đ/m²`.
2. `140 < Khuôn < 180 mm` -> mỗi `10 mm` vượt 140 cộng `10.000 đ/m²`.
3. `180 <= Khuôn <= 250 mm` -> phụ thu cố định `110.000 đ/m²`.
4. `Khuôn > 250 mm` -> `110.000 đ/m²` + mỗi `10 mm` vượt 250 cộng tiếp `10.000 đ/m²`.

`Đơn giá cửa = Giá đại lý gốc + Phụ thu Khuôn`

Ví dụ:

- Giá đại lý `3.050.000`, Khuôn `210` -> `3.160.000`.
- Giá đại lý `2.160.000`, Khuôn `245` -> làm tròn `250` -> `2.270.000`.
- Khuôn `255` -> làm tròn `260` -> phụ thu `120.000`.

## Các giá trị có thể cấu hình

Trong menu **Cấu hình tính toán**:

- Bật/tắt tự động tính giá theo Khuôn.
- Nấc làm tròn Khuôn.
- Mốc Khuôn thường tiêu chuẩn.
- Mốc bắt đầu Khuôn kép.
- Mốc kết thúc vùng phụ thu khuôn kép cố định.
- Nấc tăng phụ thu.
- Phụ thu mỗi nấc khuôn thường.
- Phụ thu cố định khuôn kép.
- Phụ thu mỗi nấc vượt khuôn kép.

Cấu hình tiếp tục lưu trong `system_settings`, key `ORDER_CALCULATION_CONFIG_V1`. Không cần Prisma migration.

## Logic V44 giữ nguyên

- KH/Lượng Bộ cửa = `Cao × Rộng / 1.000.000`.
- Phào/Phao = `(Cao × 2 + Rộng) / 1.000`.
- Ô thoáng: `1TK/2TK/3TK -> 1/2/3`.
- Khóa = SL bộ cửa cha.
- Phào rời/Phào biệt thự tiếp tục dùng rule đề xuất Cao/Rộng đã cấu hình.
- KH/Lượng mặc định làm tròn 2 chữ số thập phân.
