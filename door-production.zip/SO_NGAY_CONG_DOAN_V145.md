# V145 — CÔNG ĐOẠN DÙNG **SỐ NGÀY** (bỏ "số giờ")

> Chốt với xưởng 26/09/2026: cột thời lượng của công đoạn ghi thẳng **SỐ NGÀY**, không còn "giờ".
> Lý do: cột cũ `lead_time_hours` phải chia cho "giờ-ngày" (số ca × giờ/ca = 2 × 8 = 16) mới ra ngày,
> nên **8 giờ và 16 giờ đều ra 1 ngày** — nhập xong không biết đúng hay sai.

---

## 1. Quy tắc mới (đúng như bạn mô tả)

| Việc | Cách tính |
|---|---|
| Số ngày của công đoạn | **chính cột `Số ngày`** trong Cấu hình → Công đoạn (không chia, không quy đổi) |
| Bước 10 (Thiết kế) | bắt đầu **ngày 1** |
| Bước sau | bắt đầu **ngày (ngày bắt đầu bước trước + số ngày bước trước)** — ví dụ bước 10 là 2 ngày thì bước 20 bắt đầu **ngày 3** |
| Cùng **BƯỚC** (`seq`) | chạy **song song → cùng ngày**, tính 1 lần (Cắt/Vân khung-cánh-phào) |
| Công đoạn **0 ngày** | vẫn nằm trong bộ, **không chiếm ngày** (dùng chung ngày với bước liền trước) |
| Công đoạn **BỎ QUA** (màu 11/14) | không tính ngày |
| Ngày nghỉ | **bỏ Chủ nhật + ngày lễ** (mốc là ngày dương lịch nên vẫn phải nhảy qua ngày nghỉ) |
| Gối công đoạn (Cấu hình) | nay tính bằng **NGÀY** (`Gối công đoạn (ngày/bước)`) |

**SỔ GIẤY xưởng (11 bước, TỔNG 12 ngày)** — chính là bảng để nhập vào Cấu hình → Công đoạn:

| Bước | Công đoạn | Số ngày |
|---|---|---|
| 10 | Thiết kế · 20 Bôi Lares | 1 · 1 |
| 30 | Cắt khung / cánh / phào | 1 |
| 40 | Chấn khung / cánh / phào | 1 |
| 50 | Hàn khung / cánh / phào | 2 |
| 60 | Ép cánh | 0 |
| 70 | Test cơ khí | 1 |
| 80 | Sơn | 2 |
| 90 | Vân khung / cánh / phào | 2 |
| 110 | Vệ sinh + Đóng gói | 1 |
| 120 | Kho giao | 0 |
| — | Các bước **chờ** (chờ sau bồi, chờ trước sơn, chờ sau sơn, chờ sau vân, lắp kính) | 0 |
| | **TỔNG** | **12** |

Kiểm bằng chính engine: bắt đầu **01/10/2026** → xong **14/10/2026**, **12 ngày làm việc**.

---

## 2. Chạy SQL (bắt buộc)

```bash
psql "<CHUỖI KẾT NỐI>" -f migrate-production-v145-so-ngay-cong-doan.sql
```
Trên Supabase: dán cả file vào **SQL Editor** → Run. Không có bảng tạm, không phụ thuộc phiên.

File làm **2 việc**, chạy lại nhiều lần vẫn an toàn:
1. **Đổi tên cột** `production_stages.lead_time_hours` → `lead_time_days` (nếu chưa đổi).
2. **Quy giá trị còn là giờ (≥ 8) về số ngày đúng sổ giấy.** Dòng đã nhập theo ngày (< 8) **không bị sửa**
   ⇒ chạy lại không làm hỏng số bạn đã chỉnh.

Cuối file có `SELECT` để bạn **đối chiếu**: dòng `tong_ngay_theo_so_do` phải bằng **12**.

Nếu dùng `prisma migrate deploy` thì migration `20260927020000_stage_lead_time_days` đã có sẵn (làm y hệt).
Cài mới tinh: 2 file seed (`migrate-production-v136.sql`, `migrate-production-v139-split-parts.sql`) đã đổi sang
`lead_time_days` và tự đặt số ngày theo sổ giấy.

---

## 3. Code đã đổi

| File | Việc |
|---|---|
| `prisma/schema.prisma` | `leadTimeHours` → **`leadTimeDays`** (`@map("lead_time_days")`) |
| `src/lib/production/targets.ts` | Engine mốc: lấy thẳng **số ngày** của bước (`step.days`), bỏ phép chia giờ-ngày; gối theo ngày |
| `src/lib/production/calendar.ts` | Bỏ `hoursToWorkingDays`/`hoursPerWorkingDay`; `latestStartDate` nhận **số ngày** |
| `src/lib/production/config.ts` | `overlapHoursPerStep` → **`overlapDaysPerStep`** (số nguyên ≥ 0) |
| `src/lib/production/catalog.ts` + `production-config.tsx` | Nhãn cột đổi thành **"Số ngày"** |
| `src/lib/production/scheduling.ts` | `setLeadDaysFromTasks` (đường găng tính bằng ngày) |
| `src/lib/production/routing.ts` | `totalLeadTimeDays` |
| `src/lib/production/reporting.ts` + `/reports/production` | Cột **"Định mức (ngày)"** |
| `src/lib/production/service.ts` | Preview mốc trả `days` (bỏ `hours`) |
| Trang bộ cửa | KPI "Đường găng = N ngày", bảng mốc bỏ cột Giờ |

**Không đổi:** năng lực theo công đoạn vẫn theo **cánh/ngày** (`capacity_per_day`), cảnh báo QUÁ TẢI,
lịch làm việc/lễ, cột "Ngày KH" (để dành cho điều độ + lô gộp sau này).

---

## 4. Kiểm chứng

`tmp-verify-v145.mjs` (PGlite, chạy hết migration + seed) — **đạt hết**:

- V145 chạy **2 lần**: chỉ còn cột `lead_time_days`, tổng số ngày **vẫn 12** (không bị quy đổi lần 2).
- Danh mục sau V145: mọi công đoạn ≤ 5 ngày (không còn 24/48).
- Sổ giấy: **12 ngày**, bắt đầu 01/10 → xong **14/10/2026**.
- Bước 2 ngày: xong 02/10, bước sau bắt đầu **ngày 3** (03/10 — tuần này làm Thứ 7).
- 3 phần cùng bước = **1 mốc/bước** (không cộng 3 lần); bước 0 ngày không chiếm ngày; BỎ QUA không tính.
- Gối công đoạn: 1 ngày → bước sau bắt đầu ngay ngày bước trước kết thúc; gối quá đà **không lùi trước ngày bắt đầu**.
- Ngày không hợp lệ (`2026-13-45`, `2026-02-31`) không làm sập trang.
- SQL ghi gộp 1 lượt vẫn khớp engine; công đoạn đầu tiên chuyển `DANG_LAM`.
- `tsc --noEmit` 0 lỗi · `eslint` vùng sản xuất 0 lỗi · `npm run build` OK.

---

## 5. Lưu ý

- Bảng **Báo cáo sản xuất → theo công đoạn**: bỏ cột **"Chênh"** vì "Định mức (ngày)" và "Thực tế TB (giờ)"
  khác đơn vị, so trực tiếp là sai.
- Nếu bạn đã **lưu Cấu hình** sản xuất từ trước (có khoá `overlapHoursPerStep`), lần lưu kế tiếp sẽ ghi bằng
  khoá mới `overlapDaysPerStep`; giá trị gối cũ **không được chuyển tự động** → mở Cấu hình xem lại ô
  "Gối công đoạn (ngày/bước)", đặt 0 hoặc 1.
- Công đoạn đã tạo trong các bộ cũ là **ảnh chụp** — đổi số ngày trong danh mục chỉ ảnh hưởng **tính mốc mới**;
  bộ đã "Đưa vào sản xuất" thì giữ nguyên mốc đã ghi.
