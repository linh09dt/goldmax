# ERP V6 – Tính cước vận chuyển

Bổ sung tab **Tính cước vận chuyển** dựa trên file `tính cước vận chuyển.xlsx`.

## Logic áp dụng

- Chỉ tính trên **dòng bộ cửa chính**, không tính dòng phụ kiện/phụ phí vì Model cửa đã bao gồm phụ kiện theo bảng tiêu chuẩn.
- Gom tổng số lượng theo `Model`.
- Tổng cùng Model = 1 bộ → dùng mức **1 bộ**.
- Tổng cùng Model >= 2 bộ → dùng mức **2 bộ trở lên**.
- Miền Bắc:
  - <= 100 km
  - > 100 đến 200 km
  - > 200 km hoặc huyện miền núi
- Miền Trung: dùng cột **Từ Nghệ An trở vào**; theo công thức mẫu chỉ áp dụng khi quãng đường > 200 km.
- Nhà máy hỗ trợ 50 km đầu tiên.
- Cước thu khách = `(đơn giá chuẩn / tổng km) × (tổng km - 50) × số bộ`, không âm khi <= 50 km.
- Tổng cước làm tròn **lên 1.000 đồng**.

## Master Data cước vận chuyển

Bảng `shipping_rates` lưu giá theo Model và mức số lượng. Giá mẫu được nhúng sẵn từ file Excel và có thể lưu/chỉnh trực tiếp trên tab **Bảng tiêu chuẩn cước**.

## Audit

Mỗi lần bấm **Áp dụng cước vào đơn hàng**, hệ thống:

1. Tính lại ở server để tránh tin dữ liệu từ trình duyệt.
2. Cập nhật `shipping_fee`, vùng miền, quãng đường và các tổng tiền của đơn.
3. Lưu snapshot chi tiết vào `shipping_calculations` để truy vết công thức đã dùng.

## Cài đặt

Sau khi chép patch vào project V5 hiện tại:

```cmd
npm run db:generate
npm run db:migrate -- --name shipping_freight_v6
npm run dev
```

Mở:

```text
http://localhost:3000/shipping
```

## Cập nhật V37 – Mapping TENHANG vận chuyển

Logic vùng miền, số lượng, hỗ trợ 50 km và làm tròn của V6 vẫn giữ nguyên. Nguồn phân loại cước đã đổi sang **TENHANG**: MODEL trên đơn hàng được tra về TENHANG trong `item_masters`, sau đó TENHANG được ánh xạ sang `modelCode` trong `shipping_rates`. Xem `SHIPPING_TENHANG_CONFIG_V37.md`.
