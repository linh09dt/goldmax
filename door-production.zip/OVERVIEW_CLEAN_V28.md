# ERP V28 - Tinh gọn tab Tổng quan

- Tab Tổng quan chỉ giữ lại khối **Quản lý đơn hàng**.
- Giữ 2 nút:
  - **Tạo đơn hàng**
  - **Danh sách đơn hàng**
- Xóa khỏi Tổng quan:
  - Tổng đơn hàng
  - Tổng bộ cửa
  - Cơ sở dữ liệu PostgreSQL 18
  - Khối Nhập dữ liệu Excel
- Không thay đổi menu bên trái hoặc logic các module khác.
- Không thay đổi database.
