# ORDER CALCULATION CONFIG V48

## KH/Lượng: hiển thị 2 số thập phân, tính tiền bằng giá trị chính xác

Chốt ngày 24/09/2026.

### Quy tắc

- Với KH/Lượng được tính tự động, UI chỉ hiển thị tối đa 2 chữ số thập phân để dễ đọc.
- Giá trị nội bộ không làm tròn 2 chữ số trước khi tính tiền.
- `Thành tiền = KH/Lượng chính xác × Đơn giá`.
- Tổng bộ cửa và tổng đơn hàng dùng Thành tiền tính từ KH/Lượng chính xác.
- Không thay đổi công thức KH/Lượng đã chốt ở V44-V47.

### Ví dụ

Cửa cao `2968 mm`, rộng `2773 mm`:

- KH/Lượng chính xác: `(2968 × 2773) / 1.000.000 = 8.230264`
- UI hiển thị: `8,23`
- Nếu đơn giá `2.270.000 đ/m²`, Thành tiền tính bằng `8.230264 × 2.270.000 = 18.682.699,28 đ`.
- Khi hiển thị tiền không có phần lẻ VND: `18.682.699 đ`.

### Lưu trữ

- `pricingQuantity` của dòng tự động lưu giá trị chính xác thay vì giá trị đã làm tròn để tránh mất sai số khi lưu/mở lại đơn.
- Ô KH/Lượng tự động vẫn read-only và chỉ format 2 chữ số thập phân trên giao diện.
- KH/Lượng nhập tay không bị ép làm tròn khi lưu.
