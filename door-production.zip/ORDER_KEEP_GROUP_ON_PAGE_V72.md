# ORDER KEEP GROUP ON ONE PAGE V72

## Yêu cầu
Tránh trường hợp một **bộ cửa bị cắt sang trang** (ví dụ số TT 3 – bộ số 12064: 2 dòng đầu ở cuối trang 1,
các dòng còn lại ở trang 2). Nếu bộ không đủ chỗ ở cuối trang thì **đẩy trọn bộ xuống trang sau**.

## Nguyên nhân
Bảng dữ liệu là 1 `LongTable` dài, ReportLab tự tách ở bất kỳ ranh giới hàng nào → ranh giới trang có thể rơi
**giữa** một bộ. Cách chữa "chỉ thêm lệnh `NOSPLIT`" **không đủ**: khi bảng bị tách, phần còn lại được đặt tiếp
vào chỗ trống cuối trang và bị tách lần nữa ở vị trí không kiểm soát (đã thử và đo được vẫn còn tách).

## Cách làm (tự chia trang, không phụ thuộc ReportLab)
`python/reportlab_order_v2.py`:
1. Tách hàm cũ `_data_table()` thành:
   - `_order_table_body()` — dựng 2 hàng header + các hàng hàng hóa/ghi chú và trả về `meta`
     (chỉ số hàng chính / hàng phụ kiện / hàng ghi chú / khoảng hàng của từng bộ + cờ mờ).
   - `_order_col_widths()` — bề rộng 19 cột (giữ nguyên V70).
   - `_order_table(...)` — dựng 1 bảng cho 1 trang, nhận danh sách **chỉ số hàng** của trang đó,
     tự quy đổi chỉ số style về chỉ số cục bộ.
   - `_data_tables(...)` — **chia trang**:
     - wrap thử cả bảng để lấy **chiều cao thật từng hàng** (`probe._rowHeights`, cùng colWidths + style);
     - sức chứa trang 1 = `PAGE_H - TOP - BOTTOM` trừ chiều cao các flowable đã in phía trên
       (header công ty + bảng thông tin đơn — đo bằng `flowable.wrap()`), các trang sau trừ 2 hàng header;
     - xếp lần lượt **từng bộ** vào trang: bộ nào không đủ chỗ thì chuyển sang trang mới.
2. Mỗi bảng con được đặt `splitByRow=0, splitInRow=0` (atomic) vì đã vừa đúng 1 trang → khi không đủ chỗ ở cuối
   trang, ReportLab đẩy **cả bảng con** (tức cả bộ) sang trang sau thay vì tách.
   Bộ đơn lẻ **cao hơn 1 trang** (ghi chú khổng lồ) vẫn được phép tách để không tràn trang.
3. Giữ nguyên các lệnh style cũ (nền xen kẽ, viền mờ 60% cho phụ kiện, hàng ghi chú span, vạch cuối bộ) và
   giữ `NOSPLIT` theo từng bộ như lớp bảo hiểm thứ hai.

## Kiểm chứng (đo trên PDF thật)
Kịch bản test: 9 bộ × ~5 dòng, thêm dần 0–7 dòng phụ kiện vào bộ đầu để **dịch ranh giới trang** vào giữa các bộ.
- **Trước khi sửa**: k=1, 2, 3, 4, 5, 6, 7 đều có bộ bị tách (ví dụ k=1: bộ 12063 có ghi chú ở trang 2 trong khi
  dòng hàng ở trang 1).
- **Sau khi sửa**: cả 8 kịch bản **không còn bộ nào bị tách**; mỗi trang luôn bắt đầu bằng **dòng hàng chính**
  của một bộ (`5 | 12064…`, `4 | 12063…`, `9 | 12068…`…), không trang nào bắt đầu bằng dòng `↳` hoặc hàng ghi chú.
- Hồi quy: đơn 1 bộ vẫn 1 trang; đơn 9 bộ 3 trang (trang 3 = tổng kết); đơn 14 bộ 4 trang — ranh giới trang
  đều rơi giữa 2 bộ, 2 hàng header vẫn lặp ở đầu mỗi trang.
- Ca biên: một bộ có ghi chú dài hơn 1 trang → file vẫn xuất bình thường (rc=0), không tràn/lỗi.
- `python -m py_compile`: OK.

## Ghi chú về Excel
Bản Excel để Excel/LibreOffice tự ngắt trang; file `.xlsx` không có khái niệm "giữ nhóm dòng cùng trang"
(chỉ có thể chèn page break thủ công theo ước lượng chiều cao in, không chắc đúng như bản in thật).
Vì vậy V72 chỉ áp dụng cho **PDF**. Nếu bạn cần cả Excel thì nói, mình sẽ chèn page break ước lượng
theo chiều cao hàng + tỉ lệ fit-to-width.

## File thay đổi
- `python/reportlab_order_v2.py`
