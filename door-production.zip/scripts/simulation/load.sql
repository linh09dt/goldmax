BEGIN;
SET client_min_messages = warning;
CREATE TEMP TABLE t_upd(id int, status text, actual_start text, actual_end text, reason_code text,
                        is_rework text, assignee text, qty_done float8, note text, updated_by text);
\copy t_upd FROM '/tmp/sim/tasks_upd.csv' WITH (FORMAT csv)
UPDATE production_tasks t SET
  status       = v.status,
  actual_start = NULLIF(v.actual_start,'')::timestamp,
  actual_end   = NULLIF(v.actual_end,'')::timestamp,
  reason_code  = NULLIF(v.reason_code,''),
  is_rework    = (v.is_rework = 'true'),
  assignee     = NULLIF(v.assignee,''),
  qty_done     = v.qty_done,
  note         = NULLIF(v.note,''),
  updated_by   = v.updated_by,
  updated_at   = now()
FROM t_upd v WHERE t.id = v.id;

CREATE TEMP TABLE s_upd(id int, status text, percent_done int, planned_start text, planned_end text,
                        actual_completed_at text, actual_delivered_at text, program_ready text,
                        material_ready text, pack_count text, note text, updated_by text);
\copy s_upd FROM '/tmp/sim/sets_upd.csv' WITH (FORMAT csv)
UPDATE production_sets s SET
  status              = v.status,
  percent_done        = v.percent_done,
  planned_start       = NULLIF(v.planned_start,'')::date,
  planned_end         = NULLIF(v.planned_end,'')::date,
  actual_completed_at = NULLIF(v.actual_completed_at,'')::timestamp,
  actual_delivered_at = NULLIF(v.actual_delivered_at,'')::timestamp,
  program_ready       = (v.program_ready = 'true'),
  material_ready      = (v.material_ready = 'true'),
  pack_count          = NULLIF(v.pack_count,'')::int,
  note                = NULLIF(v.note,''),
  updated_at          = now()
FROM s_upd v WHERE s.id = v.id;
COMMIT;
