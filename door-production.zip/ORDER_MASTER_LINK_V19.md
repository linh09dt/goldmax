# ERP V19 — Liên kết đơn hàng với Tên sản phẩm diễn giải + MODEL

## Thay đổi

- Trong màn hình Tạo/Sửa đơn hàng, khi chọn hàng hóa từ Danh mục hàng hóa:
  - `Tên sản phẩm` lấy từ **Tên sản phẩm diễn giải**.
  - `MODEL danh mục` lấy từ **MODEL** của Master Data.
  - Trường `Model` cũng được đồng bộ bằng MODEL để dữ liệu cũ / export không bị lệch.
  - `ĐVT` và giá mặc định tiếp tục lấy từ Master Data theo logic V15.
- Datalist tìm kiếm cho phép tìm theo Tên sản phẩm diễn giải, TENHANG và MODEL.
- Khi tạo đơn mới, các dòng mẫu có MODEL trùng Master Data sẽ tự đồng bộ sang Tên sản phẩm diễn giải + MODEL + ĐVT + giá.
- Khi chỉnh sửa đơn cũ, hệ thống **không tự ghi đè snapshot** đã lưu.
- Không thay đổi database schema.
- Không thay đổi quy tắc xuất Excel/PDF đã chốt trước đó: file xuất vẫn có thể dùng TENHANG/MODEL theo cấu hình xuất hiện tại.

## Cài đặt

Chép patch chồng lên V18 rồi chạy:

```cmd
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần migrate.
