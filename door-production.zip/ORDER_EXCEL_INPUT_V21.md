# ERP V21 — Nhập Excel mẫu đơn hàng .XLSB/.XLSX

## Mục tiêu

- Nhập dữ liệu trực tiếp vào màn hình Tạo/Sửa đơn hàng từ mẫu GOLDMAX mới.
- Hỗ trợ cả `.xlsb` và `.xlsx`.
- Không tự lưu ngay: dữ liệu được đưa lên form để kiểm tra/chỉnh sửa rồi mới bấm **Lưu đơn hàng**.
- Giữ nguyên cột **Hình ảnh SP / Tải ảnh** trên Web App. Ảnh nhúng trong Excel không được tự import.

## Mapping mẫu mới

Worksheet ưu tiên: `HÓA ĐƠN`.

- B: STT
- C: BỘ SỐ
- D: Tên sản phẩm
- E: Model
- F: Ô thoáng
- G: Hướng mở
- H: Phào (Thuận - Nghịch)
- I: Màu sơn
- J/K/L: Cao / Rộng / Khuôn
- M/N: KT thông thủy Cao / Rộng
- O: Số lượng bộ
- P: ĐVT
- Q: KH/Lượng
- R: Đơn giá
- S: Thành tiền
- T: Ghi chú

Dòng có STT là dòng cửa chính. Các dòng sau đó đến trước STT tiếp theo là hàng hóa kèm theo.
Hàng kèm chỉ nhập khi `KH/Lượng > 0`, đồng bộ với logic hiển thị/xuất đơn đã chốt.

## Thông tin đầu đơn

Mẫu hiện tại đọc:

- Tên đại lý: C4
- Mã đại lý: từ B5
- Địa chỉ: từ E4
- Ngày đặt hàng: từ E5
- Ngày trả dự kiến: M5
- Mã đơn SX: S5 → Mã đơn hàng trên ERP
- Đặt cọc: dòng `ĐẶT CỌC`

`Hỗ trợ vc` không được tự hiểu là cước vận chuyển thu khách hàng; cước vẫn do module Tính cước vận chuyển quản lý.

## Master Data

Sau khi đọc Excel, nếu Model có trong Danh mục hàng hóa:

- Tên sản phẩm được đồng bộ sang **Tên sản phẩm diễn giải**.
- Model giữ theo Master Data.
- ĐVT và Đơn giá trong Excel được ưu tiên để giữ snapshot báo giá tại thời điểm lập đơn.
- Nếu Excel để trống ĐVT/Đơn giá thì mới lấy từ Master Data.

Nếu Model chưa có trong Master Data, dữ liệu Excel vẫn được giữ để người dùng kiểm tra/chỉnh sửa.

## Giao diện đơn hàng

Bảng nhập được rút về đúng bố cục mẫu:

`STT | Bộ số | Tên sản phẩm | Model | Ô thoáng | Hướng mở | Phào | Màu sơn | Cao | Rộng | Khuôn | TT Cao | TT Rộng | Số lượng bộ | ĐVT | KH/Lượng | Đơn giá | Thành tiền | Ghi chú | Hình ảnh SP | Xóa`

Trong cột Tên sản phẩm vẫn giữ logic ERP:

- Dòng chính: chọn Loại cửa → chọn tên sản phẩm theo Master.
- Dòng kèm: chọn nhóm hàng kèm → chọn hàng hóa theo Master.

## Cài đặt

V21 thêm thư viện đọc `.xlsb`, vì vậy sau khi chép patch cần chạy:

```cmd
npm install
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần `db:migrate`.
