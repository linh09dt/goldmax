# V125 — Bộ câu hỏi TỔNG HỢP ĐẦY ĐỦ cho module Lên kế hoạch sản xuất

**Một bản duy nhất, thay thế V117 + V122 + V123 + phần C của V124.** Gộp tất cả: 6–7 câu chặn, phạm vi & điều kiện vào kế hoạch,
đầy đủ theo **tổ → công đoạn** (7 nhóm câu hỏi cố định cho mỗi công đoạn), các vấn đề xuyên suốt, **12 câu bổ sung** đã rà lỗ hổng,
và 4 bảng điền (thời lượng · dữ liệu · kiểm tra chéo · mặc định).

**File giao:** `artifacts/bo-cau-hoi-tong-hop-v125.docx` (điền trong Word) ·
`artifacts/bo-cau-hoi-tong-hop-v125.pdf` (in A4, **17 trang**) · script sinh: `scripts/v125/mk_v125.py`.

**Tổng: 182 câu hỏi** — trong đó **~120 câu mức P1** (bắt buộc để lập trình).

---

## Cấu trúc

| Phần | Nội dung | Câu |
|---|---|---|
| **A** | **7 câu chặn** — trả lời được là bắt đầu lập trình (có cột “chi tiết ở” trỏ tới câu hỏi chi tiết) | 7 |
| **B** | Phạm vi & điều kiện vào kế hoạch: đơn vị = bộ · đơn nào vào · **đủ điều kiện khi nào** · mẫu lệnh sản xuất · Bộ số · hạn giao · giao từng phần · nhập đơn đang dở | 8 |
| **C** | **TỔ MÁY** — Thiết kế (TK 7) · **Bồi Lares = nạp chương trình máy cắt** (BL 9) · Cắt (C 8) · Chấn (CH 7) · chung (TM 6) | 37 |
| **D** | **TỔ HÀN** — Hàn (HAN 7) · Ép cánh (EP 7) · Test cơ khí (TC 6) · chung (TH 5) | 25 |
| **E** | **TỔ SƠN** — nút thắt: mẻ lò, số màu, đổi màu, gom lô, chờ khô, sơn lại | 19 |
| **F** | **TỔ VÂN** — mã vân, gom lô, vị trí so với lắp kính, làm lại | 12 |
| **G** | **LẮP KÍNH + PHỤ KIỆN** — công đoạn còn thiếu trong bảng công đoạn | 12 |
| **H** | **TỔ KHO** — Vệ sinh + Đóng gói (8) · Kho & Giao hàng & lắp đặt (12) | 20 |
| **I** | **XUYÊN SUỐT** — cách lên kế hoạch · năng lực & thực tế · ngoại lệ & thay đổi · cập nhật & báo cáo (**gồm cảnh báo mong muốn + thuê ngoài**) | 30 |
| **J** | **12 câu bổ sung** (lỗ hổng đã rà): quyền sửa kế hoạch · ai xác nhận hoàn thành · chốt kế hoạch ngày nào · xem lại tuần trước · % tiến độ hay trạng thái · tổ xem chéo · trạng thái tạm dừng · tự đề xuất lại lịch · thông báo · đơn vị báo cáo · in dán xưởng · thuê ngoài khác | 12 |
| **K–O** | Bảng điền **thời lượng 16 dòng** · **17 trường dữ liệu** cần thêm · **12 trường kiểm tra chéo** · **24 mặc định** · xin kèm theo | — |

## Trong mỗi công đoạn, câu hỏi đi theo 7 nhóm cố định

> ① nội dung & phạm vi · ② thời lượng · ③ nguồn lực & máy móc · ④ setup & gom lô · ⑤ chờ & ràng buộc · ⑥ kiểm tra & lỗi · ⑦ ghi nhận trong app

Tổ chỉ cần học **một lần** cách trả lời → mọi công đoạn đọc theo cùng một thứ tự, không bỏ sót.

## Cách dùng

| Đối tượng | Trả lời phần |
|---|---|
| Quản đốc | **A** (7 câu chặn) + **B** (phạm vi & điều kiện) |
| Tổ trưởng từng tổ | Phần của tổ mình: máy **C** · hàn **D** · sơn **E** · vân **F** · kho **H** |
| Kỹ thuật | **C.1 (thiết kế)** + **C.2 (Bồi Lares)** + phần E4 (model mới/tuần) |
| Người lên kế hoạch | **I** + **J** |
| Chủ doanh nghiệp | 11 quyết định sản phẩm/kỹ thuật trong `DOI_CHIEU_CAU_HOI_THIET_KE_V124.md` |

**Ba con số không thể dùng mặc định:** năng lực mỗi tổ (bộ/tuần) · đơn vị thời gian · quy tắc “đầy đủ đơn”.
Thiếu 3 con số này module vẫn chạy nhưng **mất phần lớn giá trị** (không cảnh báo quá tải, ngày dự kiến không đáng tin).

## Sinh lại tài liệu

```bash
cd /tmp && cat dp/scripts/v125/mk_v125_part1.py dp/scripts/v125/mk_v125_part2.py > mk_v125.py
python3 mk_v125.py
libreoffice --headless --convert-to pdf --outdir artifacts artifacts/bo-cau-hoi-tong-hop-v125.docx
```

> Kiểm tra sau khi sinh: `pdftotext … | grep -c "<b>\|&amp;"` phải = 0 (lỗi từng gặp: thẻ HTML/entity bị in ra chữ thô).
