# V144 — ĐƯA VÀO SẢN XUẤT + TỰ SUY MỐC (target) TỪNG CÔNG ĐOẠN

Nhà máy chốt 26/09/2026: **không nhập ngày cho từng công đoạn**. Chỉ nhập **MỘT mốc ngày bắt đầu**;
hệ thống tự suy **mốc (target)** của mọi công đoạn phía sau để **cảnh báo chậm / không kịp / trễ**.

> **Khác biệt quan trọng — không lẫn 2 loại ngày:**
> - **Mốc (target)** — V144, hệ thống **tự suy** từ ngày bắt đầu + số giờ của bước. Dùng để **cảnh báo**.
> - **Ngày kế hoạch sản xuất** — cột “Ngày KH” sẵn có (`planned_start/planned_end`), **giữ nguyên**,
>   sau này sẽ lấy theo **điều độ + lô gộp** (thiết kế sau).

---

## 1. Cách dùng (đúng như yêu cầu)

1. Vào **Kế hoạch sản xuất** → danh sách **Bộ chờ xếp lịch** → bấm **Bộ số**.
2. Ở thẻ **“Kế hoạch sản xuất của bộ”**: chọn **Ngày bắt đầu sản xuất** → bấm **Xem mốc các công đoạn**
   → hệ thống hiện **bảng mốc của mọi bước** và kết luận **KỊP / KHÔNG KỊP** so với hạn xưởng.
3. Bấm **Đưa vào sản xuất** → bộ chuyển **Đang sản xuất (WIP) ở công đoạn đầu tiên**,
   mốc của mọi công đoạn được lưu lại; bảng *Cập nhật tiến độ theo công đoạn* hiện thêm cột **Mốc (target)**
   và tự đánh dấu **chậm** cho công đoạn đã quá mốc mà chưa xong.

## 2. Cách hệ thống suy mốc

| Quy tắc | Chi tiết |
|---|---|
| Số ngày của bước | **cột `Số ngày` của công đoạn** (V145 — nhập thẳng số ngày, không còn chia giờ-ngày) |
| Thứ tự | Theo **BƯỚC (`seq`)** trong danh mục công đoạn |
| Bước sau bắt đầu | **Ngày làm việc kế tiếp** sau khi bước trước xong; nếu Cấu hình có **“gối công đoạn”** (`overlapHoursPerStep`) thì lùi lại đúng số ngày gối |
| Ngày nghỉ | Bỏ **Chủ nhật + ngày lễ** (bảng `production_calendar`); nếu ngày bắt đầu rơi vào ngày nghỉ thì **dời sang ngày làm việc kế tiếp** (màn hình báo rõ) |
| Cùng bước | Các công đoạn **cùng `seq`** (Cắt khung/cánh/phào, Vân khung/cánh/phào…) → **CÙNG mốc**, không cộng nhiều lần |
| Bước 0 giờ | **Không chiếm ngày** — nằm cùng ngày với bước liền trước (không đẩy ngày xong ra sau) |
| Công đoạn `BO_QUA` | Vd Vân với màu sơn 11/14 → **không tính ngày** |

> ℹ️ **TỪ V145 ĐƠN VỊ LÀ NGÀY** — xem `SO_NGAY_CONG_DOAN_V145.md`. Danh mục đã được quy về số ngày đúng
> sổ giấy ⇒ **12 ngày làm việc**; bắt đầu 01/10/2026 thì **xong 14/10/2026**.

**Ví dụ dưới đây theo SỔ GIẤY của xưởng** (Hàn 2 ngày, Test 1, Sơn 2, Vân 2, ép cánh/lắp kính/kho 0;
bắt đầu **01/10/2026**):

```
10 Thiết kế      01/10            70 Test cơ khí   08/10
20 Bồi Lares     02/10            80 Sơn           09/10 → 10/10
30 Cắt (×3)      03/10            90 Vân (×3)      12/10 → 13/10
40 Chấn (×3)     05/10            110 Vệ sinh+ĐG   14/10
50 Hàn (×3)      06/10 → 07/10    120 Kho          14/10
→ XONG 14/10/2026 = ĐÚNG 12 NGÀY LÀM VIỆC (khớp “TỔNG THỜI GIAN = 12” trong sổ giấy)
```

## 3. Cảnh báo

| Cảnh báo | Khi nào bắn |
|---|---|
| **CHẬM** (`CHAM_CONG_DOAN`) | Bộ đang sản xuất có công đoạn **quá mốc** (`target_end` < hôm nay) mà chưa *Xong* → nêu công đoạn chậm nhất + số ngày chậm |
| **KHÔNG KỊP** (`KHONG_KIP`) | Bộ **đã vào sản xuất** mà **ngày xong dự kiến > hạn xưởng** (hạn giao − đệm vận chuyển) → nêu số ngày muộn |
| **TRỄ / SẮP TRỄ** (`SAP_TRE`) | Đã có sẵn từ trước (quá hạn giao, hoặc chưa xếp lịch mà đã tới lúc phải bắt đầu) |

Cảnh báo **tính lại mỗi lần mở trang** (không lưu sẵn) nên sửa Cấu hình/ngày bắt đầu là cập nhật ngay.

## 4. Áp dụng

```bash
# 1) SQL trước khi deploy code (idempotent, không bảng tạm)
psql "<CHUỖI KẾT NỐI>" -f migrate-production-v144-moc-san-xuat.sql
# 2) Deploy code, rồi kiểm tra
npx tsc --noEmit && npm run build
```
Kiểm tra sau khi chạy:
```sql
SELECT table_name||'.'||column_name FROM information_schema.columns
 WHERE table_name IN ('production_tasks','production_sets')
   AND column_name IN ('target_start','target_end','started_at');
-- kỳ vọng: 4 dòng (tasks: target_start, target_end · sets: started_at, target_end)
```

## 5. Ghi chú thiết kế

- **Ghi gộp 1 lượt** (bài học V111): mốc của mọi công đoạn ghi bằng **một câu**
  `UPDATE production_tasks ... FROM jsonb_to_recordset(...)`, rồi 1 câu đổi công đoạn đầu sang *Đang làm*,
  1 câu cập nhật bộ, 1 câu ghi log — tất cả trong **một transaction**.
- `production_sets.started_at` = ngày bắt đầu (đã dời nếu vào ngày nghỉ), `target_end` = ngày xong dự kiến của bộ.
- **Chưa có** (cố ý): sửa lại ngày bắt đầu sau khi đã vào sản xuất, quay lui trạng thái, và hiện mốc trên **phiếu in**.
- Điều độ / lô gộp / “ngày kế hoạch sản xuất” sẽ làm ở bước sau, dùng lại cột `planned_start/planned_end`.

## 6. Kiểm chứng (`tmp-verify-v144.mjs` + `tmp-verify-v145.mjs` — đạt hết)

> Từ **V145** danh mục dùng **SỐ NGÀY** (`lead_time_days`) — xem `SO_NGAY_CONG_DOAN_V145.md`.
> File `tmp-verify-v144.mjs` là bản cũ theo giờ (đã thay bằng `tmp-verify-v145.mjs`).

- Migration: 4 cột mới, chạy 2 lần không lỗi (idempotent); V145 đổi tên cột chạy 2 lần vẫn giữ nguyên 12 ngày.
- Engine: sổ giấy **12 ngày**, xong **14/10**; bỏ Chủ nhật; ngày lễ; **3 phần cùng bước = 1 mốc**
  (1 + 2 ngày, không phải 9); bước **0 ngày** không chiếm ngày; **gối công đoạn 1 ngày** dùng chung ngày;
  bước 2 ngày → bước sau bắt đầu **ngày 3**; mốc rơi Chủ nhật → dời Thứ 2.
- **Danh mục sau V145**: mọi công đoạn ≤ 5 ngày (không còn 24/48) → tổng **12 ngày**, xong **14/10/2026**.
- **Ngày không hợp lệ không làm sập trang**: `2026-13-45`, `2026-02-31`, chuỗi rác → bị chặn (trước đây gây lỗi 500).
- **Gối công đoạn quá đà**: mốc **không lùi trước ngày bắt đầu**.
- SQL ghi gộp: mốc ghi đúng bằng engine cho **từng** công đoạn; công đoạn đầu chuyển *Đang làm*.
- Kết luận kịp/không kịp: bộ bắt đầu 01/10 → **kịp**; bắt đầu 16/11 → **KHÔNG KỊP 8 ngày**.
- `tsc --noEmit` 0 lỗi · `eslint` vùng sản xuất 0 lỗi · `npm run build` OK.

## 7. Lỗi đã sửa sau kiểm chứng độc lập

| Lỗi tìm được | Đã sửa |
|---|---|
| **Gối công đoạn quá đà làm mốc lùi TRƯỚC ngày bắt đầu** (vd 1 ca × 8h + gối 24h → bộ "xong" trước khi bắt đầu) | Chặn gối theo số ngày của chính bước, và chặn `cursor` không lùi trước ngày bắt đầu |
| Tài liệu nói "12 ngày" nhưng danh mục thật (24/48 giờ) ra 35 ngày | **V145 đổi hẳn sang số ngày**; danh mục quy về sổ giấy **12 ngày**; test khẳng định số THẬT của danh mục |
| `?ngay=2026-13-45` → Invalid Date → **sập trang (500)** | `parseIsoDateStrict()` kiểm round-trip; route trả lỗi tiếng Việt |
| Ghi mốc thiếu dòng vẫn báo thành công (`Number(updated) \|\| records.length`) | So số dòng đã ghi; thiếu → **ném lỗi, rollback** |
| Guard thiếu `started_at`; UI hiện nút dù bộ đã DANG_SX do đặt tay | Chặn theo `startedAt`; nút ẩn/khóa theo cả `startedAt` lẫn trạng thái |
| `totalDays` = tổng ngày-công (bỏ qua gối) → 3 con số khác nhau cho cùng bộ | `totalDays` = **khoảng ngày thật** giữa mốc đầu và mốc cuối |
| Gối 8–15 giờ bị bỏ qua âm thầm (làm tròn xuống 0) | Cấu hình **chặn khi lưu**: phải 0 hoặc ≥ 1 ngày làm việc |
| Một bộ bị 2 cảnh báo trùng (`KHONG_KIP` + `SAP_TRE` theo `planned_end`) | Bỏ nhánh `SAP_TRE` khi bộ **đã có** `started_at` |
| Hiển thị "chậm 0 ngày" khi khoảng chỉ vài ngày | Lấy tối thiểu **1 ngày** khi đã xác định trễ |
| Badge "chậm" ở form dùng ngày UTC của máy khách | Truyền `todayVn` từ server xuống |
| Cảnh báo CHẬM/KHÔNG KỊP bị lọc mất ở trang bộ cửa | Thêm 2 loại vào danh sách hiển thị |
| `rebuild` xoá sạch mốc của bộ đã vào sản xuất | **Chặn** sinh lại công đoạn cho bộ đã vào sản xuất |

**Còn để sau (đã biết):** mã chưa hiện trên bảng *Đang sản xuất* ở màn chính (chỉ thấy ở trang bộ và form tiến độ);
chưa có cách **đổi ngày bắt đầu** sau khi đã vào sản xuất; nút V144 chưa gửi `byName` (app không có đăng nhập);
`package.json` chưa có script `db:deploy` (chạy tay theo mục 4).
