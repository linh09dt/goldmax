# Đơn hàng ERP V2

## Phạm vi thay đổi

- Toàn bộ giao diện module Đơn hàng dùng tiếng Việt.
- Thêm màn hình **Tạo đơn hàng mẫu** tại `/orders/new`.
- Mỗi bộ cửa giữ đầy đủ các cột theo file `Đơn hàng.xlsx`.
- Mỗi bộ cửa có các dòng chi tiết/phụ kiện/phụ phí riêng, không còn chỉ nằm trong `rawBlock`.
- Hỗ trợ mẫu dòng cho Cửa đi và Cửa sổ đúng cấu trúc 15 dòng/bộ của Excel.
- Thêm nhóm **Câu hỏi thêm / Xác nhận**.
- Thêm tổng hợp giá trị: cước vận chuyển, chiết khấu, đặt cọc, trừ tiền nhận tại kho, thanh toán khi giao hàng.
- Nhập Excel V1 được nâng cấp để đưa các dòng con vào bảng `sales_order_item_details`.
- Thêm chỉnh sửa đơn tại `/orders/[id]/edit`.
- Hình ảnh sản phẩm được lưu local dưới `public/uploads/orders` trong giai đoạn localhost.

## Cập nhật database

Sau khi chép patch vào project hiện tại:

```cmd
npm install
npm run db:generate
npm run db:migrate -- --name order_erp_v2
npm run dev
```

Mở:

```text
http://localhost:3000/orders
```

Tạo đơn trực tiếp:

```text
http://localhost:3000/orders/new
```

## Kiến trúc dữ liệu

```text
SalesOrder
├── SalesOrderItem               (dòng sản phẩm chính / bộ cửa)
│   └── SalesOrderItemDetail     (từng dòng phụ kiện, phụ phí, Khác...)
├── SalesOrderRequirement        (câu hỏi xác nhận công trình)
└── OrderImport                  (lịch sử nhập Excel)
```

Không thay đổi cấu hình `.env`, `DATABASE_URL`, Prisma adapter hoặc PostgreSQL local hiện tại.
