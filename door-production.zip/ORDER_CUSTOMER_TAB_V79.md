# ORDER CUSTOMER TAB V79

## Yêu cầu (4 việc)

1. Tab Tạo đơn hàng: **điều chỉnh lại 17 ô trên 1 hàng**.
2. **Xuất file** (file Excel/PDF của đơn hàng).
3. Đổi **Email: Goldmaxdoor@gmail.com → Website: goldmaxdoor.vn**.
4. **Thêm tab Thông tin khách hàng**, tự động thu thập thông tin khách hàng trên đơn (tên khách hàng, số điện thoại, địa chỉ).

## Đã làm

### 1. Bộ cửa về 17 ô trên 1 hàng
- Gộp 2 nhóm của V78 thành **1 hàng 17 ô**: Bộ số · Nhóm cửa · Model · Ô thoáng · Hướng mở · Phào · Màu sơn · Cao · Rộng · Khuôn · TT Cao · TT Rộng · SL bộ · ĐVT · KH/Lượng · Đơn giá · Thành tiền.
- Giữ nguyên style đã chốt ở V78: **khung nhãn trải đúng bằng bề ngang khung input**, ô nhập 11.5px cao 32px.
- Nhãn trong hàng này dùng cỡ 8px và **tự xuống 2 dòng trong đúng chiều cao khung 18px** nên **không nhãn nào bị cắt “…”** (trước đây 11/17 nhãn bị cắt).
- Cân lại tỷ lệ cột (Nhóm cửa 75px, Model 80px, Hướng mở 57px, Ô thoáng 43px, KH/Lượng 48px, Thành tiền 54px…).
- Responsive: 2 cột (mobile) → 3 (sm) → 6 (lg) → 17 theo tỷ lệ (xl).

### 2 + 3. File xuất: Email → Website
Đổi dòng thông tin công ty trong **cả 3 nơi xuất file**:
- Excel V2 (`src/lib/order-export-v2.ts`): `["Email:", "Goldmaxdoor@gmail.com"]` → `["Website:", "goldmaxdoor.vn"]`
- PDF V2 (`python/reportlab_order_v2.py`): `"Email: Goldmaxdoor@gmail.com"` → `"Website: goldmaxdoor.vn"`
- PDF preview (`python/reportlab_order_preview.py`): `"Hotline: 1900 8135    Website: goldmaxdoor.vn"`

Số dòng thông tin công ty vẫn là **6 dòng** nên bố cục header (căn dòng theo V64/V65) không đổi.

**Kiểm chứng thật:** gọi `GET /api/orders/20/export-v2`, mở file bằng ExcelJS đọc lại:
- `D7 = "Website:"`, `F7 = "goldmaxdoor.vn"` ✔
- Quét toàn bộ ô: **không còn chuỗi `Goldmaxdoor@gmail.com`** ✔

### 4. Tab Thông tin khách hàng (mới)
- Menu mới **“Thông tin khách hàng”** (`/customers`) trong nhóm *Điều hành*, có icon riêng.
- **Tự động thu thập từ đơn hàng**: không có bảng danh bạ riêng, không phải nhập tay —
  API `GET /api/customers` quét các đơn hàng đã lưu (mới nhất trước, tối đa 5.000 đơn) và gom theo tên khách hàng (không phân biệt dấu).
- Mỗi khách hàng hiển thị: **Tên khách hàng · Số điện thoại · Địa chỉ** + Mã Đại Lý · NVKD · Vùng miền · Số đơn · Tổng tiền đơn hàng · Đơn gần nhất.
  (Số điện thoại lấy từ *Số điện thoại* trên đơn, địa chỉ lấy từ *Địa chỉ nhận hàng*; nếu đơn mới hơn có giá trị mới thì lấy giá trị mới nhất.)
- Tìm kiếm không phân biệt dấu theo tên / điện thoại / địa chỉ / mã đại lý / mã đơn; sắp xếp theo *Đơn gần nhất · Nhiều đơn nhất · Doanh thu cao nhất*.
- Nút **Xem N đơn**: mở danh sách đơn của khách đó (mã đơn bấm được để mở chi tiết đơn).
- Nút **Xuất Excel**: `/api/customers/export` xuất danh sách khách hàng đang xem (11 cột, kèm số đơn và tổng tiền).
- Trang Hướng dẫn sử dụng: thêm mục **4. Thông tin khách hàng**, các mục sau đánh số lại (5 Doanh thu, 6 Cấu hình, 7 Tính cước).

## Kiểm chứng

- `npx tsc --noEmit`: 0 lỗi · `next build`: **Compiled successfully** (có route `/customers`, `/api/customers`, `/api/customers/export`).
- eslint: 4 errors / 11 warnings — **đúng bằng bản gốc**, file mới không có lỗi.
- Đo trong trình duyệt ở 1280×720 ở tab Tạo đơn hàng: **đúng 17 ô / 1 hàng**, `labelWidth = inputWidth` ở mọi ô, **0 nhãn bị cắt**, không tràn ngang.
- Tab khách hàng chạy trên dữ liệu thật: 9 khách hàng / 11 đơn, tổng 353.451.045đ; số điện thoại và địa chỉ khớp dữ liệu đơn.
- Xuất Excel danh sách khách hàng: đọc lại file thấy đúng 11 cột và 9 dòng dữ liệu.

## Không thay đổi

- Không đổi công thức tính tiền, KH/Lượng, quy tắc Bộ số (V75), cấu hình tính toán, API đơn hàng, Prisma schema, `.env`. Không cần migrate.

## File thay đổi

Mới:
- `src/app/customers/page.tsx`
- `src/app/api/customers/route.ts`
- `src/app/api/customers/export/route.ts`
- `src/lib/customers.ts`
- `src/components/customer-directory.tsx`

Sửa:
- `src/components/order-form.tsx` (17 ô 1 hàng)
- `src/components/erp-nav.tsx` (thêm menu)
- `src/app/guide/page.tsx` (thêm mục 4, đánh số lại)
- `src/lib/order-export-v2.ts`, `python/reportlab_order_v2.py`, `python/reportlab_order_preview.py` (Email → Website)
