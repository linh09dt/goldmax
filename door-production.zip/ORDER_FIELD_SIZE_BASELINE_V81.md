# MỐC KÍCH THƯỚC Ô NHẬP — V81

## Nguyên tắc: 1 mốc chuẩn + co giãn theo %

Toàn bộ ô nhập dùng **tỷ lệ `fr`** (bản chất là %), KHÔNG dùng px cố định.
V81 chọn **mốc chuẩn = màn hình 1920px** và đặt tỷ lệ sao cho:

> **1fr = 1px tại mốc 1920**  →  số ghi trong code đọc ra đúng số px bạn muốn ở màn 1920.

Ở khổ màn khác, mọi ô **co giãn theo đúng %**:

```
px ở khổ W = px(1920) × (bề rộng hàng ở W ÷ 1583)
```

Ví dụ ô Model = 330px ở mốc 1920 → màn 1536px tự còn ~236px, màn 1280 còn ~173px — không phải chỉnh gì.

## Vì sao dùng `fr` chứ không ghi `%` trực tiếp?

Nếu ghi `grid-template-columns: 8% 6.4% ...` thì **cộng thêm 6px mỗi khe** → hàng bị tràn ngang.
`fr` chia phần không gian **còn lại sau khi trừ khe**, nên luôn khớp đúng 100% bề rộng hàng.

## Bảng kích thước hiện tại (mốc 1920)

### A. Thông tin đơn hàng — 1 hàng 13 ô (hàng rộng 1583px)

| Ô | px @1920 (= số trong code) | % hàng | @1536 | @1280 |
| --- | --- | --- | --- | --- |
| Mã đơn hàng | 126 | 8.0% | 94 | 73 |
| Trạng thái | 102 | 6.4% | 76 | 59 |
| Ngày cập nhật | 108 | 6.8% | 81 | 62 |
| NVKD phụ trách | 114 | 7.2% | 85 | 66 |
| Mã Đại Lý | 120 | 7.6% | 90 | 69 |
| Tên khách hàng | 144 | 9.1% | 107 | 83 |
| Ngày đặt hàng | 108 | 6.8% | 81 | 62 |
| Ngày cần giao | 114 | 7.2% | 85 | 66 |
| Người nhận | 108 | 6.8% | 81 | 62 |
| Số điện thoại | 102 | 6.4% | 76 | 59 |
| Địa chỉ nhận hàng | **180** | 11.4% | 134 | 104 |
| Vùng miền | 90 | 5.7% | 67 | 52 |
| Số Km | 96 | 6.1% | 72 | 55 |

### B. Bộ cửa — 1 hàng 17 ô (hàng rộng 1560px)

| Ô | px @1920 | % hàng | @1536 | @1280 |
| --- | --- | --- | --- | --- |
| Bộ số | 85 | 5.4% | 65 | 45 |
| Nhóm cửa | 112 | 7.2% | 86 | 57 |
| **Model** | **330** (sàn 168) | 21.2% | 236 | 172 |
| Ô thoáng | 46 (sàn 46) | 2.9% | 46 | 46 |
| Hướng mở | 46 (sàn 46) | 2.9% | 46 | 46 |
| Phào | 77 | 4.9% | 59 | 41 |
| Màu sơn | 77 | 4.9% | 59 | 41 |
| Cao | 67 | 4.3% | 51 | 35 |
| Rộng | 67 | 4.3% | 51 | 35 |
| Khuôn | 67 | 4.3% | 51 | 35 |
| TT Cao | 77 | 4.9% | 59 | 41 |
| TT Rộng | 77 | 4.9% | 59 | 41 |
| SL bộ | 32 (sàn 30) | 2.1% | 32 | 30 |
| ĐVT | 56 | 3.6% | 43 | 30 |
| KH/L | 77 | 4.9% | 59 | 41 |
| Đơn giá | 76 | 4.9% | 58 | 38 |
| Thành tiền | 87 | 5.6% | 67 | 46 |

### C. Phụ kiện / chi tiết — 10 ô mỗi dòng (hàng rộng 1537px)

| Ô | px @1920 | % hàng | @1536 | @1280 |
| --- | --- | --- | --- | --- |
| Nhóm hàng | 179 | 11.6% | 138 | 100 |
| Model | 220 | 14.3% | 170 | 124 |
| Cao / Rộng / Khuôn | 111 | 7.2% | 86 | 63 |
| ĐVT | 101 | 6.6% | 78 | 58 |
| KH/Lượng | 121 | 7.9% | 93 | 69 |
| Đơn giá | 158 | 10.3% | 122 | 88 |
| Thành tiền | 172 | 11.2% | 133 | 98 |
| Ghi chú | 198 | 12.9% | 153 | 71* |

\* Ghi chú của dòng phụ kiện chia chỗ với nút Xóa nên hẹp hơn ở màn nhỏ.

### D. Ngoài lưới
Ghi chú bộ cửa: tự giãn (1364px @1920) · Hình ảnh SP: cố định 190px · Panel "Tổng hợp giá trị": `1.2fr / 0.8fr`.

## Cách chỉnh sau này (rất đơn giản)

Trong `src/components/order-form.tsx` (3 dòng `xl:grid-cols-[...]`):

```
Thông tin đơn hàng:  xl:grid-cols-[126fr_102fr_108fr_114fr_120fr_144fr_108fr_114fr_108fr_102fr_180fr_90fr_96fr]
Bộ cửa:             xl:grid-cols-[85fr_112fr_minmax(168px,330fr)_minmax(46px,46fr)_minmax(46px,46fr)_77fr_...]
Phụ kiện:           xl:grid-cols-[179fr_220fr_111fr_111fr_111fr_101fr_121fr_158fr_172fr_198fr]
```

**Chỉ cần đổi số `fr` = số px bạn muốn ở màn 1920.** Ví dụ muốn Model 400px → `minmax(168px,400fr)`.
Muốn giữ nguyên 1 ô dù màn nhỏ → ghi px trực tiếp, ví dụ `130px` thay cho `96fr`.

## Mức sàn đang đặt
`Model ≥ 168px`, `Ô thoáng ≥ 46px`, `Hướng mở ≥ 46px`, `SL bộ ≥ 30px` — để màn nhỏ không bóp mất chữ.
Muốn co giãn thuần % (màn nhỏ thì nhỏ hẳn) → bỏ `minmax`, ghi trực tiếp `46fr`.

## Kiểm chứng
Đo trong trình duyệt: @1920 mọi ô đúng bằng số `fr` (Model 329 ≈ 330, Địa chỉ 180, Mã đơn 126…);
@1280 giữ nguyên như trước (Model 172, Địa chỉ 104, 13 ô + 17 ô vẫn 1 hàng, không tràn ngang).
`tsc` 0 lỗi · `next build` thành công · eslint bằng bản gốc.
