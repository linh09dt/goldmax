# ORDER ENTRY UI V77

## Yêu cầu

Sửa UI view **Tạo đơn hàng** theo đúng danh sách đã chốt với người dùng (phương án A + B + C):

- **A** — làm hết các điểm ①–⑦ trong mockup đề xuất.
- **B** — nhóm P1: bỏ cuộn ngang dòng phụ kiện, sửa nút Xóa bộ cửa, ngày mặc định theo giờ máy người dùng.
- **C** — **giữ bộ cửa 17 trường trên 1 hàng** như hiện tại (không tách 2 hàng); chỉ rút ngắn nhãn và cân lại tỷ lệ cột.

## Đã làm

### ① Thông tin đơn hàng tách 2 hàng (7 + 6 trường)
- Hàng 1: Mã đơn hàng · Trạng thái · Ngày cập nhật · NVKD phụ trách · Mã Đại Lý · Tên khách hàng · Ngày đặt hàng.
- Hàng 2: Ngày cần giao hàng · Người nhận · Số điện thoại · **Địa chỉ nhận hàng (rộng gấp đôi)** · Vùng miền · Số Km giao hàng.
- Responsive: 2 cột (mobile) → 3 → 4 → 7 cột (xl).
- **Đo thực tế 1280px: ô nhập 51–93px → 130px**, riêng Địa chỉ nhận hàng 265px (trước đây 93px).

### ② Thu gọn / mở rộng bộ cửa
- Nút ▾/▸ ở tiêu đề từng bộ cửa; khi thu gọn chỉ còn 1 dòng tóm tắt: *SL bộ · KH/Lượng · Đơn giá · Ghi chú*, kèm số phụ kiện trong tiêu đề.
- Nút **Thu gọn tất cả / Mở rộng tất cả** ở tiêu đề nhóm, kèm dòng tổng: *số bộ cửa · số dòng phụ kiện · tổng tiền*.
- Trạng thái thu gọn giữ theo từng bộ (không mất khi sửa dữ liệu khác).

### ③ Giữ 17 trường bộ cửa trên 1 hàng (theo phương án C)
- Cân lại tỷ lệ 17 cột (Nhóm cửa 66→80px, Model 73→84px, Hướng mở 39→59px, Bộ số 48→60px…), giảm padding nhãn.
- Nhãn dài rút gọn: **KT thông thủy - Cao → TT Cao**, **KT thông thủy - Rộng → TT Rộng** (chú thích đầy đủ khi rê chuột).
- **Đo lại 1280px: không còn ô/nhãn nào bị cắt chữ** (trước đây nhãn “Hướng mở” và các select bị cắt).
- Không cuộn ngang: bề ngang trang bằng đúng bề ngang màn hình.

### ④ Ô Bộ số
- Khi đơn còn Nháp / Chờ khách hàng xác nhận: ô chỉ đọc hiện chữ mờ nghiêng **“Tự động”** (kèm tooltip giải thích) thay vì dấu “—”.
- Khi đơn Đã xác nhận / Đã chuyển sản xuất: hiện đúng Bộ số đã cấp. Không đổi quy tắc V75.

### ⑤ Dòng phụ kiện bỏ cuộn ngang
- Bỏ `min-w-[1240px]`, thay bằng lưới co giãn theo màn hình (2 cột → 4 cột → 10 cột ở xl) — không còn vùng cuộn ngang bên trong.
- **Đo thực tế 1280px: 0 vùng cuộn ngang**, KH/Lượng, Đơn giá, Thành tiền, Ghi chú và nút Xóa luôn hiển thị.

### ⑥ Thanh lưu dưới cùng
- Thêm dải tổng hợp bên trái: **Cả đơn: …đ · N bộ cửa · M phụ kiện · Còn lại: …đ** (trước đây chỉ có 1 nút Lưu).

### ⑦ Nút Xóa bộ cửa
- Chỉ còn 1 bộ cửa: nút **bị vô hiệu hoá** kèm chú thích “Đơn hàng phải có ít nhất 1 bộ cửa” (trước đây bấm không có phản hồi).
- Bộ cửa đã có phụ kiện hoặc ảnh: **hỏi xác nhận** trước khi xóa, nêu rõ số dòng phụ kiện và ảnh sẽ mất.

### Ngày mặc định theo giờ máy người dùng
- Thêm `localTodayInput()` (dùng giờ địa phương) trong `src/lib/order-form.ts`.
- Khi **tạo đơn mới**, Ngày đặt hàng + Ngày cập nhật tự lấy theo ngày của máy người dùng (server Vercel chạy UTC nên trước đây đơn tạo trước 7h sáng giờ VN bị lùi 1 ngày).
- Chỉ thay khi người dùng **chưa sửa** hai ô đó — không ghi đè dữ liệu đã nhập.

## Kiểm chứng

- `npx tsc --noEmit`: 0 lỗi · `next build`: thành công.
- `npx eslint src/components/order-form.tsx src/lib/order-form.ts`: **4 errors / 12 warnings — đúng bằng bản gốc**, không phát sinh lỗi mới.
- Chạy `next dev` + đo bằng script trong trình duyệt ở màn **1280×720**:
  - Ô nhập Thông tin đơn hàng: 51–93px → **130px** (Địa chỉ 265px).
  - Bộ cửa: Nhóm cửa 80px, Model 84px, Hướng mở 59px, Bộ số 60px; **0 nhãn/ô bị cắt chữ**.
  - Sau khi thêm dòng phụ kiện: **0 vùng cuộn ngang**, trang không tràn ngang (`docOverflow = 0`).
  - Nút Xóa bộ cửa: `disabled = true`, tooltip “Đơn hàng phải có ít nhất 1 bộ cửa” khi chỉ có 1 bộ.
  - Thu gọn 1 bộ và “Thu gọn tất cả”: lưới dữ liệu ẩn hết, dòng tóm tắt hiển thị đúng; “Mở rộng tất cả” khôi phục lại.
  - Ngày đặt hàng / Ngày cập nhật mặc định = ngày hôm nay theo giờ máy.
- Ảnh chụp thật sau khi sửa: `ui-sau-1280.png`, trạng thái thu gọn: `ui-thu-gon-1280.png`.

## Không thay đổi

- Không đổi logic tính tiền, KH/Lượng, quy tắc Bộ số (V75), API, Prisma schema, `.env`, in PDF/Excel.
- Không cần `npm run db:migrate`.

## File thay đổi

- `src/components/order-form.tsx`
- `src/lib/order-form.ts`
