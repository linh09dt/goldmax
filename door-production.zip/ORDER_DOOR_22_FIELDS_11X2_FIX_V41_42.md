# V41.42 – Sửa đúng 22 trường Bộ cửa thành 11 cột × 2 dòng

## Mục tiêu
Khôi phục đúng bố cục đã chốt cho phần nhập **Bộ cửa**. V41.41 chỉ thay font/label nhưng source thực tế vẫn còn chia thành nhiều khối, nên giao diện chưa đúng 11 × 2.

## Bố cục desktop mới
### Dòng 1
1. Bộ số
2. Nhóm cửa
3. Model
4. Tên sản phẩm
5. Ô thoáng
6. Hướng mở
7. Phào
8. Màu sơn
9. Cao
10. Rộng
11. Khuôn

### Dòng 2
12. KT thông thủy - Cao
13. KT thông thủy - Rộng
14. SL bộ
15. ĐVT
16. KH/Lượng
17. Đơn giá
18. Model khóa
19. Loại phào
20. Thanh phào / bộ
21. Nan ô thoáng
22. Cánh / bộ

## Phần riêng bên dưới
- Ghi chú
- Hình ảnh SP

Hai field này không tham gia lưới 11 × 2.

## UI giữ lại từ V41.41
- Font input/select 12px.
- Chiều cao field 36px.
- Label có nền slate nhạt, border nhẹ, font 10px.
- Giá đại lý / bán lẻ và toàn bộ logic dữ liệu giữ nguyên.

## Responsive
- Desktop XL: 11 cột đúng 2 dòng.
- Màn hình hẹp tự xuống 6 / 4 / 2 cột để không vỡ giao diện.

## File sửa
- `src/components/order-form.tsx`

## Kiểm tra
- TypeScript transpile/syntax: 0 lỗi.
- Full `npm run build` chưa chạy được trong sandbox vì binary `prisma` không có trong `node_modules/.bin` của workspace hiện tại; không liên quan thay đổi TSX này.
