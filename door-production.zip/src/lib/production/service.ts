/**
 * V136 — Tầng truy cập dữ liệu module Lên kế hoạch sản xuất.
 *
 * Quy ước ghi DB (bài học V111): DB production là Supabase pooler, mỗi lượt round trip
 * 40–100 ms → KHÔNG ghi từng dòng. Mọi cập nhật tiến độ đi bằng:
 *   - 1 câu UPDATE ... FROM jsonb_to_recordset(...)  cho bảng `production_tasks`
 *   - 1 câu createMany                              cho bảng `production_logs`
 */

import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/prisma";
import { ORDER_WRITE_TRANSACTION } from "@/lib/db-transaction";
import { CONFIRMED_STATUS_CODES } from "@/lib/order-form";
import {
  addWorkingDays,
  buildCalendar,
  dateKeyUtc,
  MS_DAY,
  parseIsoDateStrict,
  startOfDayUtc,
  subtractWorkingDays,
  todayInVietnam,
  workingDaysBetween,
  type WorkingCalendar,
} from "@/lib/production/calendar";

export { parseIsoDateStrict };
import {
  canhEquivalentOf,
  deriveSetStatus,
  percentDoneOf,
  STAGE,
  taskUnlockState,
  type ProductionSetRow,
  type ProductionStageRow,
  type ProductionTaskRow,
  type ProductionWorkCenterRow,
  type TaskStatus,
} from "@/lib/production/catalog";
import {
  DEFAULT_PRODUCTION_CONFIG,
  normalizeProductionConfig,
  PRODUCTION_CONFIG_SETTING_KEY,
  type ProductionConfig,
} from "@/lib/production/config";
import { buildComponentOrderDrafts, buildTaskDrafts } from "@/lib/production/routing";
import {
  buildStagePlan,
  capacityOfStage,
  demandOfTask,
  loadUnitOfStage,
  PLANNABLE_SET_STATUSES,
  type CapacitySource,
  type LoadUnit,
  type StagePlanResult,
} from "@/lib/production/stage-plan";
import { downstreamTasksToClear, setPlanRange, waitStateOfTask } from "@/lib/production/manual-plan";
import { groupKeyOf, groupingOf, makePaintGroupResolver } from "@/lib/production/priority";
import { BATCH_GROUP_CODES, readyDayFor } from "@/lib/production/stage-plan";
import {
  evaluateDayProgress,
  lotLabelOf,
  mergePrevStatus,
  predecessorText,
  shiftWindow,
  vietnamMinutesNow,
  type DayProgress,
  type PrevStatus,
  type TaskAction,
} from "@/lib/production/team-report";
import { scheduleQueue } from "@/lib/production/dispatch";
import {
  normalizePriorityConfig,
  PRIORITY_CONFIG_SETTING_KEY,
  scoreSet,
  type OrderFacts,
  type PaintColorRow,
  type PriorityConfig,
} from "@/lib/production/priority";
import { defaultPriorityForOrderType } from "@/lib/production/scheduling";
import {
  assignWorkOrderCodes,
  resolveWorkOrderTemplate,
  workOrderCodeInputsForSet,
} from "@/lib/production/work-order";
import {
  computeStepTargets,
  targetStepsFromTasks,
  targetTotalDays,
  type StepTarget,
} from "@/lib/production/targets";

export const SET_INCLUDE_TASKS = {
  tasks: { orderBy: [{ seq: "asc" }, { scope: "asc" }] },
  componentOrders: { orderBy: { kind: "asc" } },
} satisfies Prisma.ProductionSetInclude;

/**
 * V142 — sinh dòng LỆNH SẢN XUẤT cho MỘT bộ: 1 lệnh cha → 3 lệnh con → 1 lệnh mỗi công đoạn.
 * Mã lệnh theo mẫu trong Cấu hình; lệnh công đoạn gắn `taskId` để tra cứu ngược.
 */
function buildWorkOrderRows(args: {
  setId: number;
  orderCode: string | null;
  setNo: string | null;
  tasks: Array<{ id: number; seq: number; scope: string; stageCode: string }>;
  config: ProductionConfig;
}): Prisma.ProductionWorkOrderCreateManyInput[] {
  const template = resolveWorkOrderTemplate(args.orderCode, args.config.workOrderCodeTemplate);
  const inputs = workOrderCodeInputsForSet({
    setId: args.setId,
    orderCode: args.orderCode,
    setNo: args.setNo,
    tasks: args.tasks,
  });
  const codes = assignWorkOrderCodes(inputs, template);

  const rows: Prisma.ProductionWorkOrderCreateManyInput[] = inputs.map((input, index) => ({
    code: codes[index],
    setId: args.setId,
    taskId: null,
    kind: input.kind,
    stageCode: input.kind === "CONG_DOAN" ? input.stageCode ?? null : null,
    scope: input.kind === "CONG_DOAN" ? input.scope ?? null : null,
    seq: input.kind === "CONG_DOAN" ? input.seq ?? null : null,
  }));

  // Gắn taskId: các lệnh công đoạn đi đúng thứ tự `tasks` truyền vào.
  let taskIndex = 0;
  for (const row of rows) {
    if (row.kind !== "CONG_DOAN") continue;
    row.taskId = args.tasks[taskIndex]?.id ?? null;
    taskIndex += 1;
  }
  return rows;
}

// ---------------------------------------------------------------------------
// Cấu hình & danh mục
// ---------------------------------------------------------------------------

export async function readProductionConfig(): Promise<ProductionConfig> {
  const setting = await prisma.systemSetting.findUnique({
    where: { key: PRODUCTION_CONFIG_SETTING_KEY },
    select: { value: true },
  });
  if (!setting?.value) return { ...DEFAULT_PRODUCTION_CONFIG, workingDays: [...DEFAULT_PRODUCTION_CONFIG.workingDays] };
  try {
    return normalizeProductionConfig(JSON.parse(setting.value));
  } catch {
    return { ...DEFAULT_PRODUCTION_CONFIG, workingDays: [...DEFAULT_PRODUCTION_CONFIG.workingDays] };
  }
}

export async function saveProductionConfig(config: ProductionConfig): Promise<ProductionConfig> {
  const normalized = normalizeProductionConfig(config);
  await prisma.systemSetting.upsert({
    where: { key: PRODUCTION_CONFIG_SETTING_KEY },
    create: { key: PRODUCTION_CONFIG_SETTING_KEY, value: JSON.stringify(normalized) },
    update: { value: JSON.stringify(normalized) },
  });
  return normalized;
}

export async function loadWorkCenters(): Promise<ProductionWorkCenterRow[]> {
  return prisma.productionWorkCenter.findMany({ orderBy: [{ sortOrder: "asc" }, { code: "asc" }] });
}

export async function loadActiveWorkCenters(): Promise<ProductionWorkCenterRow[]> {
  return prisma.productionWorkCenter.findMany({ where: { active: true }, orderBy: [{ sortOrder: "asc" }, { code: "asc" }] });
}

export async function loadStages(): Promise<ProductionStageRow[]> {
  return prisma.productionStage.findMany({ orderBy: [{ seq: "asc" }, { code: "asc" }] });
}

export async function loadActiveStages(): Promise<ProductionStageRow[]> {
  return prisma.productionStage.findMany({ where: { active: true }, orderBy: [{ seq: "asc" }, { code: "asc" }] });
}

export async function loadReasons() {
  return prisma.productionReason.findMany({ orderBy: [{ group: "asc" }, { sortOrder: "asc" }] });
}

/** Model đã có chương trình máy cắt (Bồi Lares tái dùng — V121). */
export async function loadProgramModels(): Promise<Set<string>> {
  const rows = await prisma.productionProgram.findMany({ select: { model: true } });
  return new Set(rows.map((row) => String(row.model ?? "").trim().toUpperCase()).filter(Boolean));
}

/** Lịch làm việc: ngày trong tuần theo cấu hình + các ngày nghỉ/lễ trong bảng production_calendar. */
export async function loadCalendar(config?: ProductionConfig): Promise<WorkingCalendar> {
  const effective = config ?? (await readProductionConfig());
  const holidays = await prisma.productionCalendar.findMany({
    where: { isWorkingDay: false },
    select: { date: true },
  });
  return buildCalendar(effective, holidays.map((row) => row.date));
}

// ---------------------------------------------------------------------------
// Nạp bộ cửa từ đơn hàng vào kế hoạch
// ---------------------------------------------------------------------------

export type SyncResult = { createdSets: number; createdTasks: number; skipped: number };

/**
 * Tạo `production_sets` + `production_tasks` cho các bộ cửa của đơn ĐÃ XÁC NHẬN
 * mà chưa có trong kế hoạch. Idempotent: bộ đã có thì bỏ qua.
 */
export async function syncProductionSets(options: {
  orderItemIds?: number[];
  orderIds?: number[];
  limit?: number;
} = {}): Promise<SyncResult> {
  const config = await readProductionConfig();
  const stages = await loadActiveStages();
  const programModels = await loadProgramModels();

  const orderItems = await prisma.salesOrderItem.findMany({
    where: {
      ...(options.orderItemIds?.length ? { id: { in: options.orderItemIds } } : {}),
      ...(options.orderIds?.length ? { orderId: { in: options.orderIds } } : {}),
      order: {
        status: { in: CONFIRMED_STATUS_CODES },
        orderType: { in: config.entryOrderTypes },
      },
    },
    select: {
      id: true,
      orderId: true,
      setNo: true,
      model: true,
      productName: true,
      openingDirection: true,
      paintColor: true,
      heightMm: true,
      widthMm: true,
      leavesPerSet: true,
      trimBarsPerSet: true,
      quantity: true,
      pricingQuantity: true,
      order: { select: { orderCode: true, orderType: true, customerName: true, requiredDeliveryDate: true } },
    },
    orderBy: [{ id: "asc" }],
    take: options.limit && options.limit > 0 ? options.limit : undefined,
  });
  if (!orderItems.length) return { createdSets: 0, createdTasks: 0, skipped: 0 };

  const existing = await prisma.productionSet.findMany({
    where: {
      OR: [
        { orderItemId: { in: orderItems.map((item) => item.id) } },
        { orderId: { in: Array.from(new Set(orderItems.map((item) => item.orderId))) } },
      ],
    },
    select: { orderItemId: true, orderId: true, setNo: true },
  });
  // Chống trùng theo 2 cách: theo id dòng hàng, VÀ theo (mã đơn + Bộ số).
  // Cách thứ 2 cần thiết vì khi SỬA ĐƠN, route cập nhật XOÁ dòng hàng cũ rồi tạo lại
  // (id mới) → nếu chỉ so id thì bộ sẽ bị đưa vào kế hoạch lần thứ hai.
  const plannedItemIds = new Set(existing.map((row) => row.orderItemId).filter((value): value is number => value !== null));
  const plannedOrderSetNo = new Set(
    existing
      .filter((row) => String(row.setNo ?? "").trim())
      .map((row) => `${row.orderId}|${String(row.setNo).trim().toUpperCase()}`),
  );
  // Trong CÙNG một lượt đưa vào kế hoạch: 2 dòng hàng cùng đơn + cùng Bộ số là dữ liệu lỗi.
  // Chỉ lấy dòng ĐẦU — nếu lấy cả hai thì 2 bộ sẽ trùng mã lệnh và cả transaction bị huỷ (V142).
  const seenOrderSetNo = new Set<string>();
  const pending = orderItems.filter((item) => {
    if (plannedItemIds.has(item.id)) return false;
    const setNo = String(item.setNo ?? "").trim().toUpperCase();
    if (setNo && plannedOrderSetNo.has(`${item.orderId}|${setNo}`)) return false;
    if (setNo && seenOrderSetNo.has(`${item.orderId}|${setNo}`)) return false;
    if (setNo) seenOrderSetNo.add(`${item.orderId}|${setNo}`);
    return true;
  });
  if (!pending.length) return { createdSets: 0, createdTasks: 0, skipped: orderItems.length };

  return prisma.$transaction(async (tx) => {
    const createdSets = await tx.productionSet.createManyAndReturn({
      data: pending.map((item) => {
        const leaves = item.leavesPerSet ?? null;
        const quantity = item.quantity ?? null;
        return {
          orderId: item.orderId,
          orderItemId: item.id,
          orderCode: item.order?.orderCode ?? null,
          setNo: item.setNo ?? null,
          orderType: item.order?.orderType ?? "SAN_XUAT",
          customerName: item.order?.customerName ?? null,
          productName: item.productName ?? null,
          model: item.model ?? null,
          openingDirection: item.openingDirection ?? null,
          paintColor: item.paintColor ?? null,
          heightMm: item.heightMm ?? null,
          widthMm: item.widthMm ?? null,
          leavesPerSet: leaves,
          trimBarsPerSet: item.trimBarsPerSet ?? null,
          quantity,
          pricingQuantity: item.pricingQuantity ?? null,
          canhEquivalent: canhEquivalentOf({ leavesPerSet: leaves, quantity }),
          dueDate: item.order?.requiredDeliveryDate ?? null,
          priority: defaultPriorityForOrderType(item.order?.orderType),
          status: "CHO_XEP_LICH",
        };
      }),
      select: { id: true, orderItemId: true },
    });

    // Sinh công đoạn cho từng bộ — mỗi BẢNG một lượt ghi (bài học V111).
    const setByOrderItem = new Map(createdSets.map((row) => [row.orderItemId, row.id]));
    // Mã đơn / bộ số của từng bộ vừa tạo — dùng để sinh mã lệnh.
    const setMetaById = new Map<number, { orderCode: string | null; setNo: string | null }>();
    for (const item of pending) {
      const setId = setByOrderItem.get(item.id);
      if (!setId) continue;
      setMetaById.set(setId, { orderCode: item.order?.orderCode ?? null, setNo: item.setNo ?? null });
    }
    const taskRows: Prisma.ProductionTaskCreateManyInput[] = [];
    const componentRows: Prisma.ProductionComponentOrderCreateManyInput[] = [];
    for (const item of pending) {
      const setId = setByOrderItem.get(item.id);
      if (!setId) continue;
      const setRow = {
        leavesPerSet: item.leavesPerSet ?? null,
        quantity: item.quantity ?? null,
        trimBarsPerSet: item.trimBarsPerSet ?? null,
        productName: item.productName ?? null,
        paintColor: item.paintColor ?? null,
        veneerCode: null,
        model: item.model ?? null,
      } as ProductionSetRow;

      // LỆNH CON: đúng 3 lệnh — CÁNH / KHUNG / PHÀO.
      for (const draft of buildComponentOrderDrafts(setRow, config)) {
        componentRows.push({ setId, kind: draft.kind, qtyExpected: draft.qtyExpected });
      }

      const drafts = buildTaskDrafts({
        set: setRow,
        stages,
        config,
        modelHasProgram: programModels.has(String(item.model ?? "").trim().toUpperCase()),
      });
      for (const draft of drafts) {
        taskRows.push({
          setId,
          orderItemId: item.id,
          stageCode: draft.stageCode,
          stageKind: draft.stageKind,
          scope: draft.scope,
          seq: draft.seq,
          workCenterCode: draft.workCenterCode,
          status: draft.status,
          qtyExpected: draft.qtyExpected,
        });
      }
    }
    if (componentRows.length) {
      await tx.productionComponentOrder.createMany({ data: componentRows });
    }

    // LỆNH SẢN XUẤT (V142): 1 lệnh cha + 3 lệnh con + 1 lệnh mỗi công đoạn — vẫn 1 lượt ghi.
    // Lệnh cha/3 lệnh con có NGAY cả khi bộ chưa có công đoạn nào (danh mục công đoạn trống).
    const tasksBySet = new Map<number, Array<{ id: number; seq: number; scope: string; stageCode: string }>>();
    if (taskRows.length) {
      const createdTasks = await tx.productionTask.createManyAndReturn({
        data: taskRows,
        select: { id: true, setId: true, seq: true, scope: true, stageCode: true },
      });
      for (const task of createdTasks) {
        const list = tasksBySet.get(task.setId) ?? [];
        list.push({ id: task.id, seq: task.seq, scope: task.scope, stageCode: task.stageCode });
        tasksBySet.set(task.setId, list);
      }
    }
    const workOrderRows: Prisma.ProductionWorkOrderCreateManyInput[] = [];
    for (const created of createdSets) {
      const meta = setMetaById.get(created.id);
      // Sắp theo (bước, bộ phận) để mã lệnh ổn định dù DB trả về thứ tự nào.
      const tasks = (tasksBySet.get(created.id) ?? []).sort(
        (a, b) => a.seq - b.seq || a.scope.localeCompare(b.scope) || a.id - b.id,
      );
      workOrderRows.push(
        ...buildWorkOrderRows({
          setId: created.id,
          orderCode: meta?.orderCode ?? null,
          setNo: meta?.setNo ?? null,
          tasks,
          config,
        }),
      );
    }
    if (workOrderRows.length) {
      await tx.productionWorkOrder.createMany({ data: workOrderRows });
    }

    return { createdSets: createdSets.length, createdTasks: taskRows.length, skipped: orderItems.length - pending.length };
  }, ORDER_WRITE_TRANSACTION);
}

/** Sinh lại công đoạn cho MỘT bộ đã có (dùng khi danh mục công đoạn thay đổi). */
export async function rebuildTasksForSet(setId: number): Promise<{ createdTasks: number; createdWorkOrders: number }> {
  const config = await readProductionConfig();
  const stages = await loadActiveStages();
  const programModels = await loadProgramModels();
  const set = await prisma.productionSet.findUnique({
    where: { id: setId },
    include: { componentOrders: true },
  });
  if (!set) throw new Error("Không tìm thấy bộ cửa.");
  if (set.startedAt) {
    throw new Error("Bộ đã vào sản xuất — không sinh lại công đoạn (sẽ mất tiến độ và mốc sản xuất).");
  }

  const drafts = buildTaskDrafts({
    set: set as ProductionSetRow,
    stages,
    config,
    modelHasProgram: programModels.has(String(set.model ?? "").trim().toUpperCase()),
  });

  return prisma.$transaction(async (tx) => {
    // Lệnh sản xuất sinh lại theo công đoạn mới → xoá hết lệnh cũ của bộ (lệnh công đoạn
    // còn bị xoá theo khoá ngoại khi xoá công đoạn, nhưng lệnh cha/con thì không).
    await tx.productionWorkOrder.deleteMany({ where: { setId } });
    await tx.productionTask.deleteMany({ where: { setId } });
    await tx.productionComponentOrder.deleteMany({ where: { setId } });
    await tx.productionComponentOrder.createMany({
      data: buildComponentOrderDrafts(set as ProductionSetRow, config).map((draft) => ({
        setId,
        kind: draft.kind,
        qtyExpected: draft.qtyExpected,
      })),
    });
    if (!drafts.length) {
      // Vẫn phải có lệnh cha + 3 lệnh con cho bộ (danh mục công đoạn đang trống).
      const emptyRows = buildWorkOrderRows({
        setId,
        orderCode: set.orderCode ?? null,
        setNo: set.setNo ?? null,
        tasks: [],
        config,
      });
      if (emptyRows.length) await tx.productionWorkOrder.createMany({ data: emptyRows });
      return { createdTasks: 0, createdWorkOrders: emptyRows.length };
    }
    const createdTasks = await tx.productionTask.createManyAndReturn({
      data: drafts.map((draft) => ({
        setId,
        orderItemId: set.orderItemId,
        stageCode: draft.stageCode,
        stageKind: draft.stageKind,
        scope: draft.scope,
        seq: draft.seq,
        workCenterCode: draft.workCenterCode,
        status: draft.status,
        qtyExpected: draft.qtyExpected,
      })),
      select: { id: true, seq: true, scope: true, stageCode: true },
    });
    const tasks = createdTasks
      .map((task) => ({ id: task.id, seq: task.seq, scope: task.scope, stageCode: task.stageCode }))
      .sort((a, b) => a.seq - b.seq || a.scope.localeCompare(b.scope) || a.id - b.id);
    const workOrderRows = buildWorkOrderRows({
      setId,
      orderCode: set.orderCode ?? null,
      setNo: set.setNo ?? null,
      tasks,
      config,
    });
    if (workOrderRows.length) {
      await tx.productionWorkOrder.createMany({ data: workOrderRows });
    }
    return { createdTasks: drafts.length, createdWorkOrders: workOrderRows.length };
  }, ORDER_WRITE_TRANSACTION);
}

// ---------------------------------------------------------------------------
// V144 — ĐƯA VÀO SẢN XUẤT: nhập MỘT mốc ngày bắt đầu → tự suy target của mọi công đoạn
// ---------------------------------------------------------------------------

const isoDateOnly = (value: Date): string => value.toISOString().slice(0, 10);

export type StartPlanStep = {
  seq: number;
  codes: string[];
  /** SỐ NGÀY của bước (V145) */
  days: number;
  start: string;
  end: string;
};

export type StartPreview = {
  /** ngày bắt đầu thực tế (đã dời sang ngày làm việc nếu rơi vào Chủ nhật/ngày lễ) */
  start: Date;
  requestedStart: Date;
  movedToWorkingDay: boolean;
  /** ngày xong dự kiến của cả bộ */
  end: Date;
  totalDays: number;
  steps: StartPlanStep[];
  /** hạn xưởng phải xong = hạn giao khách − đệm vận chuyển */
  workshopDue: Date | null;
  /** số ngày làm việc KHÔNG KỊP (null = kịp hoặc không có hạn giao) */
  lateDays: number | null;
};

/** Tính trước kế hoạch (không ghi DB) để người dùng xem rồi mới bấm "Đưa vào sản xuất". */
export async function previewSetStart(setId: number, requestedStart: Date): Promise<StartPreview | null> {
  const [config, stages, set] = await Promise.all([
    readProductionConfig(),
    loadActiveStages(),
    prisma.productionSet.findUnique({ where: { id: setId }, include: { tasks: true } }),
  ]);
  if (!set) return null;
  const stageByCode = new Map(stages.map((stage) => [stage.code, stage]));
  const steps = targetStepsFromTasks(set.tasks, stageByCode);
  if (!steps.length) return null;
  const calendar = await loadCalendar(config);
  return buildStartPreview({ requestedStart, steps, config, calendar, dueDate: set.dueDate });
}

function buildStartPreview(args: {
  requestedStart: Date;
  steps: Parameters<typeof computeStepTargets>[0]["steps"];
  config: ProductionConfig;
  calendar: WorkingCalendar;
  dueDate: Date | null;
}): StartPreview {
  const targets: StepTarget[] = computeStepTargets({
    start: args.requestedStart,
    steps: args.steps,
    config: args.config,
    calendar: args.calendar,
  });
  const start = targets[0].start;
  const end = targets[targets.length - 1].end;
  const workshopDue = args.dueDate
    ? startOfDayUtc(subtractWorkingDays(args.dueDate, args.config.deliveryBufferDays, args.calendar))
    : null;
  const lateDays =
    workshopDue && end.getTime() > workshopDue.getTime()
      ? Math.max(0, workingDaysBetween(workshopDue, end, args.calendar))
      : null;
  return {
    start,
    requestedStart: startOfDayUtc(args.requestedStart),
    movedToWorkingDay: startOfDayUtc(args.requestedStart).getTime() !== start.getTime(),
    end,
    totalDays: targetTotalDays(targets, args.calendar),
    steps: targets.map((step) => ({
      seq: step.seq,
      codes: step.codes,
      days: step.days,
      start: isoDateOnly(step.start),
      end: isoDateOnly(step.end),
    })),
    workshopDue,
    lateDays,
  };
}

/**
 * ĐƯA BỘ VÀO SẢN XUẤT: lưu mốc bắt đầu, tự suy target cho MỌI công đoạn,
 * chuyển bộ sang DANG_SX và công đoạn đầu tiên sang DANG_LAM. Ghi gộp 1 lượt (bài học V111).
 */
export async function startProductionForSet(
  setId: number,
  requestedStart: Date,
  byName: string | null = null,
): Promise<{ start: Date; end: Date; totalDays: number; tasks: number; startedSeq: number }> {
  const [config, stages, set] = await Promise.all([
    readProductionConfig(),
    loadActiveStages(),
    prisma.productionSet.findUnique({ where: { id: setId }, include: { tasks: true } }),
  ]);
  if (!set) throw new Error("Không tìm thấy bộ cửa.");
  if (set.status === "HUY") throw new Error("Bộ đã huỷ — không đưa vào sản xuất được.");
  if (set.startedAt) throw new Error("Bộ đã vào sản xuất (đã có ngày bắt đầu sản xuất).");
  if (set.status === "DANG_SX" || set.status === "HOAN_THANH" || set.status === "DA_GIAO") {
    throw new Error("Bộ đã vào sản xuất rồi.");
  }
  const stageByCode = new Map(stages.map((stage) => [stage.code, stage]));
  const steps = targetStepsFromTasks(set.tasks, stageByCode);
  if (!steps.length) throw new Error("Bộ chưa có công đoạn nào để sản xuất.");

  const calendar = await loadCalendar(config);
  const preview = buildStartPreview({ requestedStart, steps, config, calendar, dueDate: set.dueDate });
  const targetBySeq = new Map(preview.steps.map((step) => [step.seq, step]));
  const records = set.tasks.map((task) => {
    const target = targetBySeq.get(task.seq);
    return {
      id: task.id,
      target_start: target ? target.start : null,
      target_end: target ? target.end : null,
    };
  });
  const firstSeq = steps[0].seq;

  return prisma.$transaction(async (tx) => {
    const updated = await tx.$executeRaw`
      UPDATE production_tasks AS t
      SET target_start = v.target_start::date,
          target_end   = v.target_end::date,
          updated_at   = now()
      FROM jsonb_to_recordset(${JSON.stringify(records)}::jsonb) AS v(id int, target_start text, target_end text)
      WHERE t.id = v.id AND t.set_id = ${setId}`;
    // Ghi thiếu dòng nào là lỗi thật (không được im lặng báo thành công).
    if (Number(updated) !== records.length) {
      throw new Error(`Chỉ ghi được mốc cho ${Number(updated)}/${records.length} công đoạn — đã huỷ, không đưa vào sản xuất.`);
    }
    // WIP ở CÔNG ĐOẠN ĐẦU TIÊN
    await tx.productionTask.updateMany({
      where: { setId, seq: firstSeq, status: "CHUA_LAM" },
      data: { status: "DANG_LAM" },
    });
    await tx.productionSet.update({
      where: { id: setId },
      data: { startedAt: preview.start, targetEnd: preview.end, status: "DANG_SX" },
    });
    await tx.productionLog.create({
      data: {
        entity: "SET",
        entityId: setId,
        action: "BAT_DAU_SAN_XUAT",
        field: "started_at",
        oldValue: null,
        newValue: isoDateOnly(preview.start),
        byName,
      },
    });
    return {
      start: preview.start,
      end: preview.end,
      totalDays: preview.totalDays,
      tasks: Number(updated),
      startedSeq: firstSeq,
    };
  }, ORDER_WRITE_TRANSACTION);
}

// ---------------------------------------------------------------------------
// Đọc bảng kế hoạch
// ---------------------------------------------------------------------------

export type ProductionBoard = {
  sets: ProductionSetRow[];
  tasks: ProductionTaskRow[];
  workCenters: ProductionWorkCenterRow[];
  stages: ProductionStageRow[];
  config: ProductionConfig;
  calendar: WorkingCalendar;
  programModels: Set<string>;
};

export async function loadProductionBoard(options: {
  from?: Date;
  to?: Date;
  includeUndated?: boolean;
  statusIn?: string[];
  includeCompletedForLoad?: boolean;
} = {}): Promise<ProductionBoard> {
  const [config, workCenters, stages, programModels] = await Promise.all([
    readProductionConfig(),
    loadActiveWorkCenters(),
    loadActiveStages(),
    loadProgramModels(),
  ]);

  const dateConditions: Array<Record<string, unknown>> = [];
  if (options.from && options.to) {
    dateConditions.push({ plannedStart: { gte: startOfDayUtc(options.from), lte: startOfDayUtc(options.to) } });
  }
  if (options.includeUndated) dateConditions.push({ plannedStart: null });

  const sets = await prisma.productionSet.findMany({
    where: {
      // V137: bộ đã HUỶ (do bị xoá khỏi đơn…) không hiện trên bảng kế hoạch.
      ...(options.statusIn?.length ? { status: { in: options.statusIn } } : { status: { not: "HUY" } }),
      ...(dateConditions.length ? { OR: dateConditions } : {}),
    },
    include: SET_INCLUDE_TASKS,
    orderBy: [{ dueDate: "asc" }, { id: "asc" }],
  });

  const tasks = await prisma.productionTask.findMany({
    where: { setId: { in: sets.map((set) => set.id) } },
    orderBy: [{ setId: "asc" }, { seq: "asc" }],
  });

  const calendar = await loadCalendar(config);
  return {
    sets: sets as unknown as ProductionSetRow[],
    tasks: tasks as unknown as ProductionTaskRow[],
    workCenters,
    stages,
    config,
    calendar,
    programModels,
  };
}

export async function loadSetDetail(setId: number) {
  const [set, config, stages, reasons, programModels] = await Promise.all([
    prisma.productionSet.findUnique({
      where: { id: setId },
      include: {
        tasks: { orderBy: [{ seq: "asc" }, { scope: "asc" }] },
        componentOrders: { orderBy: { kind: "asc" } },
        workOrders: { orderBy: { id: "asc" }, include: { task: { select: { status: true } } } },
        plan: true,
      },
    }),
    readProductionConfig(),
    loadStages(),
    loadReasons(),
    loadProgramModels(),
  ]);
  if (!set) return null;
  const calendar = await loadCalendar(config);
  const logs = await prisma.productionLog.findMany({
    where: { entity: "SET", entityId: setId },
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  return { set, config, stages, reasons, calendar, logs, programModels };
}

// ---------------------------------------------------------------------------
// Cập nhật tiến độ (GHI GỘP — 2 lượt ghi cho cả bộ)
// ---------------------------------------------------------------------------

export type TaskPatch = {
  id: number;
  status?: TaskStatus;
  actualStart?: string | null;
  actualEnd?: string | null;
  /** V141 — XẾP LỊCH BẰNG TAY: ngày kế hoạch của công đoạn ("YYYY-MM-DD"). undefined = không đổi, null = xoá. */
  plannedStart?: string | null;
  note?: string | null;
  reasonCode?: string | null;
  assignee?: string | null;
  isRework?: boolean;
};

/** V137: sửa tay số lượng của lệnh con (bộ cần số phào/cánh khác công thức). */
export type ComponentPatch = { id: number; qtyExpected: number | null };

export type UpdateSetPayload = {
  tasks?: TaskPatch[];
  components?: ComponentPatch[];
  plannedStart?: string | null;
  plannedEnd?: string | null;
  note?: string | null;
  planId?: number | null;
  materialReady?: boolean;
  programReady?: boolean;
  /** Tên người cập nhật — chưa có đăng nhập nên gõ tay (V115). */
  byName?: string | null;
};

function parseDateOnly(value: string | null | undefined): Date | null {
  const text = String(value ?? "").trim();
  if (!text) return null;
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return null;
  return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
}

function parseTimestamp(value: string | null | undefined): string | null {
  const text = String(value ?? "").trim();
  if (!text) return null;
  const date = new Date(text);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString();
}

export async function updateSetProgress(setId: number, payload: UpdateSetPayload) {
  const set = await prisma.productionSet.findUnique({
    where: { id: setId },
    select: { id: true, status: true, orderItemId: true, model: true, setNo: true, orderCode: true, plannedStart: true },
  });
  if (!set) throw new Error("Không tìm thấy bộ cửa.");

  const existingTasks = await prisma.productionTask.findMany({
    where: { setId },
    select: { id: true, stageKind: true, status: true, stageCode: true, scope: true, isRework: true },
  });
  const byId = new Map(existingTasks.map((task) => [task.id, task]));
  const now = new Date().toISOString();

  const patches = (payload.tasks ?? []).filter((patch) => byId.has(patch.id));

  // --- GATE (V136.1): công đoạn chỉ được bắt đầu/kết thúc khi công đoạn bắt buộc đã XONG ---
  // Nhà máy: "nếu các công đoạn hàn được báo cáo hoàn thành, sẽ xem xét tính đủ bộ để test cơ khí"
  // và "khi nào cánh, khung, phào báo hoàn thành vân trên cùng bộ thì sẽ chuyển về vệ sinh, đóng gói".
  // Kiểm trên trạng thái SAU khi áp các thay đổi trong cùng lượt lưu (để lưu nhiều bước một lần vẫn được).
  if (patches.length) {
    const stages = await loadActiveStages();
    const stageByCode = new Map(stages.map((stage) => [stage.code, stage]));
    const effective = new Map<number, { stageCode: string; scope: string; status: string }>();
    for (const task of existingTasks) {
      effective.set(task.id, { stageCode: task.stageCode, scope: task.scope, status: task.status });
    }
    for (const patch of patches) {
      if (!patch.status) continue;
      const current = effective.get(patch.id);
      if (current) current.status = patch.status;
    }
    const effectiveRows = Array.from(effective.values());
    const blocked: string[] = [];
    for (const patch of patches) {
      if (patch.status !== "DANG_LAM" && patch.status !== "XONG") continue;
      const current = effective.get(patch.id);
      if (!current) continue;
      const state = taskUnlockState(current, effectiveRows, stageByCode);
      if (state.unlocked) continue;
      const waiting = state.waitingFor.map((code) => stageByCode.get(code)?.name ?? code).join(", ");
      blocked.push(`${stageByCode.get(current.stageCode)?.name ?? current.stageCode} (đang chờ ${waiting})`);
    }
    if (blocked.length) {
      throw new Error(
        `Chưa đủ điều kiện: ${blocked.join("; ")}. Phải báo hoàn thành công đoạn trước rồi mới báo bước sau.`,
      );
    }
  }

  const logs: Prisma.ProductionLogCreateManyInput[] = [];

  for (const patch of patches) {
    const current = byId.get(patch.id)!;
    if (patch.status !== undefined && patch.status !== current.status) {
      logs.push({
        entity: "TASK",
        entityId: patch.id,
        action: "DOI_TRANG_THAI",
        field: "status",
        oldValue: current.status,
        newValue: patch.status,
        byName: payload.byName ?? null,
      });
    }
    if (patch.isRework === true && current.isRework !== true) {
      logs.push({
        entity: "TASK",
        entityId: patch.id,
        action: "LAM_LAI",
        field: "is_rework",
        oldValue: "false",
        newValue: "true",
        byName: payload.byName ?? null,
      });
    }
  }

  const componentPatches = (payload.components ?? []).filter((patch) => Number.isInteger(patch.id));
  if (componentPatches.length) {
    const currentComponents = await prisma.productionComponentOrder.findMany({
      where: { setId, id: { in: componentPatches.map((patch) => patch.id) } },
      select: { id: true, kind: true, qtyExpected: true },
    });
    const byComponentId = new Map(currentComponents.map((row) => [row.id, row]));
    for (const patch of componentPatches) {
      const current = byComponentId.get(patch.id);
      if (!current) continue;
      const next = patch.qtyExpected === null ? null : Number(patch.qtyExpected);
      if (current.qtyExpected === next) continue;
      logs.push({
        entity: "SET",
        entityId: setId,
        action: "SUA_SO_LUONG_LENH_CON",
        field: current.kind,
        oldValue: current.qtyExpected === null ? null : String(current.qtyExpected),
        newValue: next === null ? null : String(next),
        byName: payload.byName ?? null,
      });
    }
  }

  const result = await prisma.$transaction(async (tx) => {
    if (componentPatches.length) {
      const records = componentPatches.map((patch) => ({ id: patch.id, qty: patch.qtyExpected === null ? null : Number(patch.qtyExpected) }));
      await tx.$executeRaw`
        UPDATE production_component_orders AS c
        SET qty_expected = v.qty, updated_at = now()
        FROM jsonb_to_recordset(${JSON.stringify(records)}::jsonb) AS v(id int, qty double precision)
        WHERE c.id = v.id AND c.set_id = ${setId}`;
    }

    // 1 lượt ghi cho toàn bộ công đoạn của bộ (jsonb_to_recordset — bài học V111).
    if (patches.length) {
      const records = patches.map((patch) => ({
        id: patch.id,
        status: patch.status ?? null,
        actual_start: patch.status === "DANG_LAM" || patch.status === "XONG" ? (parseTimestamp(patch.actualStart) ?? now) : parseTimestamp(patch.actualStart),
        actual_end: patch.status === "XONG" ? (parseTimestamp(patch.actualEnd) ?? now) : parseTimestamp(patch.actualEnd),
        note: patch.note ?? null,
        reason_code: patch.reasonCode ?? null,
        assignee: patch.assignee ?? null,
        is_rework: patch.isRework ?? null,
        updated_by: payload.byName ?? null,
        // V141 — gán ngày kế hoạch bằng tay cho từng công đoạn (dùng cờ has_plan để phân biệt "không đổi" với "xoá").
        planned_start: parseDateOnly(patch.plannedStart),
        has_plan: patch.plannedStart !== undefined,
      }));
      await tx.$executeRaw`
        UPDATE production_tasks AS t SET
          status      = COALESCE(v.status, t.status),
          actual_start= COALESCE(v.actual_start, t.actual_start),
          actual_end  = COALESCE(v.actual_end, t.actual_end),
          planned_start = CASE WHEN v.has_plan THEN v.planned_start::date ELSE t.planned_start END,
          planned_end   = CASE WHEN v.has_plan THEN v.planned_start::date ELSE t.planned_end END,
          note        = COALESCE(v.note, t.note),
          reason_code = COALESCE(v.reason_code, t.reason_code),
          assignee    = COALESCE(v.assignee, t.assignee),
          is_rework   = COALESCE(v.is_rework, t.is_rework),
          rework_from_stage = CASE WHEN v.is_rework IS TRUE AND t.rework_from_stage IS NULL
                                   THEN (SELECT s.rework_to_stage FROM production_stages s WHERE s.code = t.stage_code)
                                   ELSE t.rework_from_stage END,
          updated_by  = COALESCE(v.updated_by, t.updated_by),
          updated_at  = now()
        FROM jsonb_to_recordset(${JSON.stringify(records)}::jsonb) AS v(
          id int, status text, actual_start timestamptz, actual_end timestamptz,
          note text, reason_code text, assignee text, is_rework boolean, updated_by text,
          planned_start text, has_plan boolean
        )
        WHERE t.id = v.id AND t.set_id = ${setId}`;
    }

    const freshTasks = await tx.productionTask.findMany({
      where: { setId },
      select: { id: true, stageKind: true, status: true, stageCode: true },
    });

    // V141 — XẾP LỊCH BẰNG TAY: nếu lượt lưu này có gán ngày cho công đoạn mà KHÔNG nhập ngày cấp bộ,
    // thì ngày của BỘ = min/max ngày các công đoạn (để bảng tải và cột "Xếp lịch" luôn khớp).
    const touchedPlan = patches.some((patch) => patch.plannedStart !== undefined);
    let plannedStart = payload.plannedStart === undefined ? undefined : parseDateOnly(payload.plannedStart);
    let plannedEnd = payload.plannedEnd === undefined ? undefined : parseDateOnly(payload.plannedEnd);
    if (touchedPlan && plannedStart === undefined && plannedEnd === undefined) {
      const span = await tx.productionTask.aggregate({
        where: { setId, plannedStart: { not: null } },
        _min: { plannedStart: true },
        _max: { plannedEnd: true },
      });
      plannedStart = span._min.plannedStart ?? null;
      plannedEnd = span._max.plannedEnd ?? span._min.plannedStart ?? null;
    }
    const hasPlan = plannedStart === undefined ? set.plannedStart !== null : plannedStart !== null;

    const percentDone = percentDoneOf(freshTasks as unknown as ProductionTaskRow[]);
    const nextStatus = deriveSetStatus(freshTasks as unknown as ProductionTaskRow[], set.status, hasPlan);
    const completedNow = nextStatus === "HOAN_THANH" && set.status !== "HOAN_THANH";

    await tx.productionSet.update({
      where: { id: setId },
      data: {
        percentDone,
        status: nextStatus,
        ...(plannedStart !== undefined ? { plannedStart } : {}),
        ...(plannedEnd !== undefined ? { plannedEnd } : {}),
        ...(payload.note !== undefined ? { note: payload.note } : {}),
        ...(payload.planId !== undefined ? { planId: payload.planId } : {}),
        ...(payload.materialReady !== undefined ? { materialReady: payload.materialReady } : {}),
        ...(payload.programReady !== undefined ? { programReady: payload.programReady } : {}),
        ...(completedNow ? { actualCompletedAt: new Date() } : {}),
      },
    });

    // Đóng dấu thực tế cho mốc hoàn thành sản xuất / đã giao (dùng cho OTD).
    const finishedStage = freshTasks.find((task) => task.stageCode === STAGE.DONG_GOI);
    if (finishedStage?.status === "XONG" && !completedNow) {
      await tx.$executeRaw`UPDATE production_sets SET actual_completed_at = COALESCE(actual_completed_at, now()) WHERE id = ${setId}`;
    }

    if (logs.length) {
      await tx.productionLog.createMany({ data: logs });
    }

    return { percentDone, status: nextStatus };
  }, ORDER_WRITE_TRANSACTION);

  return result;
}

/** Đánh dấu bộ là ĐÃ GIAO (mốc tính tỷ lệ giao đúng hạn — L13). */
export async function markSetDelivered(setId: number, deliveredDate: string | null, byName: string | null) {
  const date = parseDateOnly(deliveredDate) ?? startOfDayUtc(new Date());
  await prisma.productionSet.update({
    where: { id: setId },
    data: { status: "DA_GIAO", actualDeliveredAt: date },
  });
  await prisma.productionLog.create({
    data: {
      entity: "SET",
      entityId: setId,
      action: "DA_GIAO",
      field: "actual_delivered_at",
      oldValue: null,
      newValue: date.toISOString().slice(0, 10),
      byName,
    },
  });
}

/**
 * Nguồn cho màn "Nhập bộ đang sản xuất dở" (B8): các bộ cửa của đơn đã xác nhận
 * mà CHƯA có trong kế hoạch sản xuất.
 *
 * Dùng NOT EXISTS thay vì quan hệ Prisma: `production_sets.order_item_id` CỐ Ý không có
 * khóa ngoại, vì route sửa đơn xoá rồi tạo lại dòng hàng — khóa ngoại sẽ chặn hoặc làm
 * mất tiến độ sản xuất. Xem V136 mục "rủi ro".
 */
export async function loadUnplannedOrderItems(limit = 200) {
  const config = await readProductionConfig();
  const types = config.entryOrderTypes;
  return prisma.$queryRaw<
    Array<{
      id: number;
      order_id: number;
      set_no: string | null;
      model: string | null;
      product_name: string | null;
      paint_color: string | null;
      height_mm: number | null;
      width_mm: number | null;
      leaves_per_set: number | null;
      trim_bars_per_set: number | null;
      quantity: number | null;
      pricing_quantity: number | null;
      order_code: string | null;
      order_type: string | null;
      customer_name: string | null;
      required_delivery_date: Date | null;
    }>
  >`
    SELECT i.id, i.order_id, i.set_no, i.model, i.product_name, i.paint_color,
           i.height_mm, i.width_mm, i.leaves_per_set, i.trim_bars_per_set,
           i.quantity, i.pricing_quantity,
           o.order_code, o.order_type, o.customer_name, o.required_delivery_date
    FROM sales_order_items i
    JOIN sales_orders o ON o.id = i.order_id
    WHERE o.status IN (${Prisma.join(CONFIRMED_STATUS_CODES)})
      AND o.order_type IN (${Prisma.join(types)})
      AND NOT EXISTS (
        SELECT 1 FROM production_sets s
        WHERE s.order_item_id = i.id
           OR (s.order_id = i.order_id AND s.set_no IS NOT NULL AND i.set_no IS NOT NULL
               AND UPPER(TRIM(s.set_no)) = UPPER(TRIM(i.set_no)))
      )
    ORDER BY o.required_delivery_date ASC NULLS LAST, i.id ASC
    LIMIT ${limit}`;
}

export async function countUnplannedOrderItems(): Promise<number> {
  const config = await readProductionConfig();
  const types = config.entryOrderTypes;
  const rows = await prisma.$queryRaw<Array<{ total: bigint | number }>>`
    SELECT COUNT(*)::bigint AS total
    FROM sales_order_items i
    JOIN sales_orders o ON o.id = i.order_id
    WHERE o.status IN (${Prisma.join(CONFIRMED_STATUS_CODES)})
      AND o.order_type IN (${Prisma.join(types)})
      AND NOT EXISTS (
        SELECT 1 FROM production_sets s
        WHERE s.order_item_id = i.id
           OR (s.order_id = i.order_id AND s.set_no IS NOT NULL AND i.set_no IS NOT NULL
               AND UPPER(TRIM(s.set_no)) = UPPER(TRIM(i.set_no)))
      )`;
  return Number(rows[0]?.total ?? 0);
}

// ---------------------------------------------------------------------------
// V137 — Dọn lệnh sản xuất khi bộ cửa bị XOÁ khỏi đơn
// ---------------------------------------------------------------------------

export type ReconcileResult = { removed: number; cancelled: number };

/**
 * Đồng bộ lại lệnh sản xuất sau khi lưu đơn: bộ nào **không còn trong đơn** thì:
 *   - **chưa có tiến độ** (0% và chưa ghi mốc hoàn thành/đã giao) → **XOÁ hẳn** (kèm công đoạn + lệnh con);
 *   - **đã có tiến độ** → **giữ lại nhưng đánh dấu ĐÃ HUỶ** — không phá công xưởng đã làm.
 *
 * KHÔNG BAO GIỜ ném lỗi ra ngoài: việc lưu đơn hàng không được phụ thuộc module sản xuất
 * (ví dụ khi DB chưa chạy migration sản xuất).
 */
export async function reconcileOrderProductionSets(
  orderId: number,
  currentSetNos: Array<string | null | undefined>,
  byName: string | null = null,
): Promise<ReconcileResult> {
  const empty: ReconcileResult = { removed: 0, cancelled: 0 };
  try {
    const sets = await prisma.productionSet.findMany({
      where: { orderId },
      select: { id: true, setNo: true, status: true, percentDone: true, actualCompletedAt: true, actualDeliveredAt: true },
    });
    if (!sets.length) return empty;

    const keep = new Set(
      currentSetNos.map((value) => String(value ?? "").trim().toUpperCase()).filter((value) => value.length > 0),
    );
    // Chỉ xét các bộ CÓ Bộ số — bộ không có số thì giữ nguyên (không đoán).
    const orphans = sets.filter((set) => {
      const no = String(set.setNo ?? "").trim().toUpperCase();
      return no.length > 0 && !keep.has(no);
    });
    if (!orphans.length) return empty;

    const untouched = orphans.filter((set) => set.percentDone === 0 && !set.actualCompletedAt && !set.actualDeliveredAt);
    const touched = orphans.filter((set) => !untouched.some((row) => row.id === set.id));
    const removeIds = new Set(untouched.map((set) => set.id));

    if (removeIds.size) {
      await prisma.productionSet.deleteMany({ where: { id: { in: Array.from(removeIds) } } });
    }
    if (touched.length) {
      await prisma.productionSet.updateMany({ where: { id: { in: touched.map((set) => set.id) } }, data: { status: "HUY" } });
    }
    await prisma.productionLog.createMany({
      data: [
        ...untouched.map((set) => ({
          entity: "SET",
          entityId: set.id,
          action: "XOA_VI_BO_KHOI_DON",
          field: "set_no",
          oldValue: String(set.setNo ?? ""),
          newValue: null,
          byName,
        })),
        ...touched.map((set) => ({
          entity: "SET",
          entityId: set.id,
          action: "HUY_VI_BO_KHOI_DON",
          field: "status",
          oldValue: set.status,
          newValue: "HUY",
          byName,
        })),
      ],
    });

    return { removed: removeIds.size, cancelled: touched.length };
  } catch (error) {
    console.error("Reconcile production sets failed:", error);
    return empty;
  }
}

/**
 * V146 — ĐÃ BỎ nhóm hàm KẾ HOẠCH TUẦN (V137: loadPlans/createPlan/approvePlan/reopenPlan/deletePlan)
 * vì tab "Kế hoạch tuần" không dùng được. Bảng `production_plans` vẫn giữ nguyên dữ liệu cũ.
 */

// ---------------------------------------------------------------------------
// V137 — Nạp dữ liệu cho BÁO CÁO SẢN XUẤT
// ---------------------------------------------------------------------------

export async function loadProductionReportData(limit = 5000) {
  const [sets, stages, workCenters, reasons] = await Promise.all([
    prisma.productionSet.findMany({ orderBy: [{ dueDate: "asc" }, { id: "asc" }], take: limit }),
    loadStages(),
    loadWorkCenters(),
    loadReasons(),
  ]);
  const tasks = sets.length
    ? await prisma.productionTask.findMany({ where: { setId: { in: sets.map((set) => set.id) } } })
    : [];
  return {
    sets: sets as unknown as ProductionSetRow[],
    tasks: tasks as unknown as ProductionTaskRow[],
    stages,
    workCenters,
    reasons: reasons.map((reason) => ({ code: reason.code, name: reason.name, group: reason.group })),
  };
}

// ---------------------------------------------------------------------------
// V148 — KẾ HOẠCH CHO TỪNG CÔNG ĐOẠN **THEO NĂNG LỰC**
//
// Khác V144 (mốc target suy từ lead time): đây là NGÀY KẾ HOẠCH thật (`planned_start/planned_end`),
// tính XUÔI theo năng lực từng công đoạn/tổ. Lead time chỉ dùng để đối chiếu "có kịp mốc không".
// Xem `src/lib/production/stage-plan.ts` + `KE_HOACH_THEO_CONG_DOAN_V147.md`.
// ---------------------------------------------------------------------------

/** Phạm vi bộ đưa vào kế hoạch: chỉ bộ chưa xếp, hay mọi bộ đang mở. */
export type StagePlanScope = "CHO_XEP_LICH" | "DANG_MO";

export type StagePlanQuery = {
  /** `YYYY-MM-DD` (bỏ trống = hôm nay theo giờ VN). */
  from?: string | null;
  /** `YYYY-MM-DD` (bỏ trống = 120 ngày làm việc kể từ `from`). */
  to?: string | null;
  scope?: StagePlanScope;
  setIds?: number[];
};

export type ApplyStagePlanResult = {
  sets: number;
  tasks: number;
  /** Số bộ chuyển từ CHỜ XẾP LỊCH → ĐÃ XẾP LỊCH. */
  statuses: number;
  warnings: number;
};

const STAGE_PLAN_MAX_SETS = 2000;

/** Chuẩn hoá khoảng ngày của một lượt lập kế hoạch (mặc định: hôm nay → +120 ngày làm việc). */
async function resolveStagePlanRange(
  query: StagePlanQuery,
  calendar: WorkingCalendar,
): Promise<{ from: Date; to: Date }> {
  const from = parseIsoDateStrict(query.from ?? null) ?? todayInVietnam();
  const parsedTo = parseIsoDateStrict(query.to ?? null);
  const to = parsedTo ?? addWorkingDays(from, 120, calendar);
  return to.getTime() < from.getTime() ? { from, to: from } : { from, to };
}

/**
 * Tính TRƯỚC kế hoạch từng công đoạn (không ghi DB) để người dùng xem rồi mới quyết định.
 */
export async function previewStagePlan(query: StagePlanQuery): Promise<StagePlanResult> {
  const config = await readProductionConfig();
  const calendar = await loadCalendar(config);
  const [stages, workCenters, priority, paintColors] = await Promise.all([
    loadActiveStages(),
    loadActiveWorkCenters(),
    readPriorityConfig(),
    loadPaintColors(),
  ]);
  const { from, to } = await resolveStagePlanRange(query, calendar);

  const scope: StagePlanScope = query.scope ?? "CHO_XEP_LICH";
  const statuses = scope === "CHO_XEP_LICH" ? ["CHO_XEP_LICH"] : [...PLANNABLE_SET_STATUSES];

  const sets = await prisma.productionSet.findMany({
    where: {
      status: { in: statuses },
      ...(query.setIds?.length ? { id: { in: query.setIds } } : {}),
    },
    orderBy: [{ priority: "asc" }, { dueDate: "asc" }, { id: "asc" }],
    take: STAGE_PLAN_MAX_SETS,
  });

  const tasks = sets.length
    ? await prisma.productionTask.findMany({ where: { setId: { in: sets.map((set) => set.id) } } })
    : [];
  // V149 — chỉ tiêu mức ĐƠN cần cột thật của `sales_orders` (giá trị, cọc, chiết khấu, km…).
  const orderIds = Array.from(new Set(sets.map((set) => Number(set.orderId)).filter((id) => Number.isInteger(id))));
  const orders = await loadOrderFacts(orderIds);

  return buildStagePlan({
    sets: sets as unknown as ProductionSetRow[],
    tasks: tasks as unknown as ProductionTaskRow[],
    stages,
    workCenters,
    calendar,
    config,
    from,
    to,
    today: todayInVietnam(),
    priority,
    orders,
    paintColors,
    setIds: query.setIds?.length ? query.setIds : undefined,
  });
}

/**
 * GHI kế hoạch vào `production_tasks.planned_start/planned_end` + `production_sets.planned_*`.
 *
 * Ghi gộp theo bài học V111: 1 câu `UPDATE … FROM jsonb_to_recordset(…)` cho mỗi bảng,
 * tất cả trong MỘT transaction. Thiếu dòng nào là **rollback** (không im lặng báo thành công).
 * Bộ `CHO_XEP_LICH` → `DA_XEP_LICH`. Không đụng công đoạn đã XONG.
 */
export async function applyStagePlan(
  query: StagePlanQuery & { byName?: string | null },
): Promise<ApplyStagePlanResult> {
  const preview = await previewStagePlan(query);
  const rows = preview.tasks.filter(
    (entry): entry is typeof entry & { start: Date; end: Date } =>
      entry.state === "XEP" && entry.start !== null && entry.end !== null,
  );
  if (!rows.length) {
    return { sets: 0, tasks: 0, statuses: 0, warnings: preview.warnings.length };
  }

  const taskRecords = rows.map((entry) => ({
    id: entry.taskId,
    planned_start: isoDateOnly(entry.start),
    planned_end: isoDateOnly(entry.end),
  }));

  const perSet = new Map<number, { start: Date; end: Date }>();
  for (const entry of rows) {
    const current = perSet.get(entry.setId);
    if (!current) {
      perSet.set(entry.setId, { start: entry.start, end: entry.end });
      continue;
    }
    if (entry.start.getTime() < current.start.getTime()) current.start = entry.start;
    if (entry.end.getTime() > current.end.getTime()) current.end = entry.end;
  }
  const setRecords = Array.from(perSet.entries()).map(([id, value]) => ({
    id,
    planned_start: isoDateOnly(value.start),
    planned_end: isoDateOnly(value.end),
  }));

  const byName = query.byName?.trim() || null;

  return prisma.$transaction(async (tx) => {
    const updatedTasks = await tx.$executeRaw`
      UPDATE production_tasks AS t
      SET planned_start = v.planned_start::date,
          planned_end   = v.planned_end::date,
          updated_at    = now()
      FROM jsonb_to_recordset(${JSON.stringify(taskRecords)}::jsonb) AS v(id int, planned_start text, planned_end text)
      WHERE t.id = v.id`;
    if (Number(updatedTasks) !== taskRecords.length) {
      throw new Error(`Chỉ ghi được ${Number(updatedTasks)}/${taskRecords.length} công đoạn — đã huỷ, kế hoạch không đổi.`);
    }

    const updatedSets = await tx.$executeRaw`
      UPDATE production_sets AS s
      SET planned_start = v.planned_start::date,
          planned_end   = v.planned_end::date,
          status        = CASE WHEN s.status = 'CHO_XEP_LICH' THEN 'DA_XEP_LICH' ELSE s.status END,
          updated_at    = now()
      FROM jsonb_to_recordset(${JSON.stringify(setRecords)}::jsonb) AS v(id int, planned_start text, planned_end text)
      WHERE s.id = v.id`;

    await tx.productionLog.createMany({
      data: setRecords.map((record) => ({
        entity: "SET",
        entityId: record.id,
        action: "LAP_KE_HOACH_CONG_DOAN",
        field: "planned_start",
        oldValue: null,
        newValue: `${record.planned_start} → ${record.planned_end}`,
        byName,
      })),
    });

    return {
      sets: setRecords.length,
      tasks: Number(updatedTasks),
      statuses: Number(updatedSets),
      warnings: preview.warnings.length,
    };
  }, ORDER_WRITE_TRANSACTION);
}

// ---------------------------------------------------------------------------
// V149 — CẤU HÌNH THỨ TỰ ƯU TIÊN (theo TỪNG CÔNG ĐOẠN) + dữ liệu đơn để chấm điểm
// ---------------------------------------------------------------------------

/** Đọc cấu hình thứ tự ưu tiên (chưa lưu thì dùng bộ mặc định của nhà máy). */
export async function readPriorityConfig(): Promise<PriorityConfig> {
  const setting = await prisma.systemSetting.findUnique({
    where: { key: PRIORITY_CONFIG_SETTING_KEY },
    select: { value: true },
  });
  if (!setting?.value) return normalizePriorityConfig(null);
  try {
    return normalizePriorityConfig(JSON.parse(setting.value));
  } catch {
    return normalizePriorityConfig(null);
  }
}

export async function savePriorityConfig(value: unknown): Promise<PriorityConfig> {
  const normalized = normalizePriorityConfig(value);
  await prisma.systemSetting.upsert({
    where: { key: PRIORITY_CONFIG_SETTING_KEY },
    create: { key: PRIORITY_CONFIG_SETTING_KEY, value: JSON.stringify(normalized) },
    update: { value: JSON.stringify(normalized) },
  });
  return normalized;
}

/**
 * Nạp các CỘT THẬT của `sales_orders` cho những đơn đang có bộ trong kế hoạch —
 * đầu vào cho các chỉ tiêu mức đơn (giá trị, đặt cọc, chiết khấu, km, nhân viên…).
 */
export async function loadOrderFacts(orderIds: number[]): Promise<Map<number, OrderFacts>> {
  if (!orderIds.length) return new Map();
  const rows = await prisma.salesOrder.findMany({
    where: { id: { in: orderIds } },
    select: {
      id: true,
      orderDate: true,
      orderType: true,
      customerCode: true,
      customerName: true,
      salesEmployeeCode: true,
      totalAfterDiscount: true,
      depositAmount: true,
      discountPercent: true,
      deliveryKm: true,
      region: true,
      shippingMountainDistrict: true,
    },
  });
  const map = new Map<number, OrderFacts>();
  for (const row of rows) {
    map.set(row.id, {
      orderId: row.id,
      orderDate: row.orderDate,
      orderType: row.orderType,
      customerCode: row.customerCode,
      customerName: row.customerName,
      salesEmployeeCode: row.salesEmployeeCode,
      totalAfterDiscount: row.totalAfterDiscount === null ? null : Number(row.totalAfterDiscount),
      depositAmount: row.depositAmount === null ? null : Number(row.depositAmount),
      discountPercent: row.discountPercent === null ? null : Number(row.discountPercent),
      deliveryKm: row.deliveryKm === null ? null : Number(row.deliveryKm),
      region: row.region,
      mountainDistrict: row.shippingMountainDistrict,
    });
  }
  return map;
}

/**
 * V151 — danh mục màu sơn (gom lô theo NHÓM MÀU CHÍNH: Đỏ / Vàng / Cát chay).
 *
 * Chịu được trường hợp **chưa chạy** `migrate-production-v151-mau-son.sql`: trả mảng rỗng
 * thay vì làm sập màn Cấu hình / màn kế hoạch. (Bảng chưa có thì gom theo nhóm màu
 * sẽ đứng riêng từng mã — không sai, chỉ chưa gom được.)
 */
export async function loadPaintColors(): Promise<PaintColorRow[]> {
  try {
    const rows = await prisma.productionPaintColor.findMany({ orderBy: [{ sortOrder: "asc" }, { code: "asc" }] });
    return rows.map((row) => ({
      id: row.id,
      code: row.code,
      label: row.label,
      colorName: row.colorName,
      family: row.family,
      specCode: row.specCode,
      tempC: row.tempC,
      minutes: row.minutes,
      needsVeneer: row.needsVeneer,
      active: row.active,
      sortOrder: row.sortOrder,
      note: row.note,
    }));
  } catch (error) {
    console.warn("Chưa đọc được bảng production_paint_colors (đã chạy migrate-production-v151-mau-son.sql chưa?):", error);
    return [];
  }
}

// ---------------------------------------------------------------------------
// V152 — ĐIỀU ĐỘ THỦ CÔNG THEO CÔNG ĐOẠN + DANH SÁCH ĐỢI + TOKEN REALTIME
// ---------------------------------------------------------------------------

/**
 * TOKEN PHIÊN BẢN dữ liệu kế hoạch — dùng cho REALTIME.
 *
 * Rất nhẹ (1 câu SQL) để client hỏi lại vài giây một lần. Khi token đổi ⇒ có người vừa
 * thêm/bớt bộ, vừa báo xong, vừa nhập đơn mới… thì client tự tải lại — **không cần F5**.
 */
export async function productionPlanVersion(): Promise<string> {
  const rows = await prisma.$queryRaw<Array<Record<string, unknown>>>`
    SELECT
      (SELECT max(updated_at)::text FROM production_tasks) AS t,
      (SELECT max(updated_at)::text FROM production_sets)  AS s,
      (SELECT max(updated_at)::text FROM sales_orders)     AS o,
      (SELECT count(*) FROM production_tasks)              AS nt,
      (SELECT count(*) FROM production_sets)               AS ns,
      (SELECT count(*) FROM sales_orders)                  AS no`;
  const row = rows[0] ?? {};
  return [row.t, row.s, row.o, row.nt, row.ns, row.no].map((value) => String(value ?? "")).join("|");
}

export type StageBoardItem = {
  taskId: number;
  setId: number;
  scope: string;
  setNo: string | null;
  orderCode: string | null;
  customerName: string | null;
  productName: string | null;
  paintColor: string | null;
  dueDate: string | null;
  /** Tải của bộ ở công đoạn này (theo đơn vị của công đoạn). */
  demand: number;
  unit: "CANH" | "BO";
  status: string;
  /** Điểm ưu tiên (để sắp danh sách đợi). */
  score: number;
  /** Đang chờ những công đoạn nào (rỗng = đủ điều kiện lên kế hoạch). */
  waitingFor: string[];
};

export type StageBoardDay = {
  date: string;
  isWorkingDay: boolean;
  items: StageBoardItem[];
  worked: number;
  capacity: number | null;
  unit: "CANH" | "BO";
  ratio: number | null;
  tone: "ok" | "warn" | "bad";
};

export type StageBoardData = {
  version: string;
  stage: {
    code: string;
    name: string;
    seq: number;
    workCenterCode: string | null;
    capacity: number | null;
    capacitySource: CapacitySource;
    unit: "CANH" | "BO";
    requiresStage: string | null;
    changeoverMaxPerDay: number | null;
    batchMinQty: number | null;
    batchKey: string | null;
  };
  stages: Array<{ code: string; name: string; seq: number }>;
  from: string;
  days: StageBoardDay[];
  waiting: StageBoardItem[];
  blocked: StageBoardItem[];
  totals: { waiting: number; blocked: number; planned: number; unplannedItems: number };
  /** Tiêu chí đang sắp thứ tự hàng đợi của công đoạn này (đầu ra của bước "ưu tiên"). */
  priority: {
    criteria: Array<{ code: string; weight: number }>;
    grouping: { code: string; tolerance: number } | null;
    /** Công đoạn có đang chạy chế độ GOM LÔ không. */
    batch: boolean;
  };
};

const BOARD_MAX_DAYS = 31;

/**
 * Dữ liệu một bảng điều độ của MỘT công đoạn: danh sách đợi + kế hoạch từng ngày.
 * (Không ghi gì — chỉ đọc.)
 */
export async function loadStageBoard(query: {
  stageCode: string;
  from?: string | null;
  days?: number | null;
}): Promise<StageBoardData> {
  const config = await readProductionConfig();
  const calendar = await loadCalendar(config);
  const [stages, workCenters, priority, unplannedItems] = await Promise.all([
    loadActiveStages(),
    loadActiveWorkCenters(),
    readPriorityConfig(),
    countUnplannedOrderItems(),
  ]);
  const stage = stages.find((row) => row.code === String(query.stageCode ?? "").trim().toUpperCase());
  if (!stage) throw new Error("Không tìm thấy công đoạn (hoặc công đoạn đã tắt).");

  const unit = loadUnitOfStage(stage);
  const capacity = capacityOfStage({ capacityPerDay: stage.capacityPerDay, workCenterCode: stage.workCenterCode }, workCenters);
  const dayCount = Math.min(BOARD_MAX_DAYS, Math.max(1, Math.trunc(Number(query.days) || 7)));
  const from = parseIsoDateStrict(query.from ?? null) ?? todayInVietnam();
  const today = todayInVietnam();

  const openTasks = await prisma.productionTask.findMany({
    where: { stageCode: stage.code, status: { notIn: ["XONG", "BO_QUA"] } },
    select: { id: true, setId: true, stageCode: true, seq: true, scope: true, status: true, plannedStart: true, plannedEnd: true, stageKind: true },
  });

  const setIds = Array.from(new Set(openTasks.map((task) => task.setId)));
  const requiredCodes = String(stage.requiresStage ?? "")
    .split(",")
    .map((code) => code.trim())
    .filter(Boolean);
  const ruleOfStage = priority.stageRules[stage.code] ?? priority.defaultRule;
  const groupingOfStage = groupingOf(ruleOfStage);

  const [sets, predecessorTasks] = await Promise.all([
    setIds.length ? prisma.productionSet.findMany({ where: { id: { in: setIds } } }) : Promise.resolve([]),
    requiredCodes.length && setIds.length
      ? prisma.productionTask.findMany({
          where: { setId: { in: setIds }, stageCode: { in: requiredCodes } },
          select: { setId: true, stageCode: true, scope: true, status: true, plannedStart: true },
        })
      : Promise.resolve([]),
  ]);

  const setById = new Map(sets.map((row) => [row.id, row]));
  const tasksBySet = new Map<number, Array<{ stageCode: string; scope: string; status: string; plannedStart: Date | null }>>();
  for (const task of predecessorTasks) {
    const list = tasksBySet.get(task.setId);
    if (list) list.push(task);
    else tasksBySet.set(task.setId, [task]);
  }

  const orderIds = Array.from(new Set(sets.map((row) => Number(row.orderId)).filter((id) => Number.isInteger(id))));
  const orders = await loadOrderFacts(orderIds);
  const stageByCode = new Map(stages.map((row) => [row.code, { code: row.code, requiresStage: row.requiresStage }]));
  const scoreContext = {
    today,
    calendar,
    config: priority,
    orders,
    rankOf: new Map<number, number>(),
    totalSets: sets.length,
    deliveryBufferDays: Number(config.deliveryBufferDays) || 0,
  };

  const waiting: StageBoardItem[] = [];
  const blocked: StageBoardItem[] = [];

  for (const task of openTasks) {
    const set = setById.get(task.setId);
    if (!set) continue;
    const state = waitStateOfTask({
      task,
      setTasks: tasksBySet.get(task.setId) ?? [],
      stageByCode,
    });
    const item: StageBoardItem = {
      taskId: task.id,
      setId: set.id,
      scope: task.scope,
      setNo: set.setNo,
      orderCode: set.orderCode,
      customerName: set.customerName,
      productName: set.productName,
      paintColor: set.paintColor,
      dueDate: set.dueDate ? isoDateOnly(set.dueDate) : null,
      demand: demandOfTask(set as unknown as ProductionSetRow, stage),
      unit,
      status: task.status,
      score: state.waiting || task.plannedStart ? scoreSet(set as unknown as ProductionSetRow, stage.code, scoreContext).score : 0,
      waitingFor: state.waitingFor,
    };
    if (task.plannedStart) continue; // đã lên kế hoạch → nằm ở cột ngày, không nằm danh sách đợi
    (state.waiting ? waiting : blocked).push(item);
  }

  waiting.sort(
    (a, b) =>
      b.score - a.score ||
      (a.dueDate ? Date.parse(a.dueDate) : Number.POSITIVE_INFINITY) - (b.dueDate ? Date.parse(b.dueDate) : Number.POSITIVE_INFINITY) ||
      a.setId - b.setId,
  );

  // Các ngày trên bảng (ngày dương lịch liên tiếp, có đánh dấu ngày nghỉ)
  const days: StageBoardDay[] = [];
  const plannedByDay = new Map<string, StageBoardItem[]>();
  for (const task of openTasks) {
    if (!task.plannedStart) continue;
    const key = isoDateOnly(task.plannedStart);
    const set = setById.get(task.setId);
    if (!set) continue;
    const list = plannedByDay.get(key) ?? [];
    list.push({
      taskId: task.id,
      setId: set.id,
      scope: task.scope,
      setNo: set.setNo,
      orderCode: set.orderCode,
      customerName: set.customerName,
      productName: set.productName,
      paintColor: set.paintColor,
      dueDate: set.dueDate ? isoDateOnly(set.dueDate) : null,
      demand: demandOfTask(set as unknown as ProductionSetRow, stage),
      unit,
      status: task.status,
      score: 0,
      waitingFor: [],
    });
    plannedByDay.set(key, list);
  }

  for (let offset = 0; offset < dayCount; offset += 1) {
    const date = new Date(from.getTime() + offset * 86400000);
    const key = isoDateOnly(date);
    const items = (plannedByDay.get(key) ?? []).sort((a, b) => Number(b.demand) - Number(a.demand) || a.setId - b.setId);
    const worked = items.reduce((sum, item) => sum + item.demand, 0);
    const ratio = capacity.value && capacity.value > 0 ? worked / capacity.value : null;
    days.push({
      date: key,
      isWorkingDay: calendar.workingDays.includes(date.getUTCDay()) && !calendar.holidays.has(key),
      items,
      worked,
      capacity: capacity.value,
      unit,
      ratio,
      tone: ratio === null ? "ok" : ratio >= 0.999 ? "bad" : ratio >= 0.9 ? "warn" : "ok",
    });
  }

  return {
    version: await productionPlanVersion(),
    stage: {
      code: stage.code,
      name: stage.name,
      seq: stage.seq,
      workCenterCode: stage.workCenterCode,
      capacity: capacity.value,
      capacitySource: capacity.source,
      unit,
      requiresStage: stage.requiresStage,
      changeoverMaxPerDay: stage.changeoverMaxPerDay,
      batchMinQty: stage.batchMinQty,
      batchKey: stage.batchKey,
    },
    stages: stages.map((row) => ({ code: row.code, name: row.name, seq: row.seq })),
    from: isoDateOnly(from),
    days,
    waiting,
    blocked,
    totals: {
      waiting: waiting.length,
      blocked: blocked.length,
      planned: openTasks.filter((task) => task.plannedStart).length,
      unplannedItems,
    },
    priority: {
      criteria: ruleOfStage.criteria.filter((item) => item.weight > 0).map((item) => ({ code: item.code, weight: item.weight })),
      grouping: groupingOfStage ? { code: groupingOfStage.code, tolerance: groupingOfStage.tolerance } : null,
      batch: Boolean(
        stage.batchKey &&
          Number(stage.batchMinQty) >= 10 &&
          Number(stage.changeoverMaxPerDay) >= 1 &&
          groupingOfStage &&
          BATCH_GROUP_CODES.has(groupingOfStage.code),
      ),
    },
  };
}

export type TaskPlanWriteResult = {
  taskId: number;
  setId: number;
  action: "GAN" | "BO";
  clearedDownstream: number;
  setStatus: string;
  plannedStart: string | null;
  plannedEnd: string | null;
};

/**
 * THÊM/BỚT một bộ ở một công đoạn (điều độ thủ công).
 *
 * Quy tắc nhà máy chốt: thêm hay bớt ở một công đoạn ⇒ **mọi công đoạn PHÍA SAU của cùng bộ
 * bị xoá khỏi kế hoạch ngay lập tức** (trừ công đoạn đã XONG — đó là lịch sử).
 * Ghi gộp: 1 transaction, cập nhật bộ + ghi log.
 */
export async function writeTaskPlan(args: {
  taskId: number;
  date?: string | null;
  byName?: string | null;
}): Promise<TaskPlanWriteResult> {
  const action: "GAN" | "BO" = args.date ? "GAN" : "BO";
  const day = args.date ? parseIsoDateStrict(args.date) : null;
  if (action === "GAN" && !day) throw new Error("Ngày không hợp lệ (cần dạng YYYY-MM-DD).");

  const task = await prisma.productionTask.findUnique({
    where: { id: args.taskId },
    select: { id: true, setId: true, stageCode: true, seq: true, status: true },
  });
  if (!task) throw new Error("Không tìm thấy công đoạn.");
  if (task.status === "XONG" || task.status === "BO_QUA") {
    throw new Error("Công đoạn này đã xong hoặc đã bỏ qua — không sửa kế hoạch được.");
  }

  const byName = args.byName?.trim() || null;

  return prisma.$transaction(async (tx) => {
    await tx.productionTask.update({
      where: { id: task.id },
      data: { plannedStart: day, plannedEnd: day, updatedBy: byName },
    });

    const siblings = await tx.productionTask.findMany({
      where: { setId: task.setId },
      select: { id: true, seq: true, status: true, plannedStart: true, plannedEnd: true, stageKind: true },
    });
    const downstream = downstreamTasksToClear(siblings, task.seq, { excludeTaskId: task.id });
    let cleared = 0;
    if (downstream.length) {
      const result = await tx.productionTask.updateMany({
        where: { id: { in: downstream } },
        data: { plannedStart: null, plannedEnd: null, updatedBy: byName },
      });
      cleared = Number(result.count);
    }

    const fresh = await tx.productionTask.findMany({
      where: { setId: task.setId },
      select: { id: true, seq: true, status: true, plannedStart: true, plannedEnd: true, stageKind: true },
    });
    const range = setPlanRange(fresh);
    const set = await tx.productionSet.findUnique({ where: { id: task.setId }, select: { status: true } });
    const nextStatus =
      range.start === null
        ? set?.status === "DA_XEP_LICH"
          ? "CHO_XEP_LICH"
          : set?.status ?? "CHO_XEP_LICH"
        : set?.status === "CHO_XEP_LICH"
          ? "DA_XEP_LICH"
          : set?.status ?? "CHO_XEP_LICH";

    await tx.productionSet.update({
      where: { id: task.setId },
      data: { plannedStart: range.start, plannedEnd: range.end, status: nextStatus },
    });

    await tx.productionLog.create({
      data: {
        entity: "SET",
        entityId: task.setId,
        action: action === "GAN" ? "DIEU_DO_THEM_BO" : "DIEU_DO_BOT_BO",
        field: task.stageCode,
        oldValue: null,
        newValue: `${action === "GAN" ? (day ? isoDateOnly(day) : "?") : "bỏ"}${cleared ? ` · xoá ${cleared} công đoạn phía sau` : ""}`,
        byName,
      },
    });

    return {
      taskId: task.id,
      setId: task.setId,
      action,
      clearedDownstream: cleared,
      setStatus: nextStatus,
      plannedStart: range.start ? isoDateOnly(range.start) : null,
      plannedEnd: range.end ? isoDateOnly(range.end) : null,
    };
  }, ORDER_WRITE_TRANSACTION);
}

// ---------------------------------------------------------------------------
// V153 — ĐIỀU ĐỘ TỰ ĐỘNG THEO CÔNG ĐOẠN (từ HÀNG ĐỢI đã sắp theo tiêu chí ưu tiên)
//
// Luồng: tiêu chí ưu tiên → HÀNG ĐỢI có thứ tự → gom nhóm + năng lực → điều độ tự động
//        → XÁC NHẬN (apply) → rồi mới thêm/bớt thủ công.
// ---------------------------------------------------------------------------

export type StageDispatchItem = {
  taskId: number;
  setId: number;
  scope: string;
  setNo: string | null;
  orderCode: string | null;
  customerName: string | null;
  paintColor: string | null;
  dueDate: string | null;
  demand: number;
  score: number;
  groupKey: string | null;
  ready: string;
  /** Thứ tự trong hàng đợi (1 = trên cùng). */
  queueRank: number;
};

export type StageDispatchDay = {
  date: string;
  worked: number;
  capacity: number | null;
  ratio: number | null;
  tone: "ok" | "warn" | "bad";
  items: Array<{ taskId: number; setId: number; setNo: string | null; paintColor: string | null; demand: number; groupKey: string | null }>;
};

export type StageDispatchPreview = {
  version: string;
  stage: { code: string; name: string; seq: number; capacity: number | null; unit: "CANH" | "BO"; capacitySource: CapacitySource };
  /** Chế độ đã dùng: xếp lần lượt theo hàng đợi, hay GOM LÔ theo nhóm. */
  mode: "HANG_DOI" | "GOM_LO";
  modeNote: string;
  criteria: Array<{ code: string; weight: number }>;
  grouping: { code: string; tolerance: number } | null;
  queue: StageDispatchItem[];
  days: StageDispatchDay[];
  assignments: Array<{ taskId: number; setId: number; day: string; queueRank: number }>;
  overflow: number[];
  from: string;
  usedDays: number;
};

/** Hàng đợi + đề xuất ngày cho MỘT công đoạn (chưa ghi gì). */
export async function previewStageDispatch(query: {
  stageCode: string;
  from?: string | null;
  horizonDays?: number | null;
}): Promise<StageDispatchPreview> {
  const config = await readProductionConfig();
  const calendar = await loadCalendar(config);
  const [stages, workCenters, priority, paintColors] = await Promise.all([
    loadActiveStages(),
    loadActiveWorkCenters(),
    readPriorityConfig(),
    loadPaintColors(),
  ]);
  const stage = stages.find((row) => row.code === String(query.stageCode ?? "").trim().toUpperCase());
  if (!stage) throw new Error("Không tìm thấy công đoạn (hoặc công đoạn đã tắt).");

  const config2 = config;
  const today = todayInVietnam();
  const from = parseIsoDateStrict(query.from ?? null) ?? today;
  const horizonDays = Math.min(365, Math.max(1, Math.trunc(Number(query.horizonDays) || 120)));
  const to = addWorkingDays(from, horizonDays, calendar);

  const unit = loadUnitOfStage(stage);
  const capacity = capacityOfStage({ capacityPerDay: stage.capacityPerDay, workCenterCode: stage.workCenterCode }, workCenters);
  const rule = priority.stageRules[stage.code] ?? priority.defaultRule;
  const grouping = groupingOf(rule);
  const paintGroupOf = makePaintGroupResolver(paintColors);

  const openTasks = await prisma.productionTask.findMany({
    where: { stageCode: stage.code, status: { notIn: ["XONG", "BO_QUA"] }, plannedStart: null },
    select: { id: true, setId: true, stageCode: true, seq: true, scope: true, status: true, plannedStart: true },
  });
  if (!openTasks.length) {
    return {
      version: await productionPlanVersion(),
      stage: { code: stage.code, name: stage.name, seq: stage.seq, capacity: capacity.value, unit, capacitySource: capacity.source },
      mode: "HANG_DOI",
      modeNote: "Không còn bộ nào chờ ở công đoạn này.",
      criteria: [],
      grouping: null,
      queue: [],
      days: [],
      assignments: [],
      overflow: [],
      from: isoDateOnly(from),
      usedDays: 0,
    };
  }

  const setIds = Array.from(new Set(openTasks.map((task) => task.setId)));
  const requiredCodes = String(stage.requiresStage ?? "")
    .split(",")
    .map((code) => code.trim())
    .filter(Boolean);

  type PredecessorRow = {
    id: number;
    setId: number;
    stageCode: string;
    scope: string;
    status: string;
    plannedStart: Date | null;
    plannedEnd: Date | null;
    actualEnd: Date | null;
  };
  const [sets, predecessors] = await Promise.all([
    prisma.productionSet.findMany({ where: { id: { in: setIds } } }),
    requiredCodes.length
      ? prisma.productionTask.findMany({
          where: { setId: { in: setIds }, stageCode: { in: requiredCodes } },
          select: { id: true, setId: true, stageCode: true, scope: true, status: true, plannedStart: true, plannedEnd: true, actualEnd: true },
        })
      : Promise.resolve([] as PredecessorRow[]),
  ]);
  const setById = new Map(sets.map((row) => [row.id, row]));
  const tasksBySet = new Map<number, PredecessorRow[]>();
  for (const task of predecessors) {
    const list = tasksBySet.get(task.setId);
    if (list) list.push(task);
    else tasksBySet.set(task.setId, [task]);
  }

  const orders = await loadOrderFacts(Array.from(new Set(sets.map((row) => Number(row.orderId)))));
  const stageByCode = new Map(stages.map((row) => [row.code, { code: row.code, requiresStage: row.requiresStage }]));
  const scoreContext = {
    today,
    calendar,
    config: priority,
    orders,
    rankOf: new Map<number, number>(),
    totalSets: sets.length,
    deliveryBufferDays: Number(config2.deliveryBufferDays) || 0,
  };

  const queue: StageDispatchItem[] = [];
  const dispatchItems: Array<{ taskId: number; setId: number; score: number; demand: number; ready: Date; groupKey: string | null }> = [];

  for (const task of openTasks) {
    const set = setById.get(task.id === task.id ? task.setId : task.setId);
    if (!set) continue;
    const setTasks = tasksBySet.get(task.setId) ?? [];
    const state = waitStateOfTask({ task, setTasks, stageByCode });
    if (!state.waiting) continue;

    const setRow = set as unknown as ProductionSetRow;
    const score = scoreSet(setRow, stage.code, scoreContext).score;
    const demand = demandOfTask(setRow, stage);
    const ready = readyDayFor({
      set: setRow,
      task: { ...task, stageKind: "GIA_CONG", workCenterCode: stage.workCenterCode, qtyExpected: null, qtyDone: null, targetStart: null, targetEnd: null, actualStart: null, assignee: null, isRework: false, reworkFromStage: null, reasonCode: null, note: null, updatedBy: null, orderItemId: null } as unknown as ProductionTaskRow,
      stage,
      placed: new Map(
        setTasks
          .filter((row) => row.status === "XONG" || row.plannedStart)
          .map((row) => [row.id, { start: row.plannedStart, end: row.actualEnd ?? row.plannedEnd ?? row.plannedStart }]),
      ),
      calendar,
      from,
      overlap: Number(config.overlapDaysPerStep) || 0,
      tasksBySet: new Map([[task.setId, setTasks as unknown as ProductionTaskRow[]]]),
    });

    queue.push({
      taskId: task.id,
      setId: set.id,
      scope: task.scope,
      setNo: set.setNo,
      orderCode: set.orderCode,
      customerName: set.customerName,
      paintColor: set.paintColor,
      dueDate: set.dueDate ? isoDateOnly(set.dueDate) : null,
      demand,
      score,
      groupKey: grouping ? groupKeyOf(grouping.code as never, setRow, { paintGroupOf }) : null,
      ready: isoDateOnly(ready),
      queueRank: 0,
    });
    dispatchItems.push({ taskId: task.id, setId: set.id, score, demand, ready, groupKey: grouping ? groupKeyOf(grouping.code as never, setRow, { paintGroupOf }) : null });
  }

  const result = scheduleQueue({
    items: dispatchItems,
    capacity: capacity.value,
    from,
    to,
    calendar,
    // GOM LÔ chỉ khi công đoạn khai đủ và có chỉ tiêu gom nhóm (giống quy tắc engine)
    maxGroupsPerDay:
      stage.batchKey && Number(stage.batchMinQty) >= 10 && grouping && BATCH_GROUP_CODES.has(grouping.code)
        ? Number(stage.changeoverMaxPerDay) || 2
        : null,
    minLot: stage.batchMinQty,
  });

  const rankByTask = new Map(result.assignments.map((item) => [item.taskId, item.rank]));
  const queueWithRank = queue
    .map((item) => ({ ...item, queueRank: rankByTask.get(item.taskId) ?? 0 }))
    .sort((a, b) => (a.queueRank || 1e9) - (b.queueRank || 1e9) || b.score - a.score || a.setId - b.setId);

  const dayDetails: StageDispatchDay[] = result.days.map((day) => {
    const ratio = capacity.value && capacity.value > 0 ? day.worked / capacity.value : null;
    return {
      date: isoDateOnly(day.day),
      worked: day.worked,
      capacity: capacity.value,
      ratio,
      tone: ratio === null ? "ok" : ratio >= 0.999 ? "bad" : ratio >= 0.9 ? "warn" : "ok",
      items: day.assignments
        .sort((a, b) => a.rank - b.rank)
        .map((assignment) => {
          const set = setById.get(assignment.setId);
          const demand = dispatchItems.find((item) => item.taskId === assignment.taskId)?.demand ?? 0;
          return {
            taskId: assignment.taskId,
            setId: assignment.setId,
            setNo: set?.setNo ?? null,
            paintColor: set?.paintColor ?? null,
            demand,
            groupKey: assignment.groupKey,
          };
        }),
    };
  });

  return {
    version: await productionPlanVersion(),
    stage: { code: stage.code, name: stage.name, seq: stage.seq, capacity: capacity.value, unit, capacitySource: capacity.source },
    mode: result.mode,
    modeNote:
      result.mode === "GOM_LO"
        ? `GOM LÔ theo nhóm · tối đa ${Number(stage.changeoverMaxPerDay) || 2} nhóm/ngày · lô tối thiểu ${stage.batchMinQty}`
        : "Xếp lần lượt theo hàng đợi (chưa bật gom lô cho công đoạn này)",
    criteria: rule.criteria.filter((item) => item.weight > 0).map((item) => ({ code: item.code, weight: item.weight })),
    grouping: grouping ? { code: grouping.code, tolerance: grouping.tolerance } : null,
    queue: queueWithRank,
    days: dayDetails,
    assignments: result.assignments.map((item) => ({ taskId: item.taskId, setId: item.setId, day: isoDateOnly(item.day), queueRank: item.rank })),
    overflow: result.overflow,
    from: isoDateOnly(from),
    usedDays: result.usedDays,
  };
}

/**
 * XÁC NHẬN điều độ tự động của MỘT công đoạn → ghi vào kế hoạch.
 * Đồng thời **xoá kế hoạch của mọi công đoạn PHÍA SAU** của những bộ vừa xếp (đúng quy tắc nhà máy).
 * Ghi gộp: 3 câu SQL cho tasks/sets + 1 câu log, tất cả trong MỘT transaction.
 */
export async function applyStageDispatch(query: {
  stageCode: string;
  from?: string | null;
  horizonDays?: number | null;
  byName?: string | null;
}): Promise<{ sets: number; tasks: number; cleared: number; days: number; overflow: number }> {
  const preview = await previewStageDispatch(query);
  const rows = preview.assignments;
  if (!rows.length) {
    return { sets: 0, tasks: 0, cleared: 0, days: 0, overflow: preview.overflow.length };
  }
  const records = rows.map((row) => ({ id: row.taskId, day: row.day }));
  const setIds = Array.from(new Set(rows.map((row) => row.setId)));
  const assignedIds = rows.map((row) => row.taskId);
  const byName = query.byName?.trim() || null;

  return prisma.$transaction(async (tx) => {
    const updated = await tx.$executeRaw`
      UPDATE production_tasks AS t
      SET planned_start = v.day::date, planned_end = v.day::date, updated_at = now()
      FROM jsonb_to_recordset(${JSON.stringify(records)}::jsonb) AS v(id int, day text)
      WHERE t.id = v.id`;
    if (Number(updated) !== records.length) {
      throw new Error(`Chỉ ghi được ${Number(updated)}/${records.length} công đoạn — đã huỷ, điều độ không đổi.`);
    }

    // Xoá công đoạn PHÍA SAU của các bộ vừa xếp (trừ công đoạn đã XONG).
    const cleared = await tx.$executeRaw`
      UPDATE production_tasks AS t
      SET planned_start = NULL, planned_end = NULL, updated_at = now()
      FROM production_tasks AS a
      WHERE a.id = ANY(${assignedIds}::int[])
        AND t.set_id = a.set_id
        AND t.id <> a.id
        AND t.seq > a.seq
        AND t.status <> 'XONG'
        AND t.planned_start IS NOT NULL`;

    // Cập nhật lại ngày kế hoạch + trạng thái của từng bộ (một câu).
    await tx.$executeRaw`
      UPDATE production_sets AS s
      SET planned_start = x.start_date,
          planned_end   = x.end_date,
          status = CASE
            WHEN x.start_date IS NULL THEN (CASE WHEN s.status = 'DA_XEP_LICH' THEN 'CHO_XEP_LICH' ELSE s.status END)
            ELSE (CASE WHEN s.status = 'CHO_XEP_LICH' THEN 'DA_XEP_LICH' ELSE s.status END)
          END,
          updated_at = now()
      FROM (
        SELECT s2.id AS set_id,
               min(t.planned_start) AS start_date,
               max(coalesce(t.planned_end, t.planned_start)) AS end_date
        FROM production_sets AS s2
        LEFT JOIN production_tasks AS t
          ON t.set_id = s2.id AND t.planned_start IS NOT NULL AND t.status <> 'XONG' AND t.stage_kind <> 'CHO'
        WHERE s2.id = ANY(${setIds}::int[])
        GROUP BY s2.id
      ) AS x
      WHERE s.id = x.set_id`;

    await tx.productionLog.createMany({
      data: setIds.slice(0, 2000).map((setId) => ({
        entity: "SET",
        entityId: setId,
        action: "DIEU_DO_TU_DONG",
        field: preview.stage.code,
        oldValue: null,
        newValue: `${preview.mode} · ${preview.usedDays} ngày · ${byName ?? ""}`.trim(),
        byName,
      })),
    });

    return {
      sets: setIds.length,
      tasks: Number(updated),
      cleared: Number(cleared),
      days: preview.usedDays,
      overflow: preview.overflow.length,
    };
  }, ORDER_WRITE_TRANSACTION);
}

// ---------------------------------------------------------------------------
// V156 — BÁO CÁO SẢN XUẤT THEO TỔ (màn hình xưởng cho công nhân)
//
// Một màn cho MỘT TỔ; trong tổ chia theo CÔNG ĐOẠN. Dòng chỉ có
// STT · Khách hàng · Lô · Bộ số · SL kế hoạch + 4 nút 1-chạm.
// ---------------------------------------------------------------------------

export type TeamReportRow = {
  taskId: number;
  setId: number;
  setNo: string | null;
  orderCode: string | null;
  customerName: string | null;
  paintColor: string | null;
  model: string | null;
  /** Lô để cả tổ gọi chung một cái tên (xem `lotLabelOf`). */
  lot: string;
  lotSource: string;
  /** SL KẾ HOẠCH của bộ ở công đoạn này (cánh hoặc bộ — theo đơn vị công đoạn). */
  qty: number;
  unit: LoadUnit;
  status: string;
  qtyDone: number;
  actualStart: string | null;
  actualEnd: string | null;
  reasonCode: string | null;
  reasonName: string | null;
  note: string | null;
  /** CÔNG ĐOẠN TRƯỚC: tên + trạng thái gộp + GIỜ HOÀN THÀNH (nếu đã xong). */
  prev: {
    /** Tên (các) công đoạn trước, vd "Hàn cánh" hoặc "Hàn cánh + Hàn khung". */
    names: string;
    status: PrevStatus;
    /** ISO giờ hoàn thành muộn nhất trong các công đoạn trước đã xong. */
    doneAt: string | null;
    /** Câu hiện sẵn trên màn: "Xong 14:32" · "Đang làm" · "Chưa làm" · "—". */
    text: string;
  };
};

export type TeamReportStage = {
  code: string;
  name: string;
  seq: number;
  workCenterCode: string | null;
  unit: LoadUnit;
  capacity: number | null;
  capacitySource: string;
  /** Chỉ tiêu ưu tiên đang áp cho công đoạn (hiện ra cho tổ trưởng biết thứ tự). */
  criteria: Array<{ code: string; weight: number }>;
  grouping: { code: string; label: string } | null;
  totals: {
    rows: number;
    planQty: number;
    doneQty: number;
    doingQty: number;
    errorQty: number;
    pauseQty: number;
    notStarted: number;
    doneCount: number;
    doingCount: number;
    errorCount: number;
    pauseCount: number;
  };
  progress: DayProgress;
  rows: TeamReportRow[];
};

export type TeamReport = {
  day: string;
  today: string;
  nowMinutes: number;
  shift: { startMinutes: number; endMinutes: number };
  teams: Array<{ code: string; name: string; stageCount: number; planQty: number; openQty: number; rows: number }>;
  team: { code: string; name: string } | null;
  stages: TeamReportStage[];
  totals: { planQty: number; doneQty: number; errorQty: number; pauseQty: number; rows: number };
  /** Cảnh báo chung của cả tổ (nếu có công đoạn không kịp). */
  alerts: string[];
  /** Danh mục lý do để bấm chọn nhanh (LỖI / TẠM DỪNG) — không phải gõ tay. */
  reasons: { error: Array<{ code: string; name: string }>; pause: Array<{ code: string; name: string }> };
};

/** Lý do LỖI (hỏng, phế, máy) và lý do TẠM DỪNG (chờ, trễ, thiếu người) — tách để bấm cho nhanh. */
function classifyReasons(reasons: Array<{ code: string; name: string }>) {
  const isError = (code: string) => /^LOI_|^PHE_|^MAY_HONG/.test(code);
  const isPause = (code: string) => /^CHO_|^TRE_|^THIEU_NGUOI|^KHACH_DOI|^KHONG_DU_CHO/.test(code);
  return {
    error: reasons.filter((row) => isError(row.code)).map(({ code, name }) => ({ code, name })),
    pause: reasons.filter((row) => isPause(row.code)).map(({ code, name }) => ({ code, name })),
  };
}

/** Đọc bảng báo cáo của MỘT TỔ trong MỘT NGÀY. Không ghi gì. */
export async function loadTeamReport(query: {
  teamCode?: string | null;
  stageCode?: string | null;
  day?: string | null;
}): Promise<TeamReport> {
  const [stages, workCenters, priority, paintColors, reasons] = await Promise.all([
    loadActiveStages(),
    loadActiveWorkCenters(),
    readPriorityConfig(),
    loadPaintColors(),
    loadReasons(),
  ]);
  const reasonList = (reasons as Array<{ code: string; name: string }>).map((row) => ({ code: String(row.code), name: String(row.name) }));

  const today = todayInVietnam();
  const day = parseIsoDateStrict(query.day ?? null) ?? today;
  const dayEnd = new Date(day.getTime() + MS_DAY);
  const nowMinutes = vietnamMinutesNow();

  const stageCodesOfTeam = new Map<string, ProductionStageRow[]>();
  for (const stage of stages.filter((row) => row.active)) {
    const code = String(stage.workCenterCode ?? "").trim() || "CHUA_GAN";
    const list = stageCodesOfTeam.get(code);
    if (list) list.push(stage);
    else stageCodesOfTeam.set(code, [stage]);
  }

  // Số liệu tóm tắt cho từng tổ (để hiện tab chọn tổ kèm tải hôm nay).
  const dayTasks = await prisma.productionTask.findMany({
    where: {
      OR: [
        { plannedStart: day },
        { status: { in: ["DANG_LAM", "TAM_DUNG", "LOI"] } },
        { actualEnd: { gte: day, lt: dayEnd } },
      ],
    },
    select: { id: true, setId: true, stageCode: true, status: true },
  });
  const setIdsAll = Array.from(new Set(dayTasks.map((task) => task.setId)));
  const setsAll = setIdsAll.length
    ? await prisma.productionSet.findMany({ where: { id: { in: setIdsAll } } })
    : [];
  const setByIdAll = new Map(setsAll.map((row) => [row.id, row]));
  const stageByCodeAll = new Map(stages.map((row) => [row.code, row]));

  const teams = workCenters
    .filter((center) => center.active)
    .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0) || a.code.localeCompare(b.code))
    .map((center) => {
      const centerStages = stageCodesOfTeam.get(center.code) ?? [];
      const codes = new Set(centerStages.map((stage) => stage.code));
      const mine = dayTasks.filter((task) => codes.has(task.stageCode));
      let planQty = 0;
      let openQty = 0;
      for (const task of mine) {
        const set = setByIdAll.get(task.setId);
        const stage = stageByCodeAll.get(task.stageCode);
        if (!set || !stage) continue;
        const qty = demandOfTask(set, stage);
        planQty += qty;
        if (task.status !== "XONG") openQty += qty;
      }
      return { code: center.code, name: center.name, stageCount: centerStages.length, planQty, openQty, rows: mine.length };
    });

  const wantedTeam = String(query.teamCode ?? "").trim().toUpperCase();
  const team =
    teams.find((row) => row.code === wantedTeam) ??
    teams.find((row) => row.rows > 0) ??
    teams[0] ??
    null;

  const paintGroupOf = makePaintGroupResolver(paintColors);
  const paintLabelOf = (paintColor: string | null): string | null => {
    const key = paintGroupOf(paintColor);
    if (!key) return null;
    const [family, temp, minutes] = key.split("|");
    const familyLabel: Record<string, string> = { DO: "Đỏ", VANG: "Vàng", CAT_CHAY: "Cát chay" };
    return `${familyLabel[family] ?? family} ${temp}°/ ${minutes}′`;
  };
  const reasonNameByCode = new Map(reasons.map((row) => [row.code, row.name]));

  if (!team) {
    return {
      day: dateKeyUtc(day),
      today: dateKeyUtc(today),
      nowMinutes,
      shift: shiftWindow({}),
      teams,
      team: null,
      stages: [],
      totals: { planQty: 0, doneQty: 0, errorQty: 0, pauseQty: 0, rows: 0 },
      alerts: [],
      reasons: classifyReasons(reasonList),
    };
  }

  const teamStages = (stageCodesOfTeam.get(team.code) ?? [])
    .slice()
    .sort((a, b) => a.seq - b.seq || a.code.localeCompare(b.code));
  const wantedStage = String(query.stageCode ?? "").trim().toUpperCase();
  const usedStages = wantedStage ? teamStages.filter((stage) => stage.code === wantedStage) : teamStages;
  const usedCodes = new Set(usedStages.map((stage) => stage.code));
  const shift = shiftWindow(workCenters.find((row) => row.code === team.code) ?? {});
  const stageByCode = new Map(stages.map((row) => [row.code, row]));

  const myTasks = dayTasks.filter((task) => usedCodes.has(task.stageCode));
  const setIds = Array.from(new Set(myTasks.map((task) => task.setId)));
  const [sets, workOrders] = await Promise.all([
    setIds.length ? prisma.productionSet.findMany({ where: { id: { in: setIds } } }) : Promise.resolve([]),
    setIds.length
      ? prisma.productionWorkOrder.findMany({ where: { setId: { in: setIds }, kind: "BO" }, select: { setId: true, code: true } })
      : Promise.resolve([]),
  ]);
  const setById = new Map(sets.map((row) => [row.id, row]));
  const woBySet = new Map(workOrders.map((row) => [row.setId, row.code]));

  const taskIds = myTasks.map((task) => task.id);
  const fullTasks = taskIds.length
    ? await prisma.productionTask.findMany({
        where: { id: { in: taskIds } },
        select: { id: true, qtyDone: true, note: true, reasonCode: true, actualStart: true, actualEnd: true, stageCode: true, scope: true, status: true, setId: true, seq: true },
      })
    : [];
  const detailById = new Map(fullTasks.map((row) => [row.id, row]));

  // Công đoạn trước đã báo xong chưa (chỉ để CẢNH BÁO, không chặn).
  const setIdsWithRows = Array.from(new Set(myTasks.map((task) => task.setId)));
  const allSetTasks = setIdsWithRows.length
    ? await prisma.productionTask.findMany({
        where: { setId: { in: setIdsWithRows } },
        select: { id: true, setId: true, stageCode: true, scope: true, status: true, stageKind: true, actualEnd: true, plannedEnd: true },
      })
    : [];
  const setTasksById = new Map<number, typeof allSetTasks>();
  for (const row of allSetTasks) {
    const list = setTasksById.get(row.setId);
    if (list) list.push(row);
    else setTasksById.set(row.setId, [row]);
  }

  const resultStages: TeamReportStage[] = [];
  const alerts: string[] = [];
  for (const stage of usedStages) {
    const rule = priority.stageRules[stage.code] ?? priority.defaultRule;
    const grouping = groupingOf(rule);
    const capacity = capacityOfStage({ capacityPerDay: stage.capacityPerDay, workCenterCode: stage.workCenterCode }, workCenters);
    const unit = loadUnitOfStage(stage);
    const stageRows = myTasks
      .filter((task) => task.stageCode === stage.code)
      .map((task) => {
        const detail = detailById.get(task.id);
        const set = setById.get(task.setId);
        if (!set) return null;
        const qty = demandOfTask(set, stage);
        const row: TeamReportRow = {
          taskId: task.id,
          setId: set.id,
          setNo: set.setNo,
          orderCode: set.orderCode,
          customerName: set.customerName,
          paintColor: set.paintColor,
          model: set.model,
          lot: "",
          lotSource: "",
          qty,
          unit,
          status: task.status,
          qtyDone: Number(detail?.qtyDone ?? (task.status === "XONG" ? qty : 0)) || (task.status === "XONG" ? qty : 0),
          actualStart: detail?.actualStart ? detail.actualStart.toISOString() : null,
          actualEnd: detail?.actualEnd ? detail.actualEnd.toISOString() : null,
          reasonCode: detail?.reasonCode ?? null,
          reasonName: detail?.reasonCode ? reasonNameByCode.get(detail.reasonCode) ?? detail.reasonCode : null,
          note: detail?.note ?? null,
          prev: { names: "", status: "KHONG_CO" as PrevStatus, doneAt: null, text: "—" },
        };
        const usePaintLot = grouping && BATCH_GROUP_CODES.has(grouping.code);
        const lot = lotLabelOf({
          paintGroupKey: usePaintLot ? paintGroupOf(set.paintColor) : null,
          paintGroupLabel: usePaintLot ? paintLabelOf(set.paintColor) : null,
          workOrderCode: woBySet.get(set.id) ?? null,
          dueDate: set.dueDate,
        });
        row.lot = lot.text;
        row.lotSource = lot.source;
        return row;
      })
      .filter((row): row is TeamReportRow => Boolean(row))
      .sort((a, b) => (a.customerName ?? "").localeCompare(b.customerName ?? "", "vi") || a.setId - b.setId);

    // CỘT "CÔNG ĐOẠN TRƯỚC": công nhân nhìn là biết đã được phép làm chưa, và công đoạn trước
    // xong lúc mấy giờ. Chọn công đoạn trước theo CÙNG PHẦN trước (Ép cánh ← Hàn **cánh**),
    // giống quy tắc mở khoá của engine.
    for (const row of stageRows) {
      const detail = detailById.get(row.taskId);
      const requiredCodes = String(stage.requiresStage ?? "")
        .split(",")
        .map((code) => code.trim())
        .filter(Boolean);
      if (!requiredCodes.length) continue;
      const setTasks = setTasksById.get(row.setId) ?? [];
      const sameScope = setTasks.filter((item) => requiredCodes.includes(item.stageCode) && item.scope === detail?.scope);
      const pool = sameScope.length ? sameScope : setTasks.filter((item) => requiredCodes.includes(item.stageCode));
      if (!pool.length) continue;

      const status = mergePrevStatus(pool);
      const doneEnds = pool
        .filter((item) => item.status === "XONG" && item.actualEnd)
        .map((item) => item.actualEnd as Date);
      const doneAt = doneEnds.length ? new Date(Math.max(...doneEnds.map((date) => date.getTime()))).toISOString() : null;
      row.prev = {
        names: Array.from(new Set(pool.map((item) => stageByCode.get(item.stageCode)?.name ?? item.stageCode))).join(" + "),
        status,
        doneAt,
        text: predecessorText(status, doneAt),
      };
    }

    const sumBy = (predicate: (row: TeamReportRow) => boolean) =>
      stageRows.filter(predicate).reduce((total, row) => total + Math.max(0, Number(row.qty) || 0), 0);
    const totals = {
      rows: stageRows.length,
      planQty: stageRows.reduce((total, row) => total + Math.max(0, Number(row.qty) || 0), 0),
      doneQty: sumBy((row) => row.status === "XONG"),
      doingQty: sumBy((row) => row.status === "DANG_LAM"),
      errorQty: sumBy((row) => row.status === "LOI"),
      pauseQty: sumBy((row) => row.status === "TAM_DUNG"),
      notStarted: stageRows.filter((row) => row.status === "CHUA_LAM").length,
      doneCount: stageRows.filter((row) => row.status === "XONG").length,
      doingCount: stageRows.filter((row) => row.status === "DANG_LAM").length,
      errorCount: stageRows.filter((row) => row.status === "LOI").length,
      pauseCount: stageRows.filter((row) => row.status === "TAM_DUNG").length,
    };
    const progress = evaluateDayProgress({
      planQty: totals.planQty,
      doneQty: totals.doneQty,
      doingQty: totals.doingQty,
      errorQty: totals.errorQty,
      pauseQty: totals.pauseQty,
      nowMinutes,
      startMinutes: shift.startMinutes,
      endMinutes: shift.endMinutes,
    });
    if (progress.tone === "bad" && totals.planQty > 0) {
      alerts.push(`${stage.name}: ${progress.headline}`);
    }
    resultStages.push({
      code: stage.code,
      name: stage.name,
      seq: stage.seq,
      workCenterCode: stage.workCenterCode,
      unit,
      capacity: capacity.value,
      capacitySource: capacity.source,
      criteria: rule.criteria.filter((item) => item.weight > 0).map((item) => ({ code: item.code, weight: item.weight })),
      grouping: grouping ? { code: grouping.code, label: grouping.label } : null,
      totals,
      progress,
      rows: stageRows,
    });
  }

  return {
    day: dateKeyUtc(day),
    today: dateKeyUtc(today),
    nowMinutes,
    shift,
    teams,
    team: { code: team.code, name: team.name },
    stages: resultStages,
    totals: {
      planQty: resultStages.reduce((total, stage) => total + stage.totals.planQty, 0),
      doneQty: resultStages.reduce((total, stage) => total + stage.totals.doneQty, 0),
      errorQty: resultStages.reduce((total, stage) => total + stage.totals.errorQty, 0),
      pauseQty: resultStages.reduce((total, stage) => total + stage.totals.pauseQty, 0),
      rows: resultStages.reduce((total, stage) => total + stage.totals.rows, 0),
    },
    alerts,
    reasons: classifyReasons(reasonList),
  };
}

/**
 * MỘT CHẠM của công nhân → cập nhật trạng thái công đoạn.
 *
 * Ghi gộp 1 transaction: trạng thái công đoạn + (nếu là bộ chưa vào sản xuất) ngày vào sản xuất
 * + trạng thái/% của bộ + nhật ký. **Không chặn** theo thứ tự công đoạn (công nhân báo được ngay);
 * API trả về `warnings` để màn hình nhắc nhở.
 */
export async function applyTaskAction(args: {
  taskId: number;
  action: TaskAction;
  reasonCode?: string | null;
  qtyDone?: number | null;
  byName?: string | null;
  /** Chỉ dùng cho HOAN_TAC: trạng thái ngay trước đó (màn hình gửi lên). */
  prevStatus?: string | null;
  /** Chỉ dùng cho HOAN_TAC: lý do ngay trước đó (để trả lại đúng như cũ, không để lại lý do thừa). */
  prevReasonCode?: string | null;
}): Promise<{ taskId: number; setId: number; status: string; warnings: string[] }> {
  const action = args.action;
  if (!["BAT_DAU", "HOAN_THANH", "LOI", "TAM_DUNG", "HOAN_TAC"].includes(action)) {
    throw new Error("Hành động không hợp lệ.");
  }
  const task = await prisma.productionTask.findUnique({
    where: { id: args.taskId },
    select: {
      id: true,
      setId: true,
      stageCode: true,
      scope: true,
      status: true,
      qtyDone: true,
      actualStart: true,
      actualEnd: true,
      reasonCode: true,
      set: {
        select: {
          id: true,
          status: true,
          startedAt: true,
          plannedStart: true,
          quantity: true,
          leavesPerSet: true,
          productName: true,
        },
      },
    },
  });
  if (!task) throw new Error("Không tìm thấy công đoạn.");
  if (task.status === "BO_QUA") throw new Error("Công đoạn này được đánh dấu bỏ qua — không báo được.");

  const stages = await loadActiveStages();
  const stage = stages.find((row) => row.code === task.stageCode);
  if (!stage) throw new Error("Công đoạn đã tắt trong danh mục.");
  const demand = demandOfTask(task.set, stage);
  const today = todayInVietnam();

  let status = task.status;
  let actualStart = task.actualStart;
  let actualEnd = task.actualEnd;
  let qtyDone = task.qtyDone === null ? null : Number(task.qtyDone);
  let reasonCode = task.reasonCode;

  if (action === "BAT_DAU") {
    status = "DANG_LAM";
    if (!actualStart) actualStart = new Date();
    actualEnd = null;
  } else if (action === "HOAN_THANH") {
    status = "XONG";
    if (!actualStart) actualStart = new Date();
    actualEnd = new Date();
    qtyDone = Number.isFinite(Number(args.qtyDone)) && Number(args.qtyDone) > 0 ? Number(args.qtyDone) : demand;
    reasonCode = null;
  } else if (action === "LOI") {
    status = "LOI";
    if (!actualStart) actualStart = new Date();
    reasonCode = String(args.reasonCode ?? "").trim() || "PHE_PHAI_LAM_LAI";
  } else if (action === "TAM_DUNG") {
    status = "TAM_DUNG";
    if (!actualStart) actualStart = new Date();
    reasonCode = String(args.reasonCode ?? "").trim() || reasonCode;
  } else {
    // HOAN_TAC — trả về trạng thái ngay trước đó (màn hình gửi lên giá trị đã lưu).
    const prev = String(args.prevStatus ?? "").trim().toUpperCase();
    status = ["CHUA_LAM", "DANG_LAM", "TAM_DUNG", "XONG", "LOI"].includes(prev) ? prev : "DANG_LAM";
    // Trả lại ĐÚNG lý do cũ: về Chưa làm / Đang làm thì không được để lại lý do lỗi hay lý do tạm dừng.
    reasonCode = status === "CHUA_LAM" || status === "DANG_LAM" ? null : String(args.prevReasonCode ?? "").trim() || null;
    if (status === "CHUA_LAM") {
      actualStart = null;
      actualEnd = null;
      qtyDone = null;
    } else if (status === "DANG_LAM") {
      actualEnd = null;
    }
  }

  const warnings: string[] = [];
  const requiredCodes = String(stage.requiresStage ?? "")
    .split(",")
    .map((code) => code.trim())
    .filter(Boolean);
  if (requiredCodes.length && (action === "BAT_DAU" || action === "HOAN_THANH")) {
    const setTasks = await prisma.productionTask.findMany({
      where: { setId: task.setId },
      select: { stageCode: true, scope: true, status: true },
    });
    const sameScope = setTasks.filter((row) => requiredCodes.includes(row.stageCode) && row.scope === task.scope);
    const pool = sameScope.length ? sameScope : setTasks.filter((row) => requiredCodes.includes(row.stageCode));
    const notDone = pool.filter((row) => row.status !== "XONG" && row.status !== "BO_QUA");
    if (notDone.length) {
      const stageByCode = new Map(stages.map((row) => [row.code, row]));
      warnings.push(
        `Công đoạn trước chưa báo xong: ${Array.from(new Set(notDone.map((row) => stageByCode.get(row.stageCode)?.name ?? row.stageCode))).join(", ")}`,
      );
    }
  }

  const byName = args.byName?.trim() || null;
  const startedSet = action === "BAT_DAU" && !task.set.startedAt;

  return prisma.$transaction(async (tx) => {
    await tx.productionTask.update({
      where: { id: task.id },
      data: { status, actualStart, actualEnd, qtyDone, reasonCode, updatedBy: byName },
    });

    if (startedSet) {
      await tx.productionSet.update({
        where: { id: task.setId },
        data: {
          startedAt: today,
          status: ["CHO_XEP_LICH", "DA_XEP_LICH", "TAM_DUNG"].includes(task.set.status) ? "DANG_SX" : task.set.status,
        },
      });
    }

    // Cập nhật lại % + trạng thái BỘ (không đụng bộ đã giao/huỷ).
    if (!["DA_GIAO", "HUY"].includes(task.set.status)) {
      const siblings = await tx.productionTask.findMany({
        where: { setId: task.setId },
        select: { stageKind: true, status: true },
      });
      const percent = percentDoneOf(siblings);
      // Bộ đang TAM_DUNG mà KHÔNG còn công đoạn nào tạm dừng nữa (vừa được hoàn tác/báo xong) thì
      // phải rời khỏi TAM_DUNG — nếu không bộ sẽ kẹt mãi ở "Tạm dừng" dù tổ đã làm tiếp.
      const stillPaused = siblings.some((row) => row.status === "TAM_DUNG");
      // Rời TAM_DUNG thì quay về đúng "đã vào sản xuất chưa": chưa vào ⇒ bộ còn ở dạng đã/chờ xếp lịch.
      const notPausedStatus = task.set.startedAt ? "DANG_SX" : task.set.plannedStart ? "DA_XEP_LICH" : "CHO_XEP_LICH";
      const baseStatus =
        task.set.status === "TAM_DUNG" && !stillPaused ? notPausedStatus : startedSet ? "DANG_SX" : task.set.status;
      const nextStatus = deriveSetStatus(siblings, baseStatus, true);
      await tx.productionSet.update({ where: { id: task.setId }, data: { percentDone: percent, status: nextStatus } });
    }

    await tx.productionLog.create({
      data: {
        entity: "TASK",
        entityId: task.id,
        action: `BAO_CAO_${action}`,
        field: "status",
        oldValue: task.status,
        newValue: status,
        byName,
      },
    });

    return { taskId: task.id, setId: task.setId, status, warnings };
  }, ORDER_WRITE_TRANSACTION);
}
