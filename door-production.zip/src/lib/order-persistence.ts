
type UnknownRecord = Record<string, unknown>;

export type NormalizedOrderLine = {
  setNo: string | null;
  productName: string | null;
  productCode: string | null;
  model: string | null;
  openingDirection: string | null;
  trimDirection: string | null;
  paintColor: string | null;
  heightMm: number | null;
  widthMm: number | null;
  frameMm: number | null;
  clearHeightMm: number | null;
  clearWidthMm: number | null;
  panelInfo: string | null;
  trimBarsPerSet: number | null;
  trimType: string | null;
  lockModel: string | null;
  windowBars: string | null;
  leavesPerSet: number | null;
  quantity: number | null;
  unit: string | null;
  pricingQuantity: number | null;
  unitPrice: number | null;
  amount: number | null;
  note: string | null;
  imagePath: string | null;
  modelCheck: string | null;
  priceCheck: string | null;
};

export type NormalizedOrder = {
  orderCode: string;
  orderData: {
    /** V112: loại đơn (MAU | SAN_XUAT | LAM_LAI) — chọn khi tạo đơn. */
    orderType: string;
    /** V112: trạng thái (NHAP | DA_XAC_NHAN) — do hành động lưu quyết định. */
    status: string;
    customerCode: string | null;
    customerName: string | null;
    salesEmployeeCode: string | null;
    orderDate: Date | null;
    requiredDeliveryDate: Date | null;
    receiverName: string | null;
    receiverPhone: string | null;
    receiverAddress: string | null;
    deliveryKm: number | null;
    region: string | null;
    groupNo: number | null;
    excelUpdateDate: Date | null;
    formCode: string | null;
    formEffectiveDate: Date | null;
    shippingFee: number;
    subtotal: number;
    discountPercent: number;
    discountAmount: number;
    totalAfterDiscount: number;
    depositAmount: number;
    warehouseReceiptDeduction: number;
    deliveryPayment: number;
  };
  items: Array<{
    lineNo: number;
    data: NormalizedOrderLine;
    details: Array<{ rowOrder: number; detailType: string | null; data: NormalizedOrderLine }>;
  }>;
  requirements: Array<{
    code: string;
    questionText: string;
    answer: string | null;
    note: string | null;
    sortOrder: number;
  }>;
};

export function normalizeOrderPayload(input: unknown): NormalizedOrder {
  if (!isRecord(input)) throw new Error("Dữ liệu đơn hàng không hợp lệ.");

  const requiredInfo = normalizeRequiredOrderInfo(input);
  const orderCode = requiredInfo.orderCode;
  const rawItems = Array.isArray(input.items) ? input.items : [];
  if (rawItems.length === 0) throw new Error("Đơn hàng phải có ít nhất 1 bộ cửa.");

  const items = rawItems.map((rawItem, itemIndex) => {
    if (!isRecord(rawItem)) throw new Error(`Bộ cửa ${itemIndex + 1} không hợp lệ.`);
    const rawDetails = Array.isArray(rawItem.details) ? rawItem.details : [];
    return {
      lineNo: itemIndex + 1,
      data: normalizeLine(rawItem),
      details: rawDetails.filter(isRecord).map((row, rowIndex) => ({
        rowOrder: rowIndex + 1,
        detailType: optionalText(row.detailType),
        data: normalizeLine(row),
      })),
    };
  });

  const shippingFee = nonNegativeNumber(input.shippingFee) ?? 0;
  const discountPercent = clampPercent(nonNegativeNumber(input.discountPercent) ?? 0);
  const depositAmount = nonNegativeNumber(input.depositAmount) ?? 0;
  const warehouseReceiptDeduction = nonNegativeNumber(input.warehouseReceiptDeduction) ?? 0;

  const lineTotal = items.reduce((sum, item) => {
    const mainAmount = resolvedAmount(item.data);
    const detailsAmount = item.details.reduce((detailSum, detail) => detailSum + resolvedAmount(detail.data), 0);
    return sum + mainAmount + detailsAmount;
  }, 0);

  const subtotal = roundMoney(lineTotal + shippingFee);
  const discountAmount = roundMoney((subtotal * discountPercent) / 100);
  const totalAfterDiscount = roundMoney(Math.max(0, subtotal - discountAmount));
  const deliveryPayment = roundMoney(
    Math.max(0, totalAfterDiscount - depositAmount - warehouseReceiptDeduction),
  );

  for (const item of items) {
    item.data.amount = resolvedAmountOrNull(item.data);
    for (const detail of item.details) detail.data.amount = resolvedAmountOrNull(detail.data);
  }

  const rawRequirements = Array.isArray(input.requirements) ? input.requirements : [];
  const requirements = rawRequirements.filter(isRecord).map((row, index) => ({
    code: optionalText(row.code) || `CAU_HOI_${index + 1}`,
    questionText: optionalText(row.questionText) || `Câu hỏi ${index + 1}`,
    answer: optionalText(row.answer),
    note: optionalText(row.note),
    sortOrder: index + 1,
  }));

  return {
    orderCode,
    orderData: {
      orderType: normalizeOrderType(input.orderType),
      status: requiredInfo.status,
      customerCode: requiredInfo.customerCode,
      customerName: requiredInfo.customerName,
      salesEmployeeCode: requiredInfo.salesEmployeeCode,
      orderDate: requiredInfo.orderDate,
      requiredDeliveryDate: requiredInfo.requiredDeliveryDate,
      receiverName: requiredInfo.receiverName,
      receiverPhone: requiredInfo.receiverPhone,
      receiverAddress: requiredInfo.receiverAddress,
      deliveryKm: requiredInfo.deliveryKm,
      region: requiredInfo.region,
      groupNo: requiredInfo.groupNo,
      excelUpdateDate: requiredInfo.excelUpdateDate,
      formCode: requiredInfo.formCode,
      formEffectiveDate: requiredInfo.formEffectiveDate,
      shippingFee,
      subtotal,
      discountPercent,
      discountAmount,
      totalAfterDiscount,
      depositAmount,
      warehouseReceiptDeduction,
      deliveryPayment,
    },
    items,
    requirements,
  };
}

function normalizeRequiredOrderInfo(input: UnknownRecord) {
  const textFields = [
    ["customerCode", "Mã Đại Lý"],
    ["customerName", "Tên khách hàng"],
    ["salesEmployeeCode", "NVKD phụ trách"],
    ["orderCode", "Mã đơn hàng"],
    ["status", "Trạng thái"],
    ["receiverPhone", "Số điện thoại"],
    ["receiverAddress", "Địa chỉ nhận hàng"],
  ] as const;
  const dateFields = [
    ["orderDate", "Ngày đặt hàng"],
    ["requiredDeliveryDate", "Ngày cần giao hàng"],
    ["excelUpdateDate", "Ngày cập nhật"],
  ] as const;

  // V58: Người nhận, Vùng miền, Số Km giao hàng không còn bắt buộc.
  const missing = [
    ...textFields.filter(([key]) => !optionalText(input[key])).map(([, label]) => label),
    ...dateFields.filter(([key]) => !optionalText(input[key])).map(([, label]) => label),
  ];
  if (missing.length) {
    throw new Error(`Vui lòng nhập đầy đủ thông tin bắt buộc: ${missing.join(", ")}.`);
  }

  const orderDate = requiredDate(input.orderDate, "Ngày đặt hàng");
  const requiredDeliveryDate = requiredDate(input.requiredDeliveryDate, "Ngày cần giao hàng");
  const excelUpdateDate = requiredDate(input.excelUpdateDate, "Ngày cập nhật");
  const formEffectiveDate = parseDate(input.formEffectiveDate);
  const deliveryKm = optionalNonNegativeNumber(input.deliveryKm, "Số Km giao hàng");
  const groupNo = integerOrNull(input.groupNo);

  return {
    customerCode: requiredText(input.customerCode, "Mã Đại Lý"),
    customerName: requiredText(input.customerName, "Tên khách hàng"),
    salesEmployeeCode: requiredText(input.salesEmployeeCode, "NVKD phụ trách"),
    orderCode: requiredText(input.orderCode, "Mã đơn hàng"),
    // V91: chỉ nhận 2 trạng thái chuẩn — mã cũ được quy về trạng thái tương ứng.
    status: normalizeOrderStatus(requiredText(input.status, "Trạng thái")),
    orderDate,
    requiredDeliveryDate,
    excelUpdateDate,
    receiverName: optionalText(input.receiverName),
    receiverPhone: requiredText(input.receiverPhone, "Số điện thoại"),
    deliveryKm,
    region: optionalText(input.region),
    groupNo,
    formCode: optionalText(input.formCode),
    formEffectiveDate,
    receiverAddress: requiredText(input.receiverAddress, "Địa chỉ nhận hàng"),
  };
}

function normalizeLine(row: UnknownRecord): NormalizedOrderLine {
  return {
    setNo: optionalText(row.setNo),
    productName: optionalText(row.productName),
    productCode: optionalText(row.productCode),
    model: optionalText(row.model),
    openingDirection: optionalText(row.openingDirection),
    trimDirection: optionalText(row.trimDirection),
    paintColor: optionalText(row.paintColor),
    heightMm: integerOrNull(row.heightMm),
    widthMm: integerOrNull(row.widthMm),
    frameMm: integerOrNull(row.frameMm),
    clearHeightMm: integerOrNull(row.clearHeightMm),
    clearWidthMm: integerOrNull(row.clearWidthMm),
    panelInfo: optionalText(row.panelInfo),
    trimBarsPerSet: integerOrNull(row.trimBarsPerSet),
    trimType: optionalText(row.trimType),
    lockModel: optionalText(row.lockModel),
    windowBars: optionalText(row.windowBars),
    leavesPerSet: integerOrNull(row.leavesPerSet),
    quantity: integerOrNull(row.quantity),
    unit: optionalText(row.unit),
    pricingQuantity: nonNegativeNumber(row.pricingQuantity),
    unitPrice: nonNegativeNumber(row.unitPrice),
    amount: nonNegativeNumber(row.amount),
    note: optionalText(row.note),
    imagePath: optionalText(row.imagePath),
    modelCheck: optionalText(row.modelCheck),
    priceCheck: optionalText(row.priceCheck),
  };
}

function resolvedAmount(line: NormalizedOrderLine) {
  if (line.amount !== null) return line.amount;
  if (line.pricingQuantity !== null && line.unitPrice !== null) {
    return roundMoney(line.pricingQuantity * line.unitPrice);
  }
  return 0;
}

function resolvedAmountOrNull(line: NormalizedOrderLine) {
  const result = resolvedAmount(line);
  const hasPricing = line.amount !== null || (line.pricingQuantity !== null && line.unitPrice !== null);
  return hasPricing ? result : null;
}

function isRecord(value: unknown): value is UnknownRecord {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function optionalText(value: unknown) {
  if (value === null || value === undefined) return null;
  const normalized = String(value).trim();
  return normalized ? normalized : null;
}

/**
 * V112: trạng thái đơn chỉ còn 2 giá trị — NHAP (Đơn nháp) / DA_XAC_NHAN (Đã xác nhận).
 * Mã cũ trước V112 (CHUYEN_SAN_XUAT, CHO_XAC_NHAN) được quy về đúng 2 giá trị này khi ghi vào DB.
 */
/**
 * V112: mã loại đơn hợp lệ; mã lạ/rỗng → Đơn hàng mẫu (dùng cho cả payload cũ chưa gửi orderType).
 */
function normalizeOrderType(value: unknown) {
  const text = String(value ?? "").trim();
  return ["MAU", "SAN_XUAT", "LAM_LAI"].includes(text) ? text : "MAU";
}

function normalizeOrderStatus(value: string) {
  const text = value.trim();
  if (text === "CHUYEN_SAN_XUAT" || text === "DA_XAC_NHAN") return "DA_XAC_NHAN";
  if (text === "NHAP" || text === "CHO_XAC_NHAN") return "NHAP";
  // "HUY" (đơn đã huỷ) giữ nguyên, không tự khôi phục.
  return text;
}

function requiredText(value: unknown, label: string) {
  const result = optionalText(value);
  if (!result) throw new Error(`${label} là bắt buộc.`);
  return result;
}

function numberOrNull(value: unknown) {
  if (value === null || value === undefined || value === "") return null;
  const normalized = typeof value === "string" ? value.replace(/,/g, "").trim() : value;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function nonNegativeNumber(value: unknown) {
  const parsed = numberOrNull(value);
  return parsed === null ? null : Math.max(0, parsed);
}

function integerOrNull(value: unknown) {
  const parsed = numberOrNull(value);
  return parsed === null ? null : Math.trunc(parsed);
}

function parseDate(value: unknown) {
  const text = optionalText(value);
  if (!text) return null;
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return null;
  return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
}

function requiredDate(value: unknown, label: string) {
  const result = parseDate(value);
  if (!result) throw new Error(`${label} không hợp lệ.`);
  return result;
}

/** V58: Người nhận / Vùng miền / Số Km giao hàng bỏ trống được; nếu có nhập thì không cho số âm. */function optionalNonNegativeNumber(value: unknown, label: string) {
  const parsed = numberOrNull(value);
  if (parsed === null) return null;
  if (parsed < 0) throw new Error(`${label} không hợp lệ.`);
  return parsed;
}

function requiredInteger(value: unknown, label: string) {
  const parsed = numberOrNull(value);
  if (parsed === null || !Number.isInteger(parsed)) throw new Error(`${label} không hợp lệ.`);
  return parsed;
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function clampPercent(value: number) {
  return Math.min(100, Math.max(0, value));
}

function roundMoney(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}
