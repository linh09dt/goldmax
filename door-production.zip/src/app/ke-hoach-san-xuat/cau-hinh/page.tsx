import Link from "next/link";
import { ErpShell } from "@/components/erp-shell";
import { ProductionConfigScreen } from "@/components/production/production-config";
import { prisma } from "@/lib/prisma";
import {
  loadPaintColors,
  loadReasons,
  loadStages,
  loadWorkCenters,
  readPriorityConfig,
  readProductionConfig,
} from "@/lib/production/service";

export const dynamic = "force-dynamic";

/**
 * V136/V149 — Cấu hình sản xuất: tổ & năng lực, công đoạn, THỨ TỰ ƯU TIÊN (theo từng công đoạn),
 * lý do, chương trình máy cắt, ngày nghỉ, và các con số điều khiển thuật toán xếp lịch.
 */
export default async function ProductionConfigPage() {
  const [config, priority, workCenters, stages, reasons, programs, paintColors, holidays] = await Promise.all([
    readProductionConfig(),
    readPriorityConfig(),
    loadWorkCenters(),
    loadStages(),
    loadReasons(),
    prisma.productionProgram.findMany({ orderBy: [{ model: "asc" }, { version: "desc" }] }),
    loadPaintColors(),
    prisma.productionCalendar.findMany({ orderBy: { date: "asc" } }),
  ]);

  return (
    <ErpShell
      title="Cấu hình sản xuất"
      subtitle="Danh mục công đoạn và năng lực tổ nằm ở đây — sửa được, không hard-code trong code."
      actions={
        <Link className="erp-button-secondary" href="/ke-hoach-san-xuat">
          ← Bảng kế hoạch
        </Link>
      }
    >
      <ProductionConfigScreen
        config={config}
        priority={priority}
        workCenters={workCenters.map((row) => ({
          id: row.id,
          code: row.code,
          name: row.name,
          kind: row.kind,
          peopleCount: row.peopleCount,
          shiftsPerDay: row.shiftsPerDay,
          hoursPerShift: row.hoursPerShift,
          capacityPerDay: row.capacityPerDay,
          capacityUnit: row.capacityUnit,
          active: row.active,
          sortOrder: row.sortOrder,
          note: row.note,
        }))}
        stages={stages.map((row) => ({
          id: row.id,
          code: row.code,
          name: row.name,
          kind: row.kind,
          scopeMode: row.scopeMode,
          scopeParts: row.scopeParts,
          workCenterCode: row.workCenterCode,
          seq: row.seq,
          leadTimeDays: row.leadTimeDays,
          setupMinutes: row.setupMinutes,
          capacityPerDay: row.capacityPerDay,
          batchKey: row.batchKey,
          batchMinQty: row.batchMinQty,
          changeoverMaxPerDay: row.changeoverMaxPerDay,
          isQcPoint: row.isQcPoint,
          reworkToStage: row.reworkToStage,
          skipCondition: row.skipCondition,
          requiresStage: row.requiresStage,
          active: row.active,
          note: row.note,
        }))}
        reasons={reasons.map((row) => ({ id: row.id, code: row.code, name: row.name, group: row.group, sortOrder: row.sortOrder, active: row.active }))}
        programs={programs.map((row) => ({
          id: row.id,
          model: row.model,
          fileName: row.fileName,
          version: row.version,
          machine: row.machine,
          madeBy: row.madeBy,
          durationMinutes: row.durationMinutes,
          reusable: row.reusable,
          note: row.note,
        }))}
        paintColors={paintColors.map((row) => ({
          id: row.id ?? 0,
          code: row.code,
          label: row.label,
          colorName: row.colorName,
          family: row.family,
          specCode: row.specCode,
          tempC: row.tempC,
          minutes: row.minutes,
          needsVeneer: row.needsVeneer,
          sortOrder: row.sortOrder ?? 0,
          active: row.active,
          note: row.note ?? null,
        }))}
        holidays={holidays.map((row) => ({
          id: row.id,
          date: row.date.toISOString().slice(0, 10),
          isWorkingDay: row.isWorkingDay,
          note: row.note,
        }))}
      />
    </ErpShell>
  );
}
