import { ErpShell } from "@/components/erp-shell";
import { ItemMaster } from "@/components/item-master";

export const dynamic = "force-dynamic";

export default function ItemsPage() {
  return (
    <ErpShell
      title="Danh mục hàng hóa"
      description="Danh mục mã và tên hàng hóa dùng chung cho đơn hàng và các module ERP tiếp theo."
    >
      <ItemMaster />
    </ErpShell>
  );
}
