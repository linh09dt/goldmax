import Link from "next/link";
import { ErpShell } from "@/components/erp-shell";
import { OrderImport } from "@/components/order-import";
import { OrderDeleteButton } from "@/components/order-delete-button";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

type LineData = {
  id: string;
  isMain: boolean;
  setNo: string | null;
  productCode: string | null;
  unit: string | null;
  openingDirection: string | null;
  trimDirection: string | null;
  paintColor: string | null;
  heightMm: number | null;
  widthMm: number | null;
  frameMm: number | null;
  clearHeightMm: number | null;
  clearWidthMm: number | null;
  trimBarsPerSet: number | null;
  trimType: string | null;
  lockModel: string | null;
  windowBars: string | null;
  leavesPerSet: number | null;
  note: string | null;
  quantity: number | null;
  pricingQuantity: number | null;
  unitPrice: unknown;
  amount: unknown;
};

export default async function OrdersPage() {
  const orders = await prisma.salesOrder.findMany({
    orderBy: [{ requiredDeliveryDate: "asc" }, { id: "desc" }],
    include: {
      items: {
        orderBy: { lineNo: "asc" },
        include: { details: { orderBy: { rowOrder: "asc" } } },
      },
    },
  });

  const visibleLines = orders.flatMap((order) => {
    const lines: Array<{ order: typeof order; line: LineData }> = [];

    for (const item of order.items) {
      if (hasKhLuong(item.pricingQuantity)) {
        lines.push({
          order,
          line: {
            id: `i-${item.id}`,
            isMain: true,
            setNo: item.setNo,
            productCode: item.productCode,
            unit: item.unit,
            openingDirection: item.openingDirection,
            trimDirection: item.trimDirection,
            paintColor: item.paintColor,
            heightMm: item.heightMm,
            widthMm: item.widthMm,
            frameMm: item.frameMm,
            clearHeightMm: item.clearHeightMm,
            clearWidthMm: item.clearWidthMm,
            trimBarsPerSet: item.trimBarsPerSet,
            trimType: item.trimType,
            lockModel: item.lockModel,
            windowBars: item.windowBars,
            leavesPerSet: item.leavesPerSet,
            note: item.note,
            quantity: item.quantity,
            pricingQuantity: item.pricingQuantity,
            unitPrice: item.unitPrice,
            amount: item.amount,
          },
        });
      }

      for (const detail of item.details) {
        if (!hasKhLuong(detail.pricingQuantity)) continue;
        lines.push({
          order,
          line: {
            id: `d-${detail.id}`,
            isMain: false,
            setNo: detail.setNo,
            productCode: detail.productCode,
            unit: detail.unit,
            openingDirection: detail.openingDirection,
            trimDirection: detail.trimDirection,
            paintColor: detail.paintColor,
            heightMm: detail.heightMm,
            widthMm: detail.widthMm,
            frameMm: detail.frameMm,
            clearHeightMm: detail.clearHeightMm,
            clearWidthMm: detail.clearWidthMm,
            trimBarsPerSet: detail.trimBarsPerSet,
            trimType: detail.trimType,
            lockModel: detail.lockModel,
            windowBars: detail.windowBars,
            leavesPerSet: detail.leavesPerSet,
            note: detail.note,
            quantity: detail.quantity,
            pricingQuantity: detail.pricingQuantity,
            unitPrice: detail.unitPrice,
            amount: detail.amount,
          },
        });
      }
    }

    return lines;
  });

  const draftCount = orders.filter((order) => order.status === "NHAP").length;
  const totalSets = orders.reduce(
    (sum, order) => sum + order.items.reduce((s, item) => s + (item.quantity ?? 0), 0),
    0,
  );

  return (
    <ErpShell
      title="Quản lý đơn hàng"
      description="Danh sách chi tiết theo cấu trúc file Đơn đặt hàng nhập MISA; chỉ hiển thị dòng có KH/Lượng lớn hơn 0."
      actions={<Link className="erp-button" href="/orders/new">+ Tạo đơn hàng</Link>}
    >
      <OrderImport />

      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Metric title="Tổng đơn hàng" value={orders.length.toLocaleString("vi-VN")} />
        <Metric title="Đơn nháp" value={draftCount.toLocaleString("vi-VN")} />
        <Metric title="Tổng số lượng bộ" value={totalSets.toLocaleString("vi-VN")} />
        <Metric title="Dòng có KH/Lượng" value={visibleLines.length.toLocaleString("vi-VN")} />
      </section>

      <section className="erp-card mt-6 overflow-hidden">
        <div className="border-b border-slate-200 bg-slate-50 px-5 py-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-bold">Danh sách đơn hàng</h2>
              <p className="mt-1 text-sm text-slate-500">
                Bố cục theo file “Danh sách đơn hàng.xlsx”. Mã đơn hàng có thể bấm để mở chi tiết; các dòng phụ kiện được hiển thị ngay dưới dòng cửa.
              </p>
            </div>
            <div className="rounded-lg bg-cyan-50 px-3 py-2 text-xs font-semibold text-cyan-800">
              Chỉ hiện KH/Lượng &gt; 0
            </div>
          </div>
        </div>

        <div className="erp-scrollbar overflow-x-auto">
          <table className="min-w-[3600px] border-collapse text-[12px]">
            <thead className="sticky top-0 z-10 bg-slate-900 text-left text-[11px] uppercase tracking-wide text-slate-200">
              <tr>
                <Th>Ngày đơn hàng</Th>
                <Th>Số đơn hàng</Th>
                <Th>Hạn giao hàng</Th>
                <Th>Người nhận và địa chỉ nhận</Th>
                <Th>Số Km từ nhà máy đến nơi giao</Th>
                <Th>Mã khách hàng</Th>
                <Th>Tên khách hàng</Th>
                <Th>Diễn giải</Th>
                <Th>Mã nhân viên bán hàng</Th>
                <Th>Mã bộ đánh số</Th>
                <Th>Mã hàng</Th>
                <Th>ĐVT</Th>
                <Th>Hướng mở</Th>
                <Th>Hướng phào</Th>
                <Th>Màu sơn - mã vân</Th>
                <Th>Chiều Cao ô chờ</Th>
                <Th>Chiều rộng ô chờ</Th>
                <Th>Độ dày khuôn</Th>
                <Th>Cao thông thủy</Th>
                <Th>Rộng thông thủy</Th>
                <Th>Số thanh phào / bộ</Th>
                <Th>Loại phào</Th>
                <Th>Model Khóa</Th>
                <Th>Kiểu song</Th>
                <Th>Số Cánh/bộ</Th>
                <Th>Ghi chú - lưu ý</Th>
                <Th>Số lượng</Th>
                <Th>KH/Lượng</Th>
                <Th>Đơn giá</Th>
                <Th>Thành tiền</Th>
                <Th>Đối tượng THCP</Th>
                <Th>Trạng thái</Th>
                <Th>Thao tác</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {visibleLines.length === 0 ? (
                <tr>
                  <td className="px-4 py-12 text-center text-slate-500" colSpan={33}>
                    Chưa có dòng đơn hàng nào có KH/Lượng lớn hơn 0.
                  </td>
                </tr>
              ) : visibleLines.map(({ order, line }, index) => {
                const previous = index > 0 ? visibleLines[index - 1] : null;
                const firstLineOfOrder = !previous || previous.order.id !== order.id;
                const receiver = [order.receiverName, order.receiverPhone, order.receiverAddress]
                  .filter(Boolean)
                  .join(" - ");

                return (
                  <tr
                    key={`${order.id}-${line.id}`}
                    className={`${line.isMain ? "bg-cyan-50/70 font-medium" : "bg-white"} ${firstLineOfOrder ? "border-t-2 border-slate-400" : ""} hover:bg-amber-50/60`}
                  >
                    <Td>{formatDate(order.orderDate)}</Td>
                    <Td>
                      <Link className="font-semibold text-cyan-700 hover:underline" href={`/orders/${order.id}`}>
                        {order.orderCode}
                      </Link>
                    </Td>
                    <Td>{formatDate(order.requiredDeliveryDate)}</Td>
                    <Td className="max-w-[360px] whitespace-normal">{receiver || "—"}</Td>
                    <Td className="text-right">{formatNumber(order.deliveryKm)}</Td>
                    <Td>{order.customerCode || "—"}</Td>
                    <Td>{order.customerName || "—"}</Td>
                    <Td>{order.orderCode}</Td>
                    <Td>{order.salesEmployeeCode || "—"}</Td>
                    <Td>{line.setNo || "—"}</Td>
                    <Td className="font-semibold">{line.productCode || "—"}</Td>
                    <Td>{line.unit || "—"}</Td>
                    <Td>{line.openingDirection || "—"}</Td>
                    <Td>{line.trimDirection || "—"}</Td>
                    <Td>{line.paintColor || "—"}</Td>
                    <Td className="text-right">{formatNumber(line.heightMm)}</Td>
                    <Td className="text-right">{formatNumber(line.widthMm)}</Td>
                    <Td className="text-right">{formatNumber(line.frameMm)}</Td>
                    <Td className="text-right">{formatNumber(line.clearHeightMm)}</Td>
                    <Td className="text-right">{formatNumber(line.clearWidthMm)}</Td>
                    <Td className="text-right">{formatNumber(line.trimBarsPerSet)}</Td>
                    <Td>{line.trimType || "—"}</Td>
                    <Td>{line.lockModel || "—"}</Td>
                    <Td>{line.windowBars || "—"}</Td>
                    <Td className="text-right">{formatNumber(line.leavesPerSet)}</Td>
                    <Td className="max-w-[320px] whitespace-normal">{line.note || "—"}</Td>
                    <Td className="text-right">{formatNumber(line.quantity)}</Td>
                    <Td className="bg-blue-50 text-right font-bold text-blue-950">{formatDecimal(line.pricingQuantity)}</Td>
                    <Td className="text-right">{formatMoney(line.unitPrice)}</Td>
                    <Td className="text-right font-semibold">{formatMoney(line.amount)}</Td>
                    <Td>{line.productCode || "—"}</Td>
                    <Td>{firstLineOfOrder ? <Status value={order.status} /> : ""}</Td>
                    <Td>
                      {firstLineOfOrder ? (
                        <div className="flex items-center gap-2">
                          <Link className="erp-action-dark" href={`/orders/${order.id}/edit`}>Sửa</Link>
                          <OrderDeleteButton orderId={order.id} orderCode={order.orderCode} compact />
                        </div>
                      ) : null}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </ErpShell>
  );
}

function hasKhLuong(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}

function Metric({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-sm text-slate-500">{title}</p>
      <p className="mt-2 text-3xl font-bold text-slate-950">{value}</p>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="whitespace-nowrap border-r border-slate-700 px-3 py-3 font-semibold last:border-r-0">{children}</th>;
}

function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`whitespace-nowrap border-r border-slate-200 px-3 py-2.5 align-top text-slate-700 last:border-r-0 ${className}`}>{children}</td>;
}

function Status({ value }: { value: string }) {
  const labels: Record<string, string> = {
    NHAP: "Nháp",
    CHO_XAC_NHAN: "Chờ xác nhận",
    DA_XAC_NHAN: "Đã xác nhận",
    CHUYEN_SAN_XUAT: "Đã chuyển sản xuất",
    HUY: "Đã hủy",
  };
  return <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700">{labels[value] ?? value}</span>;
}

function formatDate(value: Date | null) {
  return value ? new Intl.DateTimeFormat("vi-VN").format(value) : "—";
}

function formatNumber(value: number | null | undefined) {
  if (value === null || value === undefined || !Number.isFinite(value)) return "—";
  return new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 3 }).format(value);
}

function formatDecimal(value: number | null | undefined) {
  if (value === null || value === undefined || !Number.isFinite(value) || value <= 0) return "—";
  return new Intl.NumberFormat("vi-VN", { minimumFractionDigits: 0, maximumFractionDigits: 4 }).format(value);
}

function formatMoney(value: unknown) {
  if (value === null || value === undefined) return "—";
  const n = Number(String(value));
  return Number.isFinite(n)
    ? `${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 0 }).format(n)} đ`
    : "—";
}
