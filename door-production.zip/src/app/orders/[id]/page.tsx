import Link from "next/link";
import { notFound } from "next/navigation";
import { ErpShell } from "@/components/erp-shell";
import { OrderDeleteButton } from "@/components/order-delete-button";
import { prisma } from "@/lib/prisma";
import { resolveOrderItemDetails } from "@/lib/order-detail";
import { buildOutputGroups, calculateOutputTotals, hasPricingQuantity } from "@/lib/order-output";

export const dynamic = "force-dynamic";

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) notFound();

  const order = await prisma.salesOrder.findUnique({
    where: { id: orderId },
    include: {
      items: { orderBy: { lineNo: "asc" }, include: { details: { orderBy: { rowOrder: "asc" } } } },
      requirements: { orderBy: { sortOrder: "asc" } },
      imports: { orderBy: { importedAt: "desc" }, take: 10 },
    },
  });
  if (!order) notFound();

  const outputGroups = buildOutputGroups(order.items as any, resolveOrderItemDetails as any);
  const outputTotals = calculateOutputTotals(outputGroups, order);
  const visibleItems = order.items.flatMap((item) => {
    const detailRows = resolveOrderItemDetails(item).filter((row) => hasPricingQuantity(row.pricingQuantity));
    const showMainRow = hasPricingQuantity(item.pricingQuantity);
    if (!showMainRow && detailRows.length === 0) return [];
    return [{ item, detailRows, showMainRow }];
  });

  return (
    <ErpShell
      title={`Đơn hàng ${order.orderCode}`}
      description={`${order.customerCode || "Chưa có mã KH"} · ${order.customerName || "Chưa có tên khách hàng"}`}
      actions={
        <>
          <Link className="erp-button-secondary" href="/orders">← Danh sách</Link>
          <a className="erp-button-secondary" href={`/api/orders/${order.id}/export`}>Xuất Excel</a>
          <Link className="erp-button-secondary" href={`/orders/${order.id}/print?auto=1`} target="_blank">Xuất PDF</Link>
          <Link className="erp-button" href={`/orders/${order.id}/edit`}>Sửa đơn</Link>
          <OrderDeleteButton orderId={order.id} orderCode={order.orderCode} redirectAfterDelete />
        </>
      }
    >
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-6">
        <Info title="Trạng thái" value={statusLabel(order.status)} />
        <Info title="Ngày đặt hàng" value={formatDate(order.orderDate)} />
        <Info title="Ngày cần giao" value={formatDate(order.requiredDeliveryDate)} />
        <Info title="NVKD" value={order.salesEmployeeCode || "—"} />
        <Info title="Vùng miền" value={order.region || "—"} />
        <Info title="Nhóm" value={order.groupNo?.toString() || "—"} />
        <Info title="Người nhận" value={order.receiverName || "—"} />
        <Info title="Số điện thoại" value={order.receiverPhone || "—"} />
        <Info title="Số Km giao hàng" value={order.deliveryKm?.toString() || "—"} />
        <Info title="Mã biểu mẫu" value={order.formCode || "—"} />
        <Info title="Ngày hiệu lực" value={formatDate(order.formEffectiveDate)} />
        <Info title="Nguồn dữ liệu" value={order.sourceFileName ? `Excel: ${order.sourceFileName}` : "Nhập trực tiếp"} />
      </section>

      <section className="erp-card mt-6">
        <div className="border-b border-slate-200 bg-slate-50 px-5 py-4">
          <h2 className="font-bold">Thông tin giao hàng</h2>
        </div>
        <div className="grid gap-4 p-5 md:grid-cols-2">
          <InfoPlain title="Địa chỉ nhận hàng" value={order.receiverAddress || "—"} />
          <InfoPlain title="Ngày cập nhật theo mẫu" value={formatDate(order.excelUpdateDate)} />
        </div>
      </section>

      <section className="erp-card mt-6 overflow-hidden">
        <div className="border-b border-slate-200 bg-slate-50 px-5 py-4">
          <h2 className="font-bold">Chi tiết từng bộ cửa ({visibleItems.length})</h2>
          <p className="mt-1 text-sm text-slate-500">Chỉ hiển thị dòng sản phẩm/phụ kiện có giá trị KH/Lượng lớn hơn 0.</p>
        </div>
        <div className="space-y-5 bg-slate-50 p-4">
          {visibleItems.map(({ item, detailRows, showMainRow }) => {
            return (
              <div className="overflow-hidden rounded-xl border border-slate-300 bg-white" key={item.id}>
                <div className="flex flex-col gap-1 bg-slate-900 px-4 py-3 text-white md:flex-row md:items-center md:justify-between">
                  <div className="font-semibold">
                    Bộ cửa #{item.lineNo} {item.setNo ? `· Bộ số ${item.setNo}` : ""} {item.productName ? `· ${item.productName}` : ""}
                  </div>
                  <div className="text-xs text-slate-300">{detailRows.length} dòng chi tiết có KH/Lượng</div>
                </div>
                <div className="erp-scrollbar overflow-x-auto">
                  <table className="min-w-[3450px] border-collapse text-xs">
                    <thead className="bg-slate-200 text-slate-700">
                      <tr>
                        <Th>STT</Th><Th>Bộ số</Th><Th>Tên sản phẩm</Th><Th>Mã sản phẩm</Th><Th>Model</Th><Th>Hướng mở</Th><Th>Phào Thuận/Nghịch</Th><Th>Màu sơn</Th>
                        <Th>Cao</Th><Th>Rộng</Th><Th>Khuôn</Th><Th>TT Cao</Th><Th>TT Rộng</Th><Th>Ô thoáng/Pano/Nan chớp</Th><Th>Số thanh phào/bộ</Th><Th>Loại phào PR/Lux</Th>
                        <Th>Model Khóa</Th><Th>Song cửa sổ</Th><Th>Số Cánh/bộ</Th><Th>Số lượng bộ cửa</Th><Th>ĐVT</Th><Th>KH/Lượng</Th><Th>Đơn giá</Th><Th>Thành tiền</Th><Th>Ghi chú</Th><Th>Hình ảnh SP</Th><Th>KIỂM TRA MODEL</Th><Th>KIỂM TRA GIÁ</Th>
                      </tr>
                    </thead>
                    <tbody>
                      {showMainRow ? <ReadRow lineNo={item.lineNo} row={item} main /> : null}
                      {detailRows.length > 0 ? (
                        <>
                          <tr>
                            <td className="border border-slate-300 bg-slate-100 px-3 py-2 font-semibold text-slate-700" colSpan={28}>
                              ↳ Chi tiết / phụ kiện / phụ phí của bộ cửa
                            </td>
                          </tr>
                          {detailRows.map((row, index) => (
                            <ReadRow key={row.id ?? `raw-${item.id}-${row.sourceRow ?? index}`} lineNo={null} row={row} />
                          ))}
                        </>
                      ) : null}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-6 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="erp-card">
          <div className="border-b border-slate-200 bg-slate-50 px-5 py-4"><h2 className="font-bold">Câu hỏi thêm / Xác nhận</h2></div>
          <div className="divide-y divide-slate-200">
            {order.requirements.length ? order.requirements.map((row, index) => (
              <div className="grid gap-2 p-4 md:grid-cols-[1fr_180px_1fr]" key={row.id}>
                <div className="font-medium">{index + 1}. {row.questionText}</div>
                <div className="font-semibold text-cyan-700">{row.answer || "Chưa xác nhận"}</div>
                <div className="text-slate-500">{row.note || "—"}</div>
              </div>
            )) : <div className="p-5 text-sm text-slate-500">Chưa có dữ liệu xác nhận.</div>}
          </div>
        </div>

        <div className="erp-card">
          <div className="border-b border-slate-200 bg-slate-50 px-5 py-4"><h2 className="font-bold">Tổng hợp giá trị</h2></div>
          <div className="space-y-2 p-5 text-sm">
            <MoneyLine label="Cước vận chuyển" value={outputTotals.shippingFee} />
            <MoneyLine label="Tổng tiền đơn hàng" value={outputTotals.orderTotal} strong />
            <MoneyLine label="Chiết khấu (%)" value={outputTotals.discountPercent} percent />
            <MoneyLine label="Số tiền chiết khấu" value={outputTotals.discountAmount} />
            <MoneyLine label="Tổng sau chiết khấu" value={outputTotals.afterDiscount} strong />
            <MoneyLine label="Đặt cọc" value={outputTotals.depositAmount} />
            <MoneyLine label="Trừ tiền nhận hàng tại kho" value={outputTotals.warehouseReceiptDeduction} />
            <MoneyLine label="Thanh toán khi giao hàng" value={outputTotals.paymentDue} strong />
          </div>
        </div>
      </section>

      <section className="erp-card mt-6">
        <div className="border-b border-slate-200 bg-slate-50 px-5 py-4"><h2 className="font-bold">Lịch sử nhập Excel</h2></div>
        <div className="divide-y divide-slate-200">
          {order.imports.length ? order.imports.map((entry) => (
            <div key={entry.id} className="flex flex-col justify-between gap-1 px-5 py-3 text-sm md:flex-row">
              <span>{importAction(entry.action)} · {entry.fileName} · {entry.importedItems} bộ cửa</span>
              <span className="text-slate-500">{formatDateTime(entry.importedAt)}</span>
            </div>
          )) : <div className="p-5 text-sm text-slate-500">Đơn này được tạo trực tiếp, chưa có lịch sử nhập Excel.</div>}
        </div>
      </section>
    </ErpShell>
  );
}

function ReadRow({ lineNo, row, main = false }: { lineNo: number | null; main?: boolean; row: any }) {
  return (
    <tr className={main ? "bg-cyan-50 font-medium" : "hover:bg-slate-50"}>
      <Td>{lineNo ?? ""}</Td><Td>{row.setNo || ""}</Td><Td wide>{row.productName || ""}</Td><Td>{row.productCode || ""}</Td><Td>{row.model || ""}</Td>
      <Td>{row.openingDirection || ""}</Td><Td>{row.trimDirection || ""}</Td><Td>{row.paintColor || ""}</Td><Td>{row.heightMm ?? ""}</Td><Td>{row.widthMm ?? ""}</Td><Td>{row.frameMm ?? ""}</Td>
      <Td>{row.clearHeightMm ?? ""}</Td><Td>{row.clearWidthMm ?? ""}</Td><Td wide>{row.panelInfo || ""}</Td><Td>{row.trimBarsPerSet ?? ""}</Td><Td>{row.trimType || ""}</Td><Td>{row.lockModel || ""}</Td>
      <Td>{row.windowBars || ""}</Td><Td>{row.leavesPerSet ?? ""}</Td><Td>{row.quantity ?? ""}</Td><Td>{row.unit || ""}</Td><Td>{formatNumber(row.pricingQuantity)}</Td><Td>{formatMoney(row.unitPrice)}</Td><Td>{formatMoney(row.amount)}</Td>
      <Td wide>{row.note || ""}</Td><Td>{row.imagePath ? <a className="text-cyan-700 hover:underline" href={row.imagePath} target="_blank">Xem ảnh</a> : ""}</Td><Td>{row.modelCheck || ""}</Td><Td>{row.priceCheck || ""}</Td>
    </tr>
  );
}
function Info({ title, value }: { title: string; value: string }) { return <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm"><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{title}</p><p className="mt-1 font-semibold text-slate-900">{value}</p></div>; }
function InfoPlain({ title, value }: { title: string; value: string }) { return <div><div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{title}</div><div className="mt-1 whitespace-pre-wrap text-sm text-slate-800">{value}</div></div>; }
function Th({ children }: { children: React.ReactNode }) { return <th className="min-w-[110px] border border-slate-300 px-2 py-2 text-left font-semibold first:min-w-[55px]">{children}</th>; }
function Td({ children, wide = false }: { children: React.ReactNode; wide?: boolean }) { return <td className={`border border-slate-200 px-2 py-2 align-top ${wide ? "min-w-[220px]" : "min-w-[90px]"}`}>{children}</td>; }
function MoneyLine({ label, value, strong, percent }: { label: string; value: unknown; strong?: boolean; percent?: boolean }) { return <div className={`flex justify-between gap-4 rounded-lg px-3 py-2 ${strong ? "bg-slate-900 text-white" : "bg-slate-50"}`}><span>{label}</span><span className="font-semibold">{percent ? `${formatNumber(value)} %` : formatMoney(value)}</span></div>; }
function formatDate(value: Date | null) { return value ? new Intl.DateTimeFormat("vi-VN").format(value) : "—"; }
function formatDateTime(value: Date) { return new Intl.DateTimeFormat("vi-VN", { dateStyle: "short", timeStyle: "short" }).format(value); }
function formatNumber(value: unknown) { if (value === null || value === undefined || value === "") return "—"; const n = Number(String(value)); return Number.isFinite(n) ? new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 4 }).format(n) : String(value); }
function formatMoney(value: unknown) { if (value === null || value === undefined || value === "") return "—"; const n = Number(String(value)); return Number.isFinite(n) ? `${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 0 }).format(n)} đ` : String(value); }
function statusLabel(value: string) { return ({ NHAP:"Nháp", CHO_XAC_NHAN:"Chờ khách hàng xác nhận", DA_XAC_NHAN:"Đã xác nhận", CHUYEN_SAN_XUAT:"Đã chuyển sản xuất", HUY:"Đã hủy" } as Record<string,string>)[value] ?? value; }
function importAction(value: string) { return value === "CREATED" ? "Tạo từ Excel" : value === "UPDATED" ? "Cập nhật từ Excel" : value === "REBUILT_DETAILS" ? "Khôi phục chi tiết từ Excel" : value; }
