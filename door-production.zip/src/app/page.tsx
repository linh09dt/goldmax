import Link from "next/link";
import { ErpShell } from "@/components/erp-shell";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [orders, items] = await Promise.all([
    prisma.salesOrder.count(),
    prisma.salesOrderItem.count(),
  ]);

  return (
    <ErpShell title="Tổng quan ERP sản xuất cửa" description="Nền tảng quản lý đơn hàng theo yêu cầu khách hàng và chuẩn bị dữ liệu cho sản xuất.">
      <section className="grid gap-4 md:grid-cols-3">
        <Metric title="Tổng đơn hàng" value={orders.toLocaleString("vi-VN")} />
        <Metric title="Tổng bộ cửa" value={items.toLocaleString("vi-VN")} />
        <Metric title="Cơ sở dữ liệu" value="PostgreSQL 18" />
      </section>
      <section className="mt-6 grid gap-5 xl:grid-cols-2">
        <div className="erp-card p-6">
          <h2 className="text-lg font-bold">Quản lý đơn hàng</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">Tạo đơn mẫu trực tiếp khi làm việc với khách hàng, nhập đầy đủ từng bộ cửa, phụ kiện, phụ phí, yêu cầu công trình và giá trị thanh toán.</p>
          <div className="mt-5 flex gap-2"><Link className="erp-button" href="/orders/new">Tạo đơn hàng</Link><Link className="erp-button-secondary" href="/orders">Danh sách đơn hàng</Link></div>
        </div>
        <div className="erp-card p-6">
          <h2 className="text-lg font-bold">Nhập dữ liệu Excel</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">File Đơn hàng.xlsx tiếp tục được hỗ trợ. Hệ thống đọc cả dòng sản phẩm chính và các dòng chi tiết bên dưới để đưa về cùng cấu trúc dữ liệu ERP.</p>
          <div className="mt-5"><Link className="erp-button-secondary" href="/orders">Mở khu vực nhập Excel</Link></div>
        </div>
      </section>
      <section className="erp-card mt-6 p-6">
        <h2 className="font-bold">Phạm vi hiện tại</h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">Giai đoạn này tập trung vào Đơn hàng. BOM, Routing, Lệnh sản xuất, Kế hoạch, Job Card và QC chưa được tự ý thêm cho đến khi logic đơn hàng được chốt hoàn chỉnh.</p>
      </section>
    </ErpShell>
  );
}

function Metric({ title, value }: { title: string; value: string }) { return <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">{title}</p><p className="mt-2 text-3xl font-bold text-slate-950">{value}</p></div>; }
