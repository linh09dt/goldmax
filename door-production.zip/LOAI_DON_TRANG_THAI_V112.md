# V112 — Nghiệp vụ LOẠI ĐƠN × TRẠNG THÁI (sửa logic Lưu nháp / Lưu đơn hàng)

## Nghiệp vụ đúng (theo yêu cầu)

Trước V112, một ô `status` gộp cả hai khái niệm: `NHAP` vừa nghĩa "Đơn hàng mẫu" vừa nghĩa "chưa vào sản xuất", `CHUYEN_SAN_XUAT` vừa nghĩa "Sản xuất". Nay tách hẳn:

| | Giá trị | Ai quyết định |
|---|---|---|
| **LOẠI ĐƠN** (`order_type`) | `MAU` = Đơn hàng mẫu · `SAN_XUAT` = Sản xuất · `LAM_LAI` = Đơn làm lại | Người dùng **chọn khi tạo đơn** (đổi được khi sửa đơn) |
| **TRẠNG THÁI** (`status`) | `NHAP` = Đơn nháp · `DA_XAC_NHAN` = Đã xác nhận | **Nút bấm khi lưu** |

Luồng lưu:

- **Lưu nháp** → trạng thái **Đơn nháp**, **chưa có Bộ số**.
- **Lưu đơn hàng** → trạng thái **Đã xác nhận**, hệ thống **cấp Bộ số** — áp dụng cho **mọi loại đơn** (mẫu, sản xuất, làm lại).
- Đơn **đã xác nhận** thì không bị hạ cấp về nháp dù bấm Lưu nháp (tránh sửa nhỏ rồi lỡ tay làm mất hiệu lực); Bộ số cũng **không bị cấp lại/đổi số**.
- Mọi loại đơn đều có đủ 2 trạng thái.

## Thay đổi kỹ thuật

**Dữ liệu** — `prisma/schema.prisma` + migration `20260925120000_order_type_v112`:

```sql
ALTER TABLE "sales_orders" ADD COLUMN IF NOT EXISTS "order_type" VARCHAR(30) NOT NULL DEFAULT 'MAU';
UPDATE "sales_orders" SET "status" = 'DA_XAC_NHAN', "order_type" = 'SAN_XUAT'
  WHERE "status" IN ('CHUYEN_SAN_XUAT', 'DA_XAC_NHAN');
UPDATE "sales_orders" SET "status" = 'NHAP', "order_type" = 'MAU' WHERE "status" = 'CHO_XAC_NHAN';
```

Chuyển dữ liệu cũ **giữ nguyên ý nghĩa đang hiển thị**: đơn cũ `CHUYEN_SAN_XUAT` (hiện là "Sản xuất") → loại *Sản xuất* + trạng thái *Đã xác nhận*; đơn cũ `NHAP` (hiện là "Đơn hàng mẫu") → loại *Đơn hàng mẫu* + trạng thái *Đơn nháp*. Chạy lại migration không đổi thêm gì (câu UPDATE idempotent).

**Nghiệp vụ** — `src/lib/order-form.ts`:
- `ORDER_TYPE_OPTIONS` (3 loại) + `orderTypeLabel()` / `normalizeOrderType()`.
- `ORDER_STATUS_OPTIONS` = `Đơn nháp` / `Đã xác nhận`; `isConfirmedStatus()` thay `isProductionStatus()`.
- `statusAfterSave(status, action)`: Lưu đơn hàng → Đã xác nhận; Lưu nháp → Đơn nháp, **không hạ cấp**.
- `showsSetNumber(status)`: chỉ hiện Bộ số khi **Đã xác nhận** (mọi loại đơn).
- `orderStatusLabel()` vẫn quy đổi mã cũ (`CHUYEN_SAN_XUAT` → "Đã xác nhận", `HUY` → "Đã hủy") nên dữ liệu cũ hiển thị đúng.

**Chống hạ cấp & mất Bộ số ở phía server** — `src/app/api/orders/[id]/route.ts`: khi cập nhật, server đọc trạng thái + Bộ số hiện có **trước khi xoá**:
- payload gửi trạng thái nháp nhưng đơn đang Đã xác nhận → giữ Đã xác nhận;
- dòng nào payload không gửi kèm Bộ số → **kế thừa Bộ số cũ theo `lineNo`** (không cấp số mới).

**Giao diện**:
- Form tạo/sửa đơn: thêm ô **Loại đơn** (chọn 3 loại); **Trạng thái** chỉ hiển thị (xanh lá = Đã xác nhận, vàng = Đơn nháp) kèm chú thích 2 nút Lưu.
- Danh sách đơn: 4 chip lọc **theo loại đơn** (Tất cả / Đơn hàng mẫu / Sản xuất / Đơn làm lại) kèm số lượng; mỗi dòng hiện "Loại đơn · Trạng thái". Link cũ `?status=sample|prod` vẫn lọc đúng.
- Chi tiết đơn (trang + cột phải): hiện **Loại đơn** và **Trạng thái**; Bộ số chỉ hiện khi đã xác nhận.
- **Theo dõi doanh thu**: lọc `order_type = 'SAN_XUAT'` **và** `status = 'DA_XAC_NHAN'`; cột "Loại ĐH" lấy đúng trường loại đơn. Như trước, đơn hàng mẫu / đơn làm lại / đơn nháp **không** vào doanh thu.
- Xuất Excel danh sách: thêm cột **Loại đơn hàng** trước cột Trạng thái.
- Trang Hướng dẫn sử dụng + chú thích trong mã: cập nhật theo nghiệp vụ mới.

## Kiểm chứng (Postgres 14 thật + chạy app thật)

**a) Chuyển dữ liệu cũ:** DB test có sẵn 6 đơn `CHUYEN_SAN_XUAT` + 3 đơn `NHAP` → sau migration: `DA_XAC_NHAN/SAN_XUAT` = 6, `NHAP/MAU` = 3 (không mất đơn nào).

**b) API — 18/18 kiểm tra đạt** (gọi thẳng route handler):

```
OK  Lưu nháp (Đơn hàng mẫu) → Đơn nháp, KHÔNG có Bộ số
OK  Lưu nháp (Sản xuất)     → Đơn nháp, KHÔNG có Bộ số
OK  Lưu nháp (Đơn làm lại)  → Đơn nháp, KHÔNG có Bộ số
OK  Xác nhận đơn hàng mẫu   → Đã xác nhận + Bộ số 12036, 12037
OK  Xác nhận đơn Sản xuất   → Đã xác nhận + Bộ số 12038, 12039
OK  Xác nhận đơn làm lại    → Đã xác nhận + Bộ số 12040, 12041
OK  Lưu nháp trên đơn đã xác nhận → vẫn Đã xác nhận, Bộ số giữ nguyên 12040, 12041
OK  statusAfterSave: nháp→nháp, nháp→đã xác nhận, đã xác nhận→không hạ cấp
OK  Lọc "Đơn làm lại" chỉ ra đơn LAM_LAI; link cũ ?status=prod vẫn ra đúng Sản xuất
OK  Doanh thu: có đơn Sản xuất đã xác nhận; KHÔNG có đơn hàng mẫu (dù đã xác nhận); KHÔNG có đơn làm lại
```

**c) Giao diện (chạy `next start` trên DB test):**
- Form tạo đơn: ô **Loại đơn** có đủ 3 lựa chọn; **Trạng thái** = "Đơn nháp".
- Danh sách: chip `Tất cả 15 · Đơn hàng mẫu 5 · Sản xuất 8 · Đơn làm lại 2`; dòng đơn hiện "Đơn làm lại · Đã xác nhận".
- Chi tiết đơn #16: `LOẠI ĐƠN = Đơn làm lại`, `TRẠNG THÁI = Đã xác nhận`, có `Bộ số 12040`, `Bộ số 12041`.
- Trang doanh thu: đúng **8** dòng "Sản xuất" (bằng số đơn Sản xuất đã xác nhận trong DB), không có dòng Đơn hàng mẫu / Đơn làm lại.
- Xuất Excel danh sách: có tiêu đề **Loại đơn hàng** + **Trạng thái**; lọc `?type=lam_lai` ra đúng đơn làm lại.
- Ảnh: `v112-loai-don-trang-thai.png`.

**d) Mã:** `npx tsc --noEmit` 0 lỗi · `npx eslint` các file sửa → không phát sinh lỗi mới · `npm run build` → **Compiled successfully**.

## Cách áp dụng

1. Giải nén đè lên repo (gồm cả `prisma/schema.prisma` và thư mục migration mới).
2. Chạy migration lên DB: `npx prisma migrate deploy` (hoặc quy trình migrate hiện tại của bạn).
3. `npm run build` + deploy lại.

## Lưu ý / cần bạn xác nhận

- **Đơn nhập từ Excel** (`/api/orders/import`) hiện vào với trạng thái **Đơn nháp** + loại mặc định **Đơn hàng mẫu** — giống hệt cách hiển thị trước V112 (trước đây đơn import cũng là `NHAP` = "Đơn hàng mẫu"). Nếu muốn đơn nhập từ file mặc định là **Sản xuất**, nói mình đổi 1 dòng.
- **Đơn đã hủy** (`HUY`) của dữ liệu cũ giữ nguyên trạng thái "Đã hủy" (không nằm trong 2 trạng thái mới, không vào doanh thu). Nếu muốn bỏ hẳn hoặc thêm trạng thái "Đã hủy" chính thức thì nói.
- **Doanh thu** hiện chỉ tính đơn *Sản xuất + Đã xác nhận*. Nếu "Đơn làm lại" cần xuất hiện trong doanh thu (hoặc có báo cáo riêng) thì báo mình.

## File thay đổi

- `prisma/schema.prisma` + `prisma/migrations/20260925120000_order_type_v112/migration.sql` — **mới**: cột `order_type` + chuyển dữ liệu.
- `src/lib/order-form.ts` — hằng số/nhãn/hàm nghiệp vụ loại đơn & trạng thái.
- `src/lib/order-persistence.ts` — nhận & chuẩn hoá `orderType`, quy mã trạng thái cũ.
- `src/app/api/orders/[id]/route.ts` — chống hạ cấp + giữ Bộ số phía server.
- `src/components/order-form.tsx` — ô Loại đơn, nhãn trạng thái, chú thích nút Lưu.
- `src/lib/order-list-filters.ts`, `src/components/order-list/order-list-pane.tsx`, `order-detail-pane.tsx`, `order-filter-bar.tsx`, `src/app/orders/page.tsx` — lọc/hiện theo loại đơn.
- `src/app/orders/[id]/page.tsx`, `src/app/orders/[id]/edit/page.tsx` — hiện & nạp loại đơn.
- `src/app/revenue/page.tsx`, `src/app/api/revenue/export/route.ts` — doanh thu theo loại đơn + đã xác nhận.
- `src/app/api/orders/export-list/route.ts` — thêm cột Loại đơn hàng.
- `src/lib/customers.ts`, `src/components/customer-directory.tsx` — sổ khách hàng hiện loại đơn + trạng thái.
- `src/lib/set-number.ts`, `src/app/guide/page.tsx`, `src/lib/order-input-template.ts` — chú thích/nghiệp vụ theo V112.


## V112b — Thu gọn hàng "Thông tin đơn hàng" cho vừa 1 hàng

**Hiện tượng:** thêm ô **Loại đơn** nhưng lưới vẫn 13 cột (thiết kế cũ), nên ô **Số Km** bị đẩy xuống hàng 2 — đúng như ảnh bạn gửi.

**Cách sửa** (`src/components/order-form.tsx`, lưới `xl:grid-cols-[…]`):

| Ô | Trước | Sau | Ghi chú |
|---|---|---|---|
| Loại đơn | 12,4fr (rộng nhất hàng, thừa hưởng cột của ô Trạng thái cũ) | **6,2fr** | **giảm 50%** đúng yêu cầu |
| Số Km | không có cột → rớt xuống hàng 2, chiếm 8fr | **3,2fr** | **giảm 60%** đúng yêu cầu |
| Các ô còn lại | giữ nguyên tỉ lệ | giữ nguyên | không đụng tới |

Dùng `minmax(84px,6.2fr)` cho Loại đơn và `minmax(38px,3.2fr)` cho Số Km để màn hẹp không cắt mất chữ.

**Kiểm chứng (đo trong trình duyệt thật):**

```
Màn hẹp 1280px: 14 ô / 1 hàng | Loại đơn 84px (chạm mức tối thiểu), Số Km 38px
Màn rộng (~1940px, quy đổi): Loại đơn 204px → 102px = −50% | Số Km 132px → 53px = −60%
  tỉ lệ so với ô tham chiếu: Loại đơn/Trạng thái = 0,91 (thiết kế 6,2/6,8) ✓
                             Số Km/Vùng miền     = 1,03 (thiết kế 3,2/3,1) ✓
  14 ô vẫn nằm đúng 1 hàng ✓
```

Ảnh: `v112b-hang-thong-tin.png`.


## V112c — Thu nhỏ ô Số điện thoại, mở rộng ô Loại đơn, hết xuống dòng ở chi tiết đơn

**Yêu cầu:** thu nhỏ ô Số điện thoại · mở rộng ô Loại đơn cho hiện đủ chữ · "tab chi tiết đơn bị xuống dòng".

**Chỗ xuống dòng ở chi tiết đơn:** trang `/orders/[id]` có **lưới riêng 13 cột** (khác lưới của form, V112b chỉ sửa form) → ô thứ 14 là **Số Km** rớt xuống hàng 2. Đã đổi thành 14 cột.

**Số đo lại (chiều rộng cột, đơn vị fr):**

| Ô | V112b | V112c | Ghi chú |
|---|---|---|---|
| **Loại đơn** (form) | `minmax(84px, 6,2fr)` | **`minmax(118px, 10,2fr)`** | rộng ra, đủ chỗ chữ "Đơn hàng mẫu" |
| **Số điện thoại** (form) | `11,4fr` | **`minmax(88px, 7,4fr)`** | thu nhỏ, vẫn đủ 10–11 số |
| Trang chi tiết đơn | 13 cột (Số Km xuống hàng) | **14 cột** | Loại đơn 0,88fr → 1,12fr; SĐT 1,42fr → 0,95fr |
| Cột chi tiết (pane phải) | 2 nhãn có thể xuống dòng | nhãn **không xuống dòng** (mã đơn co lại) | `flex-wrap` → giữ 1 hàng + `whitespace-nowrap` |

**Kiểm chứng (đo trong trình duyệt thật, màn 1280px — hẹp hơn màn bạn dùng):**

```
Form tạo đơn : 14 ô / 1 hàng ✓ | Loại đơn = 118px (cần 115px cho "Đơn hàng mẫu" → KHÔNG bị cắt)
                                 Số điện thoại = 88px (trước 102px)
Chi tiết đơn : 14 ô / 1 hàng ✓ (trước: 13 ô + Số Km rớt xuống hàng 2)
Cột chi tiết : nhãn "Đơn làm lại" + "Đã xác nhận" nằm cùng 1 hàng ✓
```

Ảnh: `v112c-2-hang-thong-tin.png`.
