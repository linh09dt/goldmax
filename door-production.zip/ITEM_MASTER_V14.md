# ERP V14 - Làm lại Master Data Danh mục hàng hóa

## Logic đã chốt

- Nguồn chuẩn: file `danh muc hang hoa.xlsx`.
- Danh mục hàng hóa chỉ lấy **TENHANG + MODEL**.
- Nếu file có nhiều cặp TENHANG/MODEL, dùng cặp ngoài cùng bên phải (file hiện tại là **K/L**).
- Toàn bộ Danh mục hàng hóa cũ được xóa khi người dùng xác nhận **Tạo lại Master Data từ Excel**.
- Đơn hàng hiện có được giữ nguyên.
- Chưa nhập **ĐVT** và **Giá đại lý**. Hai trường này được để trống để cấu hình ở giai đoạn sau.
- Khi tạo lại từ file hiện tại: 86 MODEL duy nhất.
- `salesName/salesModel` được đồng bộ bằng chính `TENHANG/MODEL`, nên xuất Excel/PDF dùng cùng Master Data.

## Cách cập nhật

Chép patch chồng lên V13/V12 hiện tại và chạy:

```cmd
rmdir /s /q .next
npm run dev
```

Không cần migrate database vì V14 không thay đổi schema.

Vào `/items` → chọn **Tạo lại Master Data từ Excel** → chọn file `danh muc hang hoa.xlsx` → xác nhận reset.
