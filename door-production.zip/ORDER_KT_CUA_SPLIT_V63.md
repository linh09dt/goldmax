# ORDER KT CỬA SPLIT V63

## Mục tiêu
Trong file xuất, cột **“KT CỬA (MM)”** (đang gộp kiểu `3195 x 2730`) **tách thành 2 cột riêng: Cao và Rộng**.

## Kết quả
| Trước | Sau |
|---|---|
| 1 cột `KT CỬA (CAO x RỘNG)` = `3195 x 2730`; dòng chi tiết chỉ có 1 số (3195 hoặc 2730) | Nhóm **`KT CỬA (MM)`** gồm 2 cột **CAO** (3195) và **RỘNG** (2730) — giống cách nhóm `KT THÔNG THỦY` đang làm |

## File sửa
1. `python/reportlab_order_v2.py` — `_data_table`:
   - `header_top` thêm 1 ô: `KT CỬA (MM)` + ô trống để `SPAN (8,0)-(9,0)`; `header_sub` thêm `CAO` (cột 8) và `RỘNG` (cột 9).
   - Dòng dữ liệu: bỏ `size_text` (`"h x w"`), ghi **2 ô riêng** `heightMm` và `widthMm`.
   - `base_widths_mm`: 19 → **20 cột** (tách 19mm thành 9.5 + 9.5); `SPAN` cho các cột đơn đổi thành `range(0,8) + [10] + range(13,20)`; padding cột Ghi chú/Hình ảnh 17,18 → 18,19.
2. `src/lib/order-export-v2.ts` — sheet thành **20 cột (A→T)**:
   - Bề rộng: 19 → 20 giá trị (cột KT CỬA 14.5 → 7.5 + 7.5).
   - Header: `["I12:J12","KT CỬA (MM)"]`, `I13="CAO"`, `J13="RỘNG"`; KHUÔN → K; KT THÔNG THỦY → L:M; SL…HÌNH ẢNH → N…T.
   - Dòng dữ liệu: tách `sizeText` thành 2 ô (`heightMm` ở I, `widthMm` ở J); các điều kiện canh phải/in đậm/numFmt/cột ghi chú/cột ảnh dịch theo (+1).
   - Dịch toàn bộ dải cột phía sau: banner (`D1:L1`, `M1:T2`, `M3:T3`), vùng thông tin (`I9:O9`, `P9:T9`, …), tổng kết (`A:Q` + `R:T`, số tiền ghi vào ô **R**), “Bằng chữ” và hộp ghi chú (`A:T`), `printArea = A1:T…`.

## Không thay đổi
- Dữ liệu/công thức, các cột khác (KHUÔN, KT THÔNG THỦY Cao/Rộng, SL, ĐVT, KHỐI LƯỢNG, ĐƠN GIÁ, THÀNH TIỀN, GHI CHÚ, HÌNH ẢNH), hộp tiền và hộp ghi chú.
- **PDF preview** (`reportlab_order_preview.py`) là template báo giá khác, gộp kích thước trong 1 ô — không thuộc phạm vi yêu cầu nên giữ nguyên.

## Kiểm chứng thực tế
- **PDF**: xuất thật qua CLI với đơn mẫu (Cửa 3195×2730 + Phào cao 3195 + Ô thoáng rộng 2730) → header `KT CỬA (MM) | CAO | RỘNG`; dòng cửa có Cao 3195 / Rộng 2730; dòng phào chỉ Cao 3195; dòng ô thoáng chỉ Rộng 2730. Ảnh: `pdf_kt_cua_split.png`.
- **Excel**: dựng file rồi **đọc lại từng ô**:
  - `I12:J12 = "KT CỬA (MM)"`, `I13 = "CAO"`, `J13 = "RỘNG"`, `K12:K13 = "KHUÔN"`, `L12:M12 = "KT THÔNG THỦY"`, `N…T` đúng nhãn;
  - dòng cửa `I=3195`, `J=2730`, `K=240`; dòng phào `I=3195`, `J=rỗng`; dòng ô thoáng `I=rỗng`, `J=2730`;
  - tổng kết: nhãn ở A (merge `A:Q`), số tiền ở **R** (merge `R:T`); `printArea = A1:T32`.
  - Convert sang PDF bằng LibreOffice: **1 trang**, cột CAO/RỘNG hiển thị đúng. Ảnh: `excel_kt_cua_split.png`.
- `npx tsc --noEmit`: pass · `npx eslint src/lib/order-export-v2.ts`: đúng 7 lỗi `no-explicit-any` có sẵn từ trước · `python -m py_compile`: OK.
