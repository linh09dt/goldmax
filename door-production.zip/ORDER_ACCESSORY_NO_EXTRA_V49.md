# ORDER ACCESSORY NO EXTRA V49

## Mục tiêu
Bỏ mục **“Thông số thêm”** ở dòng **PHỤ KIỆN / CHI TIẾT CỦA BỘ CỬA** trong tab Tạo đơn hàng / Sửa đơn hàng.

## Thay đổi
- `src/components/order-form.tsx`
  - Xóa toàn bộ khối `<details>` có tiêu đề **“Thông số thêm”** trong component `DetailMasterRow` (dòng phụ kiện / chi tiết của bộ cửa).
  - Dòng phụ kiện giờ chỉ còn lưới nhập liệu chính: Nhóm hàng, Model, Cao, Rộng, Khuôn, ĐVT, KH/Lượng, Đơn giá, Thành tiền, Ghi chú + nút **Xóa** (căn phải).
  - Bỏ các prop không còn dùng của `DetailMasterRow`: `optionValues`, `onUpload`.
  - Card **Bộ cửa** không đổi: vẫn giữ nguyên khối Ghi chú + Hình ảnh SP và toàn bộ trường thông số của bộ cửa.
- `src/app/guide/page.tsx`
  - Bỏ dòng mô tả “Thông số thêm” trong bảng thao tác; cập nhật Bước 4 cho khớp giao diện mới.

## Không thay đổi
- DB, Prisma schema, migration.
- API, import/export Excel, PDF, cấu hình KH/Lượng, công thức Thành tiền, tổng tiền đơn hàng.
- Các trường dữ liệu cũ của dòng phụ kiện (Bộ số, Ô thoáng, Hướng mở, Phào, Màu sơn, KT thông thủy, Số thanh phào, Loại phào, Model khóa, Số nan ô thoáng, Số cánh, SL, ảnh) vẫn được lưu và xuất như trước — chỉ không còn ô nhập trên giao diện dòng phụ kiện.

## Kiểm tra
- `npx tsc --noEmit`: pass.
- `npx eslint`: không phát sinh lỗi/cảnh báo mới so với bản gốc.
- Chạy `next dev`, mở `/orders/new`, bấm “+ Thêm phụ kiện”: không còn chữ “Thông số thêm”, dòng phụ kiện hiển thị đủ cột và nút Xóa hoạt động.
