# ORDER ACCESSORY DELETE INLINE V50

## Mục tiêu
Đưa nút **Xóa** của dòng **PHỤ KIỆN / CHI TIẾT CỦA BỘ CỬA** lên nằm cùng dòng, ngay bên phải ô **Ghi chú**, để các cột thẳng hàng và mỗi dòng gọn hơn (bỏ dòng phụ bên dưới).

## Thay đổi
- `src/components/order-form.tsx` — `DetailMasterRow`:
  - Ô **Ghi chú** giờ chứa cả ô nhập và nút **Xóa**: `<div className="flex min-w-0 items-center gap-1">` → ô nhập `flex-1 min-w-0` + nút Xóa `h-8 shrink-0`.
  - Nút Xóa đổi sang dạng viền đỏ nhạt (`border-red-200 bg-white text-red-600 hover:bg-red-50`) để không lấn át các ô nhập, cao đúng 32px bằng các ô khác.
  - Bỏ hẳn khối `<div className="mt-1.5 flex ... justify-end">` chứa nút Xóa ở dưới mỗi dòng.

## Kết quả kiểm tra (dev server, 3 dòng phụ kiện)
- Vị trí cột (px, trái) giống hệt nhau ở cả 3 dòng: 315 · 478 · 641 · 735 · 829 · 923 · 1019 · 1128 · 1247 · 1373 → các cột thẳng hàng.
- Nút Xóa cùng dòng với ô Ghi chú (lệch top 0px), cách ô nhập 4px, nằm sát phải.
- Mỗi dòng chỉ còn 1 hàng nội dung (không còn hàng phụ chứa nút Xóa) → chiều cao mỗi dòng giảm.

## Không thay đổi
- Danh sách cột, công thức **Thành tiền**, KH/Lượng tự động, DB/API/Excel/PDF.
- `npx tsc --noEmit`: pass. `npx eslint`: không phát sinh lỗi/cảnh báo mới.

> Ghi chú: V50 thay thế chi tiết “nút Xóa căn phải ở dòng dưới” đã ghi trong `ORDER_ACCESSORY_NO_EXTRA_V49.md`; phần xóa “Thông số thêm” của V49 vẫn giữ nguyên.
