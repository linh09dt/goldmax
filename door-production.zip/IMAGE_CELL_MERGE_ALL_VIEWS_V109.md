# V109 — Gộp ô “Ảnh SP” theo BỘ CỬA ở TẤT CẢ các chỗ: xem, in, xuất file

## Yêu cầu

> “áp dụng cho như chức năng xuất files, các bảng view quản lý đơn hàng, view chi tiết đơn hàng, view sửa đơn hàng”
> *(nối tiếp V108 — cột Ảnh SP ở cột phải tab Quản lý đơn hàng)*

**Quy tắc chung đã áp dụng ở mọi nơi:** **1 ô ảnh cho cả BỘ CỬA** (dòng cửa + tất cả dòng phụ kiện / chi tiết), ảnh canh giữa ô, dòng phụ kiện **không** có ô ảnh riêng. Ảnh hiển thị: **ưu tiên ảnh dòng cửa**, chưa có thì **lấy ảnh phụ kiện đầu tiên có ảnh**.

| # | Chỗ | Trước | Sau (V109) |
|---|---|---|---|
| 1 | **View quản lý đơn hàng** — cột phải `/orders` | chưa có cột ảnh | 13 cột, ô ảnh `rowSpan = 1 + số phụ kiện` *(đã làm ở V108)* |
| 2 | **View chi tiết đơn hàng** — `/orders/[id]` | mỗi dòng 1 ô ảnh | ô ảnh `rowSpan` trải từ dòng cửa → hết phụ kiện (đi qua cả hàng “↳ Chi tiết / phụ kiện”; hàng này thu 19 → 18 cột để nhường chỗ) |
| 3 | **Trang in web** — `/orders/[id]/print` | mỗi dòng 1 ô ảnh | ô ảnh `rowSpan` theo bộ, canh giữa theo chiều dọc (`vertical-align: middle`) |
| 4 | **Xuất Excel V2** — `order-export-v2.ts` (cột `S`) | mỗi dòng 1 ảnh | merge `S{đầu}:S{cuối}` cho mỗi bộ + **chỉ nhúng 1 ảnh** cho cả bộ, canh giữa khối |
| 5 | **Xuất Excel V1** — `order-export.ts` (cột `T`) | mỗi dòng 1 ảnh | merge `T{đầu}:T{cuối}` + **1 ảnh** cho cả bộ, canh giữa khối |
| 6 | **Xuất PDF** — `python/reportlab_order_v2.py` | mỗi dòng 1 ô ảnh | `SPAN` cột ẢNH SP theo bộ + ảnh chỉ in ở dòng đầu bộ, **canh giữa ô merge** (`VALIGN MIDDLE`) |
| 7 | **View sửa đơn hàng** — `order-form.tsx` (card “Bộ cửa”) | đã là 1 ô ảnh cho cả bộ (phụ kiện không có ô ảnh) | ghi rõ nhãn **“Hình ảnh SP (cả bộ cửa)”** + dòng giải thích “Ảnh dùng cho cả bộ cửa này (gồm mọi phụ kiện / chi tiết bên dưới)” |
| 8 | **PDF mẫu (preview)** — `reportlab_order_preview.py` | **đã gộp sẵn từ trước** (`SPAN` cột 9 theo bộ, ô đầu bộ hiện cả cụm ảnh) | giữ nguyên |

## Kiểm chứng (chạy thật — không đoán)

**a) View chi tiết đơn hàng — 6/6:** `rowSpan = 5` cho bộ 1 (1 cửa + 1 hàng phân cách + 3 phụ kiện), hàng “↳ Chi tiết” còn 18 cột, bộ 2 (không ảnh) vẫn có ô merge `rowSpan = 3` nhưng trống, hàng ghi chú kỹ thuật vẫn trải 19 cột. Đo trong trình duyệt: ô merge cao **169px** đúng bằng cả khối bộ cửa, có ảnh.

**b) Trang in web — 5/5:** 2 ô ảnh cho 2 bộ, `span = 4` và `span = 2` (đúng số dòng mỗi bộ), bộ 1 có ảnh, bộ 2 để trống, phụ kiện không còn ô ảnh riêng.

**c) Excel V1 + V2 — 8/8** (mở lại file bằng ExcelJS để soi):
```
Excel V2: merge cột ảnh = S14:S16, S18:S19  |  số ảnh trong file = 2 (1 logo + 1 ảnh sản phẩm)
Excel V1: merge cột ảnh = T8:T10, T11:T12   |  số ảnh trong file = 2
```
→ đúng 2 ô ảnh cho 2 bộ (không phải mỗi dòng), khối ảnh trải 3 dòng và 2 dòng, ô ảnh đã nhúng ảnh (không còn chữ “Xem ảnh”).

**d) PDF V2 — 4/4:** soi trực tiếp lệnh SPAN của bảng:
```
SPAN cột ẢNH SP (cột 18): (18,0)-(18,1)  ← hàng tiêu đề
                          (18,2)-(18,4)  ← bộ 1 (3 dòng hàng)
                          (18,6)-(18,7)  ← bộ 2 (2 dòng hàng)
```
→ không còn SPAN lẻ cho từng dòng. PDF thật sinh ra 150KB, **nhúng 1 ảnh sản phẩm** (đã qua Pillow thu nhỏ 240×168), và so sánh ảnh render **có ảnh / không ảnh** cho thấy ảnh nằm đúng trong ô merge và **canh giữa** khối (tâm ảnh ≈ tâm khối bộ cửa).

**e) Ảnh chụp chứng cứ:** `order-view-image-merge-v109.png` (view chi tiết + trang in), `pdf-image-merge-v109.png` (cắt từ PDF thật), `order-pane-image-merge-v108.png` (cột phải tab quản lý).

**g) `npm run build` → PASS** (“Compiled successfully”), `npx tsc --noEmit` → 0 lỗi, `npx eslint` các file đã sửa → **không phát sinh lỗi/cảnh báo mới**:
- `order-detail-pane.tsx` 0/0 (có thêm 1 dòng tắt cảnh báo `no-img-element` vì ảnh SP là URL ngoài),
- `orders/[id]/page.tsx` 3/1 (đúng bằng bản gốc), `print/page.tsx` **2/2** (bản gốc 3/2 — bớt 1 lỗi do dọn hàm cũ không còn dùng), `order-export.ts` + `order-export-v2.ts` 14/0 (đúng bằng bản gốc), `order-form.tsx` 4/11 (đúng bằng bản gốc).

## Lưu ý

- **Không cần migration DB**, không đổi dữ liệu. Ảnh vẫn là `sales_order_items.image_path` / `sales_order_item_details.image_path`; hệ thống vẫn đọc được ảnh của dòng phụ kiện (dùng làm ảnh dự phòng khi bộ cửa chưa có ảnh).
- **Trong view sửa đơn**, vì mỗi bộ cửa chỉ còn **một** ô ảnh nên không đặt ảnh riêng cho từng phụ kiện nữa. Nếu sau này cần nhiều ảnh cho 1 bộ (nhiều góc chụp) thì nói, mình làm dạng “nhiều ảnh” (cần thêm cột/bảng lưu).
- Ảnh trong Excel được **nhúng thật** khi máy chủ tải được URL ảnh (Supabase Storage hoặc `/uploads/...`); nếu không tải được thì ô vẫn giữ **hyperlink “Xem ảnh”** như trước.
- File `order-form.tsx` còn **2 component cũ không dùng** (`EditableMainRow`, `EditableDetailRow` — bản bảng sửa đơn ngày trước, mỗi dòng có ô ảnh riêng). Hiện không được gọi ở đâu; mình giữ nguyên cho an toàn, muốn dọn thì nói.

## File thay đổi

- `src/app/orders/[id]/page.tsx` — gộp ô ảnh theo bộ cửa (rowSpan + hàm `setImageOf`).
- `src/app/orders/[id]/print/page.tsx` — gộp ô ảnh theo bộ cửa (hàm `groupImagePath`).
- `src/lib/order-export-v2.ts` — merge cột `S` theo bộ + 1 ảnh/bộ (hàm `writeGroupImage`).
- `src/lib/order-export.ts` — merge cột `T` theo bộ + 1 ảnh/bộ (hàm `writeGroupImageV1`).
- `python/reportlab_order_v2.py` — `SPAN` cột Ảnh SP theo bộ, ảnh ở dòng đầu bộ, canh giữa ô merge.
- `src/components/order-form.tsx` — nhãn rõ “Hình ảnh SP (cả bộ cửa)” + dòng giải thích.
- `src/app/globals.css` — `.order-print-table td.product-image` canh giữa theo chiều dọc (cho ô merge ở trang in).
- `src/components/order-list/order-detail-pane.tsx` — (V108) cột Ảnh SP + merge theo bộ cửa.
