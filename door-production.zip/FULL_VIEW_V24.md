# ERP V24 — Full view bảng đơn hàng

- Bỏ thanh cuộn ngang ở bảng Tạo/Sửa đơn hàng.
- Bảng tự co theo 100% chiều rộng màn hình bằng `table-layout: fixed`.
- Phân bổ lại độ rộng 21 cột theo tỷ lệ để vẫn giữ đủ toàn bộ cột.
- Giảm padding/font trong ô nhập, Đơn giá và Hình ảnh SP để không làm bảng tràn ngang.
- Trang Chi tiết đơn hàng cũng dùng cùng chế độ full view, không cần kéo ngang.
- Không thay đổi logic nhập Excel, Master Data, giá, chiết khấu, ảnh, lưu đơn hoặc xuất Excel/PDF.

## Cập nhật

Chép patch chồng lên bản hiện tại rồi chạy:

```cmd
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần migrate database.
