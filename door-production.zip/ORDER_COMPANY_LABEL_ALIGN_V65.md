# ORDER COMPANY LABEL ALIGN V65

## Yêu cầu
Trong khối thông tin công ty ở header file xuất: **căn các chuỗi phía sau dấu `:` cho thẳng hàng** (nhãn so le — giá trị thẳng một cột dọc).

```
GPĐKKD Số:        2401031714
VP Miền Bắc:      Số 670 Toàn Thắng - Xã Thuận An - TP. Hà Nội
VP Miền Nam:      A34 Shophouse Phú Mỹ Hiệp - TP. Hồ Chí Minh
NHÀ MÁY SẢN XUẤT: Cụm CN Non Sáo, Xã Tân Dĩnh, Bắc Ninh
Hotline:          1900 8135
Email:            Goldmaxdoor@gmail.com
```

## Cách làm

### PDF (V2 + bản preview)
- Tách mỗi dòng thành cặp `(nhãn, giá trị)` theo dấu `:` đầu tiên (`company_line_pairs()`), rồi dựng **bảng 2 cột** thay cho 1 đoạn văn nhiều dòng:
  - cột 1 = nhãn (rộng = nhãn dài nhất + 4pt hở), cột 2 = giá trị → **mọi giá trị bắt đầu cùng một mốc `x`**.
  - padding 0, `VALIGN TOP`, mỗi dòng cao = `leading` (= 1.16 × cỡ chữ) nên **nhịp dòng vẫn đều**.
- Giữ nguyên hàm auto-fit: nếu `nhãn dài nhất + hở + giá trị dài nhất` vượt bề rộng cột thì thu nhỏ cỡ chữ (sàn 6.4pt PDF V2 / 5.5pt preview) → không bao giờ xuống hàng.
- Thêm `from reportlab.pdfbase import pdfmetrics` cho module preview (trước đây chưa import).

### Excel V2
- Mỗi dòng thông tin tách thành 2 ô: **nhãn ở `D:E`**, **giá trị ở `F:L`** (mỗi vùng 1 merge) → giá trị thẳng cột theo mốc cột F, nhãn vẫn thẳng lề trái cột D.
- Bề rộng đủ chỗ: `D:E` ≈ 25 ký tự (nhãn dài nhất "NHÀ MÁY SẢN XUẤT:" = 17), `F:L` ≈ 58 ký tự (giá trị dài nhất 42) — cỡ chữ giữ 9.8pt.

## Lỗi cũ phát hiện thêm khi làm (đã sửa luôn)
Hai ô ở cột phải được ghi vào `L1` / `L3`, mà `L1` nằm trong merge `D1:L1` và `L3` nằm trong merge `D3:L3` → khi lưu file, giá trị ô gốc bị ghi đè:
- **Tên công ty** (`D1`) bị thay bằng "THÔNG TIN ĐƠN HÀNG";
- **Dòng "VP Miền Bắc: …"** bị thay bằng "Mã ĐH: …".

Kiểm chứng trên bản Excel V63 render ra PDF: header chỉ còn 5/6 dòng thông tin và **mất hẳn tên công ty**. Đã sửa: ghi vào **ô gốc của vùng merge** `M1` (tiêu đề) và `M3` (mã ĐH) — đúng vùng `M1:T2` / `M3:T3` vốn đã tạo sẵn cho 2 nội dung này.

## Kiểm chứng
- **PDF V2**: trích text toạ độ → nhãn cùng `x0 = 109.5`, **6/6 giá trị cùng `x0 = 200.6`**; nhịp dòng `y = 532.3 / 521.9 / 511.4 / 501.0 / 490.5 / 480.1` → chênh **đúng 10.4pt** mỗi dòng.
- **Preview PDF**: nhãn `x0 = 108.0`, giá trị cùng `x0 = 222.3`; dựng file OK (65.8 KB) không lỗi.
- **Excel V2**: render qua LibreOffice → nhãn cùng `x0 = 145.6`, **6/6 giá trị cùng `x0 = 237.6`**; đủ 7 mục header (tên công ty + 6 dòng); tiêu đề về đúng block phải `x = 696.2…825.8`; dòng cao đều 18.
- `npx tsc --noEmit`: 0 lỗi. `npx eslint src/lib/order-export-v2.ts`: 7 lỗi `no-explicit-any` **có sẵn từ bản gốc**, không phát sinh lỗi mới.
- `py_compile` cho cả 2 module Python: OK.

## File thay đổi
- `python/reportlab_order_v2.py`
- `python/reportlab_order_preview.py`
- `src/lib/order-export-v2.ts`
