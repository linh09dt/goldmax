# V124 — Câu hỏi đã đủ để phát triển module Kế hoạch sản xuất chưa?

**Trả lời ngắn:** **Đủ phần nghiệp vụ** (nhà máy xác nhận) — nhưng **chưa đủ nếu chỉ có vậy**. Còn 3 nhóm việc:

| Nhóm | Nội dung | Ai làm |
|---|---|---|
| **A** | 14 nhóm câu hỏi đã phủ hết sự thật nghiệp vụ cần cho dữ liệu & thuật toán | Nhà máy trả lời (đang có trong V122/V123) |
| **B** | **11 quyết định sản phẩm/kỹ thuật** mà nhà máy KHÔNG thể trả lời | **Bạn quyết** (mình đã ghi đề xuất cho từng cái) |
| **C** | **12 câu hỏi còn lỗ hổng** cần bổ sung vào phiếu | Bổ sung khi đi hỏi |

**File giao:** `artifacts/doi-chieu-cau-hoi-va-thiet-ke-v124.docx` (+ `.pdf`, 3 trang) — tài liệu **nội bộ**, không gửi nhà máy.

---

## A. Đối chiếu câu hỏi → quyết định thiết kế → dùng vào đâu trong app

| Nhóm câu | Chốt được gì | Dùng vào đâu | Mặc định nếu chưa trả lời |
|---|---|---|---|
| A1 · CH5 · F7 | Quy tắc “đầy đủ đơn” | Bảng quy tắc chuyển công đoạn + lý do đang chờ | Cho đẩy **từng bộ** |
| A2 · D1 · KH9 | Đơn vị thời gian · ca làm việc | Quy đổi ngày làm việc ↔ ngày lịch; cột ngày KH | Ngày làm việc T2–T6 |
| A3 · EP* · LK* · KHO2 | Thời lượng ép cánh, lắp kính+PK, đóng gói, mài ba via | Danh mục công đoạn → tính ngày xong dự kiến | 1 · 1 · 1 · 0,5 ngày |
| A4 · E1–E7 | Năng lực tổ, máy & khuôn, nút thắt | Bảng năng lực → cảnh báo quá tải | Để trống (không cảnh báo) |
| A5 · BL1–BL9 | Bồi Lares = nạp chương trình máy cắt | Bảng chương trình · loại CHUẨN BỊ · **chặn trước Cắt** | Theo **model**, ≈0 nếu đã có |
| A6 · KH1–KH4 | Cách lên kế hoạch hiện nay + căn cứ ưu tiên | **Màn hình chính** + thuật toán sắp xếp | Màn tuần; ưu tiên EDD |
| B1–B8 | Đơn vị = bộ · đơn nào vào · **điều kiện đủ** · mốc hạn giao | Bảng công việc (1 dòng/bộ) · bộ lọc · cảnh báo vàng | Sản xuất + Đã xác nhận |
| C1–C10 | Danh mục công đoạn · song song/ghép bộ · QC · thuê ngoài · routing | Danh mục công đoạn · luồng làm lại | Thêm mài ba via + lắp kính+PK |
| D2–D9 | Định mức thời gian + thời gian chờ | Tính ngày xong · chặn xếp sát khi chưa khô | Theo bảng gốc + chờ 1 ngày |
| F1–F12 | Ưu tiên · chen gấp · gom lô · ngoại lệ · mùa vụ | Thuật toán xếp lịch · gợi ý gom lô · lý do trễ | EDD · không giới hạn lô |
| G1–G10 | Ai nhập ở đâu/mức nào · in phiếu lệnh · cảnh báo · báo cáo | Màn cập nhật · mẫu in · bảng cảnh báo | 1 người nhập, mức BỘ |
| H | 17 trường dữ liệu cần thêm | **Nội dung file migration** | Làm hết ở mức cơ bản |
| I | Trường đang có, xưởng có dùng không | Giữ/bỏ trên phiếu lệnh + màn xưởng | Giữ nguyên |
| J | Giá trị mặc định | Cấu hình trong app | — |

## B. 11 quyết định bạn phải chọn (nhà máy không trả lời được)

1. Đợt 1: chỉ **trạng thái từng bộ** hay theo dõi **từng công đoạn**? → *Đề xuất: trạng thái bộ; chi tiết công đoạn ở đợt 2.*
2. Màn hình chính: **kéo–thả** hay **bảng danh sách** theo ngày/tổ? → *Đề xuất: bảng danh sách trước.*
3. Tính tải theo **số bộ/tuần** hay **giờ công**? → *Đề xuất: số bộ/tuần (chưa có định mức giờ).*
4. Gom lô: app **tự xếp** hay chỉ **gợi ý + cảnh báo**? → *Đề xuất: gợi ý + cảnh báo.*
5. **Đăng nhập/phân quyền** làm ngay hay dùng chung 1 tài khoản? → *Đề xuất: chung trước, đăng nhập ngay sau (hiện ai có link cũng sửa được).*
6. Lưu **lịch sử sửa đổi** kế hoạch? → *Đề xuất: có, log đơn giản từ đợt 1.*
7. Nhập **đơn đang sản xuất dở** khi bắt đầu? → *Đề xuất: có, nếu không tuần đầu thiếu hàng thật.*
8. **Khóa kế hoạch đã chốt**? → *Đề xuất: không khóa, nhưng cảnh báo “đã chốt” + ghi log.*
9. Cần dùng trên **điện thoại**? → *Đề xuất: có, tối thiểu xem + cập nhật 1 chạm.*
10. Phiếu lệnh SX có cần **QR/mã vạch**? → *Đề xuất: chưa, in mã bộ cỡ lớn.*
11. Đo **thành công của module** sau 1 tháng bằng gì? → *Đề xuất: % trễ hạn · số bộ/tuần · thời gian chờ đủ đơn · số lần máy chờ chương trình.*

## C. 12 câu hỏi còn lỗ hổng (thêm vào phiếu khi đi hỏi)

P1 ai được **sửa/xóa kế hoạch đã chốt** + có lưu ai đổi gì · P2 **ai xác nhận một bộ hoàn thành** (tổ trưởng hay quản đốc) ·
P3 có cần **xem lại kế hoạch tuần trước** · P4 kế hoạch tuần **chốt vào ngày nào**, ai chốt ·
P5 hiện có bao nhiêu **đơn đang sản xuất dở** · P6 theo dõi **% tiến độ** hay chỉ **trạng thái** ·
P7 tổ có cần **xem kế hoạch tổ khác** · P8 có cần **trạng thái tạm dừng + lý do** ·
P9 trễ hạn thì app **tự đề xuất lại lịch** hay chỉ báo đỏ · P10 có cần **thông báo** (chuông/Zalo) và ai nhận ·
P11 báo cáo tính theo **bộ · m² · hay giá trị** · P12 có cần **in kế hoạch dán ở xưởng**.

## D. Ba con số KHÔNG thể dùng mặc định

1. **Năng lực mỗi tổ (bộ/tuần)** — thiếu thì app không cảnh báo được quá tải.
2. **Đơn vị thời gian** (giờ hay ngày làm việc) — thiếu thì sai toàn bộ ngày kết thúc dự kiến.
3. **Quy tắc “đầy đủ đơn”** — thiếu thì kế hoạch lệch một trong hai hướng (ảo hoặc tạo chờ vô ích).

Thiếu 3 con số này module **vẫn lập được kế hoạch** nhưng **mất phần lớn giá trị** (không cảnh báo, ngày dự kiến không đáng tin).

---

## Việc cần làm trước khi lập trình

1. Bạn chọn phương án cho **11 quyết định (mục B)** — không phản hồi thì mình dùng đúng đề xuất ở trên.
2. Bổ sung **12 câu (mục C)** vào phiếu — ưu tiên P1, P2, P4.
3. Nhà máy trả lời **6 câu chặn** (Phần A của V122).
4. Lấy **3 con số bắt buộc** ở mục D.
