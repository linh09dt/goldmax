# V143 — Khôi phục ngoại lệ “màu sơn 11 và 14 KHÔNG cần vân” (LK5)

## Lỗi đã xảy ra

| Bước | Chuyện gì |
|---|---|
| V136 | Công đoạn `VAN` có `skip_condition = 'PAINT_COLOR:11,14'` — đúng yêu cầu nhà máy (LK5: màu 11 & 14 không cần vân) |
| **V139** | Tách thành `VAN_CANH` / `VAN_KHUNG` / `VAN_PHAO` nhưng **không mang theo `skip_condition`** (để `NULL`), rồi **xoá** `VAN` cũ ⇒ **ngoại lệ bị mất**, mọi bộ đều phải làm vân |
| Ngoài ra | Đơn hàng ghi màu **kèm tiền tố** (`GM-11`, `GM-14`), còn điều kiện ghi theo số (`11`, `14`), mà app lại **so chuỗi tuyệt đối** ⇒ dù khôi phục cấu hình thì **vẫn không khớp** |

**Lỗi này do V139 gây ra** (đã kiểm chứng độc lập bằng cách so từng cột của danh mục cũ với danh mục mới —
xem mục “Kiểm chứng”). Đây là **ngoại lệ nghiệp vụ DUY NHẤT** khác giữa các model: tất cả các cửa còn lại
chạy **chung một quy trình** ⇒ **không cần thêm bảng routing**.

## Đã sửa

**1. Code** — `src/lib/production/catalog.ts`: thêm `paintColorMatches()`.
So **chính xác** trước, không khớp thì so **phần số**:
`GM-11` ↔ `11` ✔ · `gm-11` ↔ `11` ✔ · `GM-05` ✘ · `GM-111` ↔ `11` ✘ (khác số) · màu trống ✘.
Chỉ áp dụng cho `PAINT_COLOR`; điều kiện `MODEL` / `VENEER_CODE` vẫn so chính xác.

**2. Cấu hình + dữ liệu** — `migrate-production-v143-phuc-hoi-bo-qua-van.sql` (idempotent, không bảng tạm):
1. Đắp lại `skip_condition = 'PAINT_COLOR:11,14'` cho 3 công đoạn vân — **chỉ khi đang NULL**, không ghi đè nếu
   xưởng đã tự sửa ở Cấu hình sản xuất.
2. Sửa câu ghi chú sai ở V139 (“Tất cả các cửa đều đi qua công đoạn này.”).
3. **Sửa dữ liệu cũ**: công đoạn vân của bộ màu 11/14 đang “Chưa làm” → **Bỏ qua**.
   (Dòng đã **XONG** thì **giữ nguyên** — không xoá lịch sử đã làm.)
4. **Tính lại % và trạng thái** cho các bộ màu 11/14 — dùng **đúng công thức của app**
   (`percentDoneOf` + `deriveSetStatus`: bỏ qua dòng `BO_QUA` và khoảng `CHỜ`).

## Áp dụng

```bash
# 1) Deploy code (zip này) — bản sửa so màu
# 2) Chạy SQL (idempotent, không bảng tạm)
psql "<CHUỖI KẾT NỐI>" -f migrate-production-v143-phuc-hoi-bo-qua-van.sql
```

Hoặc dán cả file vào SQL Editor. Kiểm tra sau khi chạy: xem mục 5 cuối file SQL
(3 công đoạn vân đều có `PAINT_COLOR:11,14`; không còn công đoạn vân “Chưa làm” ở bộ màu 11/14).

Từ giờ **bộ mới** tự đúng: `buildTaskDrafts()` gọi `isStageSkippedForSet()` → 3 công đoạn vân của bộ màu
`11`/`14`/`GM-11`/`GM-14` được tạo thẳng ở trạng thái **Bỏ qua**, không tính vào % tiến độ.

## Kiểm chứng (`tmp-verify-v143.mjs` — đạt hết)

- **Audit danh mục (kiểm chứng độc lập của lỗi):** so **từng cột** của `CAT/CHAN/HAN/VAN` (danh mục cũ) với
  `*_CANH/_KHUNG/_PHAO` (danh mục V139). Kết quả: **các cột cấu hình khác giữ nguyên** (tổ, bước, thời lượng,
  gom lô, đổi khuôn, QC, làm lại…); `requires_stage` đổi là **chủ ý** (trỏ sang công đoạn cùng phần);
  **`skip_condition` là cột DUY NHẤT bị mất** — đúng lỗi này.
- **So màu:** 10 ca, gồm cả `GM-05`, `GM-111`, màu trống, điều kiện `MODEL` (phải so chính xác).
- **SQL:** chạy 2 lần (idempotent) → 3 công đoạn vân có điều kiện; bộ `GM-11` 3 dòng vân → `BO_QUA`, dòng khác
  không đụng; bộ `GM-14` dòng vân đã `XONG` **giữ nguyên**; bộ `GM-05` và bộ không ghi màu **không bị đụng**.
- **% và trạng thái sau khi chạy SQL khớp CHÍNH XÁC hàm TS** (`percentDoneOf`, `deriveSetStatus`) — dùng hàm
  thật của app làm oracle: bộ `GM-11` ra `50%` / `DANG_SX`, bộ `GM-05` ra `0%` / `CHO_XEP_LICH`.
- `tsc --noEmit` 0 lỗi · `eslint` vùng sản xuất 0 lỗi · `npm run build` OK.

## Lưu ý

- `production_sets.status` / `percent_done` của các bộ màu 11/14 được **SQL tính lại**; ngày
  **“Hoàn thành SX”** (`actual_completed_at`) không tự đóng — mở bộ và bấm **Lưu** là app đóng dấu.
- Nếu xưởng muốn đổi danh sách màu không cần vân: sửa ở **Cấu hình sản xuất → danh mục công đoạn → cột
  “Bỏ qua khi”** của `VAN_CANH`/`VAN_KHUNG`/`VAN_PHAO` (dạng `PAINT_COLOR:11,14`) — **không cần sửa code**.
  Từ V143, giá trị ghi theo **số màu** (`11,14`) là đủ, kể cả khi đơn ghi `GM-11`.
- **Không cần bảng routing**: mọi model cửa dùng chung quy trình; chỉ khác đúng 2 màu sơn này.
