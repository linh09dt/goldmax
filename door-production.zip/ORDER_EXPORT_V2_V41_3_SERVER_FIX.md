# V41.3 - Fix PDF V2 500 trên Vercel

- Sửa cách lấy font Roboto từ `fontpkg`: `fontpkg.path()` trả về đường dẫn file font, không phải thư mục.
- Thêm dependency lõi `fontpkg==0.1.0` bên cạnh `fontpkg-roboto==3.15`.
- Chuyển import `psycopg` và module ReportLab sang lazy import trong request để lỗi runtime trả JSON chi tiết thay vì trang 500 trắng.
- Không đổi dữ liệu đơn hàng, Excel V2, Supabase hay schema DB.
