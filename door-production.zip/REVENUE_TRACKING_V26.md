# ERP V26 — Theo dõi doanh thu

- Thêm tab `Theo dõi doanh thu` tại `/revenue`.
- Dữ liệu lấy trực tiếp từ đơn hàng hiện có, không tạo bảng database mới.
- Cột tổng hợp theo mẫu: STT, Ngày, Mã ĐL, Tên ĐL, Số ĐH, Loại ĐH, Tổng tiền, CK, Tổng tiền sau CK, Đặt cọc, Còn lại, Ghi chú.
- Ô CK hiển thị đồng thời `% chiết khấu của đơn` và `số tiền chiết khấu`.
- Dòng `Tổng` cộng: Tổng tiền, Tổng tiền CK, Tổng tiền sau CK, Đặt cọc, Còn lại.
- Mỗi đơn hiển thị ngay bên dưới toàn bộ sản phẩm/hàng hóa thực tế có trên đơn: tên sản phẩm, Model/Mã hàng, số lượng, ĐVT, KH/Lượng, đơn giá, thành tiền, ghi chú.
- Không lọc chi tiết theo KH/Lượng; mục tiêu tab này là xem tất cả sản phẩm có trên đơn.
- Loại đơn hiện hiển thị `Sản xuất` vì hệ thống hiện tại chỉ quản lý đơn sản xuất cửa.
- Không thay đổi schema PostgreSQL, không cần migrate.
