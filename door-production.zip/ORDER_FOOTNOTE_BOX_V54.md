# ORDER FOOTNOTE BOX V54

## Mục tiêu
Hoàn thiện **hộp ghi chú** ở góc dưới bên trái file xuất (V53):
1. **Có khung viền + nền nhạt nhạt** cho hộp ghi chú (trước đó chỉ là chữ trơn).
2. **In đậm** dòng “Khách hàng xác nhận các thông tin sau:”.

## Chi tiết
- Nền: `#F8FAFC` (xám-xanh rất nhạt) · Khung: `#C9D5E3`, nét mảnh 0.6pt (PDF) / border mảnh (Excel).
- Chữ vẫn nhỏ, màu xám `#6B7280` / `MUTED` → **không làm nổi bật**, chỉ là ghi chú.
- Dòng in đậm: “Ghi chú:” và “Khách hàng xác nhận các thông tin sau:”. Các dòng còn lại chữ thường.
- Hằng số tách riêng để dễ sửa: `FOOTNOTE_TITLE`, `FOOTNOTE_LEAD`, `FOOTNOTE_LINES` (+ `FOOTNOTE_FILL`, `FOOTNOTE_BORDER` ở Python).

## File sửa
1. `python/reportlab_order_v2.py` — `_footnote_block()` thêm `BACKGROUND` + `BOX` + padding 5/2.2; style mới `footnote_lead` (đậm).
2. `python/reportlab_order_preview.py` — import `FOOTNOTE_FILL/BORDER/LEAD` từ module V2 và dựng hộp tương tự.
3. `src/lib/order-export-v2.ts` — thêm `FOOTNOTE_LEAD` + `FOOTNOTE_FILL`; mỗi dòng ghi chú ghi vào ô đã merge `A→K`, sau đó `styleRange(A…:K…, FFF8FAFC, true)` để tô nền + kẻ khung cho cả hộp; đậm 2 dòng đầu.

## Kiểm chứng thực tế
- **Excel V2**: dựng file rồi đọc lại thuộc tính từng ô → 6 dòng ghi chú đều `fill = FFF8FAFC`, có border, font 8pt xám; 2 dòng đầu `bold = true`. Convert sang PDF bằng LibreOffice rồi trích text → đủ nguyên câu.
- **PDF V2**: render lại, ảnh cho thấy hộp nền xám nhạt có viền mảnh, dòng “Khách hàng xác nhận các thông tin sau:” đậm.
- `npx tsc --noEmit`: pass · `python -m py_compile`: OK.
