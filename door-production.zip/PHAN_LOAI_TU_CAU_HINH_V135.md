# V135 — Bỏ hard-code: phân loại hàng hóa tự cấu hình được trong tab Cấu hình

## Bạn phản hồi

> *"BẠN ĐANG HARD CODE, MÌNH MUỐN SỬA TÊN HOẶC THÊM BỚT LẠI KHÔNG ĐƯỢC"*

Đúng: bản V134 mình để 3 mục **Cấp cửa / Phụ kiện / Chi phí gia công** là hằng số trong code
(`ITEM_CATEGORY_SECTIONS` + 3 mã `DOOR/ACCESSORY/PROCESSING`), nên bạn không đổi tên, không thêm, không xoá được.

## Đã sửa (V135)

Phân loại hàng hóa nay là **bảng dữ liệu** `item_categories`, quản lý ngay trong tab Cấu hình.

### 1. Dữ liệu
Bảng mới `item_categories`:

| Cột | Ý nghĩa |
|---|---|
| `code` | Mã phân loại (không đổi khi đổi tên — hàng hóa lưu theo mã này) |
| `name` | Tên hiển thị — **sửa được tự do** |
| `usage` | `MAIN` = dùng làm **dòng chính / bộ cửa**; `DETAIL` = dùng làm **dòng phụ kiện / chi tiết** |
| `separate_group` | `true` = khi lập đơn, các nhóm hàng thuộc phân loại này nằm trong **optgroup riêng** (như "Chi phí gia công") |
| `sort_order` | Thứ tự hiển thị |
| `active` | Ngưng dùng = ẩn khỏi danh sách chọn, vẫn giữ phân loại cho hàng hóa cũ |

Migration `20260926220000_item_categories` tạo bảng + nạp đúng 3 phân loại đang dùng
(`DOOR/Cấp cửa/MAIN`, `ACCESSORY/Phụ kiện/DETAIL`, `PROCESSING/Chi phí gia công/DETAIL + nhóm riêng`)
⇒ sau khi chạy, app hoạt động y như trước, chỉ khác là **sửa được**.

### 2. Mục mới trong tab Cấu hình: **A3 — Phân loại hàng hóa**
- **+ Thêm phân loại**: nhập tên, chọn "Dùng cho" (Dòng chính bộ cửa / Dòng phụ kiện-chi tiết), bật/tắt "Nhóm riêng".
  Mã được sinh tự động từ tên (ví dụ "Kính" → `KINH`).
- **Đổi tên**: gõ tên mới → **Lưu**. Hàng hóa đã gán **giữ nguyên** vì hệ thống lưu theo mã.
- **Đổi cách dùng / thứ tự** ngay trên bảng.
- **Ngưng dùng / Dùng lại**: ẩn khỏi danh sách chọn nhưng không mất dữ liệu phân loại cũ.
- **Xoá**: nếu còn hàng hóa đang dùng, hệ thống **chặn** và yêu cầu chọn phân loại thay thế để chuyển hàng trước rồi mới xoá.
- Bảng hiển thị **số hàng hóa** của từng phân loại.

### 3. Các nơi đọc theo danh mục này (không còn hard-code)
- **A1 — Danh mục hàng hóa**: số khối = số phân loại bạn tạo; tên khối + ô "Phân loại" của từng dòng lấy theo bảng trên.
- **Form Tạo/Sửa đơn**: hàng hóa thuộc phân loại `MAIN` → ô **"Nhóm cửa"**; phân loại `DETAIL` → ô **"Nhóm hàng"**;
  phân loại bật **Nhóm riêng** → một `optgroup` riêng mang đúng tên phân loại đó.
- **Xuất Master Data**: cột PHÂN LOẠI in theo tên phân loại hiện tại.
- **Nạp Excel / Tạo lại Master Data**: hàng mới phân loại theo TENHANG (Cửa… → phân loại MAIN; có "gia công/chi phí/phụ phí/khoét" → phân loại nhóm riêng; còn lại → phụ kiện), **giữ phân loại cũ theo MODEL**.

### 4. API
`GET/POST /api/item-categories`, `PUT/DELETE /api/item-categories/[id]` (DELETE hỗ trợ `?moveTo=CODE`).
`GET /api/items` trả kèm `categories` để A1 và form tạo đơn dùng chung một nguồn.

## Kiểm chứng (chạy thật trên Chrome + Postgres cục bộ)

| Việc làm | Kết quả |
|---|---|
| Đổi tên "Cấp cửa" → **"Cửa"** | A3 hiện `DOOR=Cửa`; A1 đổi khối thành **CỬA** và ô chọn thành `Cửa / Phụ kiện / Chi phí gia công`; form tạo đơn vẫn đủ **7 nhóm cửa** (mã không đổi nên hàng hóa không bị lệch) |
| **Thêm** phân loại "Kính" (chi tiết + nhóm riêng) | Xuất hiện ngay ở A3 và trong ô "Phân loại" của A1; số hàng = 0 |
| **Chuyển hàng** sang phân loại mới | `Chi phí gia công 5→4`, `Kính 1` |
| Thêm "Song cửa" + chuyển hết nhóm hàng **Song Tròn** sang | Ô "Nhóm hàng" khi lập đơn có thêm **`[SONG CỬA] Song Tròn`**, và "Song Tròn" **không còn** trong danh sách thường |
| **Xoá** phân loại còn hàng | Bị chặn: *"Còn 1 hàng hóa đang ở phân loại Kính. Chọn phân loại thay thế để chuyển trước khi xoá."* → chọn nơi nhận → hàng được chuyển sang `Chi phí gia công` và phân loại được xoá |
| Dọn dẹp sau kiểm thử | Trả tên gốc + xoá 2 phân loại test ⇒ về đúng **Cấp cửa 52 / Phụ kiện 35 / Chi phí gia công 5** |
| 27 route của app | **27/27 HTTP 200**, log không có lỗi runtime |
| `tsc` / `eslint` / `next build` | 0 lỗi TS · không thêm lỗi lint · build **PASS** |

## Deploy

1. **Chạy migration trước**: `prisma/migrations/20260926220000_item_categories/migration.sql` (dán vào Supabase).
   Migration nạp sẵn 3 phân loại hiện có nên app chạy y như cũ ngay sau khi chạy.
2. Rồi mới đẩy code.

## File thay đổi

**Mới:** `src/lib/item-category-store.ts`, `src/components/item-categories.tsx`,
`src/app/api/item-categories/route.ts`, `src/app/api/item-categories/[id]/route.ts`,
`prisma/migrations/20260926220000_item_categories/migration.sql`

**Sửa:** `prisma/schema.prisma` (model `ItemCategory`), `src/lib/item-category.ts` (bỏ hằng số, đọc từ dữ liệu,
vẫn giữ 3 dòng mặc định làm dự phòng khi bảng trống), `src/components/settings/settings-tabs.ts` (+ tab A3),
`src/components/settings/settings-workspace.tsx`, `src/components/item-master.tsx`, `src/components/order-form.tsx`,
`src/app/api/items/route.ts`, `src/app/api/items/[id]/route.ts`, `src/app/api/items/export/route.ts`,
`src/app/api/items/import/route.ts`, `src/app/api/items/master/rebuild/route.ts`, `src/app/guide/page.tsx`,
`PHAN_LOAI_HANG_HOA_V134.md` (ghi chú V135)

## Ghi chú

- Phân loại **chưa** ảnh hưởng tiền, KH/Lượng, báo cáo, cước vận chuyển — chỉ đổi nơi hiển thị / chọn hàng hóa.
- Nếu bạn xoá hết phân loại `MAIN` thì ô "Nhóm cửa" sẽ trống (app không lỗi); thêm lại một phân loại "Dòng chính" là dùng được ngay.
- Muốn **đổi mã** phân loại (không chỉ tên) thì phải cập nhật cả `item_masters.category` — nói mình nếu cần, hiện giao diện cố ý không cho đổi mã để tránh lệch dữ liệu.
