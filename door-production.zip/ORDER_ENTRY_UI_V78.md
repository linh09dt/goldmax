# ORDER ENTRY UI V78

## Yêu cầu

Sau khi xem bản code V77, người dùng chốt: **UI phải giống mockup** đã duyệt —
cụ thể: **khung nền (nhãn) phải trải đúng bằng khung input**, và các ô nhập phải đẹp như mockup.
V78 **thay thế lựa chọn "giữ bộ cửa 1 hàng 17 ô" của V77 (phương án C)**.

## Đã sửa

### 1. Bộ cửa tách 2 nhóm có tiêu đề (đúng mockup)
- **NHẬN DIỆN SẢN PHẨM &amp; SỐ LƯỢNG** (9 ô): Bộ số · Nhóm cửa · Model · Ô thoáng · Hướng mở · Phào · Màu sơn · SL bộ · ĐVT.
- **KÍCH THƯỚC &amp; TÍNH GIÁ** (8 ô): Cao · Rộng · Khuôn · TT Cao · TT Rộng · KH/Lượng · Đơn giá · Thành tiền.
- Hai nhóm ngăn bằng đường kẻ đứt; mỗi nhóm có nhãn nhóm in hoa 9px + đường kẻ mảnh.
- Responsive: 2 cột (mobile) → 3 → 5 (lg) → 9 (xl) cho nhóm 1; 2 → 3 → 4 → 8 (xl) cho nhóm 2.
- **Đo thực tế ở 1280px: mỗi ô nhập 97px (nhóm 1) và 110px (nhóm 2)** — thay vì 34–84px của bản 1 hàng 17 ô.

### 2. Khung nền nhãn trải bằng đúng khung input
- `CardField` (bộ cửa + phụ kiện) và `Field` (thông tin đơn hàng): nhãn giờ là **thanh trải hết bề ngang ô**, cùng bề rộng với khung input bên dưới, cao 18px, nền `slate-100`, viền `slate-200`, chữ in hoa 9px, **cắt bằng dấu … và có tooltip** thay vì xuống dòng lộn xộn.
- Trước đây nhãn chỉ là "chip" nhỏ bằng đúng độ dài chữ nên nhìn lệch và rối so với khung input.
- **Kiểm chứng bằng đo trong trình duyệt: 100% nhãn có `labelWidth === inputWidth`** (thông tin đơn hàng 130px – riêng Địa chỉ nhận hàng 265px; bộ cửa 97px / 110px).

### 3. Ô nhập đồng bộ theo mockup
- Cùng cỡ chữ `11.5px`, cao 32px, bo 6px, viền `slate-300`, nền trắng, focus xanh cyan.
- Ô số căn phải + `tabular-nums`; ô Thành tiền nền xám nhạt chữ đậm; ô Bộ số chưa cấp hiện chữ nghiêng mờ **“Tự động”**.
- Bỏ mức phóng nhãn `xl:text-[10px]` ở khối thông tin đơn hàng để nhãn không còn bị cắt ở màn 1280.
- Nút thu gọn chuyển ra bên phải **“▾ Thu gọn / ▸ Mở rộng”** đúng như mockup (trước đó là ô vuông ▾/▸ bên trái).

### 4. Sửa lỗi JSX phát sinh giữa chừng
- Sửa thẻ `</div>` thừa ở tiêu đề bộ cửa sau khi đổi cấu trúc (bản V77 tạm lỗi cú pháp, đã `tsc` sạch lại).

## Giữ nguyên từ V77
- Thông tin đơn hàng 2 hàng; thu gọn/mở rộng từng bộ + Thu gọn/Mở rộng tất cả; phụ kiện không cuộn ngang; thanh lưu có tổng tiền; nút Xóa bộ cửa chặn khi còn 1 bộ + hỏi xác nhận khi đã có phụ kiện/ảnh; ngày mặc định theo giờ máy người dùng; quy tắc Bộ số V75.

## Kiểm chứng

- `npx tsc --noEmit`: 0 lỗi · `next build`: **Compiled successfully**.
- `npx eslint src/components/order-form.tsx`: 4 errors / 11 warnings — đúng bằng bản gốc, không phát sinh lỗi mới.
- Đo trong trình duyệt ở 1280×720: nhãn = khung input ở mọi ô; **0 nhãn bị cắt**; 0 vùng cuộn ngang; trang không tràn ngang.
- Ảnh chụp thật sau khi sửa: `ui-sau-1280.png`.

## Không thay đổi

- Không đổi logic tính tiền, KH/Lượng, API, Prisma schema, `.env`, in PDF/Excel. Không cần migrate.

## File thay đổi

- `src/components/order-form.tsx`
