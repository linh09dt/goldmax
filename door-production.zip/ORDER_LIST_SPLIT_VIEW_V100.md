# V100 — Triển khai Phương án B: màn Quản lý đơn hàng chia 2 cột

## Yêu cầu

> “làm B cho mình” *(Phương án B trong `ORDER_LIST_UI_OPTIONS_V99.md`: danh sách bên trái · chi tiết đơn bên phải)*

## Đã làm

### 1. Bố cục mới (`/orders`)

- **Thanh lọc 1 hàng** (trên cùng): `Tìm nhanh` (mã đơn, khách hàng, SĐT, mã đại lý) · chip `Hôm nay / Tuần này / Tháng này / Quý / Năm` · `Từ ngày – Đến ngày` · `Đại lý` · `Khách hàng` · `Lọc` · `Xoá lọc` · `⤓ Xuất Excel danh sách`.
- **Cột trái (452px) — danh sách đơn**:
  - 3 tab trạng thái kèm số lượng: `Tất cả · Đơn hàng mẫu · Sản xuất`.
  - 3 chỉ số nhanh: **Tổng đơn · Tổng tiền (rút gọn “1,28 tỷ”) · Quá hạn giao**.
  - Mỗi dòng: chấm màu trạng thái (xám = Đơn hàng mẫu, xanh = Sản xuất), mã đơn, khách + số bộ cửa + số km, ngày đặt, tổng tiền, và cảnh báo hạn giao (`Trễ N ngày` đỏ, `Còn N ngày` vàng, `Giao dd/mm`).
  - **Phân trang 20 đơn/trang** (thay vì tải toàn bộ đơn như trước).
  - Đơn đang xem được tô nền xanh + vạch trái.
- **Cột phải — chi tiết đơn đang chọn**:
  - Đầu trang: mã đơn (link sang trang chi tiết), nhãn trạng thái, ngày đặt, hạn giao, NVKD; nút **Sửa đơn · Xuất Excel · Xuất PDF · Xóa đơn**.
  - 4 ô thông tin nhận hàng: Khách hàng (mã ĐL), Người nhận + SĐT, Địa chỉ nhận, Số km / Vùng miền.
  - 4 ô tổng hợp: **Bộ cửa · Số lượng (+ số phụ kiện) · Tổng tiền hàng · Còn phải thu (kèm tiền cọc)**.
  - Bảng hàng hóa 13 cột (Mã hàng, Bộ số, SL, Cao, Rộng, Khuôn, Hướng mở, Màu sơn, KH/L, ĐVT, Đơn giá, Thành tiền, Ghi chú), dòng chính in đậm + dòng phụ kiện nền nhạt.
  - Chân trang: **In / Lưu PDF** · **Xem đầy đủ 23 cột** (sang trang chi tiết đơn).
- Màn < 1280px có thể cuộn dọc bình thường; cột phải nằm dưới cột trái (grid `xl:grid-cols-[452px_1fr]`).

### 2. Đổi hành vi & tối ưu kèm theo

| Việc | Trước | Sau |
|---|---|---|
| Tải dữ liệu | `findMany` **toàn bộ** đơn + toàn bộ dòng hàng mỗi lần mở | **phân trang 20 đơn**, danh sách chỉ lấy trường cần (+ đếm số bộ cửa) |
| Bộ lọc | 8 ô (Ngày/Tháng/Năm/Từ/Đến/Đại lý/Khách) | giữ nguyên khả năng lọc + **thêm tìm nhanh** + chip khoảng ngày + **lọc trạng thái** |
| Sắp xếp | không rõ | đơn **giao gần nhất lên đầu** (chưa đặt hạn nằm cuối), cùng ngày thì đơn mới trước |
| Danh sách đại lý/khách hàng | quét **toàn bộ** đơn để gom danh sách | 2 truy vấn `distinct` gọn |
| Bộ lọc trùng lặp | trang danh sách và route xuất Excel **tự parse riêng** | dùng **chung** `src/lib/order-list-filters.ts` → xuất Excel khớp đúng bộ lọc trên màn (kể cả tìm nhanh + trạng thái) |
| Ngày hiển thị | format theo giờ máy chủ → **lệch 1 ngày** (22/09 hiện 21/09) | format theo **UTC**, cảnh báo hạn giao cũng tính theo ngày UTC |

## Kiểm chứng

**a) Render thật 2 cột bằng React (SSR) với dữ liệu mẫu — 20/20 kiểm tra đúng:** 3 tab trạng thái kèm số lượng · 3 chỉ số nhanh · tổng tiền rút gọn · mỗi đơn là link có `orderId` · đơn đang chọn được tô nền · giữ bộ lọc khi đổi đơn · chip trạng thái reset về trang 1 · cảnh báo quá hạn · phân trang; cột phải: mã đơn + nhãn trạng thái · 4 ô nhận hàng · 4 ô tổng hợp · **đủ 13 cột** hàng hóa · dòng chính + phụ kiện · hiện Bộ số khi đơn ở Sản xuất · nút Sửa/Xuất/Xóa · lối xem 23 cột · nút In/Lưu PDF · ngày không lệch múi giờ · trạng thái rỗng khi chưa chọn đơn.

**b) Ảnh chụp từ chính code thật:** `order-list-B-implemented.png` — dựng HTML từ markup SSR của 2 component + **CSS Tailwind biên dịch từ dự án**, chụp bằng trình duyệt thật ở 1280px (chính ảnh này là cách mình phát hiện lỗi lệch ngày ở mục 2).

**c) `npm run build` của Next.js → PASS** (bảng route có `ƒ /orders` = dynamic, không lỗi biên dịch).

**d) `npx tsc --noEmit` → 0 lỗi. `npx eslint` 6 file → 0 errors, 0 warnings** (bằng bản gốc).

## Lưu ý

- Bảng **23 cột đầy đủ không bị mất**: vẫn ở trang chi tiết đơn (`/orders/[id]`) và trong **file Excel xuất danh sách** (nút “Xuất Excel danh sách” giờ lọc đúng như trên màn).
- Chọn đơn nằm ở **query `orderId`** nên link chia sẻ được (gửi link mở đúng đơn đang xem); bấm “Lọc” sẽ bỏ đơn đang chọn để về đơn đầu danh sách.
- Chưa làm: **Kanban · Lịch giao hàng · nút “▶ Sang Sản xuất”** ngay trên danh sách (là P1/P2 trong `ORDER_LIST_UI_OPTIONS_V99.md` — nói nếu bạn muốn làm tiếp).

## File thay đổi

- `src/app/orders/page.tsx` — viết lại theo bố cục 2 cột (thanh lọc + 2 pane + truy vấn phân trang).
- `src/components/order-list/order-list-pane.tsx` — **mới**: cột trái (tab trạng thái, chỉ số, danh sách, phân trang).
- `src/components/order-list/order-detail-pane.tsx` — **mới**: cột phải (chi tiết đơn + bảng hàng hóa 13 cột).
- `src/components/order-list/format.ts` — **mới**: định dạng ngày/tiền dùng chung (đã sửa lỗi lệch ngày UTC).
- `src/lib/order-list-filters.ts` — **mới**: bộ lọc dùng chung (tìm nhanh, trạng thái, khoảng ngày, phân trang, dựng query link).
- `src/app/api/orders/export-list/route.ts` — dùng chung bộ lọc + hỗ trợ `q`/`status`.
