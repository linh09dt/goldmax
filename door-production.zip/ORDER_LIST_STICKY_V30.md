# ERP V30 — Danh sách đơn hàng tinh gọn + cố định tiêu đề

- Xóa cột `Diễn giải`.
- Xóa cột `Ghi chú - lưu ý`.
- Bảng còn 31 cột, tự chia lại tỷ lệ full view.
- Cố định hàng tiêu đề của bảng khi cuộn trang xuống bằng `position: sticky` trên từng ô tiêu đề.
- Bỏ `overflow-hidden` ở wrapper của bảng để sticky header bám theo viewport thay vì bị giữ trong card.
- Không thay đổi dữ liệu đơn hàng, import Excel, KH/Lượng, giá, sửa/xóa hay export.
- Không thay đổi database schema.

## Cập nhật

```cmd
Ctrl + C
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần migrate database.
