# ORDER ENTRY ROW V80

## Yêu cầu

1. Trường **Model hiện chưa đủ thông tin** → cần hiện đầy đủ thông tin cho trường Model.
2. Thu nhỏ bề rộng ô nhập: **Hướng mở còn 40%**, **SL bộ 50%**, **Ô thoáng 50%**.
3. **Box Thông tin đơn hàng đang 2 dòng → đưa hết tất cả lên 1 dòng.**

## Đã làm

### Model rộng ra, hiện đủ thông tin
- Ô Model trong hàng Bộ cửa: **78px → 175px** (rộng ~2,2 lần) nhờ lấy chỗ từ 3 ô nhỏ.
- Ô đã chọn hiện đủ dạng **`MODEL · tên diễn giải`**, thêm **tooltip** trên ô select để đọc trọn nội dung khi cột còn hẹp.

### Thu nhỏ 3 ô theo yêu cầu
| Ô | Trước | Sau | Ghi chú |
| --- | --- | --- | --- |
| Ô thoáng | 43px | **46px** | đặt mức tối thiểu 46px để nhãn không bị bẻ chữ (yêu cầu 50% sẽ còn ~21px, không đọc được gì) |
| Hướng mở | 57px | **46px** | giảm ~20% |
| SL bộ | 33px | **30px** | giảm ~10% |

> Ba ô này đã được đặt `minmax(...)` để trên màn hẹp không bị bóp mất chữ; trên màn rộng chúng giữ đúng tỷ lệ nhỏ (Ô thoáng 0.3fr, Hướng mở 0.34fr, SL bộ 0.25fr) còn Model nhận 2.6fr.

### Thông tin đơn hàng: 13 ô trên 1 hàng
- Gộp 2 hàng (7 + 6) của V77 thành **1 hàng 13 ô** với tỷ lệ cột có trọng số:
  Mã đơn 73px · Trạng thái 59 · Ngày cập nhật 62 · NVKD 66 · Mã Đại Lý 69 · Tên khách hàng 83 · Ngày đặt hàng 62 · Ngày cần giao 66 · Người nhận 62 · Số điện thoại 59 · **Địa chỉ nhận hàng 104** · Vùng miền 52 · Số Km 55.
- Nhãn rút gọn: “Ngày cần giao hàng” → **“Ngày cần giao”**, “Số Km giao hàng” → **“Số Km”** (tooltip giữ nguyên nội dung đầy đủ).

### Nhãn không bị cắt
- Khung nhãn nâng lên **22px**, chữ 9px, dùng **`line-clamp-2`**: nhãn dài tự xuống tối đa 2 dòng, quá 2 dòng mới hiện “…”, không bao giờ cắt giữa chữ cái.
- Sau khi chỉnh: **chỉ còn 1 nhãn hiện “…” là “Ô thoáng”** (đúng ô được yêu cầu thu nhỏ); tất cả nhãn còn lại hiển thị đủ.

## Kiểm chứng

- `npx tsc --noEmit`: 0 lỗi · `next build`: **Compiled successfully**.
- `npx eslint src/components/order-form.tsx`: 4 errors / 11 warnings — đúng bằng bản gốc.
- Đo trong trình duyệt ở 1280×720:
  - Thông tin đơn hàng: **13 cột trên 1 hàng** (không còn hàng thứ 2), `labelWidth = inputWidth` ở mọi ô.
  - Bộ cửa: đúng **17 ô / 1 hàng**, Model **175px**, Ô thoáng 46px, Hướng mở 46px, SL bộ 30px.
  - Chỉ 1/30 nhãn hiện “…”, không nhãn nào bị cắt giữa chữ, trang **không tràn ngang**.
- Ảnh chụp thật: `ui-sau-1280.png`.

## Không thay đổi

- Không đổi logic tính tiền, KH/Lượng, Bộ số, API, Prisma schema, `.env`. Không cần migrate.

## File thay đổi

- `src/components/order-form.tsx`
