# V41.38 – Fix build lỗi `detail.clientId`

## Root cause
`OrderLineForm` không có thuộc tính `clientId`, nhưng UI V41.37 dùng `detail.clientId` làm React key cho danh sách phụ kiện.

## Sửa
- Không thay đổi model dữ liệu / DB / API.
- Không thêm `clientId` vào `OrderLineForm` để tránh ảnh hưởng dữ liệu lưu.
- Đổi React key sang key tổng hợp từ `item.clientId + detail.rowOrder + detailIndex`.

## File thay đổi
- `src/components/order-form.tsx`

## Giữ nguyên
- UI master-detail compact V41.37.
- Chỉ một phụ kiện mở tại một thời điểm.
- Logic giá, phụ kiện, ảnh, export và API.
