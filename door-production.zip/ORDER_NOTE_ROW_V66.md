# ORDER NOTE ROW V66

## Yêu cầu
File xuất: **bỏ cột "GHI CHÚ KỸ THUẬT"**. Hàng hóa nào có ghi chú thì **chèn ghi chú thành 1 hàng ngay dưới dòng đó** (trải hết chiều ngang bảng), rồi **cân chỉnh lại độ rộng các cột còn lại**. (Bản vẽ chỉ là ý tưởng — không cần khớp màu/lệch.)

## PDF V2 (`python/reportlab_order_v2.py`)
- Bảng dữ liệu 20 → **19 cột** (bỏ cột ghi chú, index 18).
- Dòng nào có `note` → thêm 1 hàng ngay sau dòng đó: `_item_note_flowable()` in
  `GHI CHÚ KỸ THUẬT: <nội dung>` (nhãn đậm), style `note` cho dòng chính / `detail` cho dòng phụ.
- Hàng ghi chú được `SPAN (0, r) → (-1, r)` (trải hết chiều ngang) + nền `#F8FAFC` để tách khỏi dòng hàng.
- Bề rộng cột: bỏ 39mm của cột ghi chú và chia lại cho các cột còn lại, **tổng vẫn = 273** nên bảng vẫn vừa `CONTENT_W`:
  `[5.5, 11, 31, 23, 9, 9, 9, 10, 10.5, 10.5, 10, 10, 10, 7, 8, 14, 21, 24, 40.5]`
  (TÊN SP +4, MODEL +2, HÌNH ẢNH SP 18→40.5 để bù phần trống còn lại, các cột số/kt +0.5→1).
- Dịch chỉ số padding của cột ảnh 18/19 → 17/18; SPAN header cột đơn `range(13, 20)` → `range(13, 19)`.

## Excel V2 (`src/lib/order-export-v2.ts`)
- 20 → **19 cột** (A→S): bỏ `S` (ghi chú), cột `T` (HÌNH ẢNH SP) dời về `S`.
- Hàng nào có ghi chú → `writeItemNoteRow()` chèn 1 hàng ngay dưới: merge `A:S`, chữ 9.5 italic,
  nền `#F8FAFC` + viền, chiều cao ước lượng theo độ dài (`≈190 ký tự/dòng`, tối thiểu 16).
- Bề rộng: `[4.5, 9, 27, 19, 7.5, 7.5, 7.5, 8.5, 8, 8, 8, 8, 8, 5.5, 6.5, 10.5, 12.5, 14, 14.5]`
  (tổng ≈ 194 ≈ tổng cũ 203 → cỡ chữ khi fit 1 trang gần như không đổi).
- Dọn theo: merge banner `M1:T2`/`M3:T3` → `M1:S2`/`M3:S3`; khối meta `P9:T9`/`P10:T10` → `P9:S9`/`P10:S10`;
  header bảng `A12:T13` → `A12:S13`; tổng kết `A:Q + R:T` → `A:P + Q:S`; hộp ghi chú & "Bằng chữ" `A:T` → `A:S`;
  `printArea` `A1:T` → `A1:S`; cột ảnh khi ghi dữ liệu `T{row}` → `S{row}` (anchor ảnh vẫn `col: 18.12` = cột S);
  căn lề `[3,4,19]` → `[3,4]` (19 giờ là cột ảnh); số dòng ước lượng của dòng hàng bỏ phần ghi chú
  (TÊN SP 22→28 ký tự/dòng, MODEL 18→22 vì cột rộng hơn).

## Kiểm chứng
- **PDF**: dựng đơn 2 bộ (có ghi chú ở dòng chính + dòng phụ + 1 ghi chú rất dài) → trích text: **28/28 hàng ghi chú** in ra ở đơn 14 bộ (4 trang), không mất ở chỗ ngắt trang; ghi chú dài **không bị cắt** (đủ 6/6 cụm "nội dung kiểm tra.").
- **Excel**: đọc lại workbook → header 19 cột **không còn "GHI CHÚ KỸ THUẬT"**; các hàng ghi chú nằm ngay dưới dòng hàng (r15/r17/r20/r22), merge `A:S`, chiều cao 16 (ngắn) / 25 (dài); tổng kết nhãn `A:P` + số tiền ở `Q`. Render qua LibreOffice: ghi chú dài không bị cắt (6/6 cụm).
- `npx tsc --noEmit`: 0 lỗi. `python -m py_compile`: OK.

## File thay đổi
- `python/reportlab_order_v2.py`
- `src/lib/order-export-v2.ts`

## Ghi chú
- `python/reportlab_order_preview.py` (bản preview trong app) **không có** cột "GHI CHÚ KỸ THUẬT" nên không phải sửa.
