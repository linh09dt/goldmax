# Door Production - Order Import V1

## Mẫu Excel đã dùng để thiết kế parser

Parser hiện bám theo mẫu `Đơn hàng.xlsx` đã cung cấp:

- C4: Mã khách hàng
- C5: Tên khách hàng
- C6: Mã NVKD
- I4: Mã đơn hàng
- I5: Ngày đặt hàng
- I6: Ngày cần giao
- V5: Số Km giao hàng
- Y5: Vùng miền
- V6: Nhóm
- AA1: Mã biểu mẫu
- AA2: Ngày hiệu lực biểu mẫu
- Dòng tiêu đề chi tiết: hàng 8-9
- Dòng cửa chính: nhận diện bằng STT ở cột A

Các dòng template có STT nhưng chưa có dữ liệu thực tế (Bộ số = 0, không có mã/model/kích thước/số lượng) sẽ bị bỏ qua.

Mỗi dòng cửa lưu thêm `rawBlock` của block Excel để giữ dữ liệu gốc phục vụ mở rộng logic sau này.

## Logic import

1. Mỗi file `.xlsx` = 1 Sales Order.
2. `orderCode` là khóa duy nhất.
3. File trùng hoàn toàn (SHA-256 + cùng orderCode) => bỏ qua.
4. Cùng `orderCode` nhưng file thay đổi => update header, xóa item snapshot cũ và tạo lại item từ file mới.
5. Mỗi lần tạo/cập nhật được ghi vào `order_imports`.
6. Có thể chọn nhiều file trên màn hình `/orders`.

## Cài code vào project hiện tại

Copy các file trong patch vào project rồi chạy:

```cmd
npm install
npm run db:migrate -- --name order_import_v1
npm run db:generate
npm run dev
```

Mở:

```text
http://localhost:3000/orders
```

## Chưa làm ở V1

- Chưa import hình ảnh nhúng trong Excel.
- Chưa chuẩn hóa riêng 14 dòng phụ/giá bên dưới từng cửa thành bảng component; dữ liệu này đã được giữ trong `rawBlock` để bổ sung sau mà không thay đổi logic chính.
