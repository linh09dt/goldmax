# V90 — Sửa lỗi “Cấu hình đang bị trùng: PR” khi cùng Model nhưng khác Bộ cửa chính

## Yêu cầu

> “Cấu hình đang bị trùng: PR. bị lỗi trùng Model, vì khác bộ cửa chính nên cho mình tạo khi khác bộ cửa chính”

## Nguyên nhân

Hàm kiểm tra trùng khi **lưu cấu hình** (`validateConfig` trong `src/app/api/calculation-config/route.ts`) tính khoá so trùng chỉ theo **phạm vi + Nhóm hàng/Model**, **không tính cột “Bộ cửa chính”** vừa thêm ở V89:

```
ITEM:<MODEL>      // mọi rule cùng Model đều bị coi là trùng
GROUP:<NHÓM HÀNG>
```

Vì vậy 2 rule `Phao Rời · PR · Cửa Đi 1 Cánh` và `Phao Rời · PR · Cửa Đi 2 Cánh` bị API chặn ngay khi bấm **Lưu cấu hình**, dù chúng áp cho 2 loại cửa khác nhau.

## Cách sửa

1. **Gom khoá so trùng về một chỗ** — thêm `calculationRuleKey()` trong `src/lib/calculation-config.ts`, khoá gồm:
   `phạm vi + Nhóm hàng/Model + nhóm hàng bộ cửa chính + model bộ cửa chính` (đã chuẩn hoá: bỏ dấu, không phân biệt hoa/thường, gộp khoảng trắng).
2. **Chuyển `validateConfig` từ API route vào lib** thành `validateCalculationConfig()` và cho nó dùng đúng khoá trên → không còn khả năng lệch quy tắc giữa lúc lưu (`validateCalculationConfig`) và lúc tạo cấu hình gợi ý (`dedupeRules`) vì cả hai dùng chung `calculationRuleKey()`.
3. **Thông báo lỗi rõ hơn**, có nêu bộ cửa chính để biết đang trùng với rule nào:
   `Cấu hình đang bị trùng: PR (bộ cửa chính: Cửa Sổ · CS-01) — đã có rule khác cùng phạm vi và cùng bộ cửa chính. Khác bộ cửa chính thì tạo được nhiều rule.`
   (thêm `calculationRuleLabel()` để dựng nhãn này)

## Kiểm chứng

**1. Không còn chặn sai (4/4 case lưu được):**

| Cấu hình | Trước | Sau |
|---|---|---|
| PR · Cửa Đi 1 Cánh + PR · Cửa Đi 2 Cánh | ❌ báo trùng | ✅ lưu được |
| 3 rule PR cho 3 loại cửa | ❌ | ✅ |
| PR · Cửa Đi 1 Cánh · model `CD1-01` + PR · cả nhóm `Cửa Đi 1 Cánh` | ❌ | ✅ |
| PR · mọi bộ cửa + PR · riêng Cửa Sổ | ❌ | ✅ |

**2. Vẫn chặn đúng khi trùng thật (7/7 case):** 2 rule PR cùng bộ cửa chính; cùng nhóm cửa; cùng nhóm cửa + cùng model cửa; khác hoa/thường và dấu (`PR - Phào mặt tròn` vs `pr - phao mat tron`) vẫn coi là trùng; 2 rule cùng nhóm hàng cùng bộ cửa; 2 rule Bộ cửa chính đang dùng. Rule đã bỏ tick **Dùng** không tính là trùng.

**3. Hồi quy (16/16 case đúng):** 5 công thức KH/Lượng (V88) tính lại đúng; khớp rule theo bộ cửa chính (V89) vẫn đúng; tích hợp qua code màn nhập đơn: phào rời của Cửa Đi 1 Cánh → `0.9`, của Cửa Sổ → `5.8`, của Cửa Đi 2 Cánh (không rule riêng) → `4.9`; cấu hình cũ (chưa có 2 field bộ cửa) mở lên vẫn hợp lệ và chạy như trước.

- `npx tsc --noEmit` → 0 lỗi. `npx eslint` 2 file sửa → 0 errors, 0 warnings.

## Lưu ý

- Không cần migration DB. Cấu hình hiện có không đổi.
- Sau khi áp gói này, các rule cùng Model cho các loại cửa khác nhau sẽ lưu được; muốn quay lại 1 rule dùng chung cho mọi cửa thì để cột **Bộ cửa chính** = “Mọi bộ cửa”.
- Vẫn giữ quy tắc **chỉ 1 rule Bộ cửa chính đang dùng** và **mỗi phạm vi 1 rule** cho cùng một bộ cửa chính.

## File thay đổi

- `src/lib/calculation-config.ts` — thêm `calculationRuleKey()`, `calculationRuleLabel()`, `validateCalculationConfig()`; `dedupeRules()` dùng chung khoá.
- `src/app/api/calculation-config/route.ts` — bỏ `validateConfig` cục bộ, gọi `validateCalculationConfig()` từ lib.
