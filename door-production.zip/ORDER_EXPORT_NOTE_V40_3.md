# V40.3 - Chú thích tùy chọn khi xuất đơn hàng

- Khi bấm Xuất Excel hoặc PDF, hiển thị hộp nhập chú thích.
- Nếu để trống, không tạo dòng chú thích trong file xuất.
- Nếu có nội dung, chèn một dòng chữ đỏ, đậm, căn giữa ngay trước phần tổng tiền.
- Áp dụng cho cả Excel và PDF.
- Không thay đổi dữ liệu đơn hàng và không cần migration.
