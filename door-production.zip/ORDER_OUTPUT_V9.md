# ERP V9 - Xuất đơn giống mẫu, PDF, CK 12%, lọc KH/Lượng

## Thay đổi
- Sửa nguyên nhân hydration phổ biến ở trang tạo đơn: dữ liệu mặc định được tạo phía server rồi truyền xuống Client Component.
- Excel xuất theo bố cục mẫu GOLDMAX: tiêu đề xanh, thông tin đơn, bảng 20 cột, tổng hợp và ghi chú xanh.
- Chỉ xuất dòng hàng hóa có KH/Lượng > 0.
- Chiết khấu cố định 12% trên Tổng đơn hàng.
- Thêm nút Xuất PDF: mở mẫu in A4 ngang và tự bật hộp thoại In / Save as PDF.
- Tổng tiền trên màn hình chi tiết cũng dùng cùng logic xuất để tránh lệch dữ liệu cũ.

## Cài đặt
Không đổi schema database, không cần migrate.

Sau khi chép patch:
1. Dừng `npm run dev`.
2. Xóa cache `.next` trên Windows: `rmdir /s /q .next`
3. Chạy lại: `npm run dev`

## Đường dẫn
- Excel: `/api/orders/[id]/export`
- PDF/In: `/orders/[id]/print?auto=1`
