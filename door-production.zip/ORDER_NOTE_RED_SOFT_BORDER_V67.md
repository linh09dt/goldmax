# ORDER NOTE RED + SOFT DETAIL BORDER V67

## Yêu cầu
1. Hàng **GHI CHÚ KỸ THUẬT** chuyển sang **chữ màu đỏ**.
2. **Độ nét đường kẻ bảng của các dòng phụ kiện chi tiết mờ 60%** so với đường kẻ dòng cửa.

## PDF V2 (`python/reportlab_order_v2.py`)
- Thêm hằng số: `NOTE_RED = #DC2626`, `BORDER_SOFT = #D7DADF`
  (đường kẻ thường `BORDER = #9CA3AF` cho nhạt đi 60%: 0x9C→0xD7, 0xA3→0xDA, 0xAF→0xDF).
- `_item_note_flowable()`: nhãn **và** nội dung ghi chú in bằng màu đỏ.
- `_soften_row_lines()`: vẽ lại toàn bộ đường kẻ của 1 hàng bằng `BORDER_SOFT` — `LINEABOVE`/`LINEBELOW`
  toàn bề ngang + `LINEBEFORE`/`LINEAFTER` cho từng cột (hàng ghi chú đã SPAN nên chỉ cần 2 mép).
  Áp dụng cho: các dòng phụ kiện chi tiết, **và** hàng ghi chú thuộc dòng phụ kiện
  (ghi chú của dòng cửa giữ đường kẻ thường).
- Đổi `note_row_numbers: list[int]` → `note_rows: list[tuple[int, bool]]` (kèm cờ main/detail).

## Excel V2 (`src/lib/order-export-v2.ts`)
- Thêm `BORDER_SOFT = #EDEEF1` (từ `BORDER = #D1D5DB` nhạt đi 60%: 0xD1→0xED, 0xD5→0xEE, 0xDB→0xF1),
  `ALL_BORDERS_SOFT`, `NOTE_RED = FFDC2626`.
- Dòng phụ kiện chi tiết (và hàng ghi chú của nó): dùng `ALL_BORDERS_SOFT`.
- Dòng cửa: đường kẻ thường; **riêng vạch dưới** mờ đi nếu bên dưới là khối phụ kiện chi tiết
  (để cả khối phụ kiện cùng mờ) — nếu dòng cửa có hàng ghi chú xen giữa thì vạch cửa↔ghi chú vẫn thường,
  và vạch ghi chú↔phụ kiện mới mờ.
- Hàng ghi chú: chữ đỏ; mép trên theo dòng cha (cửa = thường, phụ kiện = mờ), mép dưới mờ nếu bên dưới là phụ kiện.
- `writeDataRow()` thêm tham số `nextIsDetail`; vòng lặp tính cờ này theo `group.rows[index + 1]`.
- `styleRange()` nhận thêm tham số viền tuỳ chọn (mặc định như cũ) và `writeItemNoteRow()` nhận `main`, `nextIsDetail`.

## Kiểm chứng (đo pixel trên bản render)
| | Đường kẻ dòng cửa | Đường kẻ dòng phụ kiện | Mức mờ |
|---|---|---|---|
| PDF (render 2x) | độ xám min **165** | **214** | 54% nhạt hơn |
| Excel (LibreOffice render 3x) | độ xám min **214** | **239** | **61% nhạt hơn** |

- Chữ hàng ghi chú: PDF pixel đậm nhất `(239,183,184)` (đỏ) — Excel `(220,38,38)` = đúng `#DC2626`.
- Đối chiếu trong file Excel: dòng cửa viền `FFD1D5DB` (vạch dưới `FFD1D5DB` khi có ghi chú xen giữa),
  dòng phụ kiện/ghi chú phụ kiện viền `FFEDEEF1`, ô ghi chú font `FFDC2626`.
- Hàng ghi chú vẫn SPAN toàn ngang, không có vạch dọc bên trong.
- `npx tsc --noEmit`: 0 lỗi; eslint `order-export-v2.ts`: 7 lỗi `no-explicit-any` có sẵn từ bản gốc;
  `python -m py_compile`: OK.

## File thay đổi
- `python/reportlab_order_v2.py`
- `src/lib/order-export-v2.ts`

## Ghi chú
Mức mờ đang đặt **đúng 60% nhạt hơn** (độ đậm còn ~40%). Nếu bạn thấy mờ quá hoặc chưa đủ mờ thì chỉ cần đổi
`BORDER_SOFT` (PDF `#D7DADF`, Excel `EDEEF1`) sang sắc độ khác là xong.
