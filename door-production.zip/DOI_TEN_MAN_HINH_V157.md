# ĐỔI TÊN 2 MÀN SẢN XUẤT (V157) — hết lẫn nhau

## Trước → Sau

| | TÊN CŨ (dễ lẫn) | **TÊN MỚI** | Đường dẫn mới |
|---|---|---|---|
| 1 | ~~Kế hoạch theo công đoạn~~ | **Xếp lịch toàn xưởng** | `/ke-hoach-san-xuat/xep-lich-toan-xuong` |
| 2 | ~~Điều độ công đoạn~~ | **Xếp việc theo công đoạn** | `/ke-hoach-san-xuat/xep-viec-theo-cong-doan` |

**Lý do đổi:** hai tên cũ đều có chữ "công đoạn" nên nhìn menu không biết cái nào làm gì.
Tên mới nói rõ **PHẠM VI**:

- **Toàn xưởng** = một lượt cho **CẢ DÂY CHUYỀN** (mọi công đoạn một lần).
- **Theo công đoạn** = mỗi lần **MỘT công đoạn**, có hàng đợi và xác nhận.

Vẫn giữ nguyên chữ **"xếp"** ở cả hai để nhớ đây là chỗ **quyết định ngày**, khác với **"Kế hoạch sản xuất"**
(màn theo dõi tiến độ chung).

## Một câu để phân biệt

> **XẾP LỊCH TOÀN XƯỞNG** = *một lượt, cho hết cả dây chuyền* — trả lời câu hỏi **"cả xưởng có kịp hạn không?"**
> **XẾP VIỆC THEO CÔNG ĐOẠN** = *từng công đoạn, từng ngày* — trả lời câu hỏi **"hôm nay tổ này làm bộ nào?"**

## So sánh nhanh

| | **Xếp lịch toàn xưởng** | **Xếp việc theo công đoạn** |
|---|---|---|
| Phạm vi | Cả dây chuyền, **một lượt bấm** | **Một công đoạn** một lần |
| Bắt đầu từ | Danh sách **BỘ** (chờ xếp lịch…) | **Hàng đợi** của công đoạn đó (đã sắp theo tiêu chí ưu tiên) |
| Máy làm gì | Máy xếp **hết** | Máy **đề xuất** → bạn bấm **Xác nhận** |
| Sửa tay | Không | **Có** (thêm ＋ / bớt ✕ vào từng ngày) |
| Có cột "Mốc (target)" + kịp/trễ | **Có** | Không |
| Ghi vào DB | Ngày kế hoạch của **mọi công đoạn** | Ngày của **công đoạn đang chọn** + xoá công đoạn phía sau |
| Trả lời câu hỏi | "Cả xưởng có kịp hạn không? Nút thắt ở đâu?" | "Hôm nay tổ này làm bộ nào?" |

⚠️ **Nhớ**: hai màn ghi **cùng một chỗ** (`production_tasks.planned_start/planned_end`) ⇒ **cái chạy sau ghi đè cái chạy trước**.
Quy trình an toàn: **Xếp lịch toàn xưởng** trước → rồi dùng **Xếp việc theo công đoạn** để tinh chỉnh → **đừng bấm "Ghi kế hoạch vào hệ thống" lại** sau khi đã tinh chỉnh tay.

## Menu sau khi đổi

```
SẢN XUẤT
  Kế hoạch sản xuất          ← theo dõi tiến độ từng bộ (không xếp ngày)
  Xếp lịch toàn xưởng        ← ① xếp một lượt cho cả dây chuyền
  Xếp việc theo công đoạn    ← ② xếp chi tiết từng công đoạn, từng ngày
  Báo cáo theo tổ            ← màn hình xưởng cho công nhân bấm 1 chạm
  Cấu hình sản xuất
```

Hai màn xếp để **cạnh nhau** trong menu là có ý: nhìn liền nhau mới thấy khác nhau ở đâu.

## Đường dẫn cũ vẫn vào được

Bookmark/link cũ **không chết** — tự chuyển hướng (đã test thật, HTTP 307):

| Đường dẫn cũ | Chuyển tới |
|---|---|
| `/ke-hoach-san-xuat/ke-hoach-cong-doan` | `/ke-hoach-san-xuat/xep-lich-toan-xuong` |
| `/ke-hoach-san-xuat/dieu-do` | `/ke-hoach-san-xuat/xep-viec-theo-cong-doan` |

## Đã sửa trong mã nguồn

| File | Việc |
|---|---|
| `src/app/ke-hoach-san-xuat/xep-lich-toan-xuong/page.tsx` | tiêu đề + mô tả mới; nút sang màn "Xếp việc theo công đoạn" |
| `src/app/ke-hoach-san-xuat/xep-viec-theo-cong-doan/page.tsx` | tiêu đề + mô tả mới; nút sang màn "Xếp lịch toàn xưởng" |
| `src/app/ke-hoach-san-xuat/{ke-hoach-cong-doan,dieu-do}/page.tsx` | **chuyển hướng** đường dẫn cũ → mới |
| `src/components/erp-nav.tsx` | nhãn mới + **icon khác nhau** (biểu đồ / thùng) + đưa 2 màn nằm cạnh nhau |
| `src/app/ke-hoach-san-xuat/page.tsx` · `src/app/san-xuat/theo-to/page.tsx` · `priority-config.tsx` | cập nhật nút/link trỏ tới tên mới |

**Kiểm chứng**: `tsc` 0 lỗi · `eslint` 0 lỗi · `npm run build` ✓ · **chạy production thật**: 2 đường dẫn cũ trả **307** chuyển đúng, 3 màn mới trả **200** và hiện đúng tiêu đề.

---

## 9. RÀ SOÁT ẢNH HƯỞNG CỦA VIỆC ĐỔI TÊN (đã kiểm hết)

### 9.1 Những chỗ đã kiểm — không chỗ nào còn sót

| Chỗ có thể ảnh hưởng | Cách kiểm | Kết quả |
|---|---|---|
| Chuỗi đường dẫn cũ trong mã nguồn | quét `ke-hoach-cong-doan` + `/dieu-do` toàn repo (bỏ `node_modules`, `.next`) | **0 chỗ** trong `src/` (chỉ còn 2 trang chuyển hướng) |
| Nhãn cũ hiện trên giao diện | quét `"Điều độ công đoạn"`, `"Kế hoạch theo công đoạn"` trong `src/` | **0 chỗ** |
| Menu điều hướng (`erp-nav`) | nhãn + `href` + `isActive` của 5 mục nhóm "Sản xuất" | đã đổi; **thêm loại trừ đường dẫn CŨ** để lúc chuyển hướng không sáng nhầm mục "Kế hoạch sản xuất" |
| Nút/link ở các màn khác | quét mọi `href="/ke-hoach-san-xuat/*"` | 3 chỗ trỏ 2 màn này (`Bảng kế hoạch sản xuất`, `Báo cáo theo tổ`, `Cấu hình ưu tiên`) — **đã cập nhật** |
| `revalidatePath` / `router.push` / `redirect` | quét toàn `src/` | không có chỗ nào trỏ 2 màn này (không có server action phụ thuộc đường dẫn) |
| Tìm kiếm toàn cục (`global-search`) | đọc mã | chỉ tìm **đơn hàng · khách hàng · hàng hóa · mã đại lý** — **không index màn hình** ⇒ không ảnh hưởng |
| Trang chủ `/` và Trung tâm báo cáo `/reports` | quét link | không có link tới 2 màn này ⇒ không ảnh hưởng |
| `middleware` bảo vệ route | tìm file | **không có** middleware ⇒ không ảnh hưởng |
| `sitemap` / `robots` / `manifest` | tìm file | **không có** ⇒ không ảnh hưởng |
| Cấu hình trong DB (`system_settings`) | đọc 3 khoá đang có | chỉ có cấu hình tính giá · số bộ · **tiêu chí ưu tiên** — **không lưu đường dẫn màn hình** ⇒ không ảnh hưởng |
| API của module sản xuất | 6 route đều giữ nguyên tên | **không đổi gì** (đổi tên chỉ ở màn hình) |
| Test tự động trong `artifacts/verify/` | quét | các test gọi **hàm/service trực tiếp**, không gọi HTTP theo đường dẫn ⇒ không ảnh hưởng |
| Thư mục route cũ | liệt kê file | mỗi thư mục còn **đúng 1 file** `page.tsx` là trang chuyển hướng — không sót file phụ (`loading.tsx`, `layout.tsx`…) |

### 9.2 Smoke test chạy thật trên bản production

| Kiểm tra | Kết quả |
|---|---|
| `/ke-hoach-san-xuat/ke-hoach-cong-doan` | **307** → `/…/xep-lich-toan-xuong` ✓ |
| `/ke-hoach-san-xuat/dieu-do` | **307** → `/…/xep-viec-theo-cong-doan` ✓ |
| `/ke-hoach-san-xuat/xep-lich-toan-xuong` | **200**, tiêu đề "Xếp lịch toàn xưởng" ✓ |
| `/ke-hoach-san-xuat/xep-viec-theo-cong-doan` | **200**, tiêu đề "Xếp việc theo công đoạn" ✓ |
| 5 màn khác (`/ke-hoach-san-xuat`, `/san-xuat/theo-to`, `/reports/production`, `/cau-hinh`, `/in`) | **200** hết ✓ |
| API `team-report` · `plan-version` · `stage-board` (đúng tham số) | **200** hết ✓ |
| Menu HTML: có nhãn MỚI / còn nhãn CŨ | `Xếp lịch toàn xưởng` **có** · `Xếp việc theo công đoạn` **có** · 2 nhãn cũ **0** ✓ |
| Nút nhảy màn trong trang | trỏ đúng đường dẫn mới ✓ |

### 9.3 Hai điểm cần biết (không phải lỗi do đổi tên)

1. **Tài liệu cũ vẫn dùng tên cũ ở thân bài** — cố ý: chúng là bản ghi lịch sử của từng bản V148/V152/V153/V155/V156.
   Đã chèn ghi chú đổi tên ở **đầu mỗi tài liệu**; đường dẫn cũ trong tài liệu vẫn bấm được vì có chuyển hướng.
2. **Còn 32 lỗi `eslint` trong repo, nhưng ở MODULE ĐƠN HÀNG** (`order-output.ts`, `order-export.ts`,
   `master-options.tsx`, `item-master.tsx`, `calculation-config.tsx`, các trang `orders/*`) — toàn bộ là
   `no-explicit-any`, **có từ trước**, không liên quan việc đổi tên. Các file mình sửa: **0 lỗi `eslint`**.
