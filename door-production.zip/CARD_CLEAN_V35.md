# ERP V35 - Bỏ các card thống kê

Đã bỏ các card thống kê/KPI ở 3 tab:

- Quản lý đơn hàng: bỏ 4 card Tổng đơn hàng / Đơn nháp / Tổng số lượng bộ / Dòng có KH-Lượng.
- Danh mục hàng hóa: bỏ 6 card thống kê Master Data.
- Tính cước vận chuyển: bỏ 4 card Số Model / Cước toàn tuyến / Nhà máy hỗ trợ / Cước thu khách hàng.

Giữ nguyên bộ lọc, bảng dữ liệu, nút thao tác và toàn bộ logic nghiệp vụ hiện tại.
Không thay đổi database.
