-- ============================================================================
-- V136 — MODULE LÊN KẾ HOẠCH SẢN XUẤT
--
-- Nguồn nghiệp vụ: kết quả khảo sát nhà máy 2026-09-26 (222/230 câu) + tài liệu V136.
-- Đơn vị lên kế hoạch   = 1 BỘ CỬA              (production_sets)
-- Theo dõi tiến độ      = mức CÔNG ĐOẠN của bộ   (production_tasks)  ← yêu cầu KH22/L2/J5
--
-- AN TOÀN: toàn bộ là bảng MỚI, KHÔNG sửa bảng đơn hàng hiện có.
-- Chạy TRƯỚC khi deploy code (bài học V112: code trước DB → 500 toàn app, lỗi P2022).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) production_work_centers — tổ sản xuất / nguồn lực + năng lực thật
-- ----------------------------------------------------------------------------
CREATE TABLE "production_work_centers" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(40) NOT NULL,
    "name" VARCHAR(120) NOT NULL,
    "kind" VARCHAR(20) NOT NULL DEFAULT 'TO',
    "people_count" INTEGER,
    "shifts_per_day" INTEGER,
    "hours_per_shift" DOUBLE PRECISION,
    "capacity_per_day" DOUBLE PRECISION,
    "capacity_unit" VARCHAR(10) NOT NULL DEFAULT 'CANH',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "note" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_work_centers_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_work_centers_code_key" ON "production_work_centers"("code");
CREATE INDEX "production_work_centers_active_sort_order_idx" ON "production_work_centers"("active", "sort_order");

-- ----------------------------------------------------------------------------
-- 2) production_stages — danh mục CÔNG ĐOẠN (routing) — là dữ liệu, không hard-code
-- ----------------------------------------------------------------------------
CREATE TABLE "production_stages" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(40) NOT NULL,
    "name" VARCHAR(160) NOT NULL,
    "kind" VARCHAR(20) NOT NULL DEFAULT 'GIA_CONG',
    "scope_mode" VARCHAR(20) NOT NULL DEFAULT 'BO',
    "scope_parts" VARCHAR(60),
    "work_center_code" VARCHAR(40),
    "seq" INTEGER NOT NULL DEFAULT 0,
    "lead_time_hours" DOUBLE PRECISION,
    "setup_minutes" INTEGER,
    "capacity_per_day" DOUBLE PRECISION,
    "capacity_unit" VARCHAR(10) NOT NULL DEFAULT 'CANH',
    "batch_key" VARCHAR(30),
    "batch_min_qty" INTEGER,
    "changeover_max_per_day" INTEGER,
    "is_qc_point" BOOLEAN NOT NULL DEFAULT false,
    "rework_to_stage" VARCHAR(40),
    "skip_condition" VARCHAR(160),
    "requires_stage" VARCHAR(40),
    "active" BOOLEAN NOT NULL DEFAULT true,
    "note" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_stages_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_stages_code_key" ON "production_stages"("code");
CREATE INDEX "production_stages_active_seq_idx" ON "production_stages"("active", "seq");
CREATE INDEX "production_stages_work_center_code_idx" ON "production_stages"("work_center_code");

-- ----------------------------------------------------------------------------
-- 3) production_plans — kế hoạch tuần (KD + SX thống nhất, giám đốc nhà máy chốt)
-- ----------------------------------------------------------------------------
CREATE TABLE "production_plans" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(60) NOT NULL,
    "from_date" DATE NOT NULL,
    "to_date" DATE NOT NULL,
    "status" VARCHAR(20) NOT NULL DEFAULT 'NHAP',
    "created_by" VARCHAR(120),
    "approved_by" VARCHAR(120),
    "approved_at" TIMESTAMP(3),
    "note" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_plans_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_plans_code_key" ON "production_plans"("code");
CREATE INDEX "production_plans_from_date_idx" ON "production_plans"("from_date");

-- ----------------------------------------------------------------------------
-- 4) production_sets — 1 dòng = 1 BỘ CỬA (đơn vị lên kế hoạch)
-- ----------------------------------------------------------------------------
CREATE TABLE "production_sets" (
    "id" SERIAL NOT NULL,
    "order_id" INTEGER NOT NULL,
    "order_item_id" INTEGER,
    "order_code" VARCHAR(120),
    "set_no" VARCHAR(80),
    "order_type" VARCHAR(30) NOT NULL DEFAULT 'SAN_XUAT',
    "customer_name" VARCHAR(200),
    "product_name" TEXT,
    "model" VARCHAR(100),
    "opening_direction" VARCHAR(60),
    "paint_color" VARCHAR(100),
    "veneer_code" VARCHAR(100),
    "height_mm" INTEGER,
    "width_mm" INTEGER,
    "leaves_per_set" INTEGER,
    "trim_bars_per_set" INTEGER,
    "quantity" INTEGER,
    "pricing_quantity" DOUBLE PRECISION,
    "canh_equivalent" INTEGER NOT NULL DEFAULT 1,
    "due_date" DATE,
    "plan_id" INTEGER,
    "priority" INTEGER NOT NULL DEFAULT 5,
    "status" VARCHAR(30) NOT NULL DEFAULT 'CHO_XEP_LICH',
    "percent_done" INTEGER NOT NULL DEFAULT 0,
    "planned_start" DATE,
    "planned_end" DATE,
    "actual_completed_at" TIMESTAMP(3),
    "actual_delivered_at" TIMESTAMP(3),
    "program_ready" BOOLEAN NOT NULL DEFAULT false,
    "material_ready" BOOLEAN NOT NULL DEFAULT false,
    "pack_count" INTEGER,
    "note" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_sets_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_sets_order_item_id_key" ON "production_sets"("order_item_id");
CREATE INDEX "production_sets_status_due_date_idx" ON "production_sets"("status", "due_date");
CREATE INDEX "production_sets_plan_id_idx" ON "production_sets"("plan_id");
CREATE INDEX "production_sets_set_no_idx" ON "production_sets"("set_no");
CREATE INDEX "production_sets_order_id_idx" ON "production_sets"("order_id");

ALTER TABLE "production_sets"
    ADD CONSTRAINT "production_sets_plan_id_fkey"
    FOREIGN KEY ("plan_id") REFERENCES "production_plans"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- ----------------------------------------------------------------------------
-- 5) production_tasks — 1 dòng = 1 BỘ × 1 CÔNG ĐOẠN
-- ----------------------------------------------------------------------------
CREATE TABLE "production_tasks" (
    "id" SERIAL NOT NULL,
    "set_id" INTEGER NOT NULL,
    "order_item_id" INTEGER,
    "stage_code" VARCHAR(40) NOT NULL,
    "stage_kind" VARCHAR(20) NOT NULL DEFAULT 'GIA_CONG',
    "scope" VARCHAR(10) NOT NULL DEFAULT 'BO',
    "seq" INTEGER NOT NULL DEFAULT 0,
    "work_center_code" VARCHAR(40),
    "status" VARCHAR(20) NOT NULL DEFAULT 'CHUA_LAM',
    "qty_expected" DOUBLE PRECISION,
    "qty_done" DOUBLE PRECISION,
    "planned_start" DATE,
    "planned_end" DATE,
    "actual_start" TIMESTAMP(3),
    "actual_end" TIMESTAMP(3),
    "assignee" VARCHAR(120),
    "is_rework" BOOLEAN NOT NULL DEFAULT false,
    "rework_from_stage" VARCHAR(40),
    "reason_code" VARCHAR(40),
    "note" TEXT,
    "updated_by" VARCHAR(120),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_tasks_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_tasks_set_id_stage_code_scope_key" ON "production_tasks"("set_id", "stage_code", "scope");
CREATE INDEX "production_tasks_work_center_code_planned_start_idx" ON "production_tasks"("work_center_code", "planned_start");
CREATE INDEX "production_tasks_status_idx" ON "production_tasks"("status");
CREATE INDEX "production_tasks_planned_start_idx" ON "production_tasks"("planned_start");

ALTER TABLE "production_tasks"
    ADD CONSTRAINT "production_tasks_set_id_fkey"
    FOREIGN KEY ("set_id") REFERENCES "production_sets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ----------------------------------------------------------------------------
-- 6) production_reasons — lý do tạm dừng / trễ / máy dừng / lỗi
-- ----------------------------------------------------------------------------
CREATE TABLE "production_reasons" (
    "id" SERIAL NOT NULL,
    "code" VARCHAR(40) NOT NULL,
    "name" VARCHAR(160) NOT NULL,
    "group" VARCHAR(20) NOT NULL DEFAULT 'TAM_DUNG',
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_reasons_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_reasons_code_key" ON "production_reasons"("code");
CREATE INDEX "production_reasons_active_group_sort_order_idx" ON "production_reasons"("active", "group", "sort_order");

-- ----------------------------------------------------------------------------
-- 7) production_logs — lịch sử sửa kế hoạch (J1)
-- ----------------------------------------------------------------------------
CREATE TABLE "production_logs" (
    "id" SERIAL NOT NULL,
    "entity" VARCHAR(20) NOT NULL,
    "entity_id" INTEGER NOT NULL,
    "action" VARCHAR(40) NOT NULL,
    "field" VARCHAR(60),
    "old_value" TEXT,
    "new_value" TEXT,
    "by_name" VARCHAR(120),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "production_logs_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "production_logs_entity_entity_id_created_at_idx" ON "production_logs"("entity", "entity_id", "created_at");

-- ----------------------------------------------------------------------------
-- 8) production_programs — thư viện chương trình máy cắt theo model (L5)
-- ----------------------------------------------------------------------------
CREATE TABLE "production_programs" (
    "id" SERIAL NOT NULL,
    "model" VARCHAR(100) NOT NULL,
    "file_name" VARCHAR(255),
    "version" INTEGER NOT NULL DEFAULT 1,
    "machine" VARCHAR(120),
    "made_by" VARCHAR(120),
    "made_at" TIMESTAMP(3),
    "duration_minutes" INTEGER,
    "reusable" BOOLEAN NOT NULL DEFAULT true,
    "note" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_programs_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_programs_model_version_key" ON "production_programs"("model", "version");
CREATE INDEX "production_programs_model_idx" ON "production_programs"("model");

-- ----------------------------------------------------------------------------
-- 9) production_machine_downtimes — máy dừng + lý do (KH28)
-- ----------------------------------------------------------------------------
CREATE TABLE "production_machine_downtimes" (
    "id" SERIAL NOT NULL,
    "work_center_code" VARCHAR(40) NOT NULL,
    "machine" VARCHAR(120),
    "from_at" TIMESTAMP(3) NOT NULL,
    "to_at" TIMESTAMP(3),
    "reason_code" VARCHAR(40),
    "note" TEXT,
    "created_by" VARCHAR(120),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_machine_downtimes_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "production_machine_downtimes_work_center_code_from_at_idx" ON "production_machine_downtimes"("work_center_code", "from_at");

-- ----------------------------------------------------------------------------
-- 10) production_calendar — ngày nghỉ / lễ (A2: không tính Chủ nhật và ngày lễ)
-- ----------------------------------------------------------------------------
CREATE TABLE "production_calendar" (
    "id" SERIAL NOT NULL,
    "date" DATE NOT NULL,
    "is_working_day" BOOLEAN NOT NULL DEFAULT true,
    "note" VARCHAR(160),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "production_calendar_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "production_calendar_date_key" ON "production_calendar"("date");

-- ============================================================================
-- SEED DỮ LIỆU KHỞI TẠO (idempotent — chạy lại không nhân đôi)
-- Số liệu lấy nguyên từ khảo sát nhà máy, sửa được trong app ở Cấu hình sản xuất.
-- ============================================================================

-- 6 tổ + kỹ thuật + thuê ngoài
INSERT INTO "production_work_centers"
  ("code", "name", "kind", "people_count", "shifts_per_day", "hours_per_shift", "capacity_per_day", "capacity_unit", "sort_order", "note", "updated_at")
VALUES
  ('TO_MAY',      'Tổ máy (Cắt + Chấn)',                          'TO',               8, 2, 8, 60,   'CANH', 10, '2 máy CNC Lares Fiber × 2 người. Chấn 30 cánh/ca (CH7); 60 cánh/2 ca (TM3). Đổi khuôn 5 phút, tối đa 2 lần/ngày (CH4).', now()),
  ('TO_HAN',      'Tổ hàn (Hàn + Ép cánh + Test cơ khí)',          'TO',              12, NULL, 8, 45,  'CANH', 20, '8 máy MIG, 8 người; hàn 10 phút/cánh (HAN3). 1 máy ép: 45 phút/lượt, 9–12 cánh/lượt (EP2). Test 20 phút/bộ, 10 bộ/người/ngày (TC2/TC6). 45 cánh/ngày đã test đạt (TH3).', now()),
  ('TO_SON',      'Tổ sơn (sơn tĩnh điện, 1 lò)',                  'TO',             NULL, NULL, 8, 44,   'CANH', 30, 'NÚT THẮT: 1 mẻ 20–25 cánh (kèm khung), 2 mẻ/ngày = 40–50 cánh (SON2/SON3). Đổi màu 2 giờ (SON6); gom lô màu tối thiểu 20 cánh (SON7).', now()),
  ('TO_VAN',      'Tổ vân (dán film + buồng sấy)',                 'TO',              13, NULL, 8, NULL, 'CANH', 40, 'Dán tay, 13 người (VAN5). CHƯA CÓ SỐ năng lực (VAN12 chưa trả lời) → để trống, app không cảnh báo quá tải tổ này.', now()),
  ('TO_DONG_GOI', 'Tổ đóng gói (lắp kính + phụ kiện + vệ sinh)',   'TO',               8, NULL, 8, 50,   'CANH', 50, '8 người = 2 xịt giấy + 1 đi keo + 1 bắt phụ kiện + 4 đóng gói (LK10). Lắp kính+PK 20 phút/bộ (LK4). Đóng gói 4 phút/kiện, ~5 kiện/bộ (KHO2/KHO3).', now()),
  ('KHO',         'Kho / giao hàng',                               'TO',             NULL, NULL, 8, NULL, 'CANH', 60, 'Gọi xe ghép (GH3). Giao đủ cả bộ, không giao từng phần (B7/GH5). Hàng để quá 2 tháng tính tồn kho (GH9).', now()),
  ('KY_THUAT',    'Kỹ thuật (Thiết kế + Bồi Lares/CAM)',           'VAN_PHONG',      NULL, NULL, 8, 60,   'CANH', 70, 'Kỹ sư CAD làm tại nhà máy (TK3). 1 người 1 ca 8h bồi được 60 cánh (BL3). Bồi Lares CHẶN Cắt (BL4).', now()),
  ('NGOAI',       'Thuê ngoài (cắt kính, hàn khung)',              'NGUON_LUC_NGOAI', NULL, NULL, NULL, NULL, 'CANH', 80, 'Kính đặt ngoài ngay sau thiết kế (LK6). Có khi thuê hàn khung, gửi/nhận ≤ 3 ngày (J12).', now())
ON CONFLICT ("code") DO NOTHING;

-- 17 công đoạn: thứ tự thật theo khảo sát (khác bảng giấy 6 điểm — xem V136 mục 1.1)
INSERT INTO "production_stages"
  ("code", "name", "kind", "scope_mode", "scope_parts", "work_center_code", "seq", "lead_time_hours", "setup_minutes", "capacity_per_day", "capacity_unit", "batch_key", "batch_min_qty", "changeover_max_per_day", "is_qc_point", "rework_to_stage", "skip_condition", "requires_stage", "note", "updated_at")
VALUES
  ('THIET_KE',           'Thiết kế (bản vẽ CAD)',                              'CHUAN_BI', 'MODEL', NULL,                  'KY_THUAT',   10, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               NULL,        'Tùy model, nhiều phi tiêu chuẩn (TK2). Leader thiết kế duyệt (TK6). Đặt kính ngoài ngay sau bước này (LK6).', now()),
  ('BOI_LARES',          'Bồi Lares — nạp chương trình máy cắt (CAM)',          'CHUAN_BI', 'MODEL', NULL,                  'KY_THUAT',   20, 24, NULL, NULL, 'CANH', 'MODEL',    NULL, NULL, false, NULL,   NULL,               NULL,        'Hậu thiết kế (V121). Theo model, tái dùng được: model đã có chương trình ⇒ ~0. CHẶN Cắt (BL4).', now()),
  ('CHO_SAU_BOI_LARES',  'Chờ sau Bồi Lares mới cắt được',                      'CHO',      'BO',    NULL,                  NULL,         25, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'BOI_LARES', 'K16. Thực tế xưởng gối công đoạn 1 ngày (C6).', now()),
  ('CAT',                'Cắt (khung / cánh / phào)',                          'GIA_CONG', 'PARTS', 'KHUNG,CANH,PHAO',     'TO_MAY',     30, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'BOI_LARES', '2 máy CNC Lares Fiber × 2 người (C1). Ba phần làm song song (C2). KHÔNG kiểm tra sau cắt (C7).', now()),
  ('CHAN',               'Chấn (khung / cánh / phào)',                         'GIA_CONG', 'PARTS', 'KHUNG,CANH,PHAO',     'TO_MAY',     40, 24, 5,    30,   'CANH', 'MODEL',    NULL, 2,    false, NULL,   NULL,               'CAT',       'Máy 1: khung+phào; máy 2: cánh+phào (CH2). 30 cánh/ca (CH7). Đổi khuôn 5 phút, ngày chỉ đổi 2 lần (CH4). Có QC, lỗi phải làm lại (CH6).', now()),
  ('HAN',                'Hàn + mài ba via (khung / cánh / phào)',              'GIA_CONG', 'PARTS', 'KHUNG,CANH,PHAO',     'TO_HAN',     50, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'CHAN',      '8 máy MIG, 8 người, 10 phút/cánh (HAN1/HAN3). Ba phần làm ĐỘC LẬP, không cần đủ 3 phần (HAN5). Thợ hàn mài mối hàn luôn (HAN6).', now()),
  ('EP_CANH',            'Ép cánh (sau khi hàn cánh)',                         'GIA_CONG', 'PARTS', 'CANH',                'TO_HAN',     60, 24, NULL, 95,   'CANH', 'MODEL',    NULL, NULL, false, NULL,   NULL,               'HAN',       'SAU khi hàn cánh (EP4). 1 máy: 45 phút/lượt, 9–12 cánh/lượt; 8h ép được 90–100 cánh (EP2/EP7). Chờ keo khô 45 phút. Ép lỗi → phế, làm lại (EP6).', now()),
  ('TEST_CO_KHI',        'Test cơ khí (QC — lắp ghép kiểm tra trước sơn)',      'QC',       'BO',    NULL,                  'TO_HAN',     70, 48, NULL, NULL, 'CANH', NULL,       NULL, NULL, true,  'HAN',  NULL,               'HAN',       'Lắp ghép khung+cánh+phào kiểm tra trước sơn (TC1). Từng bộ, 20 phút/bộ, 10 bộ/người/ngày (TC2/TC6). Lỗi thường móp méo / hàn sai vị trí (TC4) → quay lại HÀN hoặc báo phế (TC5). Ghi lịch sử + chụp ảnh (TC3).', now()),
  ('CHO_TRUOC_SON',      'Chờ sơn (sau test cơ khí)',                           'CHO',      'BO',    NULL,                  NULL,         75, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'TEST_CO_KHI', 'TH2: chờ tối đa 24 giờ, có chỗ để.', now()),
  ('SON',                'Sơn (cả bộ 1 lượt — GATE: đủ 3 phần đã test)',        'GIA_CONG', 'BO',    NULL,                  'TO_SON',     80, 48, 120,  44,   'CANH', 'MAU_SON', 20,   2,    false, NULL,   NULL,               'TEST_CO_KHI', 'A1/CH5: bộ phải đủ khung+cánh+phào đã test mới sơn. Cả bộ sơn 1 lượt (SON4). 20–25 cánh/mẻ × 2 mẻ/ngày (SON2/SON3). Đổi màu 2 giờ (SON6), gom lô màu ≥ 20 cánh (SON7), ít hàng thì chờ ghép lô (SON8). Sơn hàng ngày (SON9).', now()),
  ('CHO_KHO_SAU_SON',    'Chờ khô / nguội sau sơn',                             'CHO',      'BO',    NULL,                  NULL,         85, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'SON',       'K14 CHƯA TRẢ LỜI — tạm để 24 giờ (mặc định, sửa được). SON11: sấy xong nguội mới dán vân được.', now()),
  ('VAN',                'Vân (dán film + sấy in chuyển nhiệt)',                'GIA_CONG', 'BO',    NULL,                  'TO_VAN',     90, 48, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, 'SON',  'PAINT_COLOR:11,14', 'SON',    'Dán film tay, buồng sấy riêng (VAN1/VAN5). Cần dán đủ hoàn chỉnh trước khi sấy (VAN2). KHÔNG cần gom lô (VAN6). Màu sơn 11 và 14 KHÔNG cần vân (LK5) → tự bỏ qua. Vân lỗi → tẩy sơn lại (VAN10).', now()),
  ('CHO_SAU_VAN',        'Chờ sau vân trước khi lắp kính / đóng gói',            'CHO',      'BO',    NULL,                  NULL,         95, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'VAN',       'K15: 24 giờ. VAN8: sau vân đem đi sấy in chuyển nhiệt.', now()),
  ('LAP_KINH',           'Lắp kính + phụ kiện',                                 'GIA_CONG', 'BO',    NULL,                  'TO_DONG_GOI',100, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'VAN',       'Do TỔ ĐÓNG GÓI làm (LK1) — không thuộc tổ vân. Gồm gioăng, silicon, nêm, nẹp, khoá, bản lề, tay nắm… (LK2/LK3). 20 phút/bộ (LK4). Kính đặt ngoài (LK6); thiếu kính thì bộ khác vẫn đẩy trước được (LK7).', now()),
  ('DONG_GOI',           'Vệ sinh + đóng gói (mốc HOÀN THÀNH SẢN XUẤT)',        'GIA_CONG', 'BO',    NULL,                  'TO_DONG_GOI',110, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'LAP_KINH',  'Xịt giấy dán film + lau chùi (KHO1). Đóng gói theo KIỆN, ~5 kiện/bộ (KHO3), 4 phút/kiện (KHO2). KHO5: đóng gói xong = HOÀN THÀNH SẢN XUẤT.', now()),
  ('KHO_GIAO',           'Kho / giao hàng (đã giao khách)',                     'GIA_CONG', 'BO',    NULL,                  'KHO',        120, 24, NULL, NULL, 'CANH', NULL,       NULL, NULL, false, NULL,   NULL,               'DONG_GOI',  'GH1: ghi ngày giao thực tế. GH2: hạn giao = ngày giao tới khách. Gọi xe ghép (GH3). Không lắp đặt tại công trình (GH6). Thu tiền khi giao (GH10).', now())
ON CONFLICT ("code") DO NOTHING;

-- Lý do tạm dừng / trễ / máy dừng / lỗi (KH13 · KH28 · L14 · J7)
INSERT INTO "production_reasons" ("code", "name", "group", "sort_order", "updated_at")
VALUES
  ('CHO_PHOI',        'Chờ phôi / chờ nhôm',                       'TAM_DUNG', 10, now()),
  ('CHO_CHUONG_TRINH','Chờ chương trình máy cắt (Bồi Lares)',      'TAM_DUNG', 20, now()),
  ('CHO_LO_SON',      'Chờ lô sơn (chưa đủ 20 cánh cùng màu)',     'TAM_DUNG', 30, now()),
  ('CHO_KINH_NGOAI',  'Chờ kính đặt ngoài',                        'TAM_DUNG', 40, now()),
  ('CHO_HAN_NGOAI',   'Chờ hàn thuê ngoài',                        'TAM_DUNG', 50, now()),
  ('KHACH_DOI',       'Khách đổi kích thước / màu / số lượng',     'TAM_DUNG', 60, now()),
  ('THIEU_NGUOI',     'Thiếu người',                               'TAM_DUNG', 70, now()),
  ('MAY_HONG',        'Máy hỏng / bảo trì',                        'MAY_DUNG', 80, now()),
  ('KHONG_DU_CHO',    'Hết chỗ để hàng chờ',                       'TAM_DUNG', 90, now()),
  ('TRE_CHO_PHOI',    'Trễ do chờ phôi',                           'TRE_HAN', 110, now()),
  ('TRE_QUA_TAI',     'Trễ do quá tải tổ',                         'TRE_HAN', 120, now()),
  ('TRE_NANG_SL',     'Trễ do nhận quá nhiều đơn',                 'TRE_HAN', 130, now()),
  ('TRE_KHACH_DOI',   'Trễ do khách đổi giữa lúc sản xuất',        'TRE_HAN', 140, now()),
  ('LOI_MOP_MEO',     'Lỗi móp méo',                               'LOI',     210, now()),
  ('LOI_HAN_SAI_VT',  'Lỗi hàn sai vị trí',                        'LOI',     220, now()),
  ('LOI_SON',         'Lỗi sơn (chảy / bụi / lệch màu)',           'LOI',     230, now()),
  ('LOI_VAN',         'Lỗi vân (bong / lệch / xước)',              'LOI',     240, now()),
  ('LOI_EP_CANH',     'Lỗi ép cánh (bọt khí / lệch / bong)',       'LOI',     250, now()),
  ('PHE_PHAI_LAM_LAI','Phế — phải làm lại',                        'LOI',     260, now())
ON CONFLICT ("code") DO NOTHING;
