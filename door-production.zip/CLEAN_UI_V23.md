# ERP V23 — Dọn giao diện, bỏ chú thích phụ

## Thay đổi

Đã rà soát các màn hình chính và xóa các đoạn chú thích/hướng dẫn tĩnh nằm bên dưới tiêu đề hoặc tiêu đề khu vực:

- Tổng quan
- Quản lý đơn hàng
- Tạo / Chỉnh sửa đơn hàng
- Chi tiết đơn hàng
- Danh mục hàng hóa
- Danh mục cấu hình
- Tính cước vận chuyển
- Khu vực nhập Excel

Đồng thời bỏ chú thích phụ ở sidebar.

## Giữ nguyên

Không xóa các nội dung nghiệp vụ cần thiết:

- Nhãn trường và tên cột
- Thông báo thành công / lỗi
- Cảnh báo trạng thái cần xử lý
- Kết quả import
- Dữ liệu tổng hợp / KPI
- Ghi chú thực tế của đơn hàng
- Empty state khi chưa có dữ liệu

Không thay đổi database, logic import Excel, Master Data, giá, chiết khấu, cước vận chuyển, xuất Excel/PDF hoặc dữ liệu đơn hàng.

## Cập nhật

Chép patch chồng lên bản hiện tại, sau đó:

```cmd
Ctrl + C
rmdir /s /q .next
npm run dev -- --webpack
```

Không cần `db:migrate`.
