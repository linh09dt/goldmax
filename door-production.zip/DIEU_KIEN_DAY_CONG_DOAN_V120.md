# V120 — Ghi chú "Cần đầy đủ đơn để đẩy công đoạn kế tiếp" hiểu thế nào

**Vị trí ghi chú:** dòng **CHẤN** của **TỔ MÁY** (chấn khung / chấn cánh / chấn phào), tức nói về **điều kiện để hàng đi từ CHẤN sang công đoạn kế tiếp là HÀN**.

Đây không phải một câu mô tả thời gian — nó là **quy tắc chuyển công đoạn (batching rule)**. Trong app, quy tắc này quyết định: *một bộ cửa được coi là “xong công đoạn chấn” khi nào, và ai/cái gì cho phép đẩy nó sang hàn.*

---

## 1. Ba cách hiểu — chữ “đơn” đang mơ hồ

| Cách hiểu | Nghĩa | Dấu hiệu nhận biết |
|---|---|---|
| **(1) Đủ BỘ PHẬN của 1 bộ** | Một bộ chỉ được chuyển sang hàn khi **cả 3 phần khung + cánh + phào đã chấn xong** | Đây là nghĩa kỹ thuật: hàn cần đủ 3 phần, đẩy lẻ 1 phần thì không hàn được thành bộ |
| **(2) Đủ CÁC BỘ trong 1 ĐƠN HÀNG** | Chỉ khi **toàn bộ các bộ trong đơn** đã chấn xong mới chuyển cả đơn sang hàn | Đúng chữ “đầy đủ **đơn**”; thường do muốn gom lô, đỡ đổi khuôn, dễ kiểm soát, hoặc hết chỗ để hàng chờ |
| **(3) Đủ LÔ theo model/màu** | Phải gom đủ số bộ cùng **model nhôm / màu** mới mở 1 lượt chấn để tối ưu khuôn | Thường đi kèm câu “chờ đủ lô mới chấn/sơn” |

**Mình nghiêng về (2)** vì trong bảng ghi đúng chữ “đầy đủ **đơn**”, nhưng **(1) là cách hiểu kỹ thuật rất hay gặp** và cũng có thể là điều xưởng muốn nói.
→ **Phải hỏi để chốt**, không nên tự suy. Câu hỏi đã có sẵn trong phiếu V118: **CH5** (mục 1.4) và **D3** (mục 7.3).

---

## 2. Vì sao phải chốt trước khi lập trình

Nếu hiểu sai, kế hoạch sẽ lệch theo một trong hai hướng — và cả hai đều tệ:

| Nếu app làm | Mà xưởng thật làm | Hậu quả |
|---|---|---|
| Cho **đẩy từng bộ** | **Đủ đơn mới đẩy** | Kế hoạch “ảo”: app báo sớm hơn thực tế → sale hứa hạn giao sai → trễ hạn |
| Bắt **đủ đơn mới đẩy** | Cho **đẩy từng bộ** | App tạo ra chờ vô ích: bộ xong vẫn không được xếp việc → năng lực bị bỏ phí |

---

## 3. Hệ quả lên cách xếp lịch

- **Nếu là (1) – đủ 3 phần của bộ:** xếp lịch theo **từng bộ**; app chỉ cần kiểm tra “bộ đã hàn được chưa” = đã có khung + cánh + phào sau chấn. Linh hoạt nhất, lead time ngắn nhất.
- **Nếu là (2) – đủ cả đơn:** giai đoạn **Chấn → Hàn** phải xếp theo **khối đơn hàng**. Kéo theo:
  - App cần trạng thái **“đang chờ đủ đơn”** cho từng bộ và **đo thời gian chờ** (thường đây là chỗ làm trễ hạn mà không ai nhìn thấy).
  - Một bộ thiếu (chưa có nhôm, khách đổi, cắt lỗi) sẽ **giữ chân cả đơn** → app phải **cảnh báo sớm** đúng bộ/bộ phận còn thiếu, chứ không chỉ báo “đơn chưa xong”.
  - Tổ máy có thể **bị chờ (idle)** dù vẫn còn đơn khác → năng lực thật bị giảm; nếu không mô hình hoá thì app sẽ báo “quá tải” sai.
- **Nếu là (3) – đủ lô:** gom lô theo **model nhôm** (chấn) và **màu sơn** (sơn) — cần thêm quy tắc “số bộ tối thiểu mỗi lô”.

---

## 4. Cách mình sẽ thiết kế để sau này đổi quy tắc mà không phải sửa code

Quy tắc chuyển công đoạn để **thành dữ liệu**, không hard-code:

```
stage_transition_rule
  tu_cong_doan   (vd: CHAN)
  den_cong_doan  (vd: HAN)
  pham_vi        BỘ_PHẬN | BỘ | ĐƠN | LÔ
  so_toi_thieu   (chỉ dùng cho LÔ)
  cho_phep_vuot  (có cho phép đẩy tay + ghi lý do?)
```

- **Mặc định ban đầu (theo V117 mục 10):** *cho phép đẩy từng bộ* + luôn kiểm tra “đủ 3 phần của bộ”.
- **Khi xưởng xác nhận “đủ đơn”:** bật `pham_vi = ĐƠN` cho cặp CHẤN→HÀN (và bất kỳ cặp công đoạn nào khác nếu có).
- App vẫn **hiện lý do đang chờ** (“chờ đủ đơn: còn 2 bộ chưa chấn”) — đây là thông tin quản đốc cần nhất.

---

## 5. Bốn câu hỏi để chốt (đã nằm trong phiếu V118)

1. “Đầy đủ đơn” là đủ **3 phần của 1 bộ** (khung + cánh + phào), hay đủ **tất cả các bộ trong đơn hàng**?
2. Nếu trong đơn có **1 bộ chưa chấn được** (thiếu nhôm / cắt lỗi / khách đổi), các bộ còn lại **có được chuyển sang hàn** không?
3. Quy tắc này áp dụng **chỉ ở Chấn → Hàn**, hay **mọi công đoạn**? (sơn có phải đủ lô màu không? vân có phải đủ lô mã vân không?)
4. **Lý do chính** của quy tắc là gì: đỡ đổi khuôn / dễ kiểm soát / không có chỗ để hàng chờ? (để biết có thể bỏ quy tắc này khi nâng cấp xưởng hay không)

---

## 6. Gợi ý cải tiến (nếu sau này nhà máy muốn rút ngắn thời gian)

Quy tắc “đủ cả đơn mới đẩy” thường là **cách chống thiếu chỗ để hàng + chống lẫn hàng** hơn là yêu cầu kỹ thuật thật. Hai thử nghiệm rẻ:

1. **Cho phép đẩy theo từng BỘ (đủ 3 phần)** với một khu vực riêng “hàng đã chấn xong, chờ hàn” có dán nhãn đơn/bộ → giảm chờ ở tổ máy.
2. Nếu lý do là **gom lô theo model nhôm**, thì chuyển sang quy tắc **(3) đủ lô theo model** thay vì “đủ cả đơn” — vừa tối ưu khuôn vừa không bắt cả đơn chờ 1 bộ.
