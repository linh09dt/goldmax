# ORDER NOTE AT GROUP END V68

## Yêu cầu
Di chuyển dòng **GHI CHÚ KỸ THUẬT** xuống **phía dòng cuối của bộ cửa** (in sau dòng phụ kiện chi tiết
cuối cùng của bộ đó), thay vì in ngay dưới dòng hàng chứa ghi chú.

## Cách làm

### PDF V2 (`python/reportlab_order_v2.py`)
- Trong vòng lặp bộ cửa: thay vì in ghi chú ngay, **gom** `pending_notes` (theo thứ tự dòng: dòng cửa trước,
  rồi các dòng phụ kiện) và chỉ in ra **sau khi hết các dòng hàng của bộ**.
- Bộ không có dòng phụ kiện nào → ghi chú vẫn nằm ngay dưới dòng cửa (không có gì để dời xuống).
- Bộ có nhiều ghi chú → mỗi ghi chú 1 hàng, in liền nhau ở cuối bộ (giữ nguyên nội dung từng ghi chú).
- `note_rows` đổi thành `list[tuple[int, bool, bool]]` = (chỉ số hàng, dòng chính?, nằm trong khối phụ kiện?).
  Hàng ghi chú nằm trong khối phụ kiện vẫn dùng đường kẻ mờ 60% (V67).
- **Thêm:** vạch dưới cùng của mỗi bộ cửa luôn vẽ lại bằng vạch thường (`BORDER`) → ranh giới giữa các bộ rõ ràng,
  không bị mờ lây khi hàng cuối bộ là hàng ghi chú/hàng phụ kiện.

### Excel V2 (`src/lib/order-export-v2.ts`)
- Vòng lặp bộ: gom `pendingNotes` rồi ghi các hàng ghi chú sau **dòng hàng cuối của bộ**.
- `writeDataRow()` thêm tham số `lastOfGroup`: vạch dưới của hàng cuối bộ luôn là viền thường (V67 + V68),
  các vạch còn lại của khối phụ kiện vẫn mờ 60%.
- `writeItemNoteRow()` nhận `groupHasDetail` + `isLastNote`: mép trên mờ nếu nằm trong khối phụ kiện,
  mép dưới của hàng ghi chú **cuối cùng** là viền thường (ranh giới bộ).
- Cờ `lastOfGroup` tính theo `index === group.rows.length - 1 && !groupHasNotes` — vì hàng cuối bộ thực tế
  là hàng ghi chú khi bộ có ghi chú.

## Kiểm chứng
Đơn test 2 bộ (bộ 1: dòng cửa có ghi chú + 2 phụ kiện, phụ kiện thứ 2 có ghi chú; bộ 2: dòng cửa + 1 phụ kiện có ghi chú).

- **PDF**: thứ tự in ra đúng — bộ 1: `Cửa Đi 1 Cánh` → `Phào mặt trong` → `Ô thoáng` → hàng ghi chú (cửa) → hàng ghi chú (phụ kiện);
  bộ 2: `Cửa Đi 4 Cánh` → `Phào Biệt Thự đứng 260` → `Khóa tay trúc GM805` → 2 hàng ghi chú.
  Đo pixel độ đậm vạch: vạch trong khối phụ kiện `min ≈ 211` (mờ), **vạch cuối bộ `min = 165` (thường)**.
- **Excel**: đọc lại workbook — bộ 1: r14 cửa, r15-r16 phụ kiện, **r17-r18 ghi chú**, r18 viền dưới `FFD1D5DB` (thường);
  bộ 2: r19 cửa, r20 phụ kiện, **r21 ghi chú**, viền dưới `FFD1D5DB`; các hàng trong khối phụ kiện dùng `FFEDEEF1` (mờ 60%);
  chữ hàng ghi chú `FFDC2626` (đỏ).
- `npx tsc --noEmit`: 0 lỗi. `npx eslint src/lib/order-export-v2.ts`: **7 lỗi `no-explicit-any` có sẵn từ bản gốc**
  (đã bỏ 2 chỗ `as any[]` tự thêm để không phát sinh lỗi mới). `python -m py_compile`: OK.

## File thay đổi
- `python/reportlab_order_v2.py`
- `src/lib/order-export-v2.ts`
