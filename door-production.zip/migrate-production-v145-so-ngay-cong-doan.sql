-- =============================================================================
-- V145 — CÔNG ĐOẠN DÙNG "SỐ NGÀY" THAY CHO "SỐ GIỜ"
--
-- Lý do: cột cũ `lead_time_hours` gây nhầm lẫn — muốn biết bao nhiêu ngày phải
-- chia cho "giờ-ngày" (số ca × giờ/ca, mặc định 2 × 8 = 16), nên 8 giờ và 16 giờ
-- đều ra 1 ngày. Xưởng chốt 26/09/2026: nhập thẳng SỐ NGÀY.
--
--   Công đoạn bước 10 bắt đầu NGÀY 1; nếu số ngày của bước đó là 2 thì
--   công đoạn bước 20 bắt đầu NGÀY 3 (bước sau nối tiếp bước trước).
--
-- File này:
--   1) Đổi tên cột  lead_time_hours → lead_time_days  (chỉ chạy 1 lần, tự bỏ qua nếu đã đổi).
--   2) Quy các giá trị CÒN LÀ GIỜ (≥ 8) về SỐ NGÀY đúng theo SỔ GIẤY xưởng (TỔNG 12 ngày).
--      Dòng đã nhập theo ngày (< 8) KHÔNG bị sửa ⇒ chạy lại file nhiều lần vẫn an toàn.
--
-- Chạy:  psql "<CHUỖI KẾT NỐI>" -f migrate-production-v145-so-ngay-cong-doan.sql
-- (Trên Supabase: dán cả file vào SQL Editor rồi Run.)
-- =============================================================================

-- 1) Đổi tên cột -----------------------------------------------------------------
DO $v145$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns
              WHERE table_schema = 'public' AND table_name = 'production_stages' AND column_name = 'lead_time_hours')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns
              WHERE table_schema = 'public' AND table_name = 'production_stages' AND column_name = 'lead_time_days') THEN
    ALTER TABLE "production_stages" RENAME COLUMN "lead_time_hours" TO "lead_time_days";
    RAISE NOTICE 'V145: đã đổi tên lead_time_hours -> lead_time_days.';
  ELSE
    RAISE NOTICE 'V145: cột lead_time_days đã có — bỏ qua bước đổi tên.';
  END IF;
END
$v145$;

-- 2) Quy giá trị còn là GIỜ (≥ 8) về SỐ NGÀY theo sổ giấy -------------------------
UPDATE "production_stages" AS s
SET "lead_time_days" = v.days,
    "updated_at"     = now()
FROM (VALUES
  ('THIET_KE', 1), ('BOI_LARES', 1), ('CHO_SAU_BOI_LARES', 0),
  ('CAT', 1), ('CAT_CANH', 1), ('CAT_KHUNG', 1), ('CAT_PHAO', 1),
  ('CHAN', 1), ('CHAN_CANH', 1), ('CHAN_KHUNG', 1), ('CHAN_PHAO', 1),
  ('HAN', 2), ('HAN_CANH', 2), ('HAN_KHUNG', 2), ('HAN_PHAO', 2),
  ('EP_CANH', 0), ('TEST_CO_KHI', 1), ('CHO_TRUOC_SON', 0),
  ('SON', 2), ('CHO_KHO_SAU_SON', 0),
  ('VAN', 2), ('VAN_CANH', 2), ('VAN_KHUNG', 2), ('VAN_PHAO', 2),
  ('CHO_SAU_VAN', 0), ('LAP_KINH', 0), ('DONG_GOI', 1), ('KHO_GIAO', 0)
) AS v(code, days)
WHERE s."code" = v.code
  AND COALESCE(s."lead_time_days", 0) >= 8;   -- ≥ 8 = còn là số GIỜ (đơn vị cũ). Số ngày thật luôn ≤ 5.

-- 3) Xem lại kết quả — đối chiếu SỔ GIẤY: tổng theo bước phải = 12 ngày làm việc ----
SELECT seq, code, name, lead_time_days AS so_ngay, active
FROM "production_stages"
ORDER BY seq, code;

SELECT sum(max_days) AS tong_ngay_theo_so_do
FROM (
  SELECT seq, max(COALESCE(lead_time_days, 0)) AS max_days
  FROM "production_stages"
  WHERE active
  GROUP BY seq
) s;

-- 4) Nếu muốn tự đặt lại số ngày cho từng công đoạn thì dùng mẫu này --------------
-- UPDATE "production_stages" SET lead_time_days = 2, updated_at = now() WHERE code = 'HAN_CANH';
