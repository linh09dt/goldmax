# V139 — TÁCH CÔNG ĐOẠN THEO PHẦN: CẮT · CHẤN · HÀN · VÂN × (KHUNG · CÁNH · PHÀO)

> ⚠️ **LỖI CỦA V139 — đã sửa ở V143:** khi tạo `VAN_CANH` / `VAN_KHUNG` / `VAN_PHAO`, bản này **không mang theo
> `skip_condition = 'PAINT_COLOR:11,14'`** của công đoạn `VAN` cũ rồi xoá `VAN` ⇒ **mất ngoại lệ “màu sơn 11 và 14
> không cần vân”**. Đã khôi phục bằng `migrate-production-v143-phuc-hoi-bo-qua-van.sql` — xem
> `PHUC_HOI_BO_QUA_VAN_V143.md`. (Audit từng cột cho thấy đây là cột DUY NHẤT bị mất.)


Nối tiếp V136 (module Kế hoạch sản xuất) và V136.1 (lệnh cha–con). Nhà máy yêu cầu:
**không để chung chung** — mỗi phần (cánh / khung / phào) phải có công đoạn cắt, chấn, hàn, vân **riêng**,
cấu hình riêng (tổ, giờ, setup, QC) và hiện rõ trên phiếu lệnh.

> ✅ **KHÔNG cần migration schema.** Dùng lại các cột sẵn có (`scope_mode`, `scope_parts`, `seq`).
> Chỉ có 1 file SQL dữ liệu: `migrate-production-v139-split-parts.sql`. Phải chạy **SAU khi deploy code**
> (code cũ không hiểu `scope_mode = 'PART'` sẽ hiểu nhầm thành `BO`).

---

## 1. Trước và sau

| | Trước (V136.1) | Sau (V139) |
|---|---|---|
| Danh mục | 1 dòng `CAT` "Cắt (khung / cánh / phào)" seed ra 3 dòng task theo `scope` | **12 dòng riêng**, mỗi phần 1 dòng |
| Cấu hình | Mọi phần dùng chung tổ / giờ / setup | **Sửa riêng từng dòng** ở Cấu hình sản xuất |
| Tên trên phiếu | "Cắt (khung / cánh / phào) (Cánh)" | **"Cắt cánh"** |

12 công đoạn mới (mã = `<THAO TÁC>_<PHẦN>`):

| Bước (seq) | Công đoạn | Mã | Tổ mặc định |
|---|---|---|---|
| 30 | Cắt cánh · Cắt khung · Cắt phào | `CAT_CANH` · `CAT_KHUNG` · `CAT_PHAO` | `TO_MAY` |
| 40 | Chấn cánh · Chấn khung · Chấn phào | `CHAN_CANH` · `CHAN_KHUNG` · `CHAN_PHAO` | `TO_MAY` |
| 50 | Hàn cánh · Hàn khung · Hàn phào | `HAN_CANH` · `HAN_KHUNG` · `HAN_PHAO` | `TO_HAN` |
| 90 | Vân cánh · Vân khung · Vân phào | `VAN_CANH` · `VAN_KHUNG` · `VAN_PHAO` | `TO_VAN` |

## 2. Cơ chế (giữ tương thích với lệnh cha–con)

- `production_stages`: `scope_mode = 'PART'`, `scope_parts = KHUNG | CANH | PHAO` (đúng 1 phần).
  `scopesOfStage()` trả về đúng 1 phần ⇒ mỗi công đoạn sinh **1 dòng** `production_tasks`, gắn đúng lệnh con.
- **Các công đoạn cùng bước (`seq`) chạy SONG SONG** trong cùng ngày, không nối tiếp nhau:
  - Xếp lịch (`auto-schedule.ts`) gom theo `seq` (thay vì theo `stageCode`); nếu các phần nằm ở tổ khác nhau thì tính năng lực cho từng tổ.
  - Đường găng (`setLeadHoursFromTasks`, `totalLeadTimeHours`) đếm mỗi bước 1 lần ⇒ **tổng thời gian không tăng** dù tách 3 dòng.
  - Load theo tổ (`buildWorkCenterLoad`) vốn đã đếm mỗi bộ 1 lần/tổ/ngày ⇒ không đổi.

## 3. Cổng điều kiện (`requires_stage`) đọc được NHIỀU mã

`taskUnlockState` nay tách `requires_stage` theo dấu phẩy và **bắt buộc TẤT CẢ** mã đã XONG:

| Công đoạn | Cần xong trước |
|---|---|
| `CAT_*` | `BOI_LARES` |
| `CHAN_CANH` / `CHAN_KHUNG` / `CHAN_PHAO` | `CAT_CANH` / `CAT_KHUNG` / `CAT_PHAO` |
| `HAN_*` | `CHAN_*` cùng phần |
| `EP_CANH` | `HAN_CANH` |
| `TEST_CO_KHI` (gộp) | `HAN_CANH,HAN_KHUNG,HAN_PHAO` |
| `VAN_*` | `SON` |
| `CHO_SAU_VAN`, `LAP_KINH` (gộp) | `VAN_CANH,VAN_KHUNG,VAN_PHAO` |

Lỗi ở `TEST_CO_KHI` quay lại đúng phần hàn: `rework_to_stage = HAN_CANH,HAN_KHUNG,HAN_PHAO`.

## 4. Migration dữ liệu — `migrate-production-v139-split-parts.sql`

1. Thêm 12 công đoạn mới (`ON CONFLICT (code) DO NOTHING`).
2. Cập nhật cổng `EP_CANH`, `TEST_CO_KHI`, `CHO_SAU_VAN`, `LAP_KINH`.
3. Chuyển task cũ: `stage_code = stage_code || '_' || scope` (giữ nguyên trạng thái / ngày thực tế / người / ghi chú);
   đổi `rework_from_stage = 'HAN'` → 3 phần hàn.
4. Xoá 4 dòng gộp cũ `CAT`, `CHAN`, `HAN`, `VAN`.

Idempotent — chạy lại vô hại. Dữ liệu hiện có (11 bộ × 12 dòng) đều có `scope` KHUNG/CANH/PHAO nên remap sạch.

**Thứ tự chạy:** deploy code (đã hiểu `scope_mode = 'PART'`) → chạy SQL. Bộ tạo mới sau đó tự nhận 12 công đoạn.
Bộ cũ không cần "sinh lại"; muốn chắc chắn thì bấm **Sinh lại công đoạn** ở trang bộ cửa (`action: "rebuild"`).

## 5. File thay đổi

| File | Việc |
|---|---|
| `src/lib/production/catalog.ts` | mã công đoạn mới `STAGE.CAT_* / CHAN_* / HAN_* / VAN_*`; bảng `PART_OPERATIONS` + `partStageCode()`; `taskUnlockState` đọc nhiều mã |
| `src/lib/production/routing.ts` | `scopesOfStage()` hiểu `scopeMode = 'PART'`; đường găng đếm theo `seq` |
| `src/lib/production/scheduling.ts` | `setLeadHoursFromTasks()` đếm theo `seq` |
| `src/lib/production/auto-schedule.ts` | gom theo `seq`, hỗ trợ nhiều tổ trong cùng bước |
| `src/components/production/production-config.tsx` | thêm lựa chọn Phạm vi "Một bộ phận" |
| `src/components/production/print-sheets.tsx` | danh sách việc theo ngày: không lặp "Cắt cánh (Cánh)" |
| `migrate-production-v139-split-parts.sql` | **mới** — migration dữ liệu |

## 6. Ghi chú vận hành

- Muốn **thuê ngoài hàn khung**: sửa dòng `HAN_KHUNG`, đổi Tổ từ `TO_HAN` sang `NGOAI` ở tab Công đoạn.
- Muốn **bỏ hàn phào** cho loại cửa nào đó: đặt `skip_condition` cho dòng `HAN_PHAO`, hoặc tắt `active` — app tự bỏ qua khi sinh công đoạn.
- Đổi **thứ tự / gối công đoạn**: sửa `seq`. Các dòng **cùng `seq` = cùng bước, chạy song song**; khác `seq` = nối tiếp.
