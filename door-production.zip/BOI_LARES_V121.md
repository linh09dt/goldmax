# V121 — "Bồi Lares" là gì (đã được nhà máy xác nhận) & ảnh hưởng thiết kế

**Nhà máy xác nhận (nguyên văn):** *"Bồi Lares là công đoạn hậu thiết kế, nó chuyển đổi file từ thiết kế sang máy cắt chuyên dụng."*

→ Vậy **Bồi Lares = bước chuyển đổi/kết xuất file thiết kế thành chương trình cho máy cắt chuyên dụng** (bản chất là **CAM / nạp chương trình gia công**), chứ **không phải** một công đoạn gia công tại xưởng như cắt – chấn – hàn – sơn.

---

## 1. Đính chính những gì mình đã suy đoán sai trước đó

| Trước đây mình đoán | Thực tế |
|---|---|
| "Lares là **film vân gỗ** → có thể trùng với bước Vân" (V116) | ❌ Sai. Không liên quan tới vân. |
| "Lares là **tấm lõi/cốt** → tương đương bước *ép cốt* của cửa thép" (V119) | ❌ Sai. Không phải vật liệu, không phải ép cốt. |
| "Bồi Lares là công đoạn **gia công** trong chuỗi (1 đơn vị thời gian)" | ⚠️ Đúng một nửa: nó **có thời lượng** nhưng là **bước CHUẨN BỊ (không gia công)** và nó **chặn** công đoạn sau. |

---

## 2. Vì sao đây là thông tin quan trọng nhất trong bảng công đoạn

Bồi Lares là **công đoạn dạng chuẩn bị (preparation/setup)**, khác hẳn mọi công đoạn còn lại ở 4 điểm:

1. **Không tỷ lệ theo số bộ** — làm 1 chương trình rồi thì cắt 1 bộ hay 50 bộ cũng dùng chương trình đó.
2. **Có thể tái sử dụng** — model đã từng làm thì chương trình đã có → thời gian ≈ 0 (chỉ sửa/nạp lại). Đây là lý do "Thiết kế = 1, Bồi Lares = 1" áp cho đơn đầu, còn đơn sau cùng model thì gần như miễn phí.
3. **Là điều kiện tiên quyết (prerequisite) của CẮT**: chưa có chương trình → máy cắt **không chạy được** → nếu chương trình chậm thì **máy cắt đứng chờ** (idle) chứ không phải "chờ hàng".
4. **Là công việc văn phòng/kỹ thuật**, không phải tổ thợ — nên **không được tính vào năng lực tổ máy**, mà là **một nguồn lực riêng** (1–2 người kỹ thuật).

Chuỗi thật vì thế là:

```
Thiết kế  →  Bồi Lares (kết xuất chương trình)  →  CẮT (máy chuyên dụng chạy chương trình)  →  Chấn → ...
   ↑ văn phòng/kỹ thuật ↑                    ↑ CHẶN: chưa có chương trình thì máy không chạy
```

---

## 3. Ảnh hưởng lên thiết kế module Lên kế hoạch

### 3.1. Phải phân loại công đoạn theo bản chất
```
production_stages.loai = GIA_CONG | CHUAN_BI
   GIA_CONG   : Cắt, Chấn, Hàn, Ép cánh, Sơn, Vân, Lắp kính+PK, Vệ sinh+Đóng gói  → tỉ lệ theo số bộ
   CHUAN_BI   : Thiết kế, Bồi Lares (CAM)                                        → theo FILE/model
```
Hệ quả khi tính tải: công đoạn `CHUAN_BI` **không nhân với số bộ**, và nếu chương trình/bản vẽ **đã có** thì thời lượng **= 0**.

### 3.2. Bồi Lares là "setup theo model", không phải theo đơn
- Trong 1 tuần có 5 model mới → 5 lần Bồi Lares. Cùng model → **1 lần**.
- Vì vậy khi gom lô theo model (câu C2/C3), app phải biết: **đây là lần đầu làm model này trong hệ thống hay không**.
- Cần **thư viện chương trình theo model**: đã có thì app tự điền thời gian 0 và chỉ hiện nhắc "nạp lại chương trình đã có".

### 3.3. Ràng buộc (prerequisite) giữa công đoạn — dùng đúng cơ chế `stage_transition_rule` ở V120
```
rule: BOI_LARES  →  CAT     kiểu = BAT_BUOC (bắt buộc có chương trình mới được cắt)
      THIET_KE   →  BOI_LARES  kiểu = BAT_BUOC
```
Nếu chưa có chương trình mà kế hoạch đã xếp lịch cắt → app **cảnh báo đỏ** (giống cảnh báo quá tải), chứ không im lặng xếp rồi để máy đứng chờ.

### 3.4. Hồ sơ chương trình (dữ liệu mới)
```
machine_programs
  id · model (model nhôm / mã hàng) · ten_file · phien_ban
  may_cat (máy chuyên dụng nào) · nguoi_lam · ngay_lam
  thoi_gian_lam (phút) · ghi_chu · file_dinh_kem
  dung_lai_duoc (Y/N)
```
Có bảng này thì: (a) lần sau không phải làm lại, (b) biết **model nào chưa có chương trình** để cảnh báo trước, (c) đổi kích thước/mẫu thì sửa **phiên bản mới** và biết mất bao lâu.

### 3.5. Nguồn lực riêng, có thể thành nút thắt mới
Nếu chỉ 1–2 người kỹ thuật làm CAM cho **tất cả** đơn thì đây là **work center riêng** (`KỸ THUẬT/CAM`) với năng lực riêng (số chương trình/ngày). Cao điểm nhiều model mới → nút thắt nằm ở **đây**, không nằm ở tổ máy — điều mà nhìn bảng công đoạn hiện tại không thấy được.

---

## 4. Tám câu cần xác nhận thêm (đã thay vào phiếu V118, mục 1.2 – BL1…BL8)

| # | Câu hỏi | Vì sao cần |
|---|---|---|
| BL1 | Chương trình làm **theo model nhôm** hay **theo từng bộ/kích thước**? | Nếu theo model → **1 chương trình cho nhiều bộ** → tải tính theo model, không theo bộ |
| BL2 | Ai làm (kỹ thuật/văn phòng hay tại máy)? | Xác định đây là work center riêng hay nằm trong tổ máy |
| BL3 | **Chương trình mới** mất bao lâu? **Chương trình đã có** thì nạp lại/sửa mất bao lâu? | Hai con số khác nhau — app cần cả hai |
| BL4 | Máy cắt có **đứng chờ chương trình** bao giờ chưa? | Đo mức độ rủi ro của ràng buộc bắt buộc |
| BL5 | Chương trình **lưu ở đâu**, đặt tên theo gì? Khách đổi thì có phiên bản mới không? | Để dựng thư viện chương trình trong app |
| BL6 | Có **mấy máy cắt chuyên dụng**, model gì, đọc định dạng nào? | Năng lực cắt thật + biết chương trình phải khớp máy |
| BL7 | Có **chạy thử / cắt mẫu** trước khi cắt hàng loạt không? Mất bao lâu? | Nếu có → thêm 1 bước & 1 khoản thời gian |
| BL8 | Khách đổi kích thước/mẫu giữa lúc đang làm thì **sửa chương trình** mất bao lâu? | Thời gian phát sinh khi có thay đổi |

---

## 5. Việc cần sửa trong tài liệu trước (đã sửa)

- **V116** (đánh giá bảng công đoạn): bỏ giả thuyết "Lares là film vân/tấm lõi", thay bằng "công đoạn chuẩn bị – CAM"; bổ sung cột **Loại công đoạn (GIA_CONG / CHUAN_BI)** vào bảng cần điền.
- **V118** (phiếu câu hỏi): mục 1.2 đổi tiêu đề thành **"Bồi Lares (nạp chương trình cho máy cắt chuyên dụng)"** và thay 8 câu hỏi mới; mục 8 (dữ liệu app sẽ thêm) bổ sung dòng **"Chương trình máy cắt theo model"**; mục 0 bổ sung nhóm **"Hồ sơ chương trình máy (app chưa có)"**.
- **V119** (đánh giá video cửa thép): đính chính dòng so sánh "Bồi Lares ≈ ép cốt" — không đúng, hai thứ khác bản chất.
