# V41.33 – Xóa hàng 4 Thông tin đơn hàng

## Thay đổi
Xóa khỏi giao diện tạo/sửa đơn hàng 3 trường ở hàng 4:
- Nhóm
- Mã biểu mẫu
- Ngày hiệu lực

## Validation
Ba trường trên không còn là trường bắt buộc ở cả frontend và server.
Các trường Thông tin đơn hàng còn hiển thị vẫn giữ validation bắt buộc như hiện tại.

## Dữ liệu cũ
- Không xóa cột DB.
- Đơn hàng cũ vẫn giữ dữ liệu đã lưu.
- Payload cũ vẫn tương thích; nếu có Nhóm / Mã biểu mẫu / Ngày hiệu lực thì server vẫn tiếp nhận, nhưng không bắt buộc.

## File sửa
- `src/components/order-form.tsx`
- `src/lib/order-persistence.ts`
